# Project execution rules

All future work in this tree must first read:

1. `PS_PsoGS_Codex_Project_Master_Prompt.md` (authoritative master charter)
2. `PROJECT_CHARTER.md`
3. `STATUS.md` and `NEXT_STEPS.md`
4. the relevant rows in `metadata/dataset_manifest.tsv` and `panel_manifest.tsv`

Do not overwrite existing results or repeat completed stages. Preserve raw inputs as read-only caches, record provenance/checksums, and separate calculation from plotting. Use only the status vocabulary defined in the master charter.

Before running validation data, verify F1 exists and predates access to validation expression results. Before focused mechanism work verify F2. Before perturbational ranking verify F3. If a dependency is absent, mark the module `BLOCKED` or `SKIPPED`; do not relax the design to obtain a positive result.

Every completed stage must update `STATUS.md`, `NEXT_STEPS.md`, relevant machine-readable manifests, a Chinese factual summary, and an evidence-bounded English Methods/Results draft. Plans must never be written as completed findings.

Every figure panel must follow `panel_manifest.tsv` and retain source data, statistics, config, analysis code, plotting code, vector output, preview output, caption and render/data QA. Never fabricate experimental or spatial imagery.
