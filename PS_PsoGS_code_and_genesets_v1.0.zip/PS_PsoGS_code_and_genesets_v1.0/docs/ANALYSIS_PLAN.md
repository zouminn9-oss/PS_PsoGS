# ANALYSIS PLAN

## 总体顺序

分析按门禁推进，不并行启动所有高成本模块：Stage 00 → 01 → 02/F1 → 03 → 04/F2 → 05 → 06 → 07 → 08/F3。每阶段必须更新 `STATUS.md`、机器可读清单、实际结果、失败原因、不确定性与下一步。

## 数据隔离

| 层级 | 数据 | 允许用途 | 禁止用途 |
|---|---|---|---|
| PS-Reference | CTRA；GSE70603；经审计的 GSE270712/713、GSE26487 | 应激证据分层、候选注释 | 将全部来源合成无分层“应激分数” |
| 开发集 | GSE212126 + GSE13355 | Core/Interaction/SEP 的成员与方向 | 使用 GSE30999/GSE121212 调成员或阈值 |
| 锁定 bulk 验证 | GSE30999 + GSE121212 | F1 后复现、特异性和敏感性 | 反向进入开发流程 |
| 单细胞发现 | GSE173706 | 定位、供者级效应、F2 候选 | 把 cell 当重复 |
| 单细胞复现 | GSE162183 | 独立 pseudobulk 方向复现 | 用其重新定义 F1 |
| 空间语境 | GSE225475 | file-level QC 后的描述性定位、deconvolution 和 module score；frozen/FFPE 分层 | 称作 GSE173706 的独立复现，或在来源质量门禁未通过时运行邻近/共定位 |
| 治疗 | GSE228421；GSE117468 | 先治疗重塑，后条件性预测 | 用 n=5 已清除患者训练一般响应模型 |

## 阶段门禁

### Stage 00 — 环境、文献与可行性审计（终态 `COMPLETED_WITH_DOCUMENTED_HOLDS`）

完成目录/环境、13个GEO系列与1,381条sample元数据、工作簿内容、CTRA固定表、设计矛盾、签名规则、PS-Reference分层和90面板台账。全项目清单已同步至Stage 08并通过71项完整性检查。GSE212126来源证明、GSE270712冲突标签与GSE30999四对缺失映射保留为显式HOLD；在没有新增来源材料时不再视为待执行计算。

### Stage 01 — 独立心理应激资源

1. `COMPLETED`：固定 CTRA 原始符号及 HGNC 映射版本。
2. `COMPLETED`：对 GSE70603 完成被试内 `+45 vs -45`、`+180 vs -45` 分析、HGNC 审计、证据台账和质控图；时间效应不解释为有未应激对照的纯压力效应。
3. `COMPLETED`：GSE212126/270712/270713、GSE26487 和三个 QuickGO exact terms 已按“实际应激 / 固定签名 / 神经内分泌代理 / 药理代理 / 功能注释”分层冻结。

通过条件：每个来源的真实设计、统计单位、允许用途、成员规则和限制均冻结；只有实际执行表达差异时才另行冻结批次、协变量和多重检验族。Stage 01 已为 `PASS`，但该状态不解除 GSE212126 的 Stage 02 门禁。

### Stage 02 — 析因与签名（当前 `PASS`；鼠侧析因、人体H模型、orthology与F1均已冻结）

GSE212126 的独立动物与无混池门禁已由项目所有者确认通过；12/12 SRA、配对FASTQ与BAM完成审计，GENCODE M25下的55,487基因整数计数已按预注册规则冻结为 `strandSpecific=2`。edgeR主模型 `~ CRS + IMQ + CRS:IMQ` 保留18,484基因并输出 `S0=CRS-Control`、`SD=(CRS+IMQ)-IMQ`、`I=SD-S0`。GSE13355使用180个审计通过的raw CEL进行RMA，正式H=`PP−PN`只使用58个明确患者配对；唯一Entrez映射及探针均值汇总后20,826基因进入满秩患者固定效应模型，54项独立检查通过。release-100 reciprocal 1:1与唯一Entrez门禁后按 `SIGNATURE_SPEC.md` 冻结Core 4,976、Interaction 4,085、SEP 2,716及F1哈希清单。广泛显著项和2,260个Core方向冲突均保留，不因结果数量调整阈值或更换主模型。

Figure 1F已在不筛选基因、不追加效应阈值的条件下冻结展示全部18,484个S0/SD结果，并通过数据、隔离、实际渲染与印刷尺寸QA。Figure 1G进一步展示全部4,085个Interaction成员并通过40项QA；augmentation/attenuation/reversal仅由冻结S0/SD规则定义，不作因果解释。Figure 1H使用全部4,976个Core，完整保留1,399 concordant UP、1,317 concordant DOWN和2,260个方向冲突，并通过42项QA；相关系数仅作Core选择后的描述性统计。

### Stage 03 — 锁定 bulk 验证

先冻结验证纳入表，再运行 GSE30999 明确配对和 GSE121212 27 个完整 psoriasis 配对。报告患者内分数效应、基因方向复制、跨疾病直接交互、匹配随机签名、覆盖率及 leave-one-gene-out。任何失败不触发 F1 修改。

### Stage 04 — 单细胞定位与 F2

`PASS_WITH_LIMITATIONS_AND_INPUT_BLOCKS`。GSE173706使用22名canonical donors，其中11名psoriasis donors有PN–PP对；33个文库96,088细胞经逐库QC和Scrublet后75,209细胞进入图谱。注释由不读取组织标签的HVG/聚类及多标记证据形成；cell只用于展示，推断以donor或配对donor为单位。F2按预设规则冻结为成纤维细胞SEP状态，发现集中8对可估计供者的配对差为0.0252，Hedges g=2.41；GSE162183的3+3独立供者中同向复现（差0.0280，Welch P=0.0411）。环境RNA因缺少空液滴输入、RegVelo因缺少剪接层保持`BLOCKED`；结果不反向修改F1。

### Stage 05–06 — 轨迹、通讯、代谢、空间

Stage 05已关闭为`PASS_WITH_NEGATIVE_RESULTS_AND_BLOCKS`。成纤维细胞子图谱只有一个独立命名状态且无不依赖SEP/病损方向的root，因此Monocle2、scTour、VECTOR及所有拟时序下游分析在拟合前BLOCKED。DoRothEA A–C网络的76个可估计调控子均未通过BH。CellPhoneDB-data v5.0.0的供者级表达兼容性筛查仅JAG2–NOTCH2通过发现BH并在GSE162183的3+3供者中按最小方向/P门槛复现，但没有第二方法或空间证据，故只称表达兼容性。8个Reactome代谢RNA程序中谷胱甘肽在发现集通过BH，但独立复现P=0.415且去SEP重叠敏感性不可估计；不称代谢通量。

Stage 06已关闭为`PASS_DESCRIPTIVE_WITH_QUALITY_BLOCKS`。六个真实section共7,570个filtered spots完成文件和逐section QC；5个frozen与1个FFPE分层。Core、SEP、JAG2/NOTCH2及谷胱甘肽RNA仅作空间描述；NNLS映射另用独立单细胞参考做敏感性并公开参考依赖性。无donor ID且原文空间质量门禁失败，因此不执行邻近、LR共定位、空间置换和边界距离；无空间代谢组时SpaMTP保持`BLOCKED`。

### Stage 07 — 治疗优先、预测条件化

终态`PASS_WITH_LIMITATIONS_AND_BLOCKS`。GSE228421的20个官方UMI文库均完成逐库QC、Scrublet、冻结标签转移与患者级配对汇总，保留223,828细胞；n=5的精确检验上限明确保留。GSE117468完成20,695基因汇总、32个患者配对效应及n=74的5-fold×20 repeats内部嵌套CV。M0+SEP仅为敏感性而非canonical M2，所有性能增量区间均跨零。稳定基因选择、外部响应验证和MOGONET正式BLOCKED。Figure 7A–7J完成，7K–7L阻断。

### Stage 08 — 冻结查询后药物重定位

终态`PASS_COMPUTATIONAL_WITH_VALIDATION_BLOCKS`。F3在连接性前固定Q1=SEP、Q2=普通病损、Q3=CTRA；Q1/Q2使用公开L1000FWD landmark矩阵并按cell line内dose/time中位数、再跨cell line中位数汇总。Q3因0个DOWN landmark而使用独立SigCom ranktwosided，禁止混合分数。完成3,435个共享合格perturbagens的双轴比较和24项敏感性，Figure 8A–8F完成。毒性/分化风险、BeyondCell、药物靶点–空间网络、独立扰动、转化证据和最终候选层级均因输入不足正式BLOCKED；不把计算逆转称为疗效。

## 统计共识

- 主效应报告效应量、95% CI、原始 P 和相应检验族 BH-FDR；效应阈值若使用必须预先冻结。
- 连续变量优先保留连续形式；不得为阳性随意二分。
- paired、batch、patient/donor/animal 和 repeated measures 均显式进入设计。
- 单细胞/空间图可按 cell/spot 展示，但推断单位必须是 donor/animal/section。
- 不稳定、低覆盖、方向冲突及不可重复结果进入正式结果表，不从图中隐去。
