# SIGNATURE SPECIFICATION

## 1. PS-Reference

PS-Reference 是证据分层资源，不是单一无条件分数：

1. 固定人类逆境签名：Kohrt 2016 CTRA，原始 53 指标（19 UP、34 DOWN）；HGNC 2026-09-10 快照实现 53/53 唯一映射，其中 49 个为当前符号，4 个为 previous symbol：IL8→CXCL8、IGJ→JCHAIN、IFIT1L→IFIT1B、IGLL3→IGLL3P。
2. 实际实验室心理社会应激：GSE70603，被试内 -45/+45/+180 分钟。固定规则为 +45/-45 或 +180/-45 任一对比 BH-FDR<0.05，并分别保留两个时点的方向；得到 4,426 个原始候选。HGNC 快照审计后 3,871 个一对一映射可用于后续重叠，553 个未解析/歧义项和 2 个碰撞项保持 `HOLD`。由于没有未应激同时间对照，该层只能称为时间锁定参考证据，不能称为纯应激因果签名。
3. 实际动物束缚应激语境：GSE212126、GSE270712/713；物种和组织分开。
4. 内分泌/药理代理：肾上腺素/ADM、地塞米松；不得重命名为心理应激。
5. GO/Reactome/MSigDB：仅在固定 release、term ID 和成员后作为功能注释。

每条候选证据进入 `metadata/gene_evidence_ledger.tsv`，记录来源、物种、组织/细胞、对比、方向、效应、不确定性和证据等级。仅“stress”关键词匹配不得进入候选。

GSE70603 的早期逆境调节对比属于预设阴性结果：未调整及年龄/性别调整模型在 +45、+180 均为 0 个 FDR<0.05 基因。该结果不通过放宽阈值、更换模型或利用锁定验证集重新定义成员。

### 1.1 PS-PsoGS-Reference 与 PS-PsoGS 的边界

- `PS-PsoGS-Reference` 是上述分层来源在银屑病语境中的可追溯证据注册表；允许保存表达、功能和文献注释，但不要求成员具有统一方向。
- `PS-PsoGS` 是 Core、Interaction、SEP 及相应有方向评分的总称，不等于 PS-Reference 的并集。
- CTRA、GSE70603、GSE270712、GSE270713、GSE26487 和 GO 注释均不能凭“与应激有关”自动进入 Core。
- 当前唯一向 Core 提供疾病背景实验应激效应的来源是 GSE212126；其独立动物与无混池门禁已由项目所有者确认，12库整数raw counts、链方向和S0/SD/I已于2026-09-11通过审计。GSE13355的180个raw CEL和58对患者内H=`PP−PN`模型也已冻结并通过54项检查。Ensembl Compara release 100 的mouse/human双目录protein+ncrna静态文件及唯一Entrez映射通过19项来源审计，形成4,976个Core、4,085个Interaction和2,716个SEP成员；45项成员与F1哈希检查PASS。
- QuickGO 冻结为 `GO:0071872`、`GO:0071874`、`GO:0071385` 的人/鼠 exact direct annotations，不含 descendants。所有成员方向为 `NONE_ONTOLOGY_ANNOTATION`；人类符号只有 HGNC exact PASS 才可参与后续重叠，其余保持 HOLD。

资源、实验单位和允许用途见 `metadata/ps_reference_registry.tsv`；本体快照与成员见 `metadata/endocrine_ontology_registry.tsv` 和 `genesets/endocrine_go_exact_2026-09-10.tsv`。

## 2. 开发估计量

- `S0 = CRS - Control`：无 IMQ 背景下的应激效应。
- `SD = (CRS+IMQ) - IMQ`：银屑病样炎症背景下的应激效应。
- `I = SD - S0`：正式 CRS:IMQ 交互。
- `H = PP - PN`：GSE13355 患者内人体病损效应。

所有 mouse 基因先经版本固定的可靠 1:1 ortholog 映射；一对多、多对多和未映射基因不进入主要跨物种签名，但留在账本中。

## 3. 成员规则（F1 前不得更改）

- Core：可分析的可靠 1:1 ortholog，`SD` 与 `H` 在各自预先定义检验族中均 BH-FDR < 0.05。方向一致不是 Core 的必要条件，方向冲突必须明示。
- Interaction：Core 中 `I` BH-FDR < 0.05 的子集；按 S0、SD、I 的符号和幅度分类为 augmentation、attenuation 或 reversal。显著交互不自动等于加重。
- SEP：Core 中 `sign(SD) = sign(H)`；两者正为 SEP-UP，两者负为 SEP-DOWN。
- 高可信 SEP-Interaction：SEP 且 `I` BH-FDR < 0.05，`sign(I)=sign(SD)=sign(H)`，并且 `|SD|>|S0|`。该标签仍表示统计支持，不等同于单基因因果驱动。

Core/Interaction/SEP 只使用已通过QC的GSE212126冻结整数计数结果，不使用FPKM工作簿替代。动物独立性与无混池状态采用项目所有者确认，并与公开来源证据分开标注。若后续GSE13355配对分析或ortholog门禁不通过，相应签名不生成。

## 4. 分数

- bulk：在每个队列内按预先固定标准化方法得到基因值，分别计算 UP 与 DOWN 分量；directed score = mean/rank-score(UP) - mean/rank-score(DOWN)。
- scRNA：分别计算 UCell UP、DOWN，再相减；展示可按 cell，推断按 donor-celltype pseudobulk/配对结构。
- 不翻转方向，不根据验证表现重新加权。
- 主分数要求可用成员覆盖率 ≥70%；低于阈值只报告 UP/DOWN 分量、覆盖率和缺失成员，不报告主 directed score。
- 同名多探针的汇总规则须在首次数据处理中冻结；不得按与结局相关性选择探针。

## 5. 版本与冻结

F1 产物包括：GMT/TSV 成员表、方向、来源效应、ortholog 版本、评分公式、覆盖率规则、软件/参考版本和 SHA-256。F1 时间戳必须早于读取 GSE30999/GSE121212 表达结果；当前状态为 `PASS_F1_2026-09-11`，验证表达读取数为0。Core的2,260个方向冲突保留在账本和分层GMT中；不得在验证后删除或翻转。
