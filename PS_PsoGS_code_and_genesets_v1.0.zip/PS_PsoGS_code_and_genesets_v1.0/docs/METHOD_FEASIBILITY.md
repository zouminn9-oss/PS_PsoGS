# METHOD FEASIBILITY

状态是当前输入和环境下的真实判定，不代表永久排除。

| 模块 | 最低输入 | 当前证据 | 状态 | 启动条件 |
|---|---|---|---|---|
| GSE212126 析因 counts 模型 | 每只独立动物的 raw counts + 4 组设计 | 12 文库=12 独立小鼠且无混池已确认；12/12 FASTQ/BAM、reverse-stranded整数counts、满秩edgeR模型与S0/SD/I均通过 | PASS | 来源保持user-provided provenance；动物确认不误写成公开数据库字段 |
| GSE13355 配对开发 | CEL + 明确 PP/PN pair | 官方raw tar及180/180 CEL.gz通过审计；58个精确patient-ID配对；all-180 RMA、唯一Entrez映射、探针均值汇总和患者固定效应H模型完成；20,826基因、54项检查PASS | PASS | 保持GSM337287软QC标记可见；主H结果冻结用于ortholog/Core门禁，不因显著数量改阈值 |
| mouse–human orthology与F1 | 固定版本双物种orthology、唯一ID映射、冻结S0/SD/I/H | Ensembl Compara release 100四个mouse/human protein/ncRNA源文件通过；13,289个受检基因通过reciprocal 1:1，Core/Interaction/SEP及F1哈希完成，19+45项检查PASS | PASS | Core 2,260个方向冲突保留；验证不得修改成员、方向或权重 |
| GSE70603 应激响应 | 180 数组、60 人 × 3 时点 | 矩阵提取、配对模型、HGNC 审计和结果 QA 已通过；无未应激时间对照 | PASS（分析）/PARTIAL（因果解释） | 仅作为时间锁定 PS-Reference 证据层；不解释为纯应激效应 |
| bulk 锁定验证 | F1 + 明确 patient pairs | 81个GSE30999与27个GSE121212配对、meta、全部2,716成员复制、PSO–AD比较、4,000随机集、9个可估计敏感性、5,432行LOO及11项结论矩阵完成；Figure 2A–2E、2G–2J通过 | PASS_WITH_LIMITATIONS_AND_BLOCKS | PSO独有性FAIL；AD亦正向；比较程序/临床协变量BLOCKED；方向冲突和k=2限制保留；心理应激因果NOT_TESTED |
| 炎症/IFN/增殖等比较程序 | 验证效应查看前冻结的来源、版本、成员及方向规则 | 当前注册表和genesets目录均无合格比较程序包；12项输入门控用于确认缺失且未生成Figure 2F | BLOCKED | 获得独立于当前结果、前瞻冻结且来源版本完整的比较程序集；不得事后挑选最有利基因集 |
| donor-level scRNA | counts + donor labels | GSE173706：33文库、22供者、75,209个最终细胞；GSE162183：6独立供者、18,166个最终细胞；逐库QC、Scrublet、标签盲聚类、多标记注释、供者级F2发现/复现及Figure 3均通过 | PASS_WITH_LIMITATIONS | cell仅展示、供者为推断单位；环境RNA无空液滴而BLOCKED；复现为3+3供者且非配对 |
| GSE225475 空间定位 | 逐 section matrix、图像、坐标和可验证比例尺 | 官方RAW归档及6 sections全部核验；5 frozen/1 FFPE、共7,570 filtered spots；Core/SEP/候选表达/谷胱甘肽RNA、NNLS映射和独立参考敏感性均完成；无donor ID | PASS_DESCRIPTIVE_WITH_QUALITY_BLOCKS | spot不是生物学重复；PP4不与frozen合并；proximity/co-localization/置换/距离保持BLOCKED；映射参考依赖性必须保留 |
| Monocle2 | 合格 focus lineage + donor support | F2成纤维子图谱仅一个独立命名状态；无不依赖SEP/病损方向的root | BLOCKED | 需要至少两个跨供者可靠状态及外部生物学root；当前未拟合 |
| scTour/VECTOR | 同上 + 相应依赖 | 与Monocle2共享的生物学输入门禁失败 | BLOCKED | 不为补面板安装或用第二算法绕过root失败 |
| RegVelo | 可用 spliced/unspliced 或合适 reads | 未核实；GSE162183 reads 受控/外部 | BLOCKED | 获得并验证剪接输入 |
| CellChat/CellPhoneDB/NicheNet | 合格注释、足够 donor、冻结数据库 | CellPhoneDB-data v5.0.0知识库已冻结；672项供者配对表达兼容性检验仅JAG2–NOTCH2通过BH并在3+3供者复现；未运行CellChat/CPDB置换或NicheNet | PARTIAL_WITH_BLOCKS | 当前候选只称表达兼容性；第二方法、接收端靶网络与空间支持缺失，不升级为通讯机制 |
| scFEA | 合格 scRNA 与兼容网络 | 8个Reactome代谢RNA程序已完成；谷胱甘肽发现阳性但独立复现失败；无代谢实测和已审计scFEA网络 | BLOCKED | 不从RNA程序伪造通量；取得兼容网络后也只能称predicted flux |
| Visium/cell2location/Squidpy | image、coordinates、matrix、reference | 六个section真实输入与尺度通过；已采用可审计NNLS完成描述性映射及第二参考敏感性；深度映射不会修复缺失donor和来源质量限制 | PASS_ALTERNATIVE_METHOD_WITH_LIMITATIONS | 不为方法名改跑cell2location；若新增独立空间队列再评估推断性空间分析 |
| SpaMTP/空间多组学融合 | 匹配空间代谢组 | 不存在 | BLOCKED | 获得真实匹配空间代谢输入，否则 SKIPPED |
| GSE228421 治疗机制 | 患者配对纵向 scRNA | 官方20文库、5位患者四样本结构；逐库QC/Scrublet/冻结标签转移完成，保留223,828细胞；54个程序效应与21个比例效应输出 | PASS_WITH_SMALL_N_LIMITATION | patient为推断单位；n=5时exact Wilcoxon双侧最小P=0.0625；不从方向性趋势升级因果或显著性 |
| 一般治疗响应预测 | 足够结局和事件数、独立/外部验证 | GSE117468提交者GCRMA矩阵完成；brodalumab BL-LS n=74、PASI75 62/12；5-fold×20 repeats嵌套CV已完成，M0+SEP增量区间均跨零；sex、M1和外部队列缺失 | PARTIAL_WITH_BLOCKS | 仅保留内部敏感性；M0+SEP不是canonical M2；不执行不稳定基因选择或声称外部泛化 |
| MOGONET | 同患者匹配多视角矩阵 | 当前没有 | BLOCKED | 获得匹配多视角数据 |
| CMap/LINCS | F3 queries + 可复现数据/API | F3已在计算前冻结；L1000FWD 978×42,809 landmark矩阵及metadata归档；Q1/Q2各4,941个药物汇总，3,435个双查询共享合格药物；Q3走独立SigCom | PASS_COMPUTATIONAL_WITH_LIMITATIONS | 余弦与SigCom z不混合；Q3无强双侧支持；连接性只作假设生成 |
| BeyondCell | F2 states + compatible perturbation reference | F2/F3已冻结，但当前landmark连接性不是可审计的BeyondCell输入替代物 | BLOCKED | 取得与冻结细胞状态及扰动表达兼容、版本明确的独立参考后重开 |
| 最终双获益药物层级 | 双查询逆转 + 风险/暴露 + 独立皮肤与人类应激干预支持 | 只有计算连接性；风险、暴露、独立扰动及人类应激验证链不完整 | BLOCKED | 必须新增独立证据；不得用同一LINCS实验自证或凭已知药名补注 |

## 计算策略

- 当前 24 逻辑 CPU、约 93.6 GB RAM、D 盘约 896.5 GB 可用；未检测到 `nvidia-smi`，不得假定有可用 CUDA GPU。
- 先执行数组/bulk 和元数据审计；大型 raw 下载、单细胞整合、深度模型分别设磁盘与内存预算后启动。
- 已在项目本地库安装 Stage 01 所需的 `limma 3.62.2` 与 `statmod 1.5.2`；其他模块仍仅在过门后建立锁定环境，不一次性安装全部包。
- 长任务必须写入日志、输入校验和、随机种子、软件版本和可恢复中间文件。
