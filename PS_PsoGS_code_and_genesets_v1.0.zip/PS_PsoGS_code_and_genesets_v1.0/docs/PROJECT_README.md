# PS-PsoGS

本目录用于构建并验证心理应激相关银屑病基因程序（PS-PsoGS）、其应激加重子集（SEP），以及后续细胞、空间、治疗和药物重定位证据链。

权威执行约束见 `PS_PsoGS_Codex_Project_Master_Prompt.md`。项目遵循“先审计、后分析；先冻结、后验证；供者/动物为统计重复；阴性结果不调参追阳性”的原则。

## 当前状态

- Stage 00：`COMPLETED_WITH_DOCUMENTED_HOLDS`。目录、环境、13个数据集、1,381条样本元数据、发现/验证隔离和90面板台账均已建立并同步至Stage 08；71项全项目清单检查通过，无法从现有来源解除的问题保留为HOLD。
- Stage 01：`PASS`。CTRA、GSE70603、GSE212126/270712/270713、GSE26487 与三个 QuickGO 内分泌术语已按真实应激、固定签名、神经内分泌代理、药理代理和本体注释分层冻结；代理与非方向注释均不得自动进入 Core。
- 90个规划面板中66个为`figure_ready=YES`，均保存源数据、统计表、配置、代码、SVG、300-dpi PNG和完整图注；24个因预设输入/质量门禁失败保持正式非渲染阻断，不以重复图补齐。
- Stage 02：`PASS`。鼠侧12/12文库与S0/SD/I、GSE13355的180/180 CEL与58对患者H、Ensembl Compara release-100 reciprocal 1:1 orthology均已冻结。F1得到Core 4,976、Interaction 4,085、SEP 2,716；20项文件清单的实时SHA-256在Figure 1J独立复核中全部一致，验证表达读取数为0。
- Stage 03：`PASS_WITH_LIMITATIONS_AND_BLOCKS`。全部可执行验证分析和Figure 2A–2J终态完成；2F输入不足正式BLOCKED。两队列效应通过、匹配随机集0/2,000超越、单基因最大影响<0.5%；PSO较ordinary AD增幅更大但AD亦为正，故PSO独有性失败；炎症独立性、临床协变量调整和心理应激因果不成立或不可检验。
- Stage 04：`PASS_WITH_LIMITATIONS_AND_INPUT_BLOCKS`。GSE173706和GSE162183完成实际矩阵QC、双细胞、注释、供者级F2发现/复现；F2冻结为成纤维细胞SEP状态，Figure 3A–3L通过227项QA。
- Stage 05：`PASS_WITH_NEGATIVE_RESULTS_AND_BLOCKS`。轨迹在无独立root时停止；76个TF调控子均未通过BH；JAG2–NOTCH2只支持供者级表达兼容性；谷胱甘肽RNA程序独立复现失败。
- Stage 06：`PASS_DESCRIPTIVE_WITH_QUALITY_BLOCKS`。6个真实section、7,570 spots完成描述性空间定位；来源质量不支持邻近/共定位推断。
- Stage 07：`PASS_WITH_LIMITATIONS_AND_BLOCKS`。GSE228421的20文库全部处理、保留223,828细胞；GSE117468完成患者配对治疗分析和n=74内部预测敏感性，外部泛化及多视角模块阻断。
- Stage 08：`PASS_COMPUTATIONAL_WITH_VALIDATION_BLOCKS`。F3、L1000FWD/SigCom、上下文汇总和敏感性完成；无满足独立验证链的最终双获益候选。

## 核心入口

- 项目边界：`PROJECT_CHARTER.md`
- 数据审计：`DATA_AUDIT.md`
- 签名规则：`SIGNATURE_SPEC.md`
- 分阶段计划：`ANALYSIS_PLAN.md`
- 方法门禁：`METHOD_FEASIBILITY.md`
- 图形蓝图：`FIGURE_PLAN.md`、`panel_manifest.tsv`
- 已完成主图面板及阻断终态：见`panel_manifest.tsv`；当前66个完成、24个阻断。
- 当前状态：`STATUS.md`、`NEXT_STEPS.md`
- Stage 01 结果：`reports/STAGE01_SUMMARY_ZH.md`、`results/stage01/`、`genesets/GSE70603_*`、`audits/gse70603_*`
- Stage 02 结果：`results/stage02/counts/`、`results/stage02/factorial_edger/`、`results/stage02/gse13355/`、`results/stage02/signatures/`、`genesets/PS_PsoGS_Core_v1.0.tsv`、`genesets/PS_PsoGS_Interaction_v1.0.tsv`、`genesets/SEP_v1.0.tsv`、`audits/stage02_orthology/`、`reports/STAGE02_F1_SUMMARY_ZH.md`
- Stage 03 结果：`results/stage03/`、`audits/stage03_bulk_validation_checks.tsv`、`audits/stage03_pso_ad_specificity_checks.tsv`、`reports/STAGE03_BULK_VALIDATION_ZH.md`、`figures/panels/fig2b.svg`、`figures/panels/fig2e.svg`
- Stage 04 结果：`results/stage04/`、`audits/stage04_*`、`metadata/TARGET_FREEZE_STAGE04_F2.tsv`、`reports/STAGE04_SINGLE_CELL_F2_ZH.md`、`figures/panels/fig3a.svg`至`figures/panels/fig3l.svg`
- Stage 05 结果：`results/stage05/`、`audits/stage05_*`、`metadata/TARGET_FREEZE_STAGE05_MECHANISMS.tsv`、`reports/STAGE05_MECHANISMS_ZH.md`、Figure 4/5已登记的真实终态面板
- Stage 06 结果：`results/stage06/`、`reports/STAGE06_SPATIAL_ZH.md`、Figure 6终态面板
- Stage 07 结果：`results/stage07/`、`data/processed/stage07/gse228421/`、`reports/STAGE07_TREATMENT_PREDICTION_ZH.md`、Figure 7终态面板
- Stage 08 结果：`results/stage08/`、`metadata/F3_STAGE08_QUERY_FREEZE.tsv`、`reports/STAGE08_DRUG_REPURPOSING_ZH.md`、Figure 8终态面板
- 全阶段总结：`reports/ALL_STAGES_COMPLETION_ZH.md`
- PS-Reference 冻结：`reports/PS_REFERENCE_FREEZE_REVIEW.md`、`metadata/ps_reference_registry.tsv`、`metadata/endocrine_ontology_registry.tsv`
- GSE117468 治疗队列审计：`reports/GSE117468_METADATA_AUDIT.md`、`metadata/gse117468_patient_registry.tsv`、`audits/gse117468_cohort_summary.tsv`
- 可复现清单：`metadata/*.tsv`、`audits/*.tsv`、`scripts/stage00_*`、`scripts/stage01_*`

所有完成图板均保留源数据、统计结果、配置、绘图代码、SVG矢量文件、PNG预览和完整图注；在通过渲染、印刷尺寸可读性和数据一致性检查前不得标记为figure-ready。
