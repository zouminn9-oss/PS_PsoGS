#!/usr/bin/env python3
"""Validate the frozen Stage 02 tool, reference and disk prerequisites."""

from __future__ import annotations

import csv
import hashlib
import shutil
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def digest(path: Path, algorithm: str) -> str:
    h = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    toolkit = ROOT / "tools" / "sratoolkit" / "sratoolkit.3.4.1-win64" / "bin"
    for executable in ("prefetch.exe", "vdb-validate.exe", "fasterq-dump.exe", "fastq-dump.exe"):
        path = toolkit / executable
        check(f"tool_{executable}_exists", path.is_file(), True)
        version = subprocess.run([str(path), "--version"], check=True, capture_output=True, text=True).stdout
        check(f"tool_{executable}_version", "3.4.1" in version, True)

    toolkit_zip = ROOT / "tools" / "downloads" / "sratoolkit.3.4.1-win64.zip"
    check("sratoolkit_archive_md5", digest(toolkit_zip, "md5"), "adb911959f366f3e3de1f140128d4b23")

    rscript = Path(r"C:\Program Files\R\R-4.4.1\bin\Rscript.exe")
    check("rscript_4_4_1_exists", rscript.is_file(), True)
    r_code = (
        ".libPaths(c(normalizePath('r_libs/stage02'),normalizePath('r_libs/stage01'),.libPaths()));"
        "for(p in c('Rsubread','edgeR','limma','locfit')) cat(p,as.character(packageVersion(p)),'\\n')"
    )
    r_result = subprocess.run(
        [str(rscript), "-e", r_code], cwd=ROOT, check=True, capture_output=True, text=True
    )
    observed_r = dict(line.split() for line in r_result.stdout.splitlines() if line.strip())
    for package, version in {
        "Rsubread": "2.20.0",
        "edgeR": "4.4.2",
        "limma": "3.62.2",
        "locfit": "1.5.9.12",
    }.items():
        check(f"r_package_{package}_version", observed_r.get(package), version)

    manifest = ROOT / "metadata" / "stage02_software_manifest.tsv"
    check("stage02_software_manifest_exists", manifest.is_file(), True)
    with manifest.open(encoding="utf-8", newline="") as handle:
        manifest_rows = list(csv.DictReader(handle, delimiter="\t"))
    check("stage02_software_manifest_components", len(manifest_rows), 8)

    gtf = ROOT / "references" / "genomes" / "GRCm38_gencode_M25" / "gencode.vM25.primary_assembly.annotation.gtf.gz"
    check("gencode_m25_gtf_exists", gtf.is_file(), True)
    check("gencode_m25_gtf_md5", digest(gtf, "md5"), "c5125258a0a2c5250ddb4c192abbf4e8")

    fasta = ROOT / "references" / "genomes" / "GRCm38_gencode_M25" / "GRCm38.primary_assembly.genome.fa.gz"
    check("gencode_grcm38_fasta_exists", fasta.is_file(), True)
    check("gencode_grcm38_fasta_md5", digest(fasta, "md5"), "3bc591be24b77f710b6ba5d41022fc5a")

    usage = shutil.disk_usage(ROOT)
    check("stage02_free_disk_at_least_250GB", usage.free >= 250_000_000_000, True,
          f"observed_free_bytes={usage.free}")

    out = ROOT / "audits" / "stage02_environment_checks.tsv"
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(checks)
    print(f"PASS: {len(checks)} Stage 02 environment/reference checks")


if __name__ == "__main__":
    main()
