from pathlib import Path
import gzip, hashlib, math, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import numpy as np
import pandas as pd
from scipy import io, sparse, stats
import scrublet as scr

RAW=ROOT/"data/raw/stage07/GSE228421"; OUT=ROOT/"results/stage07/gse228421"; PROC=ROOT/"data/processed/stage07/gse228421"
OUT.mkdir(parents=True,exist_ok=True); PROC.mkdir(parents=True,exist_ok=True)
MIN_COUNTS=500; MIN_FEATURES=200; MAX_MITO=20.; MIN_GROUP_CELLS=20; UCELL_MAX_RANK=5000; SEED=20260912

def bh(p):
 p=np.asarray(p,float); q=np.full(len(p),np.nan); ok=np.isfinite(p); vals=p[ok]; o=np.argsort(vals); out=np.empty(len(vals)); last=1.
 for rank in range(len(vals),0,-1):
  i=o[rank-1]; last=min(last,vals[i]*len(vals)/rank); out[i]=last
 q[ok]=out; return q

def effect(values_after,values_before):
 d=np.asarray(values_after,float)-np.asarray(values_before,float); n=len(d); mean=d.mean(); se=d.std(ddof=1)/math.sqrt(n); crit=stats.t.ppf(.975,n-1)
 try: p=stats.wilcoxon(d,alternative="two-sided",method="exact").pvalue
 except ValueError: p=1.
 return n,mean,mean-crit*se,mean+crit*se,np.median(d),p

def rank_components(matrix,masks,sizes):
 out={f"ucell_{name}":np.empty(matrix.shape[0],np.float32) for name in masks}
 for i in range(matrix.shape[0]):
  start,stop=matrix.indptr[i],matrix.indptr[i+1]; cols=matrix.indices[start:stop]; vals=matrix.data[start:stop]
  unique,inverse,freq=np.unique(vals,return_inverse=True,return_counts=True); greater=len(vals)-np.cumsum(freq); ranks=(greater+(freq+1.)/2.)[inverse]
  for name,mask in masks.items():
   n=sizes[name]; rank_sum=(UCELL_MAX_RANK+1)*n; hit=mask[cols]
   if np.any(hit): rank_sum+=np.minimum(ranks[hit],UCELL_MAX_RANK+1).sum()-(UCELL_MAX_RANK+1)*hit.sum()
   baseline=n*(n+1)/2.; out[f"ucell_{name}"][i]=1.-(rank_sum-baseline)/(n*UCELL_MAX_RANK-baseline)
 return out

def read_features(path):
 with gzip.open(path,"rt") as f: rows=[line.rstrip("\n").split("\t") for line in f]
 return [r[0].split(".")[0] for r in rows],[r[1].upper() if len(r)>1 else "" for r in rows]

def selected_barcodes(path,indices):
 wanted=set(map(int,indices)); out={}
 with gzip.open(path,"rt") as f:
  for i,line in enumerate(f):
   if i in wanted: out[i]=line.strip()
 return [out[int(i)] for i in indices]

core=pd.read_csv(ROOT/"genesets/PS_PsoGS_Core_v1.0.tsv",sep="\t")
sep=pd.read_csv(ROOT/"genesets/SEP_v1.0.tsv",sep="\t")
programs={"core_up":set(core.loc[core.core_direction_class.str.endswith("UP"),"human_gene_symbol"].str.upper()),"core_down":set(core.loc[core.core_direction_class.str.endswith("DOWN"),"human_gene_symbol"].str.upper()),"sep_up":set(sep.loc[sep.sep_direction=="UP","human_gene_symbol"].str.upper()),"sep_down":set(sep.loc[sep.sep_direction=="DOWN","human_gene_symbol"].str.upper())}
with (ROOT/"data/raw/stage05/reactome-current/ReactomePathways.gmt").open(encoding="utf-8") as f:
 gsh=next(set(x.rstrip().split("\t")[2:]) for x in f if x.rstrip().split("\t")[1]=="R-HSA-174403")
programs["glutathione"]=set(x.upper() for x in gsh)

features_order=pd.read_csv(ROOT/"results/stage04/gse162183_label_transfer_features.tsv",sep="\t").sort_values("feature_order").human_gene_symbol.str.upper().tolist()
frozen_model=np.load(ROOT/"results/stage04/gse162183_label_transfer_model.npz",allow_pickle=True)
coef=frozen_model["coef"].astype(np.float32); intercept=frozen_model["intercept"].astype(np.float32); classes=frozen_model["classes"].astype(str)
sample_meta=pd.read_csv(ROOT/"metadata/sample_manifest.tsv",sep="\t")
sample_meta=sample_meta[sample_meta.dataset_id=="GSE228421"].set_index("sample_id")

all_obs=[]; qc_rows=[]; mapping_rows=[]
for sample_index,matrix_path in enumerate(sorted(RAW.glob("*matrix.mtx.gz")),start=1):
 gsm=matrix_path.name.split("_",1)[0]; stem=matrix_path.name.replace(".matrix.mtx.gz","")
 feature_path=RAW/f"{stem}.features.tsv.gz"; barcode_path=RAW/f"{stem}.barcodes.tsv.gz"
 gene_ids,symbols=read_features(feature_path); symbols_array=np.asarray(symbols,dtype=object)
 print(f"READ {sample_index}/20 {gsm}",flush=True)
 raw=io.mmread(matrix_path).tocoo()
 if raw.shape[0]!=len(symbols): raise AssertionError(f"feature mismatch {gsm}")
 totals=np.bincount(raw.col,weights=raw.data,minlength=raw.shape[1]); detected=np.bincount(raw.col,minlength=raw.shape[1])
 mito_gene=np.char.startswith(symbols_array.astype(str),"MT-"); mito=np.bincount(raw.col,weights=raw.data*mito_gene[raw.row],minlength=raw.shape[1]); mito_pct=np.divide(100*mito,totals,out=np.zeros_like(mito),where=totals>0)
 base=(totals>=MIN_COUNTS)&(detected>=MIN_FEATURES)&(mito_pct<=MAX_MITO)
 bt=totals[base]; bf=detected[base]
 mad_t=np.median(np.abs(bt-np.median(bt))); mad_f=np.median(np.abs(bf-np.median(bf)))
 max_t=np.median(bt)+6*max(mad_t,1); max_f=np.median(bf)+6*max(mad_f,1)
 selected=np.flatnonzero(base&(totals<=max_t)&(detected<=max_f))
 map_col=np.full(raw.shape[1],-1,np.int32); map_col[selected]=np.arange(len(selected),dtype=np.int32)
 keep=map_col[raw.col]>=0
 counts=sparse.coo_matrix((raw.data[keep],(map_col[raw.col[keep]],raw.row[keep])),shape=(len(selected),raw.shape[0]),dtype=np.int32).tocsr()
 del raw,map_col,keep
 scrub_status="PASS"; scrub_error=""
 try:
  engine=scr.Scrublet(counts,expected_doublet_rate=.08,random_state=SEED)
  doublet_score,doublet=engine.scrub_doublets(min_counts=2,min_cells=3,min_gene_variability_pctl=85,n_prin_comps=min(30,max(2,len(selected)//4)),use_approx_neighbors=False,verbose=False)
 except Exception as exc:
  scrub_status="BLOCKED_RUNTIME"; scrub_error=f"{type(exc).__name__}: {exc}"; doublet_score=np.full(len(selected),np.nan); doublet=np.zeros(len(selected),bool)
 final=counts[~doublet].tocsr(); final_orig=selected[~doublet]; final_totals=np.asarray(final.sum(axis=1)).ravel()
 barcodes=selected_barcodes(barcode_path,final_orig)
 masks={name:np.asarray([s in members for s in symbols],bool) for name,members in programs.items()}; sizes={name:int(mask.sum()) for name,mask in masks.items()}
 if min(sizes.values())<5: raise AssertionError(f"program coverage {gsm}: {sizes}")
 comps=rank_components(final,masks,sizes)
 # Frozen label-transfer model; duplicate symbols are summed into the frozen feature column.
 feature_index={s:i for i,s in enumerate(features_order)}; rr=[]; cc=[]
 for gene_i,symbol in enumerate(symbols):
  if symbol in feature_index: rr.append(gene_i); cc.append(feature_index[symbol])
 mapper=sparse.coo_matrix((np.ones(len(rr),np.float32),(rr,cc)),shape=(len(symbols),len(features_order))).tocsr()
 transfer=final.dot(mapper).tocsr().astype(np.float32); transfer=sparse.diags(10000/np.maximum(final_totals,1)).dot(transfer).tocsr(); transfer.data=np.log1p(transfer.data)
 logits=np.asarray(transfer.dot(coef.T))+intercept; logits-=logits.max(axis=1,keepdims=True); prob=np.exp(logits); prob/=prob.sum(axis=1,keepdims=True)
 best=prob.argmax(axis=1); confidence=prob[np.arange(len(best)),best]; labels=classes[best].astype(object); labels[confidence<.5]="Uncertain"
 norm=final.astype(np.float32); norm=sparse.diags(10000/np.maximum(final_totals,1)).dot(norm).tocsr(); norm.data=np.log1p(norm.data)
 def gene_expr(symbol):
  idx=np.flatnonzero(symbols_array==symbol)
  return np.asarray(norm[:,idx].sum(axis=1)).ravel() if len(idx) else np.zeros(final.shape[0])
 row=sample_meta.loc[gsm]; visit=row.timepoint_or_visit; tissue="lesional" if "Non" not in row.sample_title else "nonlesional"
 obs=pd.DataFrame({"cell_id":[f"{gsm}:{b}" for b in barcodes],"sample_id":gsm,"patient_id":row.donor_or_animal_id,"visit":visit,"tissue":tissue,"cell_type":labels,"label_transfer_probability":confidence,"scrublet_score":doublet_score[~doublet],"total_counts":final_totals,"detected_features":np.asarray((final>0).sum(axis=1)).ravel(),"mito_percent":mito_pct[final_orig]})
 for name,val in comps.items(): obs[name]=val
 obs["ucell_core_directed"]=obs.ucell_core_up-obs.ucell_core_down; obs["ucell_sep_directed"]=obs.ucell_sep_up-obs.ucell_sep_down
 obs["glutathione_score"]=comps["ucell_glutathione"]; obs["JAG2_log1pCP10K"]=gene_expr("JAG2"); obs["NOTCH2_log1pCP10K"]=gene_expr("NOTCH2")
 obs.to_csv(PROC/f"{gsm}_cell_metadata.tsv.gz",sep="\t",index=False,compression="gzip"); sparse.save_npz(PROC/f"{gsm}_counts_qc.npz",final,compressed=True)
 all_obs.append(obs)
 qc_rows.append({"sample_id":gsm,"patient_id":row.donor_or_animal_id,"visit":visit,"tissue":tissue,"raw_barcode_space":len(totals),"nonzero_barcodes":int((totals>0).sum()),"pre_doublet_cells":len(selected),"predicted_doublets":int(doublet.sum()),"post_doublet_cells":len(obs),"median_counts":float(np.median(final_totals)),"median_features":float(np.median(obs.detected_features)),"median_mito_percent":float(np.median(obs.mito_percent)),"adaptive_max_counts":max_t,"adaptive_max_features":max_f,"scrublet_status":scrub_status,"scrublet_error":scrub_error})
 mapping_rows.append({"sample_id":gsm,"transfer_features_frozen":len(features_order),"transfer_features_mapped":len(set(cc)),"labelled_probability_ge_0_5":int((confidence>=.5).sum()),"uncertain":int((confidence<.5).sum()),"model_source":"GSE173706 frozen Stage04 SGD label transfer"})
 print(f"DONE {gsm}: {len(obs)} cells",flush=True)

cells=pd.concat(all_obs,ignore_index=True); cells.to_csv(PROC/"all_cell_metadata.tsv.gz",sep="\t",index=False,compression="gzip")
qc=pd.DataFrame(qc_rows); qc.to_csv(OUT/"library_qc.tsv",sep="\t",index=False); pd.DataFrame(mapping_rows).to_csv(OUT/"label_transfer_qc.tsv",sep="\t",index=False)
composition=cells.groupby(["patient_id","visit","tissue","cell_type"],as_index=False).size().rename(columns={"size":"n_cells"}); totals_group=composition.groupby(["patient_id","visit","tissue"]).n_cells.transform("sum"); composition["proportion"]=composition.n_cells/totals_group; composition.to_csv(OUT/"celltype_composition.tsv",sep="\t",index=False)
scores=cells.groupby(["patient_id","visit","tissue","cell_type"],as_index=False).agg(n_cells=("cell_id","size"),ucell_core_directed=("ucell_core_directed","mean"),ucell_sep_directed=("ucell_sep_directed","mean"),glutathione_score=("glutathione_score","mean"),JAG2_log1pCP10K=("JAG2_log1pCP10K","mean"),NOTCH2_log1pCP10K=("NOTCH2_log1pCP10K","mean")); scores["eligible_min_20_cells"]=scores.n_cells>=MIN_GROUP_CELLS; scores.to_csv(OUT/"patient_celltype_scores.tsv",sep="\t",index=False)

effects=[]
for cell_type in sorted(scores.cell_type.unique()):
 for program in ["ucell_core_directed","ucell_sep_directed","glutathione_score"]:
  x=scores[(scores.cell_type==cell_type)&scores.eligible_min_20_cells&(scores.tissue=="lesional")].pivot(index="patient_id",columns="visit",values=program)
  for visit in ["day 3","day 14"]:
   if "day 0" in x and visit in x:
    z=x[["day 0",visit]].dropna()
    if len(z)>=3:
     n,mean,lo,hi,med,p=effect(z[visit],z["day 0"]); effects.append({"cell_type":cell_type,"program":program,"contrast":f"{visit}_minus_day 0_lesional","n_patient_pairs":n,"mean_difference":mean,"ci_low":lo,"ci_high":hi,"median_difference":med,"wilcoxon_p":p})
effects=pd.DataFrame(effects); effects["fdr_bh"]=bh(effects.wilcoxon_p); effects.to_csv(OUT/"within_celltype_program_effects.tsv",sep="\t",index=False)

comp_effects=[]
for cell_type in sorted(composition.cell_type.unique()):
 x=composition[(composition.cell_type==cell_type)&(composition.tissue=="lesional")].pivot(index="patient_id",columns="visit",values="proportion")
 for visit in ["day 3","day 14"]:
  if "day 0" in x and visit in x:
   z=x[["day 0",visit]].dropna()
   if len(z)==5:
    n,mean,lo,hi,med,p=effect(z[visit],z["day 0"]); comp_effects.append({"cell_type":cell_type,"contrast":f"{visit}_minus_day 0_lesional","n_patient_pairs":n,"mean_proportion_difference":mean,"ci_low":lo,"ci_high":hi,"median_difference":med,"wilcoxon_p":p})
comp_effects=pd.DataFrame(comp_effects); comp_effects["fdr_bh"]=bh(comp_effects.wilcoxon_p); comp_effects.to_csv(OUT/"composition_effects.tsv",sep="\t",index=False)

axis=[]
for (patient,visit),group in scores[(scores.tissue=="lesional")&scores.eligible_min_20_cells].groupby(["patient_id","visit"]):
 endo=group[group.cell_type=="Endothelial"]; fibro=group[group.cell_type=="Fibroblast"]
 if len(endo)==1 and len(fibro)==1:
  jag=float(endo.JAG2_log1pCP10K.iloc[0]); notch=float(fibro.NOTCH2_log1pCP10K.iloc[0]); axis.append({"patient_id":patient,"visit":visit,"endothelial_JAG2":jag,"fibroblast_NOTCH2":notch,"expression_compatibility":math.sqrt(max(jag,0)*max(notch,0))})
axis=pd.DataFrame(axis); axis.to_csv(OUT/"jag2_notch2_axis.tsv",sep="\t",index=False)
axis_effect=[]
for metric in ["endothelial_JAG2","fibroblast_NOTCH2","expression_compatibility"]:
 x=axis.pivot(index="patient_id",columns="visit",values=metric)
 for visit in ["day 3","day 14"]:
  if "day 0" in x and visit in x:
   z=x[["day 0",visit]].dropna()
   if len(z)>=3:
    n,mean,lo,hi,med,p=effect(z[visit],z["day 0"]); axis_effect.append({"metric":metric,"contrast":f"{visit}_minus_day 0","n_patient_pairs":n,"mean_difference":mean,"ci_low":lo,"ci_high":hi,"median_difference":med,"wilcoxon_p":p})
pd.DataFrame(axis_effect).to_csv(OUT/"jag2_notch2_axis_effects.tsv",sep="\t",index=False)

residual=[]
for cell_type in sorted(scores.cell_type.unique()):
 x=scores[(scores.cell_type==cell_type)&scores.eligible_min_20_cells].pivot_table(index="patient_id",columns=["visit","tissue"],values="ucell_sep_directed")
 if ("day 0","nonlesional") in x and ("day 14","lesional") in x:
  z=x[[('day 0','nonlesional'),('day 14','lesional')]].dropna()
  if len(z)>=3:
   n,mean,lo,hi,med,p=effect(z[('day 14','lesional')],z[('day 0','nonlesional')]); residual.append({"cell_type":cell_type,"contrast":"day14_lesional_minus_baseline_nonlesional","n_patient_pairs":n,"mean_difference":mean,"ci_low":lo,"ci_high":hi,"median_difference":med,"wilcoxon_p":p})
residual=pd.DataFrame(residual); residual["fdr_bh"]=bh(residual.wilcoxon_p); residual.to_csv(OUT/"day14_residual_sep.tsv",sep="\t",index=False)

checks=pd.DataFrame([
 {"check":"20_libraries", "pass":len(qc)==20,"detail":len(qc)},
 {"check":"five_patients", "pass":qc.patient_id.nunique()==5,"detail":qc.patient_id.nunique()},
 {"check":"four_samples_each", "pass":qc.groupby('patient_id').size().eq(4).all(),"detail":qc.groupby('patient_id').size().to_dict()},
 {"check":"all_post_qc_nonzero", "pass":qc.post_doublet_cells.gt(0).all(),"detail":qc.post_doublet_cells.min()},
 {"check":"all_transfer_ge_3000", "pass":pd.DataFrame(mapping_rows).transfer_features_mapped.ge(3000).all(),"detail":pd.DataFrame(mapping_rows).transfer_features_mapped.min()},
 {"check":"wilcoxon_five_pair_minimum_p", "pass":not ((effects.n_patient_pairs==5)&(effects.wilcoxon_p<.0625-1e-12)).any(),"detail":effects.loc[effects.n_patient_pairs==5,'wilcoxon_p'].min()},
])
checks.to_csv(ROOT/"audits/stage07_gse228421_checks.tsv",sep="\t",index=False)
if not checks['pass'].all(): raise AssertionError(checks.loc[~checks['pass']].to_string(index=False))
print(f"PASS: GSE228421 {len(cells)} cells; {len(effects)} program effects; {len(comp_effects)} composition effects")
