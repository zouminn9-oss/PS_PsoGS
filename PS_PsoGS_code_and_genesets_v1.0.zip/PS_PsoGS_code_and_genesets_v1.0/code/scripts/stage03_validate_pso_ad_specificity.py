#!/usr/bin/env python3
"""Independent patient, score and direct-contrast QA for PSO-versus-AD specificity."""

from __future__ import annotations

import csv
import math
import statistics
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "audits/stage03_pso_ad_specificity_checks.tsv"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def bh(values: list[float]) -> list[float]:
    order = sorted(range(len(values)), key=values.__getitem__)
    out = [0.0] * len(values); running = 1.0
    for position in range(len(values) - 1, -1, -1):
        index = order[position]
        running = min(running, values[index] * len(values) / (position + 1))
        out[index] = min(1.0, running)
    return out


def main() -> None:
    checks: list[dict[str, object]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": observed, "expected": expected,
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}; expected {expected!r}")

    scores = read_tsv(ROOT / "results/stage03/specificity/gse121212_pso_ad_paired_scores.tsv")
    group_stats = read_tsv(ROOT / "results/stage03/specificity/gse121212_pso_ad_group_statistics.tsv")
    comparisons = read_tsv(ROOT / "results/stage03/specificity/gse121212_pso_ad_direct_comparisons.tsv")
    locks = read_tsv(ROOT / "metadata/stage03_validation_sample_lock.tsv")
    prior = read_tsv(ROOT / "results/stage03/scores/paired_scores.tsv")

    check("specificity_score_rows", len(scores), 54)
    check("specificity_group_counts", Counter(r["group_id"] for r in scores),
          Counter({"PSO_PRIMARY": 27, "AD_ORDINARY": 21, "AD_CHRONIC": 6}))
    check("specificity_unique_donors", len({r["donor_id"] for r in scores}), 54)
    check("specificity_delta_identity", all(abs(float(r["delta_LS_minus_NL"]) -
          (float(r["lesional_score"]) - float(r["nonlesional_score"]))) < 1e-14
          for r in scores), True)
    expected_lesions = {"PSO_PRIMARY": "lesional", "AD_ORDINARY": "lesional",
                        "AD_CHRONIC": "chronic_lesion"}
    check("specificity_lesion_definitions",
          all(r["lesion_definition"] == expected_lesions[r["group_id"]] for r in scores), True)

    lock_samples = {r["sample_title"]: r for r in locks if r["dataset_id"] == "GSE121212"}
    invalid_sample_links = 0
    for row in scores:
        nl = lock_samples[row["nonlesional_sample"]]
        ls = lock_samples[row["lesional_sample"]]
        invalid_sample_links += nl["donor_id"] != row["donor_id"] or ls["donor_id"] != row["donor_id"]
        invalid_sample_links += nl["skin_type"] != "non-lesional" or ls["skin_type"] != row["lesion_definition"]
        expected_status = {"PSO_PRIMARY": "PRIMARY_INCLUDE", "AD_ORDINARY": "SPECIFICITY_INCLUDE",
                           "AD_CHRONIC": "SENSITIVITY_INCLUDE"}[row["group_id"]]
        invalid_sample_links += nl["lock_status"] != expected_status or ls["lock_status"] != expected_status
    check("specificity_locked_sample_links", invalid_sample_links, 0)

    prior_pso = {r["donor_id"]: r for r in prior if r["dataset_id"] == "GSE121212"}
    current_pso = {r["donor_id"]: r for r in scores if r["group_id"] == "PSO_PRIMARY"}
    check("specificity_primary_donor_lock", set(current_pso), set(prior_pso))
    check("specificity_primary_scores_unchanged", all(
          abs(float(current_pso[key][field]) - float(prior_pso[key][field])) < 1e-14
          for key in current_pso for field in ("nonlesional_score", "lesional_score", "delta_LS_minus_NL")), True)

    check("specificity_group_stats_rows", len(group_stats), 3)
    stats_map = {r["group_id"]: r for r in group_stats}
    expected_group = {"PSO_PRIMARY": (27, 0.0888004583355417, 27, 0),
                      "AD_ORDINARY": (21, 0.0550937151559984, 21, 0),
                      "AD_CHRONIC": (6, 0.058792540553978, 6, 0)}
    for group, (n, expected_mean, positive, negative) in expected_group.items():
        values = [float(r["delta_LS_minus_NL"]) for r in scores if r["group_id"] == group]
        row = stats_map[group]
        check(f"specificity_n::{group}", len(values), n)
        check(f"specificity_mean::{group}", abs(statistics.mean(values) - expected_mean) < 1e-14, True)
        check(f"specificity_positive::{group}", sum(v > 0 for v in values), positive)
        check(f"specificity_negative::{group}", sum(v < 0 for v in values), negative)
        check(f"specificity_stats_mean::{group}", abs(float(row["mean_delta"]) - statistics.mean(values)) < 1e-14, True)
        t_value = statistics.mean(values) / (statistics.stdev(values) / math.sqrt(n))
        check(f"specificity_stats_t::{group}", abs(float(row["t_statistic"]) - t_value) < 1e-10, True)
        check(f"specificity_group_ci_positive::{group}", float(row["ci_low"]) > 0, True)

    check("specificity_comparison_rows", len(comparisons), 3)
    check("specificity_primary_contrast", comparisons[0]["contrast_id"], "PSO_MINUS_AD_ORDINARY")
    check("specificity_roles", [r["analysis_role"] for r in comparisons],
          ["PRIMARY", "SENSITIVITY", "SENSITIVITY"])
    group_values = {group: [float(r["delta_LS_minus_NL"]) for r in scores if r["group_id"] == group]
                    for group in expected_group}
    definitions = [("PSO_PRIMARY", "AD_ORDINARY"), ("PSO_PRIMARY", "AD_CHRONIC"),
                   ("AD_ORDINARY", "AD_CHRONIC")]
    for row, (left, right) in zip(comparisons, definitions):
        x, y = group_values[left], group_values[right]
        difference = statistics.mean(x) - statistics.mean(y)
        se2 = statistics.variance(x) / len(x) + statistics.variance(y) / len(y)
        t_value = difference / math.sqrt(se2)
        df = se2**2 / ((statistics.variance(x) / len(x))**2 / (len(x) - 1) +
                       (statistics.variance(y) / len(y))**2 / (len(y) - 1))
        check(f"specificity_difference::{row['contrast_id']}",
              abs(float(row["difference_left_minus_right"]) - difference) < 1e-14, True)
        check(f"specificity_welch_t::{row['contrast_id']}", abs(float(row["t_statistic"]) - t_value) < 1e-10, True)
        check(f"specificity_welch_df::{row['contrast_id']}", abs(float(row["t_df"]) - df) < 1e-10, True)
    primary = comparisons[0]
    check("specificity_primary_difference", abs(float(primary["difference_left_minus_right"]) - 0.0337067431795434) < 1e-14, True)
    check("specificity_primary_ci_positive", float(primary["ci_low"]) > 0, True)
    check("specificity_primary_p", abs(float(primary["t_p_value"]) - 0.000179700676629047) < 1e-16, True)
    check("specificity_primary_wilcoxon", float(primary["wilcoxon_p_value"]) < 0.001, True)
    recomputed_bh = bh([float(r["t_p_value"]) for r in comparisons])
    check("specificity_BH_recalculation", max(abs(a - float(r["BH_FDR_three_between_group_tests"]))
          for a, r in zip(recomputed_bh, comparisons)) < 1e-14, True)
    check("specificity_ordinary_chronic_not_significant", float(comparisons[2]["t_p_value"]) > 0.05, True)

    config = (ROOT / "config/stage03_pso_ad_specificity.yaml").read_text(encoding="utf-8")
    for rule in ("PSO delta minus AD_ORDINARY delta", "two-sided Welch t-test",
                 "chronic_pooling_with_ordinary: false", "separate_group_significance_as_interaction_evidence: false",
                 "validation_to_signature_feedback: false"):
        check(f"specificity_rule::{rule}", rule in config, True)

    with AUDIT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(checks)
    print(f"PASS: {len(checks)} PSO-versus-AD specificity checks")


if __name__ == "__main__":
    main()
