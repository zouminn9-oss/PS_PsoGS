#!/usr/bin/env python3
"""Create a QC-filtered sparse discovery matrix, run per-library Scrublet, and score frozen programs.

The script never uses condition labels for feature selection, doublet calling, or
program construction. Cells are display units; donor/library identifiers are
carried forward for later donor-level inference.
"""
from __future__ import annotations

import csv
import gzip
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))

import numpy as np
import pandas as pd
from scipy import sparse
import scrublet as scr

RAW = ROOT / "data/raw/single_cell/GSE173706/csv_gz"
CELL_QC = ROOT / "data/processed/stage04/gse173706_cell_qc.tsv.gz"
GENE_QC = ROOT / "results/stage04/qc/gse173706_gene_detection.tsv.gz"
CORE = ROOT / "genesets/PS_PsoGS_Core_v1.0.tsv"
SEP = ROOT / "genesets/SEP_v1.0.tsv"
OUT = ROOT / "data/processed/stage04"
RES = ROOT / "results/stage04/qc"
AUDIT = ROOT / "audits/stage04_discovery_sparse_checks.tsv"
SEED = 20260911
MIN_DETECTED = 20
N_HVG = 4000
UCELL_MAX_RANK = 5000

MARKERS = {
    "Keratinocyte": ["KRT14", "KRT5", "KRT1", "KRT10", "DMKN", "SFN"],
    "Fibroblast": ["DCN", "LUM", "COL1A1", "COL1A2", "COL3A1", "PDGFRA"],
    "Endothelial": ["PECAM1", "VWF", "CDH5", "CLDN5", "EMCN", "KDR"],
    "T_cell": ["CD3D", "CD3E", "TRAC", "IL7R", "CD8A", "CD247"],
    "Myeloid": ["LYZ", "TYROBP", "FCER1G", "CTSS", "HLA-DRA", "CD74"],
    "Mast": ["TPSAB1", "TPSB2", "CPA3", "MS4A2", "KIT", "CTSG"],
    "Melanocyte": ["DCT", "TYRP1", "PMEL", "MLANA", "TYR", "SOX10"],
    "Eccrine": ["DCD", "PIP", "MUCL1", "KRT19", "KRT8", "KRT18"],
    "Smooth_muscle": ["ACTA2", "TAGLN", "MYL9", "CNN1", "MYH11", "RGS5"],
    "Nerve_glial": ["MPZ", "PLP1", "S100B", "SOX10", "SLC1A3", "NGFR"],
    "B_cell": ["CD79A", "MS4A1", "CD37", "CD74", "CD22", "CD19"],
}


def read_tsv(path: Path) -> list[dict[str, str]]:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict], gz: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if gz else open
    with opener(path, "wt", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def frozen_programs() -> dict[str, set[str]]:
    core = read_tsv(CORE)
    sep = read_tsv(SEP)
    return {
        "core_up": {r["selected_human_ensembl_gene_id"] for r in core if r["core_direction_class"].endswith("UP")},
        "core_down": {r["selected_human_ensembl_gene_id"] for r in core if r["core_direction_class"].endswith("DOWN")},
        "sep_up": {r["selected_human_ensembl_gene_id"] for r in sep if r["sep_direction"] == "UP"},
        "sep_down": {r["selected_human_ensembl_gene_id"] for r in sep if r["sep_direction"] == "DOWN"},
    }


def rank_components(matrix: sparse.csr_matrix, masks: dict[str, np.ndarray], sizes: dict[str, int]) -> dict[str, np.ndarray]:
    """Exact count-tie ranks for UCell and a whole-transcriptome rank-mean sensitivity score."""
    output = {f"ucell_{name}": np.empty(matrix.shape[0], dtype=np.float32) for name in masks}
    output.update({f"rankmean_{name}": np.empty(matrix.shape[0], dtype=np.float32) for name in masks})
    for i in range(matrix.shape[0]):
        start, stop = matrix.indptr[i], matrix.indptr[i + 1]
        cols = matrix.indices[start:stop]
        vals = matrix.data[start:stop]
        unique, inverse, freq = np.unique(vals, return_inverse=True, return_counts=True)
        greater = len(vals) - np.cumsum(freq)
        value_ranks = greater + (freq + 1.0) / 2.0
        ranks = value_ranks[inverse]
        zero_rank = (len(vals) + 1.0 + matrix.shape[1]) / 2.0
        for name, mask in masks.items():
            n = sizes[name]
            rank_sum = float((UCELL_MAX_RANK + 1) * n)
            hit = mask[cols]
            if np.any(hit):
                rank_sum += float(np.minimum(ranks[hit], UCELL_MAX_RANK + 1).sum()) - float((UCELL_MAX_RANK + 1) * hit.sum())
            baseline = n * (n + 1) / 2.0
            denom = n * UCELL_MAX_RANK - baseline
            output[f"ucell_{name}"][i] = 1.0 - (rank_sum - baseline) / denom
            full_rank_sum = zero_rank * n
            if np.any(hit):
                full_rank_sum += float(ranks[hit].sum()) - zero_rank * int(hit.sum())
            output[f"rankmean_{name}"][i] = 1.0 - ((full_rank_sum / n) - 1.0) / (matrix.shape[1] - 1.0)
        if (i + 1) % 1000 == 0:
            print(f"  UCELL {i + 1}/{matrix.shape[0]}", flush=True)
    return output


def load_sample(path: Path, keep_cells: np.ndarray, gene_keep: np.ndarray, expected_genes: list[str]) -> sparse.csr_matrix:
    data_parts: list[np.ndarray] = []
    row_parts: list[np.ndarray] = []
    col_parts: list[np.ndarray] = []
    kept_gene_row = 0
    with gzip.open(path, "rb") as handle:
        header = handle.readline().rstrip(b"\r\n").split(b",")[1:]
        n_input_cells = len(header)
        for gene_index, line in enumerate(handle):
            gene_raw, values_raw = line.rstrip(b"\r\n").split(b",", 1)
            gene = gene_raw.decode("ascii")
            if gene != expected_genes[gene_index]:
                raise AssertionError(f"gene order mismatch in {path.name}: {gene_index + 1}")
            if not gene_keep[gene_index]:
                continue
            values = np.fromstring(values_raw, dtype=np.int32, sep=",")
            if values.size != n_input_cells:
                raise AssertionError(f"cell parse mismatch in {path.name}: {gene}")
            values = values[keep_cells]
            nz = np.flatnonzero(values)
            if nz.size:
                data_parts.append(values[nz])
                row_parts.append(np.full(nz.size, kept_gene_row, dtype=np.int32))
                col_parts.append(nz.astype(np.int32, copy=False))
            kept_gene_row += 1
    data = np.concatenate(data_parts) if data_parts else np.array([], dtype=np.int32)
    rows = np.concatenate(row_parts) if row_parts else np.array([], dtype=np.int32)
    cols = np.concatenate(col_parts) if col_parts else np.array([], dtype=np.int32)
    gene_by_cell = sparse.coo_matrix((data, (rows, cols)), shape=(int(gene_keep.sum()), int(keep_cells.sum())), dtype=np.int32)
    return gene_by_cell.T.tocsr()


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    RES.mkdir(parents=True, exist_ok=True)
    cell_qc = pd.read_csv(CELL_QC, sep="\t")
    gene_qc = pd.read_csv(GENE_QC, sep="\t")
    gene_ids = gene_qc["ensembl_gene_id"].astype(str).tolist()
    symbols = gene_qc["human_gene_symbol"].fillna("").astype(str).tolist()
    gene_keep = gene_qc["detected_input_cells"].to_numpy(dtype=int) >= MIN_DETECTED
    kept_gene_ids = np.asarray(gene_ids, dtype=object)[gene_keep]
    kept_symbols = np.asarray(symbols, dtype=object)[gene_keep]
    programs = frozen_programs()
    kept_index = {gene: i for i, gene in enumerate(kept_gene_ids)}
    program_masks = {name: np.array([gene in genes for gene in kept_gene_ids], dtype=bool) for name, genes in programs.items()}
    program_sizes = {name: int(mask.sum()) for name, mask in program_masks.items()}

    mean = gene_qc["mean_count"].to_numpy(float)
    variance = gene_qc["variance_count"].to_numpy(float)
    symbol_array = np.asarray(symbols, dtype=object)
    eligible_hvg = gene_keep & (mean >= 0.01) & ~np.char.startswith(symbol_array.astype(str), "MT-") & ~np.char.startswith(symbol_array.astype(str), "RPS") & ~np.char.startswith(symbol_array.astype(str), "RPL")
    dispersion = np.full(len(gene_ids), -np.inf)
    dispersion[eligible_hvg] = variance[eligible_hvg] / np.maximum(mean[eligible_hvg], 1e-8)
    hvg_global = set(np.argsort(dispersion)[-N_HVG:].tolist())
    marker_symbols = {gene for genes in MARKERS.values() for gene in genes}
    selected_global = {
        i for i, (gene, symbol) in enumerate(zip(gene_ids, symbols))
        if gene_keep[i] and (i in hvg_global or symbol in marker_symbols or any(gene in x for x in programs.values()))
    }
    selected_kept_idx = np.array([j for j, global_i in enumerate(np.flatnonzero(gene_keep)) if global_i in selected_global], dtype=np.int32)

    matrix_parts: list[sparse.csr_matrix] = []
    obs_parts: list[pd.DataFrame] = []
    doublet_rows: list[dict] = []
    sample_rows: list[dict] = []
    for sample_i, path in enumerate(sorted(RAW.glob("*.csv.gz")), start=1):
        sample = path.name.split("_", 1)[0]
        sample_qc = cell_qc.loc[cell_qc["sample_id"] == sample].copy()
        keep_cells = sample_qc["qc_pass_pre_doublet"].astype(str).str.lower().eq("true").to_numpy()
        kept_obs = sample_qc.loc[keep_cells].reset_index(drop=True)
        print(f"SPARSE {sample_i}/33 {sample} pre_doublet={len(kept_obs)}", flush=True)
        matrix = load_sample(path, keep_cells, gene_keep, gene_ids)
        scrublet_status = "PASS"
        scrublet_error = ""
        try:
            engine = scr.Scrublet(matrix, expected_doublet_rate=0.06, random_state=SEED)
            scores, predicted = engine.scrub_doublets(
                min_counts=2, min_cells=3, min_gene_variability_pctl=85,
                n_prin_comps=min(30, max(2, matrix.shape[0] // 4)),
                use_approx_neighbors=False, verbose=False,
            )
            threshold = float(engine.threshold_)
        except Exception as exc:
            scores = np.full(matrix.shape[0], np.nan)
            predicted = np.zeros(matrix.shape[0], dtype=bool)
            threshold = np.nan
            scrublet_status = "BLOCKED_RUNTIME"
            scrublet_error = f"{type(exc).__name__}: {exc}"
        components = rank_components(matrix, program_masks, program_sizes)
        retained = ~predicted
        kept_obs["scrublet_score"] = scores
        kept_obs["predicted_doublet"] = predicted
        kept_obs["scrublet_status"] = scrublet_status
        for name, values in components.items():
            kept_obs[name] = values
        kept_obs["ucell_core_directed"] = kept_obs["ucell_core_up"] - kept_obs["ucell_core_down"]
        kept_obs["ucell_sep_directed"] = kept_obs["ucell_sep_up"] - kept_obs["ucell_sep_down"]
        kept_obs["rankmean_core_directed"] = kept_obs["rankmean_core_up"] - kept_obs["rankmean_core_down"]
        kept_obs["rankmean_sep_directed"] = kept_obs["rankmean_sep_up"] - kept_obs["rankmean_sep_down"]
        matrix_parts.append(matrix[retained][:, selected_kept_idx].astype(np.int32))
        obs_parts.append(kept_obs.loc[retained].copy())
        for cell_id, score, flag in zip(kept_obs["cell_id"], scores, predicted):
            doublet_rows.append({"cell_id": cell_id, "sample_id": sample, "scrublet_score": score,
                                 "predicted_doublet": bool(flag), "scrublet_status": scrublet_status})
        sample_rows.append({"sample_id": sample, "donor_id": kept_obs.loc[0, "donor_id"], "tissue": kept_obs.loc[0, "tissue"],
                            "pre_doublet_cells": matrix.shape[0], "predicted_doublets": int(predicted.sum()),
                            "post_doublet_cells": int(retained.sum()), "predicted_doublet_fraction": float(predicted.mean()),
                            "scrublet_threshold": threshold, "scrublet_status": scrublet_status,
                            "scrublet_error": scrublet_error})
        del matrix

    combined = sparse.vstack(matrix_parts, format="csr", dtype=np.int32)
    obs = pd.concat(obs_parts, ignore_index=True)
    sparse.save_npz(OUT / "gse173706_selected_counts.npz", combined, compressed=True)
    obs.to_csv(OUT / "gse173706_cell_metadata.tsv.gz", sep="\t", index=False, compression="gzip")
    selected_gene_rows = []
    hvg_ids = {gene_ids[i] for i in hvg_global}
    for output_i, kept_i in enumerate(selected_kept_idx):
        gene = str(kept_gene_ids[kept_i]); symbol = str(kept_symbols[kept_i])
        selected_gene_rows.append({"matrix_column": output_i, "ensembl_gene_id": gene, "human_gene_symbol": symbol,
                                   "hvg_global_raw_dispersion": gene in hvg_ids,
                                   "canonical_annotation_marker": symbol in marker_symbols,
                                   "core_member": gene in programs["core_up"] or gene in programs["core_down"],
                                   "sep_member": gene in programs["sep_up"] or gene in programs["sep_down"]})
    write_tsv(OUT / "gse173706_selected_genes.tsv", selected_gene_rows)
    write_tsv(RES / "gse173706_scrublet_by_library.tsv", sample_rows)
    write_tsv(RES / "gse173706_scrublet_by_cell.tsv.gz", doublet_rows, gz=True)
    coverage_rows = []
    for name, genes in programs.items():
        coverage_rows.append({"program_component": name, "frozen_genes": len(genes), "detected_ge20_cells": program_sizes[name],
                              "coverage_fraction": program_sizes[name] / len(genes), "ucell_max_rank": UCELL_MAX_RANK})
    write_tsv(RES / "gse173706_program_coverage.tsv", coverage_rows)

    checks = [
        {"check_id": "input_pre_doublet_cells", "observed": int(sum(x["pre_doublet_cells"] for x in sample_rows)), "expected": 75944},
        {"check_id": "libraries_processed", "observed": len(sample_rows), "expected": 33},
        {"check_id": "post_doublet_cells_gt_50000", "observed": combined.shape[0] > 50000, "expected": True},
        {"check_id": "selected_matrix_rows_match_metadata", "observed": combined.shape[0], "expected": len(obs)},
        {"check_id": "selected_matrix_columns_match_genes", "observed": combined.shape[1], "expected": len(selected_gene_rows)},
        {"check_id": "unique_cell_ids", "observed": obs["cell_id"].nunique(), "expected": len(obs)},
        {"check_id": "all_program_components_ge70pct_coverage", "observed": all(x["coverage_fraction"] >= 0.70 for x in coverage_rows), "expected": True},
    ]
    for row in checks:
        row["status"] = "PASS" if row["observed"] == row["expected"] else "FAIL"
    write_tsv(AUDIT, checks)
    if any(row["status"] == "FAIL" for row in checks):
        raise AssertionError("Stage 04 sparse preparation audit failed")
    with (RES / "gse173706_sparse_summary.json").open("w", encoding="utf-8") as handle:
        json.dump({"shape": combined.shape, "nnz": int(combined.nnz), "scrublet_pass_libraries": sum(x["scrublet_status"] == "PASS" for x in sample_rows),
                   "seed": SEED, "min_detected_cells": MIN_DETECTED, "n_hvg": N_HVG,
                   "ucell_max_rank": UCELL_MAX_RANK}, handle, indent=2)
    print(f"PASS: selected sparse matrix {combined.shape}, nnz={combined.nnz}; scrublet PASS {sum(x['scrublet_status'] == 'PASS' for x in sample_rows)}/33")


if __name__ == "__main__":
    main()
