#!/usr/bin/env python3
"""Independent checks for locked Stage 03 bulk validation outputs."""

from __future__ import annotations

import csv
import gzip
import hashlib
import math
import statistics
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "audits/stage03_bulk_validation_checks.tsv"
MANIFEST = ROOT / "metadata/stage03_analysis_output_manifest.tsv"


def read_tsv(path: Path, compressed: bool = False) -> list[dict[str, str]]:
    opener = gzip.open if compressed else open
    mode = "rt" if compressed else "r"
    with opener(path, mode, encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def bh_adjust(values: list[float]) -> list[float]:
    n = len(values)
    order = sorted(range(n), key=values.__getitem__)
    adjusted = [0.0] * n
    running = 1.0
    for position in range(n - 1, -1, -1):
        index = order[position]
        candidate = values[index] * n / (position + 1)
        running = min(running, candidate)
        adjusted[index] = min(running, 1.0)
    return adjusted


def main() -> None:
    checks: list[dict[str, object]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": observed, "expected": expected,
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            write_tsv(AUDIT, checks)
            raise AssertionError(f"{check_id}: observed {observed!r}; expected {expected!r}")

    prep = read_tsv(ROOT / "audits/stage03_matrix_preparation_checks.tsv")
    qc = read_tsv(ROOT / "results/stage03/qc/validation_matrix_qc.tsv")
    software = read_tsv(ROOT / "results/stage03/stage03_software.tsv")
    locks = read_tsv(ROOT / "metadata/stage03_validation_sample_lock.tsv")
    scores = read_tsv(ROOT / "results/stage03/scores/paired_scores.tsv")
    score_stats = read_tsv(ROOT / "results/stage03/scores/paired_score_statistics.tsv")
    array_effect = read_tsv(ROOT / "results/stage03/effects/gse30999_paired_all_genes.tsv")
    rna_effect = read_tsv(ROOT / "results/stage03/effects/gse121212_pso_paired_all_tested_genes.tsv")

    check("matrix_preparation_checks", (len(prep), {row["status"] for row in prep}), (522, {"PASS"}))
    check("matrix_qc_rows", (len(qc), {row["status"] for row in qc}), (17, {"PASS"}))
    qc_map = {(row["dataset_id"], row["metric"]): row["value"] for row in qc}
    expected_qc = {("GSE30999", "submitted_normalization"): "GCRMA",
                   ("GSE30999", "gene_rows"): "20848", ("GSE30999", "sample_columns"): "170",
                   ("GSE30999", "primary_samples"): "162", ("GSE30999", "nonfinite_values"): "0",
                   ("GSE121212", "raw_feature_rows"): "31364",
                   ("GSE121212", "unique_feature_rows_after_sum"): "31362",
                   ("GSE121212", "sample_columns"): "147",
                   ("GSE121212", "primary_samples"): "54",
                   ("GSE121212", "negative_counts"): "0",
                   ("GSE121212", "minimum_library_size"): "4075585",
                   ("GSE121212", "maximum_library_size"): "36109600",
                   ("GSE121212", "filterByExpr_genes"): "24382"}
    for key, value in expected_qc.items():
        check(f"matrix_qc::{key}", qc_map[key], value)
    check("software_versions", {row["component"]: row["version"] for row in software},
          {"R": "4.4.1", "edgeR": "4.4.2", "limma": "3.62.2"})

    check("paired_score_rows", len(scores), 108)
    score_counts = Counter(row["dataset_id"] for row in scores)
    check("paired_score_cohorts", score_counts, Counter({"GSE30999": 81, "GSE121212": 27}))
    check("paired_score_unique_units", len({(row["dataset_id"], row["donor_id"]) for row in scores}), 108)
    check("paired_score_definition", {row["score_definition"] for row in scores},
          {"mean_fractional_rank_SEP_UP_minus_SEP_DOWN"})
    check("paired_score_delta_identity", all(abs(float(row["delta_LS_minus_NL"]) -
          (float(row["lesional_score"]) - float(row["nonlesional_score"]))) < 1e-14
          for row in scores), True)
    lock_array = {row["sample_id"] for row in locks if row["dataset_id"] == "GSE30999" and
                  row["lock_status"] == "PRIMARY_INCLUDE"}
    lock_rna = {row["sample_title"] for row in locks if row["dataset_id"] == "GSE121212" and
                row["lock_status"] == "PRIMARY_INCLUDE"}
    used_array = {value for row in scores if row["dataset_id"] == "GSE30999"
                  for value in (row["nonlesional_sample"], row["lesional_sample"])}
    used_rna = {value for row in scores if row["dataset_id"] == "GSE121212"
                for value in (row["nonlesional_sample"], row["lesional_sample"])}
    check("array_only_locked_samples", used_array, lock_array)
    check("rna_only_locked_samples", used_rna, lock_rna)

    check("score_statistics_rows", len(score_stats), 2)
    stats_by_dataset = {row["dataset_id"]: row for row in score_stats}
    expected_summary = {"GSE30999": (81, 79, 2, 0.0741412288058754),
                        "GSE121212": (27, 27, 0, 0.0888004583355417)}
    for dataset, (n, positive, negative, expected_mean) in expected_summary.items():
        cohort = [float(row["delta_LS_minus_NL"]) for row in scores if row["dataset_id"] == dataset]
        row = stats_by_dataset[dataset]
        check(f"score_n::{dataset}", len(cohort), n)
        check(f"score_positive::{dataset}", sum(value > 0 for value in cohort), positive)
        check(f"score_negative::{dataset}", sum(value < 0 for value in cohort), negative)
        check(f"score_mean::{dataset}", abs(statistics.mean(cohort) - expected_mean) < 1e-14, True)
        check(f"score_mean_table::{dataset}", abs(float(row["mean_delta"]) - statistics.mean(cohort)) < 1e-14, True)
        check(f"score_median_table::{dataset}", abs(float(row["median_delta"]) - statistics.median(cohort)) < 1e-14, True)
        sd = statistics.stdev(cohort)
        t_value = statistics.mean(cohort) / (sd / math.sqrt(n))
        check(f"score_t::{dataset}", abs(float(row["t_statistic"]) - t_value) < 1e-10, True)
        check(f"score_primary_p_positive::{dataset}", 0 < float(row["t_p_value"]) < 0.001, True)
        check(f"score_sensitivity_p_positive::{dataset}", 0 < float(row["wilcoxon_p_value"]) < 0.001, True)
        check(f"score_ci_positive::{dataset}", float(row["mean_delta_ci_low"]) > 0, True)

    check("array_effect_rows", len(array_effect), 20848)
    check("array_effect_unique_genes", len({row["entrez_id"] for row in array_effect}), 20848)
    check("array_effect_model", {row["model"] for row in array_effect},
          {"GCRMA_gene_median_paired_difference_limma_robust"})
    check("rna_effect_rows", len(rna_effect), 24382)
    check("rna_effect_unique_genes", len({row["human_gene_symbol"] for row in rna_effect}), 24382)
    check("rna_effect_model", {row["model"] for row in rna_effect},
          {"TMM_filterByExpr_paired_edgeR_robust_QL"})
    for label, rows in (("array", array_effect), ("rna", rna_effect)):
        p = [float(row["PValue"]) for row in rows]
        fdr = [float(row["FDR"]) for row in rows]
        check(f"{label}_p_range", all(0 <= value <= 1 for value in p), True)
        check(f"{label}_fdr_range", all(0 <= value <= 1 for value in fdr), True)
        check(f"{label}_finite_effects", all(math.isfinite(float(row["logFC"])) for row in rows), True)
        recomputed = bh_adjust(p)
        max_delta = max(abs(a - b) for a, b in zip(fdr, recomputed))
        check(f"{label}_BH_recalculation", max_delta < 1e-12, True, f"max delta={max_delta:.3e}")

    config_text = (ROOT / "config/stage03_bulk_validation_analysis.yaml").read_text(encoding="utf-8")
    for rule in ("primary_pairs: 81", "primary_pairs: 27", "probe_selection_by_variance: false",
                 "duplicate_feature_rule: \"sum", "change F1 members, directions or weights"):
        check(f"analysis_rule::{rule}", rule in config_text, True)
    check("held_samples_absent", not any(row["lock_status"].startswith("HOLD") and
          (row["sample_id"] in used_array or row["sample_title"] in used_rna) for row in locks), True)

    output_paths = [
        ROOT / "results/stage03/matrices/gse30999_gcrma_entrez_gene_matrix.tsv.gz",
        ROOT / "results/stage03/qc/gse30999_sample_distribution_qc.tsv",
        ROOT / "results/stage03/qc/validation_matrix_qc.tsv",
        ROOT / "results/stage03/effects/gse30999_paired_all_genes.tsv",
        ROOT / "results/stage03/effects/gse121212_pso_paired_all_tested_genes.tsv",
        ROOT / "results/stage03/scores/paired_scores.tsv",
        ROOT / "results/stage03/scores/paired_score_statistics.tsv",
        ROOT / "results/stage03/stage03_bulk_validation_fits.rds",
        ROOT / "results/stage03/stage03_software.tsv",
        ROOT / "config/stage03_bulk_validation_analysis.yaml",
    ]
    manifest_rows = []
    for path in output_paths:
        check(f"output_present::{path.name}", path.is_file() and path.stat().st_size > 0, True)
        manifest_rows.append({"artifact_id": path.name, "path": path.relative_to(ROOT).as_posix(),
                              "bytes": path.stat().st_size, "sha256": sha256(path),
                              "analysis_version": "v1.0"})
    write_tsv(MANIFEST, manifest_rows)
    write_tsv(AUDIT, checks)
    print(f"PASS: {len(checks)} locked bulk-validation matrix, model and score checks")


if __name__ == "__main__":
    main()
