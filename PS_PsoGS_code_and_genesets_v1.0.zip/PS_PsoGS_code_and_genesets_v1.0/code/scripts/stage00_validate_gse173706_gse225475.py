#!/usr/bin/env python3
"""Validate donor and spatial-design adjudication for GSE173706/GSE225475."""

from __future__ import annotations

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    identities = read_tsv(ROOT / "audits" / "gse173706_identity_audit.tsv")
    donors = read_tsv(ROOT / "metadata" / "gse173706_donor_registry.tsv")
    spatial = read_tsv(ROOT / "audits" / "gse225475_design_audit.tsv")
    evidence = read_tsv(ROOT / "audits" / "gse173706_gse225475_paper_evidence.tsv")
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    corrected = [r for r in identities if r["adjudication_status"] == "CORRECTED_GEO_SUBJECT_TYPO"]
    check("gse173706_sample_rows", len(identities), 33)
    check("gse173706_unique_gsm", len({r["sample_accession"] for r in identities}), 33)
    check("gse173706_ns_libraries", sum(r["tissue_code"] == "NS" for r in identities), 8)
    check("gse173706_pn_libraries", sum(r["tissue_code"] == "PN" for r in identities), 11)
    check("gse173706_pp_libraries", sum(r["tissue_code"] == "PP" for r in identities), 14)
    check("gse173706_corrected_rows", len(corrected), 1)
    check("gse173706_corrected_gsm", corrected[0]["sample_accession"], "GSM5277178")
    check("gse173706_corrected_donor", corrected[0]["canonical_donor_id"], "30696")
    check("gse173706_expression_not_used", sum(r["expression_matrix_accessed"] == "NO" for r in identities), 33)
    check("gse173706_canonical_donors", len(donors), 22)
    check("gse173706_psoriasis_donors", sum(r["donor_group"] == "psoriasis" for r in donors), 14)
    check("gse173706_healthy_donors", sum(r["donor_group"] == "healthy" for r in donors), 8)
    check("gse173706_complete_pn_pp_pairs", sum(r["pn_pp_pair_status"] == "COMPLETE_PAIRED" for r in donors), 11)

    check("gse225475_section_rows", len(spatial), 6)
    check("gse225475_healthy_sections", sum(r["disease_state"] == "healthy" for r in spatial), 2)
    check("gse225475_psoriasis_sections", sum(r["disease_state"] == "psoriasis" for r in spatial), 4)
    check("gse225475_frozen_sections", sum(r["tissue_storage"] == "Frozen" for r in spatial), 5)
    check("gse225475_ffpe_sections", sum(r["tissue_storage"] == "FFPE" for r in spatial), 1)
    check("gse225475_missing_public_donor_ids", sum(not r["public_donor_id"] for r in spatial), 6)
    check("gse225475_overlap_unresolved", sum(r["cross_modality_donor_overlap"] == "UNRESOLVED_NO_PUBLIC_DONOR_IDS" for r in spatial), 6)
    check("gse225475_descriptive_only", sum(r["confirmatory_eligibility"] == "DESCRIPTIVE_SPATIAL_ONLY" for r in spatial), 6)
    check("gse225475_proximity_blocked", sum(r["proximity_analysis_status"] == "BLOCKED_BY_PRIMARY_PAPER_QUALITY_LIMITATION" for r in spatial), 6)
    check("gse225475_expression_not_used", sum(r["expression_matrix_accessed"] == "NO" for r in spatial), 6)
    check("paper_evidence_rows", len(evidence), 3)

    write_tsv(ROOT / "audits" / "gse173706_gse225475_integrity_checks.tsv", checks)
    print(f"PASS: {len(checks)} GSE173706/GSE225475 integrity checks")


if __name__ == "__main__":
    main()
