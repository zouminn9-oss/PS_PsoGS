options(stringsAsFactors = FALSE)

.libPaths(c(normalizePath(file.path("r_libs", "stage02")),
            normalizePath(file.path("r_libs", "stage01")), .libPaths()))
stopifnot(requireNamespace("Rsubread", quietly = TRUE))
stopifnot(as.character(packageVersion("Rsubread")) == "2.20.0")

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L || !grepl("^SRR[0-9]+$", args[[1L]])) {
  stop("usage: Rscript scripts/stage02_pilot_featurecounts.R SRR########")
}
run <- args[[1L]]
registry <- read.delim(file.path("metadata", "gse212126_library_animal_registry.tsv"),
                       check.names = FALSE, stringsAsFactors = FALSE)
stopifnot(sum(registry$srr == run) == 1L)

bam <- file.path("data", "interim", "gse212126_bam", paste0(run, ".bam"))
gtf <- file.path("references", "genomes", "GRCm38_gencode_M25",
                 "gencode.vM25.primary_assembly.annotation.gtf")
stopifnot(file.exists(bam), file.info(bam)$size > 0, file.exists(gtf))

out_root <- file.path("results", "stage02", "pilot_featurecounts", run)
audit_root <- file.path("audits", "stage02_counts")
dir.create(out_root, recursive = TRUE, showWarnings = FALSE)
dir.create(audit_root, recursive = TRUE, showWarnings = FALSE)
expected <- file.path(audit_root, paste0(run, "_pilot_strand_assignment.tsv"))
if (file.exists(expected)) stop("refusing to overwrite existing pilot audit: ", expected)

run_feature_counts <- function(strand) {
  Rsubread::featureCounts(
    files = bam,
    annot.ext = gtf,
    isGTFAnnotationFile = TRUE,
    GTF.featureType = "exon",
    GTF.attrType = "gene_id",
    useMetaFeatures = TRUE,
    allowMultiOverlap = FALSE,
    countMultiMappingReads = FALSE,
    primaryOnly = TRUE,
    strandSpecific = strand,
    isPairedEnd = TRUE,
    countReadPairs = TRUE,
    requireBothEndsMapped = TRUE,
    countChimericFragments = FALSE,
    nthreads = 8,
    tmpDir = file.path("data", "interim"),
    verbose = TRUE
  )
}

rows <- list()
for (strand in 0:2) {
  fc <- run_feature_counts(strand)
  stopifnot(ncol(fc$counts) == 1L, nrow(fc$counts) > 0L,
            all(is.finite(fc$counts)), all(fc$counts >= 0),
            all(fc$counts == round(fc$counts)))
  counts <- data.frame(gene_id = rownames(fc$counts),
                       count = as.integer(fc$counts[, 1L]),
                       check.names = FALSE)
  write.table(counts,
              file.path(out_root, paste0(run, "_gene_counts_strand", strand, ".tsv")),
              sep = "\t", quote = FALSE, row.names = FALSE)
  stat <- fc$stat
  colnames(stat)[2L] <- run
  write.table(stat,
              file.path(out_root, paste0(run, "_assignment_status_strand", strand, ".tsv")),
              sep = "\t", quote = FALSE, row.names = FALSE)
  assigned <- as.numeric(stat[stat$Status == "Assigned", 2L])
  total <- sum(as.numeric(stat[, 2L]))
  stopifnot(length(assigned) == 1L, total > 0L)
  rows[[length(rows) + 1L]] <- data.frame(
    srr = run,
    strand_specific = strand,
    assigned_fragments = assigned,
    total_classified_fragments = total,
    assignment_fraction = assigned / total,
    status = "PASS_PILOT_ONLY",
    inference_scope = "PIPELINE_QC_ONLY_NOT_STRAND_FREEZE_NOT_BIOLOGICAL_INFERENCE",
    stringsAsFactors = FALSE
  )
}

audit <- do.call(rbind, rows)
unstranded <- audit$assigned_fragments[audit$strand_specific == 0L]
audit$retention_vs_unstranded <- audit$assigned_fragments / unstranded
write.table(audit, expected, sep = "\t", quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: featureCounts pilot completed for %s; no strand choice was frozen\n", run))
