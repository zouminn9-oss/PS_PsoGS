from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parents[1]; path=ROOT/"panel_manifest.tsv"
with path.open(encoding="utf-8",newline="") as f: rows=list(csv.DictReader(f,delimiter="\t"))
fields=list(rows[0]); ready={f"8{x}" for x in "ABCDEF"}
blocked={
 "8G":"BLOCKED_NO_FROZEN_RISK_ANNOTATIONS",
 "8H":"BLOCKED_NO_COMPATIBLE_VALIDATED_PERTURBATION_REFERENCE",
 "8I":"BLOCKED_NO_FROZEN_DRUG_TARGET_NETWORK_AND_SPATIAL_LR",
 "8J":"BLOCKED_NO_PREIDENTIFIED_INDEPENDENT_SKIN_DATASET",
 "8K":"BLOCKED_NO_AUDITED_TRANSLATIONAL_EVIDENCE_MATRIX",
 "8L":"BLOCKED_NO_INDEPENDENT_HUMAN_STRESS_OR_SKIN_DRUG_VALIDATION",
}
for row in rows:
 pid=row["panel_id"]
 if pid in ready:
  low=pid.lower(); row.update({"analysis_script":"scripts/figures/figure8_analysis.py","plot_script":"scripts/figures/figure8_plot.py","source_data":f"figures/source_data/fig{low}.tsv","statistics_file":f"results/figures/fig{low}_statistics.tsv","config_file":f"config/figures/fig{low}.yaml","vector_output":f"figures/panels/fig{low}.svg","preview_output":f"figures/previews/fig{low}.png","status":"PASS","qa_status":"PASS_RENDER_DATA_PRINT","figure_ready":"YES"})
 elif pid in blocked: row.update({"status":blocked[pid],"qa_status":"NOT_RENDERED_INPUT_BLOCK","figure_ready":"NO"})
with path.open("w",encoding="utf-8",newline="") as f:
 w=csv.DictWriter(f,fieldnames=fields,delimiter="\t",lineterminator="\n"); w.writeheader(); w.writerows(rows)
print("PASS: registered Stage 08 panels and terminal blocks")
