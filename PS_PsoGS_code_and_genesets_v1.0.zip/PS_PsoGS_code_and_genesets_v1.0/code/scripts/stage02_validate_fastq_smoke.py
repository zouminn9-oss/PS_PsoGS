#!/usr/bin/env python3
"""Validate the paired FASTQ subset emitted by the Stage 02 SRA smoke test."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUN = "SRR21221234"
EXPECTED_READS = 100_000


def inspect_fastq(path: Path) -> dict[str, object]:
    digest = hashlib.sha256()
    reads = 0
    bases = 0
    n_bases = 0
    min_length = None
    max_length = 0
    first_id = ""
    last_id = ""
    min_quality_ascii = 127
    max_quality_ascii = 0
    with path.open("rb") as handle:
        while True:
            header = handle.readline()
            if not header:
                break
            sequence = handle.readline()
            plus = handle.readline()
            quality = handle.readline()
            if not (sequence and plus and quality):
                raise AssertionError(f"truncated FASTQ record in {path}")
            for line in (header, sequence, plus, quality):
                digest.update(line)
            if not header.startswith(b"@") or not plus.startswith(b"+"):
                raise AssertionError(f"invalid FASTQ markers in {path}")
            seq = sequence.rstrip(b"\r\n")
            qual = quality.rstrip(b"\r\n")
            if len(seq) != len(qual):
                raise AssertionError(f"sequence/quality length mismatch in {path}")
            identifier = header[1:].split()[0].decode("ascii")
            first_id = first_id or identifier
            last_id = identifier
            reads += 1
            bases += len(seq)
            n_bases += seq.upper().count(b"N")
            min_length = len(seq) if min_length is None else min(min_length, len(seq))
            max_length = max(max_length, len(seq))
            if qual:
                min_quality_ascii = min(min_quality_ascii, min(qual))
                max_quality_ascii = max(max_quality_ascii, max(qual))
    return {
        "file": str(path.relative_to(ROOT)).replace("\\", "/"),
        "bytes": path.stat().st_size,
        "sha256": digest.hexdigest(),
        "reads": reads,
        "bases": bases,
        "mean_read_length": bases / reads if reads else 0,
        "n_bases": n_bases,
        "n_fraction": n_bases / bases if bases else 0,
        "min_read_length": min_length or 0,
        "max_read_length": max_length,
        "first_read_id": first_id,
        "last_read_id": last_id,
        "min_quality_ascii": min_quality_ascii if reads else 0,
        "max_quality_ascii": max_quality_ascii if reads else 0,
    }


def canonical_pair_id(identifier: str) -> str:
    """Remove only conventional mate suffixes, never the run spot identifier."""
    for suffix in ("/1", "/2"):
        if identifier.endswith(suffix):
            return identifier[:-2]
    return identifier


def main() -> None:
    smoke_dir = ROOT / "data" / "interim" / "gse212126_fastq" / f"smoke_{RUN}"
    with (ROOT / "audits" / "gse212126_sra_audit.tsv").open(
        encoding="utf-8", newline=""
    ) as handle:
        metadata = [row for row in csv.DictReader(handle, delimiter="\t") if row["srr"] == RUN]
    if len(metadata) != 1:
        raise AssertionError(f"expected one cached SRA metadata row for {RUN}")
    expected_lengths = (
        float(metadata[0]["read1_average_length"]),
        float(metadata[0]["read2_average_length"]),
    )
    rows = [inspect_fastq(smoke_dir / f"{RUN}_1.fastq"),
            inspect_fastq(smoke_dir / f"{RUN}_2.fastq")]
    if any(row["reads"] != EXPECTED_READS for row in rows):
        raise AssertionError(f"expected {EXPECTED_READS} reads per mate, observed {[r['reads'] for r in rows]}")
    if any(not (50 <= int(row["min_read_length"]) <= int(row["max_read_length"]) <= 300) for row in rows):
        raise AssertionError("implausible read-length range in smoke FASTQ")
    if any(abs(float(row["mean_read_length"]) - expected) > 1.0
           for row, expected in zip(rows, expected_lengths)):
        raise AssertionError("smoke mean read length differs from cached SRA metadata by more than 1 bp")
    if any(not (33 <= int(row["min_quality_ascii"]) <= int(row["max_quality_ascii"]) <= 126)
           for row in rows):
        raise AssertionError("quality characters are outside printable Phred+33-compatible range")
    if any(float(row["n_fraction"]) >= 0.05 for row in rows):
        raise AssertionError("N fraction is at least 5% in a smoke mate")
    if canonical_pair_id(str(rows[0]["first_read_id"])) != canonical_pair_id(str(rows[1]["first_read_id"])):
        raise AssertionError("first paired read identifiers do not match")
    if canonical_pair_id(str(rows[0]["last_read_id"])) != canonical_pair_id(str(rows[1]["last_read_id"])):
        raise AssertionError("last paired read identifiers do not match")
    if abs(int(rows[0]["bases"]) - int(rows[1]["bases"])) / max(int(rows[0]["bases"]), int(rows[1]["bases"])) >= 0.01:
        raise AssertionError("mate base totals differ by at least 1%")
    for row in rows:
        row.update({
            "structure_status": "PASS",
            "paired_id_status": "PASS",
            "read_length_status": "PASS",
            "quality_encoding_status": "PASS",
            "n_fraction_status": "PASS",
        })

    out = ROOT / "audits" / "gse212126_fastq_smoke.tsv"
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    print(f"PASS: {RUN} paired FASTQ smoke subset has {EXPECTED_READS} reads per mate")


if __name__ == "__main__":
    main()
