from pathlib import Path
import hashlib
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage08"))
sys.path.insert(0, str(ROOT / "python_libs/stage04"))
import h5py
import numpy as np
import pandas as pd
from scipy.stats import binomtest, spearmanr

OUT = ROOT / "results/stage08"
OUT.mkdir(parents=True, exist_ok=True)
MATRIX_PATH = ROOT / "data/raw/stage08/CD_signatures_LM_42809x978.gctx"


def decode(value):
    return value.decode("utf-8") if isinstance(value, (bytes, np.bytes_)) else str(value)


def bh(values):
    p = np.asarray(values, float)
    order = np.argsort(p)
    q = np.empty(len(p))
    last = 1.0
    for rank in range(len(p), 0, -1):
        index = order[rank - 1]
        last = min(last, p[index] * len(p) / rank)
        q[index] = last
    return q


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


probes = pd.read_csv(ROOT / "data/raw/stage08/Probes_L1000_metadata.csv")
probe_to_symbol = dict(zip(probes.pr_id, probes.pr_gene_symbol.str.upper()))
query_genes = pd.read_csv(OUT / "query_genes.tsv", sep="\t")
drugs = pd.read_csv(ROOT / "data/raw/stage08/Drugs_metadata.csv")
preferred_names = drugs.dropna(subset=["pert_id", "pert_iname"]).drop_duplicates("pert_id").set_index("pert_id").pert_iname.to_dict()

with h5py.File(MATRIX_PATH, "r") as handle:
    matrix = handle["0/DATA/0/matrix"][:].astype(np.float32)
    probe_ids = [decode(x) for x in handle["0/META/COL/id"][:]]
    metadata = pd.DataFrame({
        key: [decode(x) for x in handle[f"0/META/ROW/{key}"][:]]
        for key in ["id", "batch", "cell_id", "pert_desc", "pert_dose", "pert_id", "pert_time"]
    })
    for key in ["SCS_centered_by_batch", "mean_cosine_dist_centered_by_batch"]:
        metadata[key] = handle[f"0/META/ROW/{key}"][:]

assert matrix.shape == (978, 42809)
assert len(metadata) == 42809 and len(probe_ids) == 978
metadata["pert_desc"] = metadata.pert_id.map(preferred_names).fillna(metadata.pert_desc)
symbols = [probe_to_symbol.get(x, "") for x in probe_ids]
assert len(set(symbols)) == 978 and all(symbols)
signature_norm = np.sqrt((matrix * matrix).sum(axis=0))
assert (signature_norm > 0).all()


def query_vector(query_id, top_n=None, drop_symbol=None):
    genes = query_genes[(query_genes.query_id == query_id) & query_genes.landmark_member.astype(bool)].copy()
    genes = genes.sort_values(["source_effect", "symbol"], ascending=[False, True])
    if top_n is not None:
        genes = genes.head(top_n)
    if drop_symbol is not None:
        genes = genes[genes.symbol != drop_symbol]
    direction = dict(zip(genes.symbol, genes.direction))
    vector = np.asarray([1.0 if direction.get(symbol) == "UP" else -1.0 if direction.get(symbol) == "DOWN" else 0.0 for symbol in symbols], dtype=np.float32)
    assert (vector > 0).any() and (vector < 0).any()
    return vector, genes


def signature_cosine(query_id, top_n=None, drop_symbol=None):
    vector, genes = query_vector(query_id, top_n=top_n, drop_symbol=drop_symbol)
    score = vector @ matrix / (np.sqrt((vector * vector).sum()) * signature_norm)
    return score.astype(np.float32), genes


def aggregate(scores, query_id, variant, infer=True):
    frame = metadata[["id", "cell_id", "pert_desc", "pert_id", "pert_dose", "pert_time"]].copy()
    frame["cosine"] = scores
    cell = frame.groupby(["pert_id", "cell_id"], as_index=False).agg(
        pert_desc=("pert_desc", lambda x: x.mode().iloc[0] if len(x.mode()) else x.iloc[0]),
        cell_median_cosine=("cosine", "median"), n_signatures=("cosine", "size")
    )
    drug = cell.groupby("pert_id", as_index=False).agg(
        pert_desc=("pert_desc", lambda x: x.mode().iloc[0] if len(x.mode()) else x.iloc[0]),
        median_cosine=("cell_median_cosine", "median"),
        q25_cosine=("cell_median_cosine", lambda x: x.quantile(.25)),
        q75_cosine=("cell_median_cosine", lambda x: x.quantile(.75)),
        fraction_cells_negative=("cell_median_cosine", lambda x: (x < 0).mean()),
        n_cell_lines=("cell_id", "nunique"),
        n_signatures=("n_signatures", "sum"),
    )
    eligible = drug.n_cell_lines >= 3
    drug["sign_test_p"] = np.nan
    if infer:
        for index, row in drug[eligible].iterrows():
            values = cell[cell.pert_id == row.pert_id].cell_median_cosine
            drug.loc[index, "sign_test_p"] = binomtest(int((values < 0).sum()), len(values), .5, alternative="two-sided").pvalue
    drug["fdr_bh"] = np.nan
    if infer:
        drug.loc[eligible, "fdr_bh"] = bh(drug.loc[eligible, "sign_test_p"])
    drug["eligible_min_3_cell_lines"] = eligible
    drug["query_id"] = query_id
    drug["variant"] = variant
    drug["reversal_rank"] = np.nan
    order = drug.loc[eligible].sort_values(["median_cosine", "pert_id"]).index
    drug.loc[order, "reversal_rank"] = np.arange(1, len(order) + 1)
    cell["query_id"] = query_id
    cell["variant"] = variant
    return cell, drug


primary_signature_rows = []
primary_cells = []
primary_drugs = []
for query_id in ["Q1_SEP", "Q2_ORDINARY_LESION"]:
    scores, genes = signature_cosine(query_id)
    rows = metadata.copy()
    rows["query_id"] = query_id
    rows["cosine"] = scores
    rows["query_landmark_genes"] = len(genes)
    primary_signature_rows.append(rows)
    cell, drug = aggregate(scores, query_id, "PRIMARY_ALL_LANDMARK_OVERLAP")
    primary_cells.append(cell)
    primary_drugs.append(drug)

signature_scores = pd.concat(primary_signature_rows, ignore_index=True)
cell_scores = pd.concat(primary_cells, ignore_index=True)
drug_scores = pd.concat(primary_drugs, ignore_index=True)
signature_scores.to_csv(OUT / "l1000_signature_cosines.tsv.gz", sep="\t", index=False, compression="gzip")
cell_scores.to_csv(OUT / "l1000_cell_context_scores.tsv.gz", sep="\t", index=False, compression="gzip")
drug_scores.to_csv(OUT / "l1000_drug_scores.tsv", sep="\t", index=False)

sensitivity_rows = []
for query_id in ["Q1_SEP", "Q2_ORDINARY_LESION"]:
    primary = drug_scores[(drug_scores.query_id == query_id) & drug_scores.eligible_min_3_cell_lines].set_index("pert_id")
    _, ranked_genes = query_vector(query_id)
    variants = [("TOP50_SOURCE_EFFECT", 50, None), ("TOP100_SOURCE_EFFECT", 100, None)]
    variants.extend([(f"DROP_{symbol}", None, symbol) for symbol in ranked_genes.head(10).symbol])
    primary_top20 = set(primary.nsmallest(20, "median_cosine").index)
    for variant, top_n, drop_symbol in variants:
        scores, used = signature_cosine(query_id, top_n=top_n, drop_symbol=drop_symbol)
        _, drug = aggregate(scores, query_id, variant, infer=False)
        test = drug[drug.eligible_min_3_cell_lines].set_index("pert_id")
        common = primary.index.intersection(test.index)
        rho = spearmanr(primary.loc[common, "median_cosine"], test.loc[common, "median_cosine"]).statistic
        overlap = len(primary_top20 & set(test.nsmallest(20, "median_cosine").index))
        sensitivity_rows.append({"query_id": query_id, "variant": variant, "genes_used": len(used), "common_eligible_drugs": len(common), "spearman_rho_primary": rho, "top20_overlap": overlap})
pd.DataFrame(sensitivity_rows).to_csv(OUT / "l1000_sensitivity.tsv", sep="\t", index=False)

wide = drug_scores[drug_scores.eligible_min_3_cell_lines].pivot(index="pert_id", columns="query_id", values="median_cosine").dropna()
wide = wide.join(metadata.drop_duplicates("pert_id").set_index("pert_id")[["pert_desc"]], how="left").reset_index()
rho = spearmanr(wide.Q1_SEP, wide.Q2_ORDINARY_LESION)
wide["rank_Q1"] = wide.Q1_SEP.rank(method="min")
wide["rank_Q2"] = wide.Q2_ORDINARY_LESION.rank(method="min")
wide["rank_difference_Q1_minus_Q2"] = wide.rank_Q1 - wide.rank_Q2
wide.to_csv(OUT / "query_rank_comparison.tsv", sep="\t", index=False)
pd.DataFrame([{"n_common_drugs": len(wide), "spearman_rho": rho.statistic, "spearman_p": rho.pvalue, "note": "Q3 excluded because score family differs"}]).to_csv(OUT / "query_rank_comparison_statistics.tsv", sep="\t", index=False)

values = wide[["Q1_SEP", "Q2_ORDINARY_LESION"]].to_numpy()
pareto = np.ones(len(wide), dtype=bool)
for i in range(len(wide)):
    pareto[i] = not np.any(np.all(values <= values[i], axis=1) & np.any(values < values[i], axis=1))
wide["pareto_nondominated_more_negative"] = pareto
wide.to_csv(OUT / "l1000_two_axis_pareto.tsv", sep="\t", index=False)

q3 = pd.read_csv(OUT / "q3_sigcom_gate.tsv", sep="\t").iloc[0]
gate = pd.DataFrame([
    {"module":"Q1_LM_cosine","status":"PASS","detail":f"222 landmark genes; {int((drug_scores.query_id=='Q1_SEP').sum())} drugs summarized"},
    {"module":"Q2_LM_cosine","status":"PASS","detail":f"744 landmark genes; {int((drug_scores.query_id=='Q2_ORDINARY_LESION').sum())} drugs summarized"},
    {"module":"Q3_LM_cosine","status":"BLOCKED_LM_TWO_SIDED_NO_DOWN_COVERAGE","detail":"7 UP and 0 DOWN landmark genes"},
    {"module":"Q3_SigCom_ranktwosided","status":q3.status,"detail":f"{int(q3.mapped_up)} UP/{int(q3.mapped_down)} DOWN; {int(q3.reversal_concordant)} returned concordant reversers"},
    {"module":"cross_family_weighted_score","status":"BLOCKED_DIFFERENT_SCORE_FAMILIES","detail":"LM cosine and SigCom z-scores are not mixed"},
    {"module":"toxicity_differentiation_risk","status":"BLOCKED_NO_FROZEN_RISK_ANNOTATIONS","detail":"L1000FWD metadata lacks audited toxicity/differentiation outcomes"},
    {"module":"BeyondCell","status":"BLOCKED_NO_COMPATIBLE_VALIDATED_PERTURBATION_REFERENCE","detail":"landmark connectivity is not a BeyondCell input substitute"},
    {"module":"drug_target_cell_space_network","status":"BLOCKED_NO_FROZEN_DRUG_TARGET_NETWORK_AND_SPATIAL_LR","detail":"Stage06 LR colocalization is blocked"},
    {"module":"independent_perturbation_validation","status":"BLOCKED_NO_PREIDENTIFIED_INDEPENDENT_SKIN_DATASET","detail":"same LINCS experiments cannot validate themselves"},
    {"module":"final_dual_benefit_hierarchy","status":"BLOCKED_NO_INDEPENDENT_HUMAN_STRESS_OR_SKIN_DRUG_VALIDATION","detail":"connectivity alone is insufficient"},
])
gate.to_csv(OUT / "stage08_module_gate.tsv", sep="\t", index=False)

inputs = [MATRIX_PATH, ROOT / "data/raw/stage08/CD_signature_metadata.csv", ROOT / "data/raw/stage08/Drugs_metadata.csv", ROOT / "data/raw/stage08/Probes_L1000_metadata.csv", ROOT / "metadata/F3_STAGE08_QUERY_FREEZE.tsv"]
pd.DataFrame([{"path":str(path.relative_to(ROOT)).replace('\\','/'),"bytes":path.stat().st_size,"sha256":sha256(path)} for path in inputs]).to_csv(OUT / "stage08_input_manifest.tsv", sep="\t", index=False)
print(f"PASS: Stage 08 L1000FWD matrix {matrix.shape}; {len(drug_scores)} query-drug rows")
print(drug_scores[drug_scores.eligible_min_3_cell_lines].sort_values(["query_id","median_cosine"]).groupby("query_id").head(10)[["query_id","pert_desc","median_cosine","fraction_cells_negative","n_cell_lines","fdr_bh"]].to_string(index=False))
