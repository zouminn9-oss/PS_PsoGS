#!/usr/bin/env python3
"""Complete-denominator and internal-consistency audit for Stage 03 influence."""

from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "audits/stage03_score_influence_checks.tsv"


def read(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main():
    checks = []

    def check(name, observed, expected):
        ok = observed == expected
        checks.append({"check_id": name, "observed": str(observed), "expected": str(expected), "status": "PASS" if ok else "FAIL"})
        if not ok: raise AssertionError(f"{name}: {observed!r} != {expected!r}")

    genes = read(ROOT / "results/stage03/influence/stage03_gene_leave_one_out.tsv")
    coverage = read(ROOT / "results/stage03/influence/stage03_score_coverage.tsv")
    summary = read(ROOT / "results/stage03/influence/stage03_influence_summary.tsv")
    sep = read(ROOT / "genesets/SEP_v1.0.tsv")
    check("influence_rows", len(genes), 5432)
    check("cohort_denominators", Counter(r["dataset_id"] for r in genes), Counter({"GSE30999": 2716, "GSE121212": 2716}))
    check("sep_rows", len(sep), 2716)
    sep_keys = {(r["human_gene_symbol"], r["sep_direction"]) for r in sep}
    for dataset in ("GSE30999", "GSE121212"):
        rows = [r for r in genes if r["dataset_id"] == dataset]
        check(f"keys::{dataset}", {(r["human_gene_symbol"], r["sep_direction"]) for r in rows}, sep_keys)
        measurable = [r for r in rows if r["measurement_status"] == "MEASURABLE"]
        expected_n = 2679 if dataset == "GSE30999" else 2585
        check(f"measurable::{dataset}", len(measurable), expected_n)
        check(f"missing::{dataset}", len(rows) - len(measurable), 2716 - expected_n)
        check(f"measurable_complete::{dataset}", all(r[f] not in ("", "NA") for r in measurable for f in
              ("loo_mean_effect", "change_from_primary", "absolute_change", "relative_absolute_change", "max_absolute_patient_change", "influence_rank")), True)
        missing = [r for r in rows if r["measurement_status"] == "NOT_MAPPABLE"]
        check(f"missing_no_effect::{dataset}", all(r["loo_mean_effect"] in ("", "NA") for r in missing), True)
        check(f"loo_identity::{dataset}", all(abs(float(r["loo_mean_effect"]) - float(r["primary_mean_effect"]) - float(r["change_from_primary"])) < 2e-15 for r in measurable), True)
        check(f"absolute_identity::{dataset}", all(abs(float(r["absolute_change"]) - abs(float(r["change_from_primary"]))) < 2e-15 for r in measurable), True)
        check(f"relative_identity::{dataset}", all(abs(float(r["relative_absolute_change"]) - float(r["absolute_change"]) / abs(float(r["primary_mean_effect"]))) < 2e-15 for r in measurable), True)
        check(f"rank_sequence::{dataset}", sorted(int(r["influence_rank"]) for r in measurable), list(range(1, expected_n + 1)))
        ranked = sorted(measurable, key=lambda r: int(r["influence_rank"]))
        check(f"rank_monotone::{dataset}", all(float(ranked[i]["absolute_change"]) >= float(ranked[i + 1]["absolute_change"]) for i in range(len(ranked) - 1)), True)
        s = next(r for r in summary if r["dataset_id"] == dataset)
        top = max(measurable, key=lambda r: float(r["absolute_change"]))
        check(f"summary_top_gene::{dataset}", s["most_influential_gene"], top["human_gene_symbol"])
        check(f"summary_max::{dataset}", abs(float(s["max_absolute_loo_change"]) - float(top["absolute_change"])) < 2e-15, True)
        check(f"max_relative_below_half_percent::{dataset}", float(s["max_relative_loo_change"]) < 0.005, True)
    check("coverage_rows", len(coverage), 4)
    check("coverage_range", all(float(r["coverage_fraction"]) > 0.94 for r in coverage), True)
    check("no_sample_below_gate", all(int(r["samples_below_threshold"]) == 0 for r in coverage), True)
    check("top_genes", {r["dataset_id"]: r["most_influential_gene"] for r in summary}, {"GSE121212": "IL36A", "GSE30999": "IL19"})
    with OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(checks)
    print(f"PASS: {len(checks)} complete-denominator score-influence checks")


if __name__ == "__main__": main()

