#!/usr/bin/env python3
"""Freeze the GSE13355 PP-PN discovery pairs without using validation data."""

from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t",
                                lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    rows = [row for row in read_tsv(ROOT / "metadata" / "sample_manifest.tsv")
            if row["dataset_id"] == "GSE13355"]
    by_patient: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        by_patient[row["donor_or_animal_id"]].append(row)

    checks: list[dict[str, object]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": observed, "expected": expected,
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: {observed!r} != {expected!r}")

    conditions = Counter(row["condition"] for row in rows)
    check("gse13355_metadata_rows", len(rows), 180)
    check("gse13355_unique_gsm", len({row["sample_id"] for row in rows}), 180)
    check("gse13355_platform", {row["platform_id"] for row in rows}, {"GPL570"})
    check("gse13355_condition_counts", conditions, Counter({"NN": 64, "PN": 58, "PP": 58}))
    check("gse13355_unique_people", len(by_patient), 122)
    check("gse13355_complete_case_pairs",
          sum({row["condition"] for row in group} == {"PN", "PP"}
              for group in by_patient.values()), 58)
    check("gse13355_unpaired_controls",
          sum({row["condition"] for row in group} == {"NN"}
              for group in by_patient.values()), 64)
    check("gse13355_noncanonical_people",
          sum({row["condition"] for row in group} not in ({"PN", "PP"}, {"NN"})
              for group in by_patient.values()), 0)
    check("gse13355_validation_datasets_accessed", 0, 0,
          "pair registry is derived only from GSE13355 metadata")

    raw_path = ROOT / "data" / "raw" / "GSE13355" / "GSE13355_RAW.tar"
    raw_complete = raw_path.is_file() and raw_path.stat().st_size == 955_514_880
    raw_audit_path = (ROOT / "audits" / "stage02_gse13355" /
                      "gse13355_raw_archive_checks.tsv")
    raw_audit_pass = (raw_audit_path.is_file() and
                      all(row["status"] == "PASS" for row in read_tsv(raw_audit_path)))
    raw_status = ("PASS_RAW_CEL_AUDIT" if raw_complete and raw_audit_pass else
                  "READY_FOR_ARCHIVE_AUDIT" if raw_complete else "PENDING_ARCHIVE_DOWNLOAD")
    registry: list[dict[str, object]] = []
    for patient, group in sorted(by_patient.items(), key=lambda item: int(item[0])):
        indexed = {row["condition"]: row for row in group}
        if set(indexed) != {"PN", "PP"}:
            continue
        registry.append({
            "patient_id": patient,
            "pn_gsm": indexed["PN"]["sample_id"],
            "pp_gsm": indexed["PP"]["sample_id"],
            "pn_title": indexed["PN"]["sample_title"],
            "pp_title": indexed["PP"]["sample_title"],
            "primary_contrast": "PP-PN",
            "statistical_unit": "paired_patient",
            "pair_metadata_status": "PASS_EXACT_PATIENT_ID",
            "raw_cel_status": raw_status,
            "development_role": "HUMAN_DISCOVERY_ONLY",
        })
    check("gse13355_pair_registry_rows", len(registry), 58)
    check("gse13355_unique_pn_gsm", len({row["pn_gsm"] for row in registry}), 58)
    check("gse13355_unique_pp_gsm", len({row["pp_gsm"] for row in registry}), 58)
    check("gse13355_disjoint_pair_samples",
          bool({row["pn_gsm"] for row in registry} & {row["pp_gsm"] for row in registry}), False)
    check("gse13355_primary_contrast", {row["primary_contrast"] for row in registry}, {"PP-PN"})
    check("gse13355_statistical_unit", {row["statistical_unit"] for row in registry},
          {"paired_patient"})
    check("gse13355_nn_excluded_from_primary_contrast",
          any(row["condition"] == "NN" and row["sample_id"] in
              ({entry["pn_gsm"] for entry in registry} | {entry["pp_gsm"] for entry in registry})
              for row in rows), False)

    write_tsv(ROOT / "metadata" / "gse13355_pp_pn_pair_registry.tsv", registry)
    write_tsv(ROOT / "audits" / "stage02_gse13355" / "gse13355_pair_metadata_checks.tsv", checks)
    print(f"PASS: froze {len(registry)} exact PP-PN pairs; raw status={raw_status}; "
          f"{len(checks)} metadata checks passed")


if __name__ == "__main__":
    main()
