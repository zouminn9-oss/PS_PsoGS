from pathlib import Path
import hashlib,sys
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import pandas as pd
OUT=ROOT/"results/stage08"; OUT.mkdir(parents=True,exist_ok=True)

landmark=set(pd.read_csv(ROOT/"data/raw/stage08/Probes_L1000_metadata.csv").pr_gene_symbol.astype(str).str.upper())
sep=pd.read_csv(ROOT/"genesets/SEP_v1.0.tsv",sep="\t")
q1=pd.DataFrame({"query_id":"Q1_SEP","symbol":sep.human_gene_symbol.str.upper(),"direction":sep.sep_direction,"source_effect":sep.H_logFC.abs(),"source":"SEP_v1.0_full_frozen"})
h=pd.read_csv(ROOT/"results/stage02/gse13355/gse13355_H_paired_all_genes.tsv",sep="\t")
h=h[(h.FDR<.05)&h.gene_symbol.notna()].sort_values(["FDR","gene_symbol"]).drop_duplicates("gene_symbol")
q2=pd.DataFrame({"query_id":"Q2_ORDINARY_LESION","symbol":h.gene_symbol.str.upper(),"direction":h.direction,"source_effect":h.logFC.abs(),"source":"GSE13355_H_all_FDR_lt_0.05"})
ctra=pd.read_csv(ROOT/"genesets/ctra_kohrt2016_v1.0.tsv",sep="\t")
q3=pd.DataFrame({"query_id":"Q3_CTRA","symbol":ctra.normalized_symbol.str.upper(),"direction":ctra.direction,"source_effect":ctra.weight.abs(),"source":"CTRA_Kohrt2016_fixed"})
allq=pd.concat([q1,q2,q3],ignore_index=True)
allq=allq[allq.direction.isin(["UP","DOWN"])].drop_duplicates(["query_id","symbol"],keep="first")
allq["landmark_member"]=allq.symbol.isin(landmark)
allq["effect_rank_within_query"]=allq.groupby("query_id").source_effect.rank(method="first",ascending=False).astype(int)
allq.to_csv(OUT/"query_genes.tsv",sep="\t",index=False)

rows=[]
for q,g in allq.groupby("query_id",sort=False):
  lm=g[g.landmark_member]
  lm_ok=(lm.direction=="UP").sum()>0 and (lm.direction=="DOWN").sum()>0
  route="L1000FWD_LM_COSINE" if lm_ok else "SIGCOM_RANKTWOSIDED_SEPARATE_SCORE_PENDING"
  status="PASS_LANDMARK_TWO_SIDED" if lm_ok else "BLOCKED_LM_TWO_SIDED_NO_DOWN_COVERAGE"
  rows.append({"freeze_id":"F3_STAGE08_v1.0","query_id":q,"source":g.source.iloc[0],"total_genes":len(g),"total_up":(g.direction=="UP").sum(),"total_down":(g.direction=="DOWN").sum(),"landmark_genes":len(lm),"landmark_up":(lm.direction=="UP").sum(),"landmark_down":(lm.direction=="DOWN").sum(),"connectivity_route":route,"landmark_gate_status":status,"primary_rule":"all source genes; LM overlap only for LM cosine route","query_direction":"original pathology UP/DOWN; seek reversal","frozen_before_connectivity":"YES"})
reg=pd.DataFrame(rows); reg.to_csv(OUT/"query_registry.tsv",sep="\t",index=False)

def sha(p):
  x=hashlib.sha256();
  with p.open("rb") as f:
    for b in iter(lambda:f.read(1024*1024),b""): x.update(b)
  return x.hexdigest().upper()
files=[ROOT/"genesets/SEP_v1.0.tsv",ROOT/"results/stage02/gse13355/gse13355_H_paired_all_genes.tsv",ROOT/"genesets/ctra_kohrt2016_v1.0.tsv",ROOT/"data/raw/stage08/Probes_L1000_metadata.csv",OUT/"query_genes.tsv",OUT/"query_registry.tsv",ROOT/"config/stage08_connectivity.yaml"]
pd.DataFrame([{"freeze_id":"F3_STAGE08_v1.0","path":str(p.relative_to(ROOT)).replace('\\','/'),"bytes":p.stat().st_size,"sha256":sha(p),"connectivity_values_accessed_before_freeze":"NO"} for p in files]).to_csv(ROOT/"metadata/F3_STAGE08_QUERY_FREEZE.tsv",sep="\t",index=False)
assert len(reg)==3 and (reg.total_up>0).all() and (reg.total_down>0).all()
assert (reg.query_id.eq("Q3_CTRA") & reg.landmark_gate_status.eq("BLOCKED_LM_TWO_SIDED_NO_DOWN_COVERAGE")).sum()==1
print("PASS: F3 frozen before connectivity values")
print(reg.to_string(index=False))
