#!/usr/bin/env python3
"""Write SHA-256 checksums for frozen Stage 01 GSE70603 artifacts."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = [
    "config/gse70603_stage01.yaml",
    "metadata/gse70603_analysis_samples.tsv",
    "metadata/gse70603_platform_annotation.tsv",
    "data/processed/GSE70603_processed_log2_matrix.tsv.gz",
    "data/processed/GSE70603_gene_within_subject_differences.rds",
    "results/stage01/GSE70603_probe_statistics.tsv.gz",
    "results/stage01/GSE70603_gene_statistics.tsv.gz",
    "results/stage01/GSE70603_contrast_summary.tsv",
    "genesets/GSE70603_time_locked_stress_v1.0.tsv",
    "genesets/GSE70603_time_locked_stress_v1.1_hgnc_2026-09-10.tsv",
    "audits/gse70603_result_integrity_checks.tsv",
    "audits/gse70603_hgnc_mapping_audit.tsv",
    "audits/GSE70603_sessionInfo.txt",
    "scripts/stage01_extract_gse70603.py",
    "scripts/stage01_extract_gse70603_platform.py",
    "scripts/stage01_analyze_gse70603.R",
    "scripts/stage01_validate_gse70603.py",
    "scripts/stage01_map_gse70603_hgnc.py",
    "config/stage01_gse70603_qc_figure.yaml",
    "figures/source_data/stage01_gse70603_qc_panel_a.tsv",
    "figures/source_data/stage01_gse70603_qc_panel_b.tsv",
    "figures/source_data/stage01_gse70603_qc_panel_c.tsv",
    "figures/qc/stage01_gse70603_qc.svg",
    "figures/qc/stage01_gse70603_qc.png",
    "figures/captions/stage01_gse70603_qc.md",
    "scripts/stage01_plot_gse70603_qc.R",
    "scripts/stage01_validate_gse70603_qc_figure.py",
    "audits/stage01_gse70603_qc_figure_checks.tsv",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    rows = []
    for relative in ARTIFACTS:
        path = ROOT / relative
        if not path.exists():
            raise FileNotFoundError(path)
        rows.append({
            "artifact": relative,
            "bytes": str(path.stat().st_size),
            "sha256": sha256(path),
            "frozen_local_date": "2026-09-10",
        })
    output = ROOT / "audits" / "gse70603_stage01_artifact_checksums.tsv"
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    print(f"PASS: wrote checksums for {len(rows)} Stage 01 artifacts")


if __name__ == "__main__":
    main()
