#!/usr/bin/env python3
"""Validate the frozen GSE212126 design and contrast matrices."""

from __future__ import annotations

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main() -> None:
    design = read_tsv(ROOT / "results" / "stage02" / "gse212126_design_matrix.tsv")
    contrast = read_tsv(ROOT / "results" / "stage02" / "gse212126_contrast_matrix.tsv")
    estimands = read_tsv(ROOT / "results" / "stage02" / "gse212126_estimand_registry.tsv")
    assert len(design) == 12
    assert len({row["canonical_animal_id"] for row in design}) == 12
    assert len({row["srr"] for row in design}) == 12
    assert all(row["statistical_unit"] == "independent_mouse" for row in design)
    assert all(row["pooling_status"] == "NO_POOLING_USER_CONFIRMED" for row in design)
    assert {row["condition"] for row in design} == {"Control", "CRS", "IMQ", "CRS+IMQ"}
    assert all(sum(row["condition"] == condition for row in design) == 3
               for condition in ("Control", "CRS", "IMQ", "CRS+IMQ"))
    expected = {
        "Intercept": (0, 0, 0),
        "CRS": (1, 1, 0),
        "IMQ": (0, 0, 0),
        "CRS_by_IMQ": (0, 1, 1),
    }
    assert {row["coefficient"]: (int(row["S0"]), int(row["SD"]), int(row["I"]))
            for row in contrast} == expected
    assert [row["estimand"] for row in estimands] == ["S0", "SD", "I"]
    assert all(
        row["current_result_status"] == "ESTIMATED_MOUSE_FACTORIAL;VALIDATION_NOT_ACCESSED"
        for row in estimands
    )
    assert all(row["correction"] == "Benjamini-Hochberg" for row in estimands)
    print("PASS: frozen 12-mouse full-rank design and S0/SD/I contrast registry")


if __name__ == "__main__":
    main()
