#!/usr/bin/env python3
"""Build a non-inferential per-library Stage 02 processing ledger."""

from __future__ import annotations

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read_tsv(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        return []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main() -> None:
    registry = read_tsv(ROOT / "metadata" / "gse212126_library_animal_registry.tsv")
    if len(registry) != 12 or len({row["canonical_animal_id"] for row in registry}) != 12:
        raise SystemExit("expected 12 unique independent-mouse registry rows")
    downloads = {
        row["srr"]: row
        for row in read_tsv(ROOT / "audits" / "gse212126_sra_download_state.tsv")
    }

    output = []
    for row in registry:
        run = row["srr"]
        download = downloads.get(run, {})
        sra_file = ROOT / "data" / "raw" / "gse212126_sra" / run / f"{run}.sra"
        fastq = read_tsv(ROOT / "audits" / "stage02_fastq" / f"{run}_full_fastq.tsv")
        compressed = read_tsv(ROOT / "audits" / "stage02_fastq" / f"{run}_compressed_fastq.tsv")
        bam = read_tsv(ROOT / "audits" / "stage02_alignment" / f"{run}_bam.tsv")
        metrics = read_tsv(ROOT / "audits" / "stage02_alignment" / f"{run}_subjunc_metrics.tsv")
        pilot = read_tsv(ROOT / "audits" / "stage02_counts" / f"{run}_pilot_strand_assignment.tsv")

        sra_pass = (
            download.get("integrity_status") == "PASS"
            and download.get("vdb_validate_status") == "PASS"
        )
        sra_status = "PASS" if sra_pass else ("DOWNLOADING_UNVERIFIED" if sra_file.is_file() else "PENDING")
        fastq_pass = (
            len(fastq) == 2
            and len(compressed) == 2
            and all(item.get("structure_status") == "PASS" for item in fastq)
            and all(item.get("gzip_test_status") == "PASS" for item in compressed)
        )
        arithmetic = {
            item.get("metric"): item.get("status") for item in metrics
            if item.get("metric", "").endswith(("equals_total", "equals_mapped"))
        }
        alignment_pass = (
            len(bam) == 1
            and bam[0].get("status") == "PASS"
            and arithmetic == {
                "mapped_plus_unmapped_equals_total": "PASS",
                "unique_plus_multimapping_equals_mapped": "PASS",
            }
        )
        pilot_pass = (
            len(pilot) == 3
            and all(item.get("status") == "PASS_PILOT_ONLY" for item in pilot)
        )
        output.append({
            "srr": run,
            "gsm": row["gsm"],
            "canonical_animal_id": row["canonical_animal_id"],
            "condition": row["condition"],
            "independent_mouse_no_pooling": "PASS_USER_CONFIRMED",
            "sra_md5_vdb": sra_status,
            "full_fastq": "PASS" if fastq_pass else "PENDING",
            "alignment_bam": "PASS" if alignment_pass else "PENDING",
            "single_library_count_pilot": "PASS_QC_ONLY" if pilot_pass else "NOT_RUN",
            "eligible_for_final_12_library_counting": "YES" if alignment_pass else "NO",
            "biological_inference_allowed": "NO_UNTIL_ALL_12_QC_PASS",
        })

    out = ROOT / "audits" / "gse212126_run_processing_state.tsv"
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=list(output[0]), delimiter="\t", lineterminator="\n"
        )
        writer.writeheader()
        writer.writerows(output)
    print(
        "PASS: wrote 12-run ledger; "
        f"SRA={sum(row['sra_md5_vdb'] == 'PASS' for row in output)}, "
        f"FASTQ={sum(row['full_fastq'] == 'PASS' for row in output)}, "
        f"BAM={sum(row['alignment_bam'] == 'PASS' for row in output)}"
    )


if __name__ == "__main__":
    main()
