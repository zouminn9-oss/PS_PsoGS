options(stringsAsFactors = FALSE)
.libPaths(c(normalizePath(file.path("r_libs", "stage02")),
            normalizePath(file.path("r_libs", "stage01")), .libPaths()))
stopifnot(requireNamespace("edgeR", quietly = TRUE),
          requireNamespace("limma", quietly = TRUE),
          as.character(packageVersion("edgeR")) == "4.4.2",
          as.character(packageVersion("limma")) == "3.62.2")

dir.create(file.path("results", "stage03", "effects"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("results", "stage03", "scores"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("results", "stage03", "qc"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("logs"), recursive = TRUE, showWarnings = FALSE)
log_con <- file(file.path("logs", "stage03_bulk_validation.log"), open = "wt")
sink(log_con, type = "output", split = TRUE); sink(log_con, type = "message")
on.exit({sink(type = "message"); sink(type = "output"); close(log_con)}, add = TRUE)

sample_lock <- read.delim(file.path("metadata", "stage03_validation_sample_lock.tsv"), check.names = FALSE)
pair30999 <- read.delim(file.path("metadata", "gse30999_metadata_pair_registry.tsv"), check.names = FALSE)
pair30999 <- pair30999[pair30999$metadata_pair_status == "COMPLETE_EXACT_ID_PAIR", ]
sep <- read.delim(file.path("genesets", "SEP_v1.0.tsv"), check.names = FALSE)
stopifnot(nrow(pair30999) == 81L, nrow(sep) == 2716L,
          sum(sep$sep_direction == "UP") == 1399L,
          sum(sep$sep_direction == "DOWN") == 1317L)

rank_score <- function(matrix_values, feature_ids, up_ids, down_ids) {
  up_index <- match(up_ids, feature_ids); down_index <- match(down_ids, feature_ids)
  up_index <- up_index[!is.na(up_index)]; down_index <- down_index[!is.na(down_index)]
  stopifnot(length(up_index) / length(up_ids) >= 0.70,
            length(down_index) / length(down_ids) >= 0.70)
  ranks <- apply(matrix_values, 2, rank, ties.method = "average") / (nrow(matrix_values) + 1)
  colMeans(ranks[up_index, , drop = FALSE]) - colMeans(ranks[down_index, , drop = FALSE])
}

summarize_scores <- function(dataset_id, pairs) {
  delta <- pairs$lesional_score - pairs$nonlesional_score
  tt <- t.test(delta, mu = 0, alternative = "two.sided")
  wt <- suppressWarnings(wilcox.test(delta, mu = 0, alternative = "two.sided", exact = FALSE))
  data.frame(dataset_id = dataset_id, n_pairs = length(delta),
    mean_nonlesional = mean(pairs$nonlesional_score), mean_lesional = mean(pairs$lesional_score),
    mean_delta = mean(delta), median_delta = median(delta), sd_delta = sd(delta),
    standardized_mean_change = mean(delta) / sd(delta),
    positive_pairs = sum(delta > 0), negative_pairs = sum(delta < 0), zero_pairs = sum(delta == 0),
    t_statistic = unname(tt$statistic), t_df = unname(tt$parameter), t_p_value = tt$p.value,
    mean_delta_ci_low = tt$conf.int[1], mean_delta_ci_high = tt$conf.int[2],
    wilcoxon_statistic = unname(wt$statistic), wilcoxon_p_value = wt$p.value,
    primary_test = "two-sided one-sample t-test on paired LS-minus-NL differences",
    sensitivity_test = "two-sided Wilcoxon signed-rank", stringsAsFactors = FALSE)
}

# GSE30999: submitted GCRMA matrix, deterministic probe-to-gene medians.
array_df <- read.delim(gzfile(file.path("results", "stage03", "matrices",
                                       "gse30999_gcrma_entrez_gene_matrix.tsv.gz")),
                       check.names = FALSE)
array_ids <- as.character(array_df[[1]])
array_mat <- as.matrix(array_df[-1]); storage.mode(array_mat) <- "double"
rownames(array_mat) <- array_ids
stopifnot(nrow(array_mat) == 20848L, ncol(array_mat) == 170L, !anyNA(array_mat),
          all(pair30999$nl_gsm %in% colnames(array_mat)),
          all(pair30999$ls_gsm %in% colnames(array_mat)))
array_diff <- array_mat[, pair30999$ls_gsm, drop = FALSE] -
              array_mat[, pair30999$nl_gsm, drop = FALSE]
colnames(array_diff) <- pair30999$public_subject_id
array_fit <- limma::lmFit(array_diff, design = matrix(1, ncol(array_diff), 1))
array_fit <- limma::eBayes(array_fit, trend = TRUE, robust = TRUE)
array_top <- limma::topTable(array_fit, coef = 1, number = Inf, sort.by = "none")
array_effect <- data.frame(entrez_id = array_ids, logFC = array_top$logFC,
                           AveExpr = array_top$AveExpr, t = array_top$t,
                           PValue = array_top$P.Value, FDR = array_top$adj.P.Val,
                           model = "GCRMA_gene_median_paired_difference_limma_robust",
                           stringsAsFactors = FALSE)
write.table(array_effect, file.path("results", "stage03", "effects",
                                   "gse30999_paired_all_genes.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)

array_primary_gsms <- c(pair30999$nl_gsm, pair30999$ls_gsm)
array_score_all <- rank_score(array_mat[, array_primary_gsms, drop = FALSE], array_ids,
                              as.character(sep$selected_human_entrez_id[sep$sep_direction == "UP"]),
                              as.character(sep$selected_human_entrez_id[sep$sep_direction == "DOWN"]))
array_scores <- data.frame(dataset_id = "GSE30999", donor_id = pair30999$public_subject_id,
  nonlesional_sample = pair30999$nl_gsm, lesional_sample = pair30999$ls_gsm,
  nonlesional_score = unname(array_score_all[pair30999$nl_gsm]),
  lesional_score = unname(array_score_all[pair30999$ls_gsm]), stringsAsFactors = FALSE)
array_scores$delta_LS_minus_NL <- array_scores$lesional_score - array_scores$nonlesional_score
array_scores$score_definition <- "mean_fractional_rank_SEP_UP_minus_SEP_DOWN"

# GSE121212: official counts, duplicate feature labels summed before TMM.
count_df <- read.delim(gzfile(file.path("data", "raw", "validation", "GSE121212",
                                       "GSE121212_readcount.txt.gz")), check.names = FALSE)
count_ids <- as.character(count_df[[1]])
count_mat <- as.matrix(count_df[-1]); storage.mode(count_mat) <- "integer"
stopifnot(!anyNA(count_mat), all(count_mat >= 0), all(count_mat == floor(count_mat)),
          nrow(count_mat) == 31364L, ncol(count_mat) == 147L)
count_mat <- rowsum(count_mat, group = count_ids, reorder = FALSE)
stopifnot(nrow(count_mat) == 31362L, !anyDuplicated(rownames(count_mat)))
rna_lock <- sample_lock[sample_lock$dataset_id == "GSE121212" &
                        sample_lock$lock_status == "PRIMARY_INCLUDE", ]
stopifnot(nrow(rna_lock) == 54L, all(rna_lock$sample_title %in% colnames(count_mat)))
rna_lock <- rna_lock[match(colnames(count_mat)[colnames(count_mat) %in% rna_lock$sample_title],
                           rna_lock$sample_title), ]
rna_counts <- count_mat[, rna_lock$sample_title, drop = FALSE]
lesion <- as.integer(rna_lock$skin_type == "lesional")
patient <- factor(rna_lock$donor_id)
design <- model.matrix(~ patient + lesion)
stopifnot(qr(design)$rank == ncol(design), ncol(design) == 28L)
y0 <- edgeR::DGEList(counts = rna_counts)
keep <- edgeR::filterByExpr(y0, design = design)
y <- y0[keep, , keep.lib.sizes = FALSE]
y <- edgeR::calcNormFactors(y, method = "TMM")
y <- edgeR::estimateDisp(y, design = design, robust = TRUE)
rna_fit <- edgeR::glmQLFit(y, design = design, robust = TRUE)
rna_test <- edgeR::glmQLFTest(rna_fit, coef = "lesion")
rna_top <- edgeR::topTags(rna_test, n = Inf, sort.by = "none")$table
rna_effect <- data.frame(human_gene_symbol = rownames(rna_top), logFC = rna_top$logFC,
                         logCPM = rna_top$logCPM, F = rna_top$F,
                         PValue = rna_top$PValue, FDR = rna_top$FDR,
                         model = "TMM_filterByExpr_paired_edgeR_robust_QL",
                         stringsAsFactors = FALSE)
write.table(rna_effect, file.path("results", "stage03", "effects",
                                 "gse121212_pso_paired_all_tested_genes.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)

y_score <- edgeR::DGEList(counts = count_mat[, rna_lock$sample_title, drop = FALSE])
y_score <- edgeR::calcNormFactors(y_score, method = "TMM")
rna_logcpm <- edgeR::cpm(y_score, log = TRUE, prior.count = 2)
rna_score_all <- rank_score(rna_logcpm, rownames(rna_logcpm),
                            sep$human_gene_symbol[sep$sep_direction == "UP"],
                            sep$human_gene_symbol[sep$sep_direction == "DOWN"])
rna_pairs <- split(rna_lock, rna_lock$donor_id)
rna_scores <- do.call(rbind, lapply(rna_pairs, function(rows) {
  nl <- rows$sample_title[rows$skin_type == "non-lesional"]
  ls <- rows$sample_title[rows$skin_type == "lesional"]
  stopifnot(length(nl) == 1L, length(ls) == 1L)
  data.frame(dataset_id = "GSE121212", donor_id = rows$donor_id[1],
             nonlesional_sample = nl, lesional_sample = ls,
             nonlesional_score = unname(rna_score_all[nl]),
             lesional_score = unname(rna_score_all[ls]), stringsAsFactors = FALSE)
}))
rownames(rna_scores) <- NULL
rna_scores$delta_LS_minus_NL <- rna_scores$lesional_score - rna_scores$nonlesional_score
rna_scores$score_definition <- "mean_fractional_rank_SEP_UP_minus_SEP_DOWN"

paired_scores <- rbind(array_scores, rna_scores)
stopifnot(nrow(paired_scores) == 108L, !anyNA(paired_scores))
write.table(paired_scores, file.path("results", "stage03", "scores", "paired_scores.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
score_stats <- rbind(summarize_scores("GSE30999", array_scores),
                     summarize_scores("GSE121212", rna_scores))
score_stats$BH_FDR_across_two_primary_cohorts <- p.adjust(score_stats$t_p_value, method = "BH")
write.table(score_stats, file.path("results", "stage03", "scores",
                                  "paired_score_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)

matrix_qc <- data.frame(
  dataset_id = c(rep("GSE30999", 7), rep("GSE121212", 10)),
  metric = c("submitted_normalization", "gene_rows", "sample_columns", "primary_samples",
             "minimum_value", "maximum_value", "nonfinite_values",
             "raw_feature_rows", "unique_feature_rows_after_sum", "sample_columns",
             "primary_samples", "minimum_count", "maximum_count", "negative_counts",
             "minimum_library_size", "maximum_library_size", "filterByExpr_genes"),
  value = c("GCRMA", nrow(array_mat), ncol(array_mat), length(array_primary_gsms),
            min(array_mat), max(array_mat), sum(!is.finite(array_mat)),
            31364, nrow(count_mat), ncol(count_mat), ncol(rna_counts), min(count_mat),
            max(count_mat), sum(count_mat < 0), min(colSums(count_mat)),
            max(colSums(count_mat)), sum(keep)),
  status = "PASS", stringsAsFactors = FALSE)
write.table(matrix_qc, file.path("results", "stage03", "qc", "validation_matrix_qc.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

software <- data.frame(component = c("R", "edgeR", "limma"),
  version = c(as.character(getRversion()), as.character(packageVersion("edgeR")),
              as.character(packageVersion("limma"))),
  role = c("analysis runtime", "GSE121212 paired robust QL", "GSE30999 paired differences"))
write.table(software, file.path("results", "stage03", "stage03_software.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

saveRDS(list(array_fit = array_fit, rna_fit = rna_fit, rna_test = rna_test,
             rna_keep = keep, rna_design = design),
        file.path("results", "stage03", "stage03_bulk_validation_fits.rds"))
cat(sprintf("PASS: GSE30999 %d pairs; GSE121212 %d pairs; score deltas %.6f and %.6f\n",
            nrow(array_scores), nrow(rna_scores), score_stats$mean_delta[1], score_stats$mean_delta[2]))
