#!/usr/bin/env python3
"""Record exact Stage 02 executable/package versions and archive checksums."""

from __future__ import annotations

import csv
import hashlib
import re
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def run_version(command: list[str]) -> str:
    result = subprocess.run(command, cwd=ROOT, check=True, capture_output=True, text=True)
    return (result.stdout or result.stderr).strip().replace("\n", " | ")


def semantic_version(output: str) -> str:
    match = re.search(r"(?<![0-9])([0-9]+(?:\.[0-9]+){2,3})(?![0-9])", output)
    if not match:
        raise RuntimeError(f"could not parse a version from: {output}")
    return match.group(1)


def main() -> None:
    toolkit_bin = ROOT / "tools" / "sratoolkit" / "sratoolkit.3.4.1-win64" / "bin"
    rows = []
    for name in ("prefetch", "vdb-validate", "fasterq-dump", "fastq-dump"):
        executable = toolkit_bin / f"{name}.exe"
        rows.append({
            "component": name,
            "version": semantic_version(run_version([str(executable), "--version"])),
            "path": str(executable.relative_to(ROOT)).replace("\\", "/"),
            "archive_sha256": sha256(ROOT / "tools" / "downloads" / "sratoolkit.3.4.1-win64.zip"),
            "role": "SRA retrieval/validation/conversion",
        })

    rscript = Path(r"C:\Program Files\R\R-4.4.1\bin\Rscript.exe")
    code = (
        ".libPaths(c(normalizePath('r_libs/stage02'),normalizePath('r_libs/stage01'),.libPaths()));"
        "for(p in c('Rsubread','edgeR','limma','locfit')) cat(p,as.character(packageVersion(p)),'\\n')"
    )
    versions = dict(line.split() for line in run_version([str(rscript), "-e", code]).split(" | "))
    for name, archive, role in (
        ("Rsubread", "Rsubread_2.20.0.zip", "splice-aware alignment and featureCounts"),
        ("edgeR", "edgeR_4.4.2.zip", "TMM and robust quasi-likelihood model"),
        ("limma", "", "edgeR dependency and existing Stage 01 model support"),
        ("locfit", "locfit_1.5-9.12.zip", "edgeR abundance-dependent dispersion dependency"),
    ):
        archive_path = ROOT / "tools" / "downloads" / archive if archive else None
        rows.append({
            "component": name,
            "version": versions[name],
            "path": f"r_libs/stage02/{name}" if name != "limma" else "r_libs/stage01/limma",
            "archive_sha256": sha256(archive_path) if archive_path else "RECORDED_IN_STAGE01",
            "role": role,
        })

    out = ROOT / "metadata" / "stage02_software_manifest.tsv"
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)
    print(f"PASS: recorded {len(rows)} Stage 02 software components")


if __name__ == "__main__":
    main()
