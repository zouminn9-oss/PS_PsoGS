#!/usr/bin/env python3
"""Normalize one Rsubread subjunc summary and fingerprint its BAM.

The first completed run was written without row names.  This strict helper
restores only the metric labels defined by Rsubread's fixed 13-row summary,
checks the two exact mapping identities, and retains the original file.
"""

from __future__ import annotations

import csv
import hashlib
import sys
from pathlib import Path


METRICS = (
    "total_fragments",
    "mapped_fragments",
    "uniquely_mapped_fragments",
    "multi_mapping_fragments",
    "unmapped_fragments",
    "properly_paired_fragments",
    "singleton_fragments",
    "chimeric_fragments",
    "unexpected_strandness_fragments",
    "unexpected_fragment_length_fragments",
    "unexpected_read_order_fragments",
    "junctions",
    "indels",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    if len(sys.argv) != 2 or not sys.argv[1].startswith("SRR"):
        raise SystemExit("usage: stage02_finalize_alignment_audit.py SRR########")
    run = sys.argv[1]
    root = Path.cwd()
    source = root / "audits" / "stage02_alignment" / f"{run}_subjunc.tsv"
    bam = root / "data" / "interim" / "gse212126_bam" / f"{run}.bam"
    if not source.is_file() or not bam.is_file():
        raise SystemExit(f"missing source audit or BAM for {run}")

    with source.open(encoding="utf-8-sig", newline="") as handle:
        table = [row for row in csv.reader(handle, delimiter="\t") if row]
    if len(table) != len(METRICS) + 1:
        raise SystemExit(f"expected header plus {len(METRICS)} values, found {len(table)} lines")
    if all(len(row) == 1 for row in table):
        values = [int(row[0]) for row in table[1:]]
    elif all(len(row) >= 2 for row in table):
        values = [int(row[-1]) for row in table[1:]]
    else:
        raise SystemExit("mixed-width subjunc audit cannot be normalized safely")
    record = dict(zip(METRICS, values, strict=True))

    checks = {
        "mapped_plus_unmapped_equals_total": (
            record["mapped_fragments"] + record["unmapped_fragments"]
            == record["total_fragments"]
        ),
        "unique_plus_multimapping_equals_mapped": (
            record["uniquely_mapped_fragments"] + record["multi_mapping_fragments"]
            == record["mapped_fragments"]
        ),
    }
    if not all(checks.values()):
        raise SystemExit(f"alignment arithmetic failed: {checks}")

    metrics_out = source.with_name(f"{run}_subjunc_metrics.tsv")
    with metrics_out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(("srr", "metric", "value", "status", "note"))
        for metric, value in record.items():
            writer.writerow((run, metric, value, "RECOVERED_PASS", "metric order from Rsubread 13-row subjunc summary"))
        for metric, passed in checks.items():
            writer.writerow((run, metric, str(passed).upper(), "PASS" if passed else "FAIL", "exact arithmetic identity"))

    bam_out = source.with_name(f"{run}_bam.tsv")
    with bam_out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(("srr", "path", "bytes", "sha256", "status"))
        writer.writerow((run, bam.as_posix(), bam.stat().st_size, sha256(bam), "PASS"))

    print(f"PASS: normalized {len(METRICS)} metrics and fingerprinted {bam.name}")


if __name__ == "__main__":
    main()
