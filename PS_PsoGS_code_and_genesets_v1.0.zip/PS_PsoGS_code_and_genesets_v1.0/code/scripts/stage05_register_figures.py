from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "panel_manifest.tsv"
with path.open(encoding="utf-8", newline="") as f:
    rows = list(csv.DictReader(f, delimiter="\t"))
fields = list(rows[0])
ready = {"4A", "4H", "5A", "5B", "5D", "5F", "5G", "5I", "5J", "5L"}
blocked = {
    "4B": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY", "4C": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY",
    "4D": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY", "4E": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY",
    "4F": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY", "4G": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY",
    "4I": "BLOCKED_NO_FDR_SIGNIFICANT_TF", "4J": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY",
    "5C": "BLOCKED_NO_SECOND_COMMUNICATION_METHOD", "5E": "BLOCKED_NO_FROZEN_NICHENET_NETWORK",
    "5H": "BLOCKED_NO_VALIDATED_FLUX_INPUT", "5K": "BLOCKED_NO_SECOND_DATABASE_METHOD",
}
for r in rows:
    pid = r["panel_id"]
    if pid in ready:
        low = pid.lower()
        r.update({
            "analysis_script": "scripts/figures/figure45_analysis.py",
            "plot_script": "scripts/figures/figure45_plot.py",
            "source_data": f"figures/source_data/fig{low}.tsv",
            "statistics_file": f"results/figures/fig{low}_statistics.tsv",
            "config_file": f"config/figures/fig{low}.yaml",
            "vector_output": f"figures/panels/fig{low}.svg",
            "preview_output": f"figures/previews/fig{low}.png",
            "status": "PASS", "qa_status": "PASS_RENDER_DATA_PRINT", "figure_ready": "YES",
        })
    elif pid in blocked:
        r.update({"status": blocked[pid], "qa_status": "NOT_RENDERED_INPUT_BLOCK", "figure_ready": "NO"})
with path.open("w", encoding="utf-8", newline="") as f:
    w = csv.DictWriter(f, fieldnames=fields, delimiter="\t", lineterminator="\n")
    w.writeheader(); w.writerows(rows)
print("PASS: registered Stage 05 terminal Figure 4/5 states")
