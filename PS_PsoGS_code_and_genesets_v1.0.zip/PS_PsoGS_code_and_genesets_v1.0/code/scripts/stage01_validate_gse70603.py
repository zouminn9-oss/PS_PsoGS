#!/usr/bin/env python3
"""Validate the frozen GSE70603 Stage 01 analysis outputs.

Checks are relation-based where possible so that a rerun cannot pass merely by
matching a copied result count.  Every check is written before a failure is
raised, leaving an auditable diagnostic table.
"""

from __future__ import annotations

import csv
import gzip
import math
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXPECTED_CONTRASTS = {
    "stress_plus45_vs_pre_all",
    "stress_plus180_vs_pre_all",
    "stress_plus180_vs_plus45_all",
    "adversity_moderation_plus45_unadjusted",
    "adversity_moderation_plus180_unadjusted",
    "adversity_moderation_plus45_age_sex_adjusted",
    "adversity_moderation_plus180_age_sex_adjusted",
}


def read_tsv(path: Path) -> list[dict[str, str]]:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def bh_adjust(values: list[float]) -> list[float]:
    n = len(values)
    order = sorted(range(n), key=values.__getitem__)
    adjusted = [1.0] * n
    running = 1.0
    for rank_index in range(n - 1, -1, -1):
        original_index = order[rank_index]
        rank = rank_index + 1
        running = min(running, values[original_index] * n / rank)
        adjusted[original_index] = min(1.0, running)
    return adjusted


def main() -> None:
    sample_rows = read_tsv(ROOT / "metadata" / "gse70603_analysis_samples.tsv")
    master_sample_rows = [
        row for row in read_tsv(ROOT / "metadata" / "sample_manifest.tsv")
        if row["dataset_id"] == "GSE70603"
    ]
    platform_rows = read_tsv(ROOT / "metadata" / "gse70603_platform_annotation.tsv")
    gene_rows = read_tsv(ROOT / "results" / "stage01" / "GSE70603_gene_statistics.tsv.gz")
    probe_rows = read_tsv(ROOT / "results" / "stage01" / "GSE70603_probe_statistics.tsv.gz")
    summary_rows = read_tsv(ROOT / "results" / "stage01" / "GSE70603_contrast_summary.tsv")
    candidate_rows = read_tsv(ROOT / "genesets" / "GSE70603_time_locked_stress_v1.0.tsv")
    mapped_rows = read_tsv(
        ROOT / "genesets" / "GSE70603_time_locked_stress_v1.1_hgnc_2026-09-10.tsv")
    ledger_rows = read_tsv(ROOT / "metadata" / "gene_evidence_ledger.tsv")
    signature_rows = read_tsv(ROOT / "metadata" / "signature_registry.tsv")

    checks: list[dict[str, str]] = []

    def check(check_id: str, observed, expected, note: str = "") -> None:
        passed = observed == expected
        checks.append({
            "check_id": check_id,
            "observed": str(observed),
            "expected": str(expected),
            "status": "PASS" if passed else "FAIL",
            "note": note,
        })

    check("sample_records", len(sample_rows), 180)
    check("sample_ids_unique", len({r["gsm"] for r in sample_rows}), 180)
    check("subjects", len({r["subject_id"] for r in sample_rows}), 60)
    subject_counts = Counter(r["subject_id"] for r in sample_rows)
    check("complete_three_timepoints", sum(value == 3 for value in subject_counts.values()), 60,
          f"subjects with non-three counts={sum(value != 3 for value in subject_counts.values())}")
    check("control_history_people",
          len({r["subject_id"] for r in sample_rows if r["history_group"] == "control_history"}), 30)
    check("early_adversity_people",
          len({r["subject_id"] for r in sample_rows if r["history_group"] == "early_adversity"}), 30)
    check("metadata_matches", sum(r["metadata_match"] == "PASS" for r in sample_rows), 180)
    check("master_manifest_group_counts", Counter(r["condition"] for r in master_sample_rows),
          Counter({"control_history": 90, "early_adversity": 90}))
    check("master_manifest_group_mapping_resolved",
          sum("requires source confirmation" in r["derivation_note"] for r in master_sample_rows), 0)

    platform_ids = {r["ID"] for r in platform_rows}
    with gzip.open(ROOT / "data" / "processed" / "GSE70603_processed_log2_matrix.tsv.gz",
                   "rt", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle, delimiter="\t")
        header = next(reader)
        matrix_ids = [row[0] for row in reader]
    check("matrix_samples", len(header) - 1, 180)
    check("matrix_probe_rows", len(matrix_ids), 50599)
    check("matrix_probe_ids_unique", len(set(matrix_ids)), 50599)
    check("matrix_platform_coverage", sum(x in platform_ids for x in matrix_ids), 50599)

    by_contrast: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in gene_rows:
        by_contrast[row["contrast_id"]].append(row)
    check("gene_contrast_set", set(by_contrast), EXPECTED_CONTRASTS)
    gene_counts = {key: len(rows) for key, rows in by_contrast.items()}
    check("genes_per_contrast_constant", len(set(gene_counts.values())), 1)
    genes_tested = next(iter(gene_counts.values()))
    check("genes_tested", genes_tested, 32080)
    check("gene_result_rows", len(gene_rows), genes_tested * len(EXPECTED_CONTRASTS))
    check("gene_result_keys_unique",
          len({(r["feature_id"], r["contrast_id"]) for r in gene_rows}), len(gene_rows))
    check("gene_statistical_unit_person", sum(r["statistical_unit"] == "person" for r in gene_rows),
          len(gene_rows))
    check("gene_n_units_60", sum(r["n_units"] == "60" for r in gene_rows), len(gene_rows))

    invalid_probability = 0
    nonfinite_numeric = 0
    max_bh_error = 0.0
    for contrast, rows in by_contrast.items():
        p_values = [float(r["p_value"]) for r in rows]
        observed_fdr = [float(r["fdr_bh"]) for r in rows]
        invalid_probability += sum(not (0.0 <= p <= 1.0 and 0.0 <= q <= 1.0)
                                   for p, q in zip(p_values, observed_fdr))
        for row in rows:
            nonfinite_numeric += sum(not math.isfinite(float(row[field]))
                                     for field in ("effect_log2", "t", "p_value", "fdr_bh", "B"))
        expected_fdr = bh_adjust(p_values)
        max_bh_error = max(max_bh_error,
                           max(abs(a - b) for a, b in zip(observed_fdr, expected_fdr)))
    check("probabilities_in_range", invalid_probability, 0)
    check("all_numeric_statistics_finite", nonfinite_numeric, 0)
    check("bh_recalculation_max_abs_error_le_1e-12", max_bh_error <= 1e-12, True,
          f"maximum absolute error={max_bh_error:.3g}")

    check("summary_rows", len(summary_rows), 7)
    check("summary_contrast_set", {r["contrast_id"] for r in summary_rows}, EXPECTED_CONTRASTS)
    for row in summary_rows:
        contrast = row["contrast_id"]
        source = by_contrast[contrast]
        check(f"summary_up_{contrast}", int(row["fdr_lt_0_05_up"]),
              sum(float(r["fdr_bh"]) < 0.05 and float(r["effect_log2"]) > 0 for r in source))
        check(f"summary_down_{contrast}", int(row["fdr_lt_0_05_down"]),
              sum(float(r["fdr_bh"]) < 0.05 and float(r["effect_log2"]) < 0 for r in source))

    early = {r["feature_id"]: r for r in by_contrast["stress_plus45_vs_pre_all"]}
    late = {r["feature_id"]: r for r in by_contrast["stress_plus180_vs_pre_all"]}
    expected_candidates = {
        gene for gene in early
        if float(early[gene]["fdr_bh"]) < 0.05 or float(late[gene]["fdr_bh"]) < 0.05
    }
    observed_candidates = {r["gene_symbol"] for r in candidate_rows}
    check("candidate_rows_unique", len(observed_candidates), len(candidate_rows))
    candidate_difference = observed_candidates ^ expected_candidates
    check("candidate_exact_union", len(candidate_difference), 0,
          "symmetric difference between saved candidates and FDR<0.05 union")
    class_errors = 0
    for row in candidate_rows:
        gene = row["gene_symbol"]
        early_sig = float(early[gene]["fdr_bh"]) < 0.05
        late_sig = float(late[gene]["fdr_bh"]) < 0.05
        same_direction = math.copysign(1, float(early[gene]["effect_log2"])) == math.copysign(
            1, float(late[gene]["effect_log2"]))
        expected_class = (
            "persistent_same_direction" if early_sig and late_sig and same_direction else
            "biphasic_opposite_direction" if early_sig and late_sig else
            "plus45_only" if early_sig else "plus180_only"
        )
        class_errors += row["response_class"] != expected_class
    check("candidate_classification_errors", class_errors, 0)
    check("candidate_evidence_label",
          sum(r["evidence_label"] ==
              "time_locked_human_laboratory_stress_response_no_unstressed_time_control"
              for r in candidate_rows), len(candidate_rows))
    check("candidate_not_core_eligible",
          sum(r["eligibility"] == "PS_REFERENCE_EVIDENCE_ONLY" for r in candidate_rows),
          len(candidate_rows))

    check("hgnc_mapping_rows", len(mapped_rows), len(candidate_rows))
    check("hgnc_mapping_raw_symbol_difference",
          len({r["raw_symbol"] for r in mapped_rows} ^ observed_candidates), 0)
    mapping_status = Counter(r["mapping_status"] for r in mapped_rows)
    check("hgnc_mapping_status_counts", mapping_status,
          Counter({"PASS": 3871, "HOLD": 553, "HOLD_COLLISION": 2}))
    pass_symbols = [r["current_hgnc_symbol"] for r in mapped_rows if r["mapping_status"] == "PASS"]
    check("hgnc_pass_symbols_nonempty", sum(bool(symbol) for symbol in pass_symbols), 3871)
    check("hgnc_pass_symbols_unique", len(set(pass_symbols)), 3871)
    check("hgnc_held_rows", sum(r["mapping_status"].startswith("HOLD") for r in mapped_rows), 555)

    gse_ledger = [r for r in ledger_rows if r["evidence_source"] == "GSE70603_TIME_LOCKED_v1.1"]
    expected_ledger_rows = sum(
        float(r["fdr_plus45"]) < 0.05 for r in candidate_rows
    ) + sum(float(r["fdr_plus180"]) < 0.05 for r in candidate_rows)
    check("gse70603_gene_ledger_rows", len(gse_ledger), expected_ledger_rows)
    check("gse70603_gene_ledger_core_ineligible",
          sum(r["core_eligibility"] in {"ANNOTATION_ONLY", "HOLD_HGNC_MAPPING"}
              for r in gse_ledger), len(gse_ledger))
    registered = [r for r in signature_rows
                  if r["signature_id"] == "GSE70603_TIME_LOCKED_v1.1_HGNC_2026-09-10"]
    check("gse70603_signature_registry_row", len(registered), 1)

    probe_contrasts = Counter(r["contrast_id"] for r in probe_rows)
    check("probe_contrast_set", set(probe_contrasts), EXPECTED_CONTRASTS)
    check("probe_rows_per_contrast", set(probe_contrasts.values()), {50599})
    check("probe_result_rows", len(probe_rows), 50599 * 7)

    analysis_text = (ROOT / "scripts" / "stage01_analyze_gse70603.R").read_text(encoding="utf-8")
    leaked = [accession for accession in ("GSE30999", "GSE121212") if accession in analysis_text]
    check("validation_accessions_absent_from_analysis_script", leaked, [])

    output = ROOT / "audits" / "gse70603_result_integrity_checks.tsv"
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(checks)

    failures = [row for row in checks if row["status"] == "FAIL"]
    if failures:
        raise AssertionError(f"{len(failures)} GSE70603 integrity checks failed; see {output}")
    print(f"PASS: {len(checks)} GSE70603 Stage 01 integrity checks; "
          f"{len(candidate_rows)} candidates")


if __name__ == "__main__":
    main()
