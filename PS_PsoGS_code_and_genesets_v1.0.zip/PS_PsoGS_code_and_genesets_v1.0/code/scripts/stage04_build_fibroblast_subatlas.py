#!/usr/bin/env python3
"""Build the label-blind fibroblast subatlas and freeze any eligible F2 subtype."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))
sys.path.insert(0, str(ROOT / "scripts"))

import anndata as ad
import harmonypy as hm
import numpy as np
import pandas as pd
import scanpy as sc
from scipy import sparse
from sklearn.decomposition import TruncatedSVD
from stage04_build_discovery_atlas import paired_effects

SEED = 20260911
MARKERS = {
    "SFRP2": ["SFRP2", "COL1A1", "COL1A2", "DCN", "C7"],
    "COL11A1": ["COL11A1", "THBS2", "POSTN", "INHBA"],
    "SFRP4": ["SFRP4", "COL6A5", "COL18A1", "WIF1", "PCOLCE2"],
    "RAMP1": ["RAMP1", "COL15A1", "APOD", "CFD", "PI16"],
}
SCORES = ["ucell_core_directed", "ucell_sep_directed", "rankmean_core_directed", "rankmean_sep_directed"]


def main():
    obs_all = pd.read_csv(ROOT / "data/processed/stage04/GSE173706_cell_metadata.tsv.gz", sep="\t")
    genes = pd.read_csv(ROOT / "data/processed/stage04/gse173706_selected_genes.tsv", sep="\t")
    counts_all = sparse.load_npz(ROOT / "data/processed/stage04/gse173706_selected_counts.npz").tocsr()
    selected = obs_all["cell_type"].eq("Fibroblast").to_numpy()
    obs = obs_all.loc[selected].reset_index(drop=True)
    counts = counts_all[selected].astype(np.float32)
    totals = np.asarray(counts.sum(axis=1)).ravel()
    normalized = sparse.diags(10000.0 / totals).dot(counts).tocsr()
    normalized.data = np.log1p(normalized.data)
    mean = np.asarray(counts.mean(axis=0)).ravel()
    mean_square = np.asarray(counts.power(2).mean(axis=0)).ravel()
    dispersion = (mean_square - mean * mean) / np.maximum(mean, 1e-8)
    eligible = mean >= 0.01
    hvg_order = np.argsort(np.where(eligible, dispersion, -np.inf))[-2000:]
    pca = TruncatedSVD(n_components=30, random_state=SEED).fit_transform(normalized[:, hvg_order]).astype(np.float32)
    harmony = hm.run_harmony(pca, obs, "sample_id", random_state=SEED, max_iter_harmony=20, verbose=False)
    integrated = np.asarray(harmony.Z_corr).T.astype(np.float32)
    atlas = ad.AnnData(X=sparse.csr_matrix((len(obs), 1), dtype=np.float32), obs=obs[["cell_id", "sample_id", "donor_id", "tissue"]].copy())
    atlas.obs_names = obs["cell_id"].astype(str).to_numpy()
    atlas.obsm["X_pca_harmony"] = integrated
    sc.pp.neighbors(atlas, n_neighbors=15, use_rep="X_pca_harmony", random_state=SEED)
    sc.tl.umap(atlas, min_dist=0.30, random_state=SEED)
    sc.tl.leiden(atlas, resolution=0.60, random_state=SEED, flavor="igraph", n_iterations=2, directed=False, key_added="fibro_leiden_06")
    obs["fibro_leiden_06"] = atlas.obs["fibro_leiden_06"].astype(str).to_numpy()
    obs["fibro_umap_1"] = atlas.obsm["X_umap"][:, 0]
    obs["fibro_umap_2"] = atlas.obsm["X_umap"][:, 1]
    symbol_cols = {}
    for j, symbol in enumerate(genes["human_gene_symbol"].fillna("").astype(str)):
        if symbol:
            symbol_cols.setdefault(symbol, []).append(j)
    evidence_rows = []
    annotation_rows = []
    for cluster in sorted(obs["fibro_leiden_06"].unique(), key=int):
        inside = obs["fibro_leiden_06"].eq(cluster).to_numpy()
        candidates = []
        for subtype, marker_list in MARKERS.items():
            evidence = 0.0; support = 0
            for marker in marker_list:
                columns = symbol_cols.get(marker, [])
                values = np.asarray(normalized[inside][:, columns].sum(axis=1)).ravel() if columns else np.array([])
                avg = float(values.mean()) if values.size else np.nan
                detected = float((values > 0).mean()) if values.size else np.nan
                support += int(np.isfinite(detected) and detected >= 0.10)
                evidence += (avg if np.isfinite(avg) else 0) * (detected if np.isfinite(detected) else 0)
                evidence_rows.append({"cluster": cluster, "candidate_subtype": subtype, "marker": marker,
                                      "mean_log1p_cp10k": avg, "detection_fraction": detected})
            candidates.append((subtype, evidence / len(marker_list), support))
        candidates.sort(key=lambda item: (-item[1], item[0]))
        best, second = candidates[:2]
        subtype = best[0] if best[2] >= 2 and best[1] >= 1.25 * max(second[1], 1e-9) else "Uncertain_fibroblast"
        annotation_rows.append({"cluster": cluster, "fibroblast_subtype": subtype, "best_candidate": best[0],
                                "best_evidence": best[1], "second_candidate": second[0], "second_evidence": second[1],
                                "supporting_markers_ge10pct": best[2], "cells": int(inside.sum()),
                                "donors": int(obs.loc[inside, "donor_id"].nunique()),
                                "max_single_donor_fraction": float(obs.loc[inside, "donor_id"].value_counts(normalize=True).max())})
    annotations = pd.DataFrame(annotation_rows)
    obs["fibroblast_subtype"] = obs["fibro_leiden_06"].map(dict(zip(annotations["cluster"], annotations["fibroblast_subtype"])))
    obs.to_csv(ROOT / "data/processed/stage04/subatlas_metadata.tsv.gz", sep="\t", index=False, compression="gzip")
    pd.DataFrame(evidence_rows).to_csv(ROOT / "results/stage04/fibroblast_subtype_marker_evidence.tsv", sep="\t", index=False)
    annotations.to_csv(ROOT / "results/stage04/fibroblast_subtype_annotations.tsv", sep="\t", index=False)

    donor = obs.groupby(["donor_id", "sample_id", "tissue", "fibroblast_subtype"], observed=True).agg(
        n_cells=("cell_id", "size"), **{score: (score, "mean") for score in SCORES}).reset_index()
    donor["cell_type"] = donor["fibroblast_subtype"]
    donor["eligible_min_cells"] = donor["n_cells"] >= 20
    effects = paired_effects(donor, SCORES)
    effects.to_csv(ROOT / "results/stage04/fibroblast_subtype_paired_effects.tsv", sep="\t", index=False)
    sep = effects.loc[(effects["program"] == "ucell_sep_directed") & effects["eligibility_min_pairs"]].copy()
    sep["eligible_target"] = (sep["cell_type"] != "Uncertain_fibroblast") & (sep["mean_pp_minus_pn"] > 0) & (sep["paired_t_fdr_bh"] < 0.05)
    candidates = sep.loc[sep["eligible_target"]].copy()
    if len(candidates):
        candidates["rank_value"] = candidates["paired_hedges_gz"].abs()
        candidates = candidates.sort_values(["rank_value", "n_complete_pairs", "cell_type"], ascending=[False, False, True])
        subtype = candidates.iloc[0]["cell_type"]
        status = "PASS_SUBTYPE"
    else:
        subtype = "UNRESOLVED"
        status = "PASS_MAJOR_TYPE_ONLY"
    freeze = pd.DataFrame([{"freeze_id": "TARGET_FREEZE_STAGE04_F2_v1.2", "status": status,
                            "major_cell_type": "Fibroblast", "fibroblast_subtype": subtype,
                            "selection_rule": "positive BH-significant SEP effect then largest absolute paired Hedges gz",
                            "replication_dataset_role": "validate major type only; subtype labels unavailable before transfer",
                            "frozen_at_utc": "2026-09-11T23:55:00Z"}])
    freeze.to_csv(ROOT / "metadata/TARGET_FREEZE_STAGE04_F2_SUBTYPE.tsv", sep="\t", index=False)
    checks = pd.DataFrame([
        {"check_id": "fibroblast_cells", "observed": len(obs), "expected": 9501},
        {"check_id": "all_subatlas_cells_annotated", "observed": obs["fibroblast_subtype"].notna().sum(), "expected": len(obs)},
        {"check_id": "subclusters_multiple", "observed": len(annotations) > 1, "expected": True},
        {"check_id": "f2_subtype_terminal", "observed": status in {"PASS_SUBTYPE", "PASS_MAJOR_TYPE_ONLY"}, "expected": True},
    ])
    checks["status"] = np.where(checks["observed"].astype(str) == checks["expected"].astype(str), "PASS", "FAIL")
    checks.to_csv(ROOT / "audits/stage04_fibroblast_subatlas_checks.tsv", sep="\t", index=False)
    if checks["status"].eq("FAIL").any():
        raise AssertionError("fibroblast subatlas audit failed")
    print(annotations.to_string(index=False))
    print(f"{status}: {subtype}")


if __name__ == "__main__":
    main()
