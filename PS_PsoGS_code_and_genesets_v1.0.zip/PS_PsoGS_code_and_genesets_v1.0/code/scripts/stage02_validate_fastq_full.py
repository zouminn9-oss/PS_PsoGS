#!/usr/bin/env python3
"""Validate every record in one full paired FASTQ conversion."""

from __future__ import annotations

import csv
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from stage02_validate_fastq_smoke import canonical_pair_id, inspect_fastq


def main() -> None:
    if len(sys.argv) != 2 or not sys.argv[1].startswith("SRR"):
        raise SystemExit("usage: stage02_validate_fastq_full.py SRR########")
    run = sys.argv[1]
    with (ROOT / "audits" / "gse212126_sra_audit.tsv").open(
        encoding="utf-8", newline=""
    ) as handle:
        metadata = [row for row in csv.DictReader(handle, delimiter="\t") if row["srr"] == run]
    if len(metadata) != 1:
        raise AssertionError(f"expected one cached SRA metadata row for {run}")
    meta = metadata[0]
    expected_spots = int(meta["total_spots"])
    expected_bases = int(meta["total_bases"])
    expected_lengths = (float(meta["read1_average_length"]), float(meta["read2_average_length"]))

    fastq_root = ROOT / "data" / "interim" / "gse212126_fastq" / f"full_{run}"
    rows = [
        inspect_fastq(fastq_root / f"{run}_1.fastq"),
        inspect_fastq(fastq_root / f"{run}_2.fastq"),
    ]
    if any(int(row["reads"]) != expected_spots for row in rows):
        raise AssertionError(f"full FASTQ read counts do not equal {expected_spots} spots per mate")
    if sum(int(row["bases"]) for row in rows) != expected_bases:
        raise AssertionError("full FASTQ base total does not equal cached SRA metadata")
    if any(abs(float(row["mean_read_length"]) - expected) > 0.1
           for row, expected in zip(rows, expected_lengths)):
        raise AssertionError("full FASTQ mean length differs from cached SRA metadata by more than 0.1 bp")
    if any(not (20 <= int(row["min_read_length"]) <= int(row["max_read_length"]) <= 300) for row in rows):
        raise AssertionError("implausible read-length range")
    if any(not (33 <= int(row["min_quality_ascii"]) <= int(row["max_quality_ascii"]) <= 126)
           for row in rows):
        raise AssertionError("quality characters are outside printable Phred+33-compatible range")
    if any(float(row["n_fraction"]) >= 0.05 for row in rows):
        raise AssertionError("N fraction is at least 5% in a full FASTQ mate")
    for key in ("first_read_id", "last_read_id"):
        if canonical_pair_id(str(rows[0][key])) != canonical_pair_id(str(rows[1][key])):
            raise AssertionError(f"paired identifiers differ at {key}")
    for row in rows:
        row.update({
            "expected_spots_per_mate": expected_spots,
            "expected_total_bases_both_mates": expected_bases,
            "structure_status": "PASS",
            "paired_id_status": "PASS",
            "read_count_status": "PASS",
            "base_total_status": "PASS",
            "read_length_status": "PASS",
            "quality_encoding_status": "PASS",
            "n_fraction_status": "PASS",
        })
    out_root = ROOT / "audits" / "stage02_fastq"
    out_root.mkdir(parents=True, exist_ok=True)
    out = out_root / f"{run}_full_fastq.tsv"
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    print(f"PASS: validated all {expected_spots} paired spots and {expected_bases} bases for {run}")


if __name__ == "__main__":
    main()
