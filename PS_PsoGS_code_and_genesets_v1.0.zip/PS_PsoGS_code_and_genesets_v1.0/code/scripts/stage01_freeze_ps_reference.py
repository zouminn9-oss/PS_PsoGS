#!/usr/bin/env python3
"""Freeze the layered PS-Reference registry and endocrine GO annotations.

The outputs distinguish actual stress experiments from fixed literature
signatures, endocrine/pharmacologic proxies, and ontology-only annotations.
No expression matrix is read and no resource is promoted automatically into
PS-PsoGS-Core.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import json
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATE = "2026-09-10"
QUICKGO_BASE = "https://www.ebi.ac.uk/QuickGO/services"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_tsv(path: Path, rows: list[dict[str, str]]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write empty table: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def read_soft_samples(path: Path) -> list[dict[str, object]]:
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
        text = handle.read()
    records: list[dict[str, object]] = []
    for part in text.split("^SAMPLE = ")[1:]:
        record: dict[str, object] = {"gsm": part.splitlines()[0].strip(), "characteristics": []}
        for line in part.splitlines()[1:]:
            if " = " not in line:
                continue
            key, value = line.split(" = ", 1)
            if key == "!Sample_title":
                record["title"] = value
            elif key == "!Sample_description":
                record["description"] = value
            elif key == "!Sample_characteristics_ch1":
                record["characteristics"].append(value)
        records.append(record)
    return records


def characteristic(record: dict[str, object], key: str) -> str:
    prefix = f"{key.lower()}:"
    for value in record["characteristics"]:
        if str(value).lower().startswith(prefix):
            return str(value).split(":", 1)[1].strip()
    return ""


def exact_hgnc_symbols() -> set[str]:
    path = ROOT / "metadata" / "hgnc_complete_set_2026-09-10.tsv"
    with path.open(encoding="utf-8", newline="") as handle:
        rows = csv.DictReader(handle, delimiter="\t")
        return {row["symbol"] for row in rows if row.get("symbol")}


def build_design_audit() -> list[dict[str, str]]:
    g270 = read_soft_samples(ROOT / "metadata" / "geo_soft" / "GSE270713_family.soft.gz")
    g264 = read_soft_samples(ROOT / "metadata" / "geo_soft" / "GSE26487_family.soft.gz")
    groups: dict[str, list[dict[str, object]]] = defaultdict(list)
    for record in g270:
        cell_line = characteristic(record, "cell line")
        if "mouse dermal fibroblast" in cell_line:
            groups["GSE270713_MDFB"].append(record)
        elif cell_line == "HPAd":
            groups["GSE270713_HPAD"].append(record)
        else:
            groups["GSE270713_SKIN"].append(record)
    groups["GSE26487_DEX_KERATINOCYTE"].extend(g264)

    facts = {
        "GSE270713_MDFB": {
            "dataset_id": "GSE270713",
            "organism": "Mus musculus",
            "biospecimen": "primary isolated mouse dermal fibroblast culture",
            "conditions": "Control|adrenaline|ADM|ADM+adrenaline",
            "nominal_replicates": "3 libraries per condition",
            "independence": "source animal/batch identities not reported",
            "unit": "culture_library; not an independent mouse",
            "stratum": "NEUROENDOCRINE_PROXY_IN_VITRO",
            "use": "mechanism annotation and sensitivity only",
            "status": "PARTIAL",
        },
        "GSE270713_HPAD": {
            "dataset_id": "GSE270713",
            "organism": "Homo sapiens",
            "biospecimen": "commercial HPAd human preadipocyte culture",
            "conditions": "Control|adrenaline|ADM|ADM+adrenaline",
            "nominal_replicates": "3 libraries per condition",
            "independence": "no distinct donor identities; replicated cultures from one commercial cell source",
            "unit": "culture_library; not an independent human donor",
            "stratum": "NEUROENDOCRINE_PROXY_IN_VITRO",
            "use": "mechanism annotation and sensitivity only",
            "status": "PARTIAL",
        },
        "GSE270713_SKIN": {
            "dataset_id": "GSE270713",
            "organism": "Mus musculus",
            "biospecimen": "peri-lesional whole skin after SA infection",
            "conditions": "Sham+SA|Sham+SA+stress|ADX+SA|ADX+SA+stress",
            "nominal_replicates": "3 labelled libraries per condition",
            "independence": "animal identifiers not reported in GEO",
            "unit": "labelled skin library; animal independence unresolved",
            "stratum": "ACTUAL_RESTRAINT_STRESS_SKIN_CONTEXT",
            "use": "descriptive mechanism context until animal independence and count scale pass",
            "status": "PARTIAL",
        },
        "GSE26487_DEX_KERATINOCYTE": {
            "dataset_id": "GSE26487",
            "organism": "Homo sapiens",
            "biospecimen": "primary epidermal keratinocyte cultures",
            "conditions": "Control|0.1uM dexamethasone at 1h|4h|24h|48h|72h",
            "nominal_replicates": "2 independent cell batches per time-treatment cell",
            "independence": "independent batches are explicit; distinct human donor identities are not reported",
            "unit": "cell_batch within destructive time-treatment sampling",
            "stratum": "GLUCOCORTICOID_PHARMACOLOGIC_PROXY",
            "use": "keratinocyte glucocorticoid sensitivity annotation only",
            "status": "PARTIAL",
        },
    }

    rows: list[dict[str, str]] = []
    for resource_id, fact in facts.items():
        records = groups[resource_id]
        rows.append(
            {
                "resource_id": resource_id,
                "dataset_id": fact["dataset_id"],
                "sample_records": str(len(records)),
                "organism": fact["organism"],
                "biospecimen": fact["biospecimen"],
                "conditions": fact["conditions"],
                "nominal_replicates": fact["nominal_replicates"],
                "independence_status": fact["independence"],
                "statistical_unit": fact["unit"],
                "evidence_stratum": fact["stratum"],
                "allowed_use": fact["use"],
                "core_member_generation": "NO",
                "expression_matrix_accessed": "NO",
                "status": fact["status"],
                "source_url": f"https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={fact['dataset_id']}",
                "accessed_local_date": DATE,
            }
        )
    return rows


def load_term_names() -> dict[str, str]:
    names: dict[str, str] = {}
    for path in sorted((ROOT / "metadata").glob("quickgo_*_search.json")):
        with path.open(encoding="utf-8") as handle:
            payload = json.load(handle)
        for row in payload.get("results", []):
            if row.get("id") in {"GO:0071872", "GO:0071874", "GO:0071385"}:
                if row.get("isObsolete"):
                    raise AssertionError(f"Selected GO term is obsolete: {row['id']}")
                names[row["id"]] = row["name"]
    expected = {"GO:0071872", "GO:0071874", "GO:0071385"}
    if set(names) != expected:
        raise AssertionError(f"Missing GO term definitions: {expected - set(names)}")
    return names


def build_go_members() -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    approved = exact_hgnc_symbols()
    names = load_term_names()
    grouped: dict[tuple[str, str, str], dict[str, set[str] | int | str]] = {}
    snapshot_rows: list[dict[str, str]] = []

    for path in sorted((ROOT / "metadata").glob("quickgo_GO_*_exact.json")):
        with path.open(encoding="utf-8") as handle:
            payload = json.load(handle)
        if payload["pageInfo"]["total"] != 1:
            raise AssertionError(f"Pagination incomplete for {path.name}")
        taxon = "9606" if "_human_" in path.name else "10090"
        species = "Homo sapiens" if taxon == "9606" else "Mus musculus"
        go_id = next(row["goId"] for row in payload["results"])
        snapshot_rows.append(
            {
                "go_id": go_id,
                "go_name": names[go_id],
                "taxon_id": taxon,
                "species": species,
                "annotation_rows": str(payload["numberOfHits"]),
                "api_snapshot_label": f"QuickGO_exact_accessed_{DATE}",
                "go_usage": "exact",
                "descendants_included": "NO",
                "query_url": f"{QUICKGO_BASE}/annotation/search?goId={go_id}&taxonId={taxon}&goUsage=exact&limit=100&page=1",
                "cached_file": path.relative_to(ROOT).as_posix(),
                "cached_sha256": sha256(path),
                "status": "PASS",
            }
        )
        for row in payload["results"]:
            symbol = row.get("symbol") or ""
            product = row.get("geneProductId") or ""
            key = (go_id, taxon, symbol)
            if key not in grouped:
                grouped[key] = {
                    "products": set(),
                    "evidence": set(),
                    "references": set(),
                    "assigned_by": set(),
                    "qualifiers": set(),
                    "dates": set(),
                    "count": 0,
                    "species": species,
                    "go_name": names[go_id],
                }
            item = grouped[key]
            item["count"] = int(item["count"]) + 1
            if product:
                item["products"].add(product)
            for field, source_key in [
                ("evidence", "evidenceCode"),
                ("references", "reference"),
                ("assigned_by", "assignedBy"),
                ("qualifiers", "qualifier"),
                ("dates", "date"),
            ]:
                value = row.get(source_key)
                if isinstance(value, list):
                    item[field].update(str(v) for v in value if v)
                elif value:
                    item[field].add(str(value))

    member_rows: list[dict[str, str]] = []
    for (go_id, taxon, symbol), item in sorted(grouped.items()):
        human = taxon == "9606"
        member_rows.append(
            {
                "go_id": go_id,
                "go_name": str(item["go_name"]),
                "taxon_id": taxon,
                "species": str(item["species"]),
                "gene_product_ids": "|".join(sorted(item["products"])),
                "source_symbol": symbol,
                "annotation_count": str(item["count"]),
                "evidence_codes": "|".join(sorted(item["evidence"])),
                "references": "|".join(sorted(item["references"])),
                "assigned_by": "|".join(sorted(item["assigned_by"])),
                "qualifiers": "|".join(sorted(item["qualifiers"])),
                "annotation_dates": "|".join(sorted(item["dates"])),
                "hgnc_exact_status": (
                    "PASS_EXACT_APPROVED_SYMBOL"
                    if human and symbol in approved
                    else "HOLD_NOT_EXACT_HGNC_APPROVED"
                    if human
                    else "NOT_APPLICABLE_MOUSE"
                ),
                "direction": "NONE_ONTOLOGY_ANNOTATION",
                "allowed_use": "PS-PsoGS-Reference functional annotation only",
                "core_member_generation": "NO",
                "snapshot_date": DATE,
            }
        )
    return snapshot_rows, member_rows


def build_registry() -> list[dict[str, str]]:
    def row(resource_id: str, stratum: str, organism: str, exposure: str, unit: str,
            allowed: str, member_rule: str, status: str, limitation: str, source: str) -> dict[str, str]:
        return {
            "resource_id": resource_id,
            "evidence_stratum": stratum,
            "organism": organism,
            "exposure_or_definition": exposure,
            "statistical_unit": unit,
            "allowed_role": allowed,
            "member_generation_rule": member_rule,
            "automatic_directional_score": "NO",
            "automatic_core_eligibility": "NO",
            "freeze_status": status,
            "critical_limitation": limitation,
            "source_url": source,
            "freeze_date": DATE,
        }

    return [
        row("CTRA_KOHRT2016", "FIXED_HUMAN_ADVERSITY_SIGNATURE", "Homo sapiens", "chronic adversity-associated immune transcription", "fixed published indicators", "PS-Reference comparison/annotation", "exact 53 published indicators with frozen direction and HGNC mapping", "PASS", "not an acute skin-stress experiment and not a Core source", "https://pmc.ncbi.nlm.nih.gov/articles/PMC4961140/"),
        row("GSE70603_STRESS_RESPONSE", "ACTUAL_HUMAN_LAB_STRESS_TIME_LOCKED", "Homo sapiens", "single laboratory psychosocial stressor", "person; paired -45/+45/+180 minutes", "time-specific PS-Reference and future Q3 candidate source", "pre-specified paired contrasts; retain time and direction", "PASS_WITH_CAUSAL_LIMIT", "no unstressed time-control arm", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE70603"),
        row("GSE212126_FACTORIAL", "ACTUAL_MOUSE_CHRONIC_RESTRAINT_STRESS_PSORIASIS_CONTEXT", "Mus musculus", "CRS x IMQ", "independent unpooled mouse (user-confirmed; anonymous project ID)", "sole experimental stress source for frozen PS-PsoGS-Core", "use audited strandSpecific=2 edgeR S0/SD/I and Ensembl Compara release-100 reciprocal 1:1 mapping; F1 frozen", "PASS_F1_SOURCE", "animal independence/no pooling user-confirmed; 12/12 reconstruction and count/model plus F1 orthology audits passed; original animal IDs/source document remain unarchived", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE212126"),
        row("GSE270712_SCRNA", "ACTUAL_MOUSE_RESTRAINT_STRESS_SKIN_CONTEXT", "Mus musculus", "restraint stress x SA infection with SB-labelled context", "one pooled library per condition", "descriptive cell-state mechanism context", "no gene-member generation", "PARTIAL_HOLD", "three animals pooled per library; n=1 library/condition; two SB labels unresolved", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270712"),
        row("GSE270713_MDFB", "NEUROENDOCRINE_PROXY_IN_VITRO", "Mus musculus", "adrenaline +/- adipocyte differentiation medium", "culture library", "mechanism annotation/sensitivity", "no gene-member generation", "PARTIAL", "source-animal and culture-batch independence unresolved", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270713"),
        row("GSE270713_HPAD", "NEUROENDOCRINE_PROXY_IN_VITRO", "Homo sapiens", "adrenaline +/- adipocyte differentiation medium", "culture library", "mechanism annotation/sensitivity", "no gene-member generation", "PARTIAL", "commercial cell source; no independent human donors", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270713"),
        row("GSE270713_SKIN", "ACTUAL_MOUSE_RESTRAINT_STRESS_SKIN_CONTEXT", "Mus musculus", "sham/ADX x restraint stress, all SA infected", "labelled skin library", "descriptive mechanism context", "no gene-member generation until animal/count audit; never a Core substitute", "PARTIAL", "animal IDs unresolved and processed tables are normalized counts", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270713"),
        row("GSE26487_DEX_KERATINOCYTE", "GLUCOCORTICOID_PHARMACOLOGIC_PROXY", "Homo sapiens", "0.1 uM dexamethasone time course", "independent cell batch", "keratinocyte glucocorticoid sensitivity annotation", "no gene-member generation", "PARTIAL", "two batches, no explicit independent donor identities; drug exposure is not psychological stress", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE26487"),
        row("ENDOCRINE_GO_EXACT_2026-09-10", "ONTOLOGY_FUNCTIONAL_ANNOTATION", "Homo sapiens; Mus musculus", "GO:0071872; GO:0071874; GO:0071385", "gene-product annotation", "PS-PsoGS-Reference annotation only", "exact-term direct QuickGO annotations; no descendants; retain evidence codes; human overlap requires exact HGNC PASS", "PASS", "non-directional ontology membership does not establish stress response or causal effect", "https://www.ebi.ac.uk/QuickGO/"),
    ]


def main() -> None:
    design = build_design_audit()
    ontology, members = build_go_members()
    registry = build_registry()
    write_tsv(ROOT / "audits" / "ps_reference_design_audit.tsv", design)
    write_tsv(ROOT / "metadata" / "endocrine_ontology_registry.tsv", ontology)
    write_tsv(ROOT / "genesets" / f"endocrine_go_exact_{DATE}.tsv", members)
    write_tsv(ROOT / "metadata" / "ps_reference_registry.tsv", registry)
    print(f"PASS: {len(registry)} resources, {len(design)} design branches, {len(ontology)} GO snapshots, {len(members)} unique term-symbol rows")


if __name__ == "__main__":
    main()
