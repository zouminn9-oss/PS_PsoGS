#!/usr/bin/env python3
"""Independent completeness and state checks for frozen-SEP gene replication."""

from __future__ import annotations

import csv
import gzip
import math
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "audits/stage03_gene_replication_checks.tsv"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_audit(rows: list[dict[str, object]]) -> None:
    with AUDIT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)


def main() -> None:
    checks: list[dict[str, object]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": observed, "expected": expected,
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            write_audit(checks)
            raise AssertionError(f"{check_id}: observed {observed!r}; expected {expected!r}")

    signature = read_tsv(ROOT / "genesets/SEP_v1.0.tsv")
    array = {r["entrez_id"]: r for r in read_tsv(
        ROOT / "results/stage03/effects/gse30999_paired_all_genes.tsv")}
    rna = {r["human_gene_symbol"]: r for r in read_tsv(
        ROOT / "results/stage03/effects/gse121212_pso_paired_all_tested_genes.tsv")}
    output = read_tsv(ROOT / "results/stage03/gene_replication.tsv")
    summary = read_tsv(ROOT / "results/stage03/gene_replication_summary.tsv")
    coverage = read_tsv(ROOT / "metadata/stage03_platform_coverage.tsv")
    with gzip.open(ROOT / "data/raw/validation/GSE121212/GSE121212_readcount.txt.gz",
                   "rt", encoding="utf-8-sig") as handle:
        raw_features = {line.split("\t", 1)[0] for line in handle if line.strip()}

    check("gene_replication_rows", len(output), 2716)
    check("gene_replication_unique_symbols", len({r["human_gene_symbol"] for r in output}), 2716)
    check("gene_replication_unique_entrez", len({r["selected_human_entrez_id"] for r in output}), 2716)
    check("gene_replication_frozen_order", [int(r["frozen_order"]) for r in output], list(range(1, 2717)))
    check("gene_replication_directions", Counter(r["sep_direction"] for r in output),
          Counter({"UP": 1399, "DOWN": 1317}))
    check("gene_replication_signature_order", [r["human_gene_symbol"] for r in output],
          [r["human_gene_symbol"] for r in signature])
    check("gene_replication_signature_entrez", [r["selected_human_entrez_id"] for r in output],
          [r["selected_human_entrez_id"] for r in signature])

    expected_array_states = Counter()
    expected_rna_states = Counter()
    invalid_rows = 0
    for gene, observed in zip(signature, output):
        expected_sign = 1 if gene["sep_direction"] == "UP" else -1
        array_effect = array.get(gene["selected_human_entrez_id"])
        rna_effect = rna.get(gene["human_gene_symbol"])
        if array_effect is None:
            expected_array = "NOT_PLATFORM_MAPPABLE"
        else:
            signed = float(array_effect["logFC"]) * expected_sign
            expected_array = ("CONCORDANT" if signed > 0 else "DISCORDANT" if signed < 0 else "ZERO_EFFECT")
            if signed != 0:
                expected_array += "_FDR_LT_0.05" if float(array_effect["FDR"]) < 0.05 else "_FDR_GE_0.05"
        if gene["human_gene_symbol"] not in raw_features:
            expected_rna = "NOT_PLATFORM_MAPPABLE"
        elif rna_effect is None:
            expected_rna = "FILTERED_LOW_EXPRESSION"
        else:
            signed = float(rna_effect["logFC"]) * expected_sign
            expected_rna = ("CONCORDANT" if signed > 0 else "DISCORDANT" if signed < 0 else "ZERO_EFFECT")
            if signed != 0:
                expected_rna += "_FDR_LT_0.05" if float(rna_effect["FDR"]) < 0.05 else "_FDR_GE_0.05"
        expected_array_states[expected_array] += 1
        expected_rna_states[expected_rna] += 1
        invalid_rows += observed["array_state"] != expected_array or observed["rnaseq_state"] != expected_rna
        if array_effect is not None:
            invalid_rows += abs(float(observed["array_logFC"]) - float(array_effect["logFC"])) > 1e-14
            invalid_rows += abs(float(observed["array_FDR"]) - float(array_effect["FDR"])) > 1e-14
        if rna_effect is not None:
            invalid_rows += abs(float(observed["rnaseq_logFC"]) - float(rna_effect["logFC"])) > 1e-14
            expected_stat = math.copysign(math.sqrt(float(rna_effect["F"])), float(rna_effect["logFC"]))
            invalid_rows += abs(float(observed["rnaseq_signed_sqrt_F"]) - expected_stat) > 1e-14

    check("gene_replication_row_recalculation_failures", invalid_rows, 0)
    check("gene_replication_array_states", Counter(r["array_state"] for r in output), expected_array_states)
    check("gene_replication_rnaseq_states", Counter(r["rnaseq_state"] for r in output), expected_rna_states)
    check("gene_replication_array_state_counts", expected_array_states,
          Counter({"CONCORDANT_FDR_LT_0.05": 1940, "CONCORDANT_FDR_GE_0.05": 421,
                   "DISCORDANT_FDR_GE_0.05": 202, "DISCORDANT_FDR_LT_0.05": 116,
                   "NOT_PLATFORM_MAPPABLE": 37}))
    check("gene_replication_rna_state_counts", expected_rna_states,
          Counter({"CONCORDANT_FDR_LT_0.05": 2070, "CONCORDANT_FDR_GE_0.05": 263,
                   "DISCORDANT_FDR_GE_0.05": 134, "DISCORDANT_FDR_LT_0.05": 105,
                   "FILTERED_LOW_EXPRESSION": 13, "NOT_PLATFORM_MAPPABLE": 131}))
    check("gene_replication_cross_states", Counter(r["cross_cohort_state"] for r in output),
          Counter({"BOTH_DIRECTION_CONCORDANT": 2065, "MIXED_DIRECTION": 406,
                   "ARRAY_ONLY_TESTED_CONCORDANT": 123, "BOTH_DIRECTION_DISCORDANT": 66,
                   "RNASEQ_ONLY_TESTED_CONCORDANT": 35, "ARRAY_ONLY_TESTED_DISCORDANT": 19,
                   "NOT_TESTED_EITHER": 2}))
    check("gene_replication_both_tested", sum(r["both_tested"] == "YES" for r in output), 2537)
    check("gene_replication_both_concordant", sum(r["both_direction_concordant"] == "YES" for r in output), 2065)
    check("gene_replication_both_strict", sum(r["both_strict_replication"] == "YES" for r in output), 1589)

    coverage_map = {(r["dataset_id"], r["signature_id"]): int(r["measurable_members"])
                    for r in coverage}
    check("gene_replication_array_coverage",
          sum(r["array_platform_mappable"] == "YES" for r in output), coverage_map[("GSE30999", "SEP")])
    check("gene_replication_rna_coverage",
          sum(r["rnaseq_platform_mappable"] == "YES" for r in output), coverage_map[("GSE121212", "SEP")])
    check("gene_replication_summary_rows", len(summary), 9)
    summary_map = {(r["dataset_id"], r["direction_stratum"]): r for r in summary}
    expected_all = {
        "GSE30999": (2679, 2361, 318, 1940, 116),
        "GSE121212": (2572, 2333, 239, 2070, 105),
        "BOTH": (2537, 2065, 66, 1589, 195),
    }
    for dataset, values in expected_all.items():
        row = summary_map[(dataset, "ALL")]
        observed = tuple(int(row[field]) for field in (
            "tested_members", "direction_concordant", "direction_discordant",
            "strict_replication", "discordant_FDR_lt_0.05"))
        check(f"gene_replication_summary::{dataset}", observed, values)

    cfg = (ROOT / "config/stage03_gene_replication.yaml").read_text(encoding="utf-8")
    for rule in ("frozen_members: 2716", "effect_size_threshold: \"none\"",
                 "filtered_low_expression_is_direction_failure: false",
                 "missing_platform_feature_is_direction_failure: false",
                 "gene_display_selection: \"none", "validation_to_signature_feedback: false"):
        check(f"gene_replication_rule::{rule}", rule in cfg, True)
    check("gene_replication_finite_tested_array",
          all(math.isfinite(float(r["array_logFC"])) and math.isfinite(float(r["array_FDR"]))
              for r in output if r["array_tested"] == "YES"), True)
    check("gene_replication_finite_tested_rna",
          all(math.isfinite(float(r["rnaseq_logFC"])) and math.isfinite(float(r["rnaseq_FDR"]))
              for r in output if r["rnaseq_tested"] == "YES"), True)

    write_audit(checks)
    print(f"PASS: {len(checks)} frozen-SEP gene replication completeness and state checks")


if __name__ == "__main__":
    main()
