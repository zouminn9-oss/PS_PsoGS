#!/usr/bin/env python3
"""Independent QA for Ensembl-100 orthology and F1 discovery signatures."""

from __future__ import annotations

import csv
import gzip
import hashlib
import math
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE_SPECS = {
    "mouse_protein": {
        "path": "references/ensembl_release100_compara/Compara.100.mouse.protein_default.homologies.tsv.gz",
        "bytes": 140_988_833,
        "sha256": "eac2cb6d24810a93b5d33bdc822e4759bc595ed3b0c93e0bf19e2912836275e2",
        "etag": "86751a1-59f6b7de48a80",
        "url": "https://ftp.ensembl.org/pub/release-100/tsv/ensembl-compara/homologies/mus_musculus/Compara.100.protein_default.homologies.tsv.gz",
    },
    "mouse_ncrna": {
        "path": "references/ensembl_release100_compara/Compara.100.mouse.ncrna_default.homologies.tsv.gz",
        "bytes": 20_209_380,
        "sha256": "5afde1d1f172252ddc1329582ddee5d2390c716c101cd686cd746d097320a30e",
        "etag": "1345ee4-59f8c4071f040",
        "url": "https://ftp.ensembl.org/pub/release-100/tsv/ensembl-compara/homologies/mus_musculus/Compara.100.ncrna_default.homologies.tsv.gz",
    },
    "human_protein": {
        "path": "references/ensembl_release100_compara/Compara.100.human.protein_default.homologies.tsv.gz",
        "bytes": 147_349_199,
        "sha256": "c744bef0769d20fd9f5131d95486d888b0bd5080995f90e496c2fa41500aacfc",
        "etag": "8c85ecf-59f6d37dc7640",
        "url": "https://ftp.ensembl.org/pub/release-100/tsv/ensembl-compara/homologies/homo_sapiens/Compara.100.protein_default.homologies.tsv.gz",
    },
    "human_ncrna": {
        "path": "references/ensembl_release100_compara/Compara.100.human.ncrna_default.homologies.tsv.gz",
        "bytes": 36_834_898,
        "sha256": "9a4b3b3662e20d2878510e70b562f32588e6ab4a045e6dbc0e21849a310c4ac5",
        "etag": "2320e52-59f8c26b22440",
        "url": "https://ftp.ensembl.org/pub/release-100/tsv/ensembl-compara/homologies/homo_sapiens/Compara.100.ncrna_default.homologies.tsv.gz",
    },
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def bsd_sum(path: Path) -> int:
    checksum = 0
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            for byte in block:
                checksum = ((checksum >> 1) | ((checksum & 1) << 15))
                checksum = (checksum + byte) & 0xFFFF
    return checksum


def read_tsv(path: Path, compressed: bool = False) -> list[dict[str, str]]:
    opener = gzip.open if compressed else open
    with opener(path, "rt" if compressed else "r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def normalized_source_pairs() -> tuple[set[tuple[str, str, str, str]], Counter[str]]:
    pairs: set[tuple[str, str, str, str]] = set()
    orientations: Counter[str] = Counter()
    expected_header = [
        "gene_stable_id", "protein_stable_id", "species", "identity", "homology_type",
        "homology_gene_stable_id", "homology_protein_stable_id", "homology_species",
        "homology_identity", "dn", "ds", "goc_score", "wga_coverage",
        "is_high_confidence", "homology_id",
    ]
    for source_id, spec in SOURCE_SPECS.items():
        path = ROOT / str(spec["path"])
        with gzip.open(path, "rt", newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle, delimiter="\t")
            if reader.fieldnames != expected_header:
                raise AssertionError(f"Unexpected homology header in {path}")
            for row in reader:
                if row["species"] == "mus_musculus" and row["homology_species"] == "homo_sapiens":
                    mouse, human, orientation = row["gene_stable_id"], row["homology_gene_stable_id"], "mouse_left"
                elif row["species"] == "homo_sapiens" and row["homology_species"] == "mus_musculus":
                    mouse, human, orientation = row["homology_gene_stable_id"], row["gene_stable_id"], "mouse_right_normalized"
                else:
                    continue
                pairs.add((mouse, human, row["homology_type"], row["homology_id"]))
                orientations[orientation] += 1
    return pairs, orientations


def parse_gmt(path: Path) -> dict[str, list[str]]:
    result: dict[str, list[str]] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        fields = line.split("\t")
        if len(fields) < 2:
            raise AssertionError(f"Malformed GMT line in {path}")
        result[fields[0]] = fields[2:]
    return result


def sign(value: float) -> str:
    return "UP" if value > 0 else ("DOWN" if value < 0 else "ZERO")


def expected_interaction_class(s0: float, sd: float) -> str:
    if sign(s0) != sign(sd):
        return "reversal"
    if abs(sd) > abs(s0):
        return "augmentation"
    if abs(sd) < abs(s0):
        return "attenuation"
    return "unchanged_magnitude"


def main() -> None:
    source_checks: list[dict[str, object]] = []
    signature_checks: list[dict[str, object]] = []

    def check(target: list[dict[str, object]], check_id: str, observed: object, expected: object, note: str = "") -> None:
        target.append(
            {
                "check_id": check_id,
                "observed": observed,
                "expected": expected,
                "status": "PASS" if observed == expected else "FAIL",
                "note": note,
            }
        )

    source_manifest: list[dict[str, object]] = []
    for source_id, spec in SOURCE_SPECS.items():
        path = ROOT / str(spec["path"])
        observed_hash = sha256(path)
        gzip_ok = True
        try:
            with gzip.open(path, "rb") as handle:
                while handle.read(8 * 1024 * 1024):
                    pass
        except Exception:
            gzip_ok = False
        check(source_checks, f"{source_id}_bytes", path.stat().st_size, spec["bytes"])
        check(source_checks, f"{source_id}_sha256", observed_hash, spec["sha256"])
        check(source_checks, f"{source_id}_gzip_crc", gzip_ok, True)
        source_manifest.append(
            {
                "source_id": source_id,
                "provider": "Ensembl Compara",
                "release": 100,
                "url": spec["url"],
                "http_etag": spec["etag"],
                "expected_bytes": spec["bytes"],
                "observed_bytes": path.stat().st_size,
                "sha256": observed_hash,
                "gzip_crc_status": "PASS" if gzip_ok else "FAIL",
            }
        )

    entrez_path = ROOT / "references/ensembl_release100_human/Homo_sapiens.GRCh38.100.entrez.tsv.gz"
    entrez_hash = sha256(entrez_path)
    check(source_checks, "human_entrez_bsd_checksum", bsd_sum(entrez_path), 7084)
    check(source_checks, "human_entrez_1kb_blocks", math.ceil(entrez_path.stat().st_size / 1024), 1462)
    source_manifest.append(
        {
            "source_id": "human_entrez_xref",
            "provider": "Ensembl",
            "release": 100,
            "url": "https://ftp.ensembl.org/pub/release-100/tsv/homo_sapiens/Homo_sapiens.GRCh38.100.entrez.tsv.gz",
            "http_etag": "not_recorded",
            "expected_bytes": "official_CHECKSUMS_1462_blocks",
            "observed_bytes": entrez_path.stat().st_size,
            "sha256": entrez_hash,
            "gzip_crc_status": "PASS",
        }
    )

    source_pairs, orientations = normalized_source_pairs()
    raw_subset = read_tsv(
        ROOT / "references/ensembl_release100_compara/mouse_human_homologies_to_human.tsv.gz",
        compressed=True,
    )
    raw_pairs = {
        (row["gene_stable_id"], row["homology_gene_stable_id"], row["homology_type"], row["homology_id"])
        for row in raw_subset
    }
    check(source_checks, "source_mouse_human_unique_rows", len(source_pairs), 26707)
    check(source_checks, "derived_raw_subset_unique_rows", len(raw_pairs), len(raw_subset))
    check(source_checks, "source_vs_derived_pair_identity", raw_pairs == source_pairs, True)
    check(source_checks, "both_source_orientations_seen", set(orientations), {"mouse_left", "mouse_right_normalized"})
    check(source_checks, "known_sox17_one2one_present",
          ("ENSMUSG00000025902", "ENSG00000164736", "ortholog_one2one") in
          {(m, h, t) for m, h, t, _ in source_pairs}, True)

    mouse_to_human: dict[str, set[str]] = defaultdict(set)
    human_to_mouse: dict[str, set[str]] = defaultdict(set)
    for mouse, human, homology_type, _ in source_pairs:
        if homology_type == "ortholog_one2one":
            mouse_to_human[mouse].add(human)
            human_to_mouse[human].add(mouse)

    entrez_map: dict[str, set[str]] = defaultdict(set)
    for row in read_tsv(entrez_path, compressed=True):
        if row["xref"].isdigit():
            entrez_map[row["gene_stable_id"]].add(row["xref"])

    orthology = read_tsv(ROOT / "metadata/mouse_human_orthology_ensembl100_ledger.tsv.gz", compressed=True)
    mouse_sd = read_tsv(ROOT / "results/stage02/factorial_edger/gse212126_SD_all_genes.tsv")
    mouse_ids = {row["gene_id"].split(".", 1)[0] for row in mouse_sd}
    check(signature_checks, "orthology_ledger_rows", len(orthology), 18484)
    check(signature_checks, "orthology_ledger_unique_mouse", len({row["mouse_ensembl_gene_id"] for row in orthology}), 18484)
    check(signature_checks, "orthology_ledger_mouse_universe",
          {row["mouse_ensembl_gene_id"] for row in orthology} == mouse_ids, True)

    status_errors = 0
    for row in orthology:
        mouse_id = row["mouse_ensembl_gene_id"]
        targets = sorted(mouse_to_human.get(mouse_id, set()))
        human_id = targets[0] if len(targets) == 1 else ""
        if not targets:
            expected_ensembl = "HOLD_NO_ONE2ONE"
        elif len(targets) != 1:
            expected_ensembl = "HOLD_AMBIGUOUS_MOUSE_TARGET"
        elif len(human_to_mouse.get(human_id, set())) != 1:
            expected_ensembl = "HOLD_NONRECIPROCAL_ONE2ONE"
        else:
            expected_ensembl = "PASS_RECIPROCAL_ONE2ONE"
        entrez_ids = sorted(entrez_map.get(human_id, set())) if human_id else []
        if expected_ensembl != "PASS_RECIPROCAL_ONE2ONE":
            expected_final = expected_ensembl
        elif not entrez_ids:
            expected_final = "HOLD_NO_HUMAN_ENTREZ"
        elif len(entrez_ids) > 1:
            expected_final = "HOLD_AMBIGUOUS_HUMAN_ENTREZ"
        else:
            expected_final = "PASS_RELIABLE_ONE2ONE_ENTREZ"
        if (
            row["ensembl_one2one_status"] != expected_ensembl
            or row["orthology_status"] != expected_final
            or row["one2one_human_targets"] != ";".join(targets)
            or row["release100_human_entrez_ids"] != ";".join(entrez_ids)
        ):
            status_errors += 1
    check(signature_checks, "orthology_status_recalculation_errors", status_errors, 0)

    cross = read_tsv(ROOT / "results/stage02/signatures/cross_species_gene_ledger.tsv.gz", compressed=True)
    check(signature_checks, "cross_ledger_rows", len(cross), 18484)
    check(signature_checks, "cross_ledger_unique_mouse", len({row["mouse_ensembl_gene_id"] for row in cross}), 18484)
    rule_errors = Counter()
    for row in cross:
        joined = row["analysis_join_status"] == "PASS_JOINED_H"
        sd_sig = float(row["SD_FDR"]) < 0.05
        i_sig = float(row["I_FDR"]) < 0.05
        h_sig = bool(row["H_FDR"]) and float(row["H_FDR"]) < 0.05
        core = joined and sd_sig and h_sig
        sd_fc = float(row["SD_logFC"])
        s0_fc = float(row["S0_logFC"])
        i_fc = float(row["I_logFC"])
        h_fc = float(row["H_logFC"]) if row["H_logFC"] else math.nan
        sep = core and sign(sd_fc) == sign(h_fc)
        interaction = core and i_sig
        high_conf = sep and i_sig and sign(i_fc) == sign(sd_fc) == sign(h_fc) and abs(sd_fc) > abs(s0_fc)
        if row["core_member"] != str(core).upper(): rule_errors["core"] += 1
        if row["interaction_member"] != str(interaction).upper(): rule_errors["interaction"] += 1
        if row["sep_member"] != str(sep).upper(): rule_errors["sep"] += 1
        if row["high_confidence_sep_interaction"] != str(high_conf).upper(): rule_errors["high_confidence"] += 1
        if interaction and row["interaction_class"] != expected_interaction_class(s0_fc, sd_fc):
            rule_errors["interaction_class"] += 1
    for rule in ("core", "interaction", "sep", "high_confidence", "interaction_class"):
        check(signature_checks, f"{rule}_rule_errors", rule_errors[rule], 0)

    core_rows = [row for row in cross if row["core_member"] == "TRUE"]
    interaction_rows = [row for row in cross if row["interaction_member"] == "TRUE"]
    sep_rows = [row for row in cross if row["sep_member"] == "TRUE"]
    core_tsv = read_tsv(ROOT / "genesets/PS_PsoGS_Core_v1.0.tsv")
    interaction_tsv = read_tsv(ROOT / "genesets/PS_PsoGS_Interaction_v1.0.tsv")
    sep_tsv = read_tsv(ROOT / "genesets/SEP_v1.0.tsv")
    key = lambda row: (row["mouse_ensembl_gene_id"], row["selected_human_entrez_id"])
    check(signature_checks, "core_tsv_members", {key(row) for row in core_tsv} == {key(row) for row in core_rows}, True)
    check(signature_checks, "interaction_tsv_members", {key(row) for row in interaction_tsv} == {key(row) for row in interaction_rows}, True)
    check(signature_checks, "sep_tsv_members", {key(row) for row in sep_tsv} == {key(row) for row in sep_rows}, True)
    check(signature_checks, "core_human_symbols_unique", len({row["human_gene_symbol"] for row in core_rows}), len(core_rows))

    core_gmt = parse_gmt(ROOT / "genesets/PS_PsoGS_Core_v1.0.gmt")
    interaction_gmt = parse_gmt(ROOT / "genesets/PS_PsoGS_Interaction_v1.0.gmt")
    sep_gmt = parse_gmt(ROOT / "genesets/SEP_v1.0.gmt")
    symbol_set = lambda rows: {row["human_gene_symbol"] for row in rows}
    check(signature_checks, "core_gmt_all", set(core_gmt["PS_PsoGS_Core_v1.0"]) == symbol_set(core_rows), True)
    for group in ("CONCORDANT_UP", "CONCORDANT_DOWN", "DISCORDANT_MOUSE_UP_HUMAN_DOWN", "DISCORDANT_MOUSE_DOWN_HUMAN_UP"):
        check(signature_checks, f"core_gmt_{group}",
              set(core_gmt[f"PS_PsoGS_Core_{group}_v1.0"]) ==
              symbol_set([row for row in core_rows if row["core_direction_class"] == group]), True)
    check(signature_checks, "interaction_gmt_all",
          set(interaction_gmt["PS_PsoGS_Interaction_v1.0"]) == symbol_set(interaction_rows), True)
    for group in ("augmentation", "attenuation", "reversal", "unchanged_magnitude"):
        check(signature_checks, f"interaction_gmt_{group}",
              set(interaction_gmt[f"PS_PsoGS_Interaction_{group}_v1.0"]) ==
              symbol_set([row for row in interaction_rows if row["interaction_class"] == group]), True)
    check(signature_checks, "sep_gmt_up",
          set(sep_gmt["SEP_UP_v1.0"]) == symbol_set([row for row in sep_rows if row["sep_direction"] == "UP"]), True)
    check(signature_checks, "sep_gmt_down",
          set(sep_gmt["SEP_DOWN_v1.0"]) == symbol_set([row for row in sep_rows if row["sep_direction"] == "DOWN"]), True)
    check(signature_checks, "sep_gmt_high_confidence",
          set(sep_gmt["SEP_HighConfidence_Interaction_v1.0"]) ==
          symbol_set([row for row in sep_rows if row["high_confidence_sep_interaction"] == "TRUE"]), True)
    for name, genes in {**core_gmt, **interaction_gmt, **sep_gmt}.items():
        check(signature_checks, f"gmt_unique_{name}", len(genes), len(set(genes)))

    stats_rows = read_tsv(ROOT / "results/stage02/signatures/signature_statistics.tsv")
    stats = {row["metric"]: int(row["value"]) for row in stats_rows}
    expected_counts = {
        "mouse_genes_total": len(cross),
        "mouse_human_homology_rows_total": len(source_pairs),
        "pass_reciprocal_one2one": sum(row["ensembl_one2one_status"] == "PASS_RECIPROCAL_ONE2ONE" for row in orthology),
        "pass_reliable_one2one_entrez": sum(row["orthology_status"] == "PASS_RELIABLE_ONE2ONE_ENTREZ" for row in orthology),
        "pass_joined_h": sum(row["analysis_join_status"] == "PASS_JOINED_H" for row in orthology),
        "core_total": len(core_rows),
        "core_concordant_up": sum(row["core_direction_class"] == "CONCORDANT_UP" for row in core_rows),
        "core_concordant_down": sum(row["core_direction_class"] == "CONCORDANT_DOWN" for row in core_rows),
        "core_discordant": sum(row["core_direction_class"].startswith("DISCORDANT") for row in core_rows),
        "interaction_total": len(interaction_rows),
        "interaction_augmentation": sum(row["interaction_class"] == "augmentation" for row in interaction_rows),
        "interaction_attenuation": sum(row["interaction_class"] == "attenuation" for row in interaction_rows),
        "interaction_reversal": sum(row["interaction_class"] == "reversal" for row in interaction_rows),
        "sep_total": len(sep_rows),
        "sep_up": sum(row["sep_direction"] == "UP" for row in sep_rows),
        "sep_down": sum(row["sep_direction"] == "DOWN" for row in sep_rows),
        "high_confidence_sep_interaction": sum(row["high_confidence_sep_interaction"] == "TRUE" for row in sep_rows),
        "validation_expression_files_read": 0,
    }
    check(signature_checks, "statistics_recalculation", stats, expected_counts)

    f1_manifest = read_tsv(ROOT / "metadata/signature_f1_manifest.tsv")
    manifest_errors = 0
    for row in f1_manifest:
        path = ROOT / row["path"]
        if not path.is_file() or int(row["bytes"]) != path.stat().st_size or row["sha256"] != sha256(path):
            manifest_errors += 1
    check(signature_checks, "f1_manifest_hash_errors", manifest_errors, 0)
    check(signature_checks, "f1_version", {row["signature_version"] for row in f1_manifest}, {"v1.0"})
    check(signature_checks, "validation_expression_files_read", stats["validation_expression_files_read"], 0)

    source_audit = ROOT / "audits/stage02_orthology/ensembl100_source_checks.tsv"
    signature_audit = ROOT / "audits/stage02_orthology/signature_f1_checks.tsv"
    source_manifest_path = ROOT / "metadata/ensembl_release100_source_manifest.tsv"
    write_tsv(source_audit, source_checks)
    write_tsv(signature_audit, signature_checks)
    write_tsv(source_manifest_path, source_manifest)

    failures = [row for row in source_checks + signature_checks if row["status"] != "PASS"]
    if failures:
        raise AssertionError(f"{len(failures)} cross-species QA checks failed: {failures[:3]}")
    print(f"PASS: {len(source_checks)} source checks and {len(signature_checks)} signature checks")


if __name__ == "__main__":
    main()
