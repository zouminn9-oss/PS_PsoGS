#!/usr/bin/env python3
"""Extract auditable text from the publisher-hosted GSE212126 supplement DOCX."""

from __future__ import annotations

import csv
import hashlib
import re
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "references" / "source_docs" / "GSE212126_article_supplement_mmc1.docx"
TEXT_OUT = ROOT / "audits" / "gse212126_supplement_text.tsv"
EVIDENCE_OUT = ROOT / "audits" / "gse212126_supplement_evidence.tsv"
NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
TERMS = re.compile(r"\b(mice|mouse|animal|random|group|sample|replicate|RNA|sequenc|transcript|skin|n\s*=)\b", re.I)


def write_tsv(path: Path, rows):
    fields = list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main():
    with zipfile.ZipFile(SOURCE) as archive:
        xml = archive.read("word/document.xml")
    root = ET.fromstring(xml)
    rows = []
    for index, paragraph in enumerate(root.findall(".//w:p", NS), start=1):
        text = "".join(node.text or "" for node in paragraph.findall(".//w:t", NS)).strip()
        if text:
            rows.append({"paragraph_index": index, "text": text})
    write_tsv(TEXT_OUT, rows)
    evidence = [{"paragraph_index": row["paragraph_index"], "matched_text": row["text"]}
                for row in rows if TERMS.search(row["text"])]
    write_tsv(EVIDENCE_OUT, evidence)
    print(f"paragraphs={len(rows)} evidence_matches={len(evidence)} sha256={hashlib.sha256(SOURCE.read_bytes()).hexdigest()}")


if __name__ == "__main__":
    main()
