options(stringsAsFactors = FALSE)
.libPaths(c(normalizePath(file.path("r_libs", "stage02")),
            normalizePath(file.path("r_libs", "stage01")), .libPaths()))
stopifnot(requireNamespace("edgeR", quietly = TRUE),
          as.character(packageVersion("edgeR")) == "4.4.2")

lock <- read.delim(file.path("metadata", "stage03_validation_sample_lock.tsv"), check.names = FALSE)
sep <- read.delim(file.path("genesets", "SEP_v1.0.tsv"), check.names = FALSE)
prior <- read.delim(file.path("results", "stage03", "scores", "paired_scores.tsv"), check.names = FALSE)
counts_df <- read.delim(gzfile(file.path("data", "raw", "validation", "GSE121212",
                                      "GSE121212_readcount.txt.gz")), check.names = FALSE)
count_ids <- as.character(counts_df[[1]])
counts <- as.matrix(counts_df[-1]); storage.mode(counts) <- "integer"
counts <- rowsum(counts, group = count_ids, reorder = FALSE)

eligible <- lock$dataset_id == "GSE121212" & lock$lock_status %in%
  c("PRIMARY_INCLUDE", "SPECIFICITY_INCLUDE", "SENSITIVITY_INCLUDE")
locked <- lock[eligible, ]
stopifnot(nrow(locked) == 108L, all(locked$sample_title %in% colnames(counts)),
          nrow(sep) == 2716L)

y <- edgeR::DGEList(counts = counts[, locked$sample_title, drop = FALSE])
y <- edgeR::calcNormFactors(y, method = "TMM")
logcpm <- edgeR::cpm(y, log = TRUE, prior.count = 2)
ranks <- apply(logcpm, 2, rank, ties.method = "average") / (nrow(logcpm) + 1)
up <- match(sep$human_gene_symbol[sep$sep_direction == "UP"], rownames(ranks))
down <- match(sep$human_gene_symbol[sep$sep_direction == "DOWN"], rownames(ranks))
up <- up[!is.na(up)]; down <- down[!is.na(down)]
stopifnot(length(up) == 1345L, length(down) == 1240L)
sample_scores <- colMeans(ranks[up, , drop = FALSE]) - colMeans(ranks[down, , drop = FALSE])

build_pairs <- function(rows, group_id, lesion_type) {
  pieces <- split(rows, rows$donor_id)
  out <- do.call(rbind, lapply(pieces, function(z) {
    nl <- z$sample_title[z$skin_type == "non-lesional"]
    ls <- z$sample_title[z$skin_type == lesion_type]
    stopifnot(length(nl) == 1L, length(ls) == 1L)
    data.frame(group_id = group_id, donor_id = z$donor_id[1],
               nonlesional_sample = nl, lesional_sample = ls,
               nonlesional_score = unname(sample_scores[nl]),
               lesional_score = unname(sample_scores[ls]), stringsAsFactors = FALSE)
  }))
  rownames(out) <- NULL
  out$delta_LS_minus_NL <- out$lesional_score - out$nonlesional_score
  out$lesion_definition <- lesion_type
  out
}

pso <- build_pairs(locked[locked$lock_status == "PRIMARY_INCLUDE", ], "PSO_PRIMARY", "lesional")
ad <- build_pairs(locked[locked$lock_status == "SPECIFICITY_INCLUDE", ], "AD_ORDINARY", "lesional")
chronic <- build_pairs(locked[locked$lock_status == "SENSITIVITY_INCLUDE", ], "AD_CHRONIC", "chronic_lesion")
scores <- rbind(pso, ad, chronic)
stopifnot(nrow(pso) == 27L, nrow(ad) == 21L, nrow(chronic) == 6L, nrow(scores) == 54L)

prior_pso <- prior[prior$dataset_id == "GSE121212", ]
prior_pso <- prior_pso[match(pso$donor_id, prior_pso$donor_id), ]
stopifnot(max(abs(pso$nonlesional_score - prior_pso$nonlesional_score)) < 1e-14,
          max(abs(pso$lesional_score - prior_pso$lesional_score)) < 1e-14)

summarize_group <- function(group_id, values) {
  tt <- t.test(values, mu = 0)
  wt <- suppressWarnings(wilcox.test(values, mu = 0, exact = FALSE))
  data.frame(group_id = group_id, n_pairs = length(values), mean_delta = mean(values),
             median_delta = median(values), sd_delta = sd(values),
             positive_pairs = sum(values > 0), negative_pairs = sum(values < 0),
             t_statistic = unname(tt$statistic), t_df = unname(tt$parameter),
             t_p_value = tt$p.value, ci_low = tt$conf.int[1], ci_high = tt$conf.int[2],
             wilcoxon_statistic = unname(wt$statistic), wilcoxon_p_value = wt$p.value)
}
group_stats <- rbind(summarize_group("PSO_PRIMARY", pso$delta_LS_minus_NL),
                     summarize_group("AD_ORDINARY", ad$delta_LS_minus_NL),
                     summarize_group("AD_CHRONIC", chronic$delta_LS_minus_NL))

compare_groups <- function(contrast_id, left, right, role) {
  tt <- t.test(left, right, paired = FALSE, var.equal = FALSE)
  wt <- suppressWarnings(wilcox.test(left, right, paired = FALSE, exact = FALSE))
  data.frame(contrast_id = contrast_id, analysis_role = role,
             n_left = length(left), n_right = length(right),
             mean_left = mean(left), mean_right = mean(right),
             difference_left_minus_right = mean(left) - mean(right),
             ci_low = tt$conf.int[1], ci_high = tt$conf.int[2],
             t_statistic = unname(tt$statistic), t_df = unname(tt$parameter),
             t_p_value = tt$p.value, wilcoxon_statistic = unname(wt$statistic),
             wilcoxon_p_value = wt$p.value, stringsAsFactors = FALSE)
}
comparisons <- rbind(
  compare_groups("PSO_MINUS_AD_ORDINARY", pso$delta_LS_minus_NL, ad$delta_LS_minus_NL, "PRIMARY"),
  compare_groups("PSO_MINUS_AD_CHRONIC", pso$delta_LS_minus_NL, chronic$delta_LS_minus_NL, "SENSITIVITY"),
  compare_groups("AD_ORDINARY_MINUS_AD_CHRONIC", ad$delta_LS_minus_NL,
                 chronic$delta_LS_minus_NL, "SENSITIVITY"))
comparisons$BH_FDR_three_between_group_tests <- p.adjust(comparisons$t_p_value, method = "BH")

dir.create(file.path("results", "stage03", "specificity"), recursive = TRUE, showWarnings = FALSE)
write.table(scores, file.path("results", "stage03", "specificity",
                              "gse121212_pso_ad_paired_scores.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
write.table(group_stats, file.path("results", "stage03", "specificity",
                                   "gse121212_pso_ad_group_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
write.table(comparisons, file.path("results", "stage03", "specificity",
                                   "gse121212_pso_ad_direct_comparisons.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: PSO=%d, ordinary AD=%d, chronic AD=%d paired score differences\n",
            nrow(pso), nrow(ad), nrow(chronic)))
