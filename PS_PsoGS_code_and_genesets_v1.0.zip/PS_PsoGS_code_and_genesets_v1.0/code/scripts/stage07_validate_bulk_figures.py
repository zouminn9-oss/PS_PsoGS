from pathlib import Path
import csv,sys
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import pandas as pd
from PIL import Image
checks=[]
def ck(n,p,d): checks.append((n,bool(p),str(d)))
for p in ["7h","7i","7j"]:
  files={"source":ROOT/f"figures/source_data/fig{p}.tsv","stats":ROOT/f"results/figures/fig{p}_statistics.tsv","config":ROOT/f"config/figures/fig{p}.yaml","svg":ROOT/f"figures/panels/fig{p}.svg","png":ROOT/f"figures/previews/fig{p}.png","caption":ROOT/f"figures/captions/fig{p}.md"}
  for k,f in files.items(): ck(f"{p}_{k}_exists",f.exists() and f.stat().st_size>0,f)
  ck(f"{p}_source_nonempty",len(pd.read_csv(files["source"],sep="\t"))>0,files["source"])
  ck(f"{p}_stats_nonempty",len(pd.read_csv(files["stats"],sep="\t"))>0,files["stats"])
  with Image.open(files["png"]) as im: ck(f"{p}_print_pixels",im.width>=900 and im.height>=600,f"{im.width}x{im.height}")
  ck(f"{p}_caption_complete",len(files["caption"].read_text(encoding="utf-8").split())>=35,"word-like tokens")
effects=pd.read_csv(ROOT/"results/stage07/gse117468_longitudinal_effects.tsv",sep="\t")
ck("longitudinal_32_contrasts",len(effects)==32,len(effects)); ck("biological_pairs_minimum",effects.n_pairs.min()>=5,effects.n_pairs.min())
pred=pd.read_csv(ROOT/"results/stage07/prediction_outer_predictions.tsv.gz",sep="\t")
ck("prediction_two_models",pred.model.nunique()==2,pred.model.nunique()); ck("prediction_74_patients",pred.patient_id.nunique()==74,pred.patient_id.nunique()); ck("prediction_20_repeats",pred.repeat.nunique()==20,pred.repeat.nunique()); ck("prediction_62_events",pred.groupby("patient_id").outcome.first().sum()==62,pred.groupby("patient_id").outcome.first().sum())
delta=pd.read_csv(ROOT/"results/stage07/prediction_model_deltas.tsv",sep="\t")
for metric in ["auroc","auprc","brier"]:
  r=delta[delta.metric==metric].iloc[0]; ck(f"{metric}_delta_interval_includes_zero",r.delta_q025<=0<=r.delta_q975,(r.delta_q025,r.delta_q975))
blocked=pd.read_csv(ROOT/"results/stage07/stage07_blocked_modules.tsv",sep="\t")
for module in ["canonical_M1","canonical_M2_comparison","gene_panel_stability","external_prediction_validation","multiview_fusion"]: ck(f"{module}_blocked",blocked.loc[blocked.module==module,"status"].iloc[0].startswith("BLOCKED"),blocked.loc[blocked.module==module,"status"].iloc[0])
with (ROOT/"panel_manifest.tsv").open(encoding="utf-8",newline="") as f: man={r["panel_id"]:r for r in csv.DictReader(f,delimiter="\t")}
for p in ["7H","7I","7J"]: ck(f"manifest_{p}_ready",man[p]["status"]=="PASS" and man[p]["figure_ready"]=="YES",man[p]["status"])
for p in ["7K","7L"]: ck(f"manifest_{p}_blocked",man[p]["status"].startswith("BLOCKED") and man[p]["figure_ready"]=="NO",man[p]["status"])
out=pd.DataFrame(checks,columns=["check","pass","detail"]); out.to_csv(ROOT/"audits/stage07_bulk_figure_checks.tsv",sep="\t",index=False)
if not out["pass"].all(): raise AssertionError(out.loc[~out["pass"]].to_string(index=False))
print(f"PASS: Stage 07 bulk Figure QA {len(out)}/{len(out)} checks")
