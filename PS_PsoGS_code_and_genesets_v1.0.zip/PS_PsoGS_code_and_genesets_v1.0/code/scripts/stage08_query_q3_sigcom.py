from pathlib import Path
import json,sys,time
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/"python_libs/stage08")); sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import pandas as pd
import requests
OUT=ROOT/"results/stage08"; OUT.mkdir(parents=True,exist_ok=True)
META="https://maayanlab.cloud/sigcom-lincs/metadata-api/"
DATA="https://data-api.sigcom-lincs.k8s.maayanlab.cloud/v1/api/v1/"
q=pd.read_csv(OUT/"query_genes.tsv",sep="\t"); q=q[q.query_id=="Q3_CTRA"]
up=q.loc[q.direction=="UP","symbol"].tolist(); down=q.loc[q.direction=="DOWN","symbol"].tolist()
entity_payload={"filter":{"where":{"meta.symbol":{"inq":up+down}},"fields":["id","meta.symbol"]}}
(OUT/"q3_sigcom_entity_request.json").write_text(json.dumps(entity_payload,indent=2),encoding="utf-8")
r=requests.post(META+"entities/find",json=entity_payload,timeout=120); r.raise_for_status(); entities=r.json()
(OUT/"q3_sigcom_entity_response.json").write_text(json.dumps(entities,indent=2),encoding="utf-8")
mapped={e["meta"]["symbol"].upper():e["id"] for e in entities}
payload={"up_entities":[mapped[x] for x in up if x in mapped],"down_entities":[mapped[x] for x in down if x in mapped],"limit":5000,"database":"l1000_cp"}
(OUT/"q3_sigcom_ranktwosided_request.json").write_text(json.dumps(payload,indent=2),encoding="utf-8")
r=requests.post(DATA+"enrich/ranktwosided",json=payload,timeout=300); r.raise_for_status(); result=r.json()
(OUT/"q3_sigcom_ranktwosided_response.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
rows=pd.DataFrame(result.get("results",[]))
if len(rows)==0: raise AssertionError("SigCom returned zero results")
rows["z_down_display"]=-rows["z-down"]
rows["reversal_concordant"]=(rows["z-up"]<0)&(rows.z_down_display<0)
rows.to_csv(OUT/"q3_sigcom_scores.tsv",sep="\t",index=False)

resolved=[]
ids=rows.uuid.tolist()
for start in range(0,len(ids),400):
  p={"filter":{"where":{"id":{"inq":ids[start:start+400]}},"fields":["id","library","meta"]}}
  rr=requests.post(META+"signatures/find",json=p,timeout=180); rr.raise_for_status(); resolved.extend(rr.json()); time.sleep(.05)
(OUT/"q3_sigcom_signature_metadata.json").write_text(json.dumps(resolved,indent=2),encoding="utf-8")
flat=[]
for x in resolved:
  m=x.get("meta",{}); flat.append({"uuid":x.get("id"),"library":x.get("library"),"pert_name":m.get("pert_name"),"pert_type":m.get("pert_type"),"cell_line":m.get("cell_line"),"pert_time":m.get("pert_time"),"pert_dose":m.get("pert_dose"),"persistent_id":m.get("persistent_id")})
pd.DataFrame(flat).merge(rows,left_on="uuid",right_on="uuid",how="right").to_csv(OUT/"q3_sigcom_resolved.tsv",sep="\t",index=False)
gate=pd.DataFrame([{"query_id":"Q3_CTRA","source_up":len(up),"source_down":len(down),"mapped_up":len(payload["up_entities"]),"mapped_down":len(payload["down_entities"]),"database":payload["database"],"returned_signatures":len(rows),"reversal_concordant":int(rows.reversal_concordant.sum()),"score_family":"SigCom_ranktwosided_z","status":"PASS_SEPARATE_SCORE_FAMILY","not_mixed_with_LM_cosine":"YES"}])
gate.to_csv(OUT/"q3_sigcom_gate.tsv",sep="\t",index=False)
print(gate.to_string(index=False))
