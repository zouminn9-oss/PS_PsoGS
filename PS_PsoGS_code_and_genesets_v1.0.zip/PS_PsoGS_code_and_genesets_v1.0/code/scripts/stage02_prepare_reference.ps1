$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$ReferenceRoot = Join-Path $ProjectRoot "references\genomes\GRCm38_gencode_M25"
$Gzip = "C:\Program Files\Git\usr\bin\gzip.exe"
$FastaGz = Join-Path $ReferenceRoot "GRCm38.primary_assembly.genome.fa.gz"
$GtfGz = Join-Path $ReferenceRoot "gencode.vM25.primary_assembly.annotation.gtf.gz"
$Fasta = Join-Path $ReferenceRoot "GRCm38.primary_assembly.genome.fa"
$Gtf = Join-Path $ReferenceRoot "gencode.vM25.primary_assembly.annotation.gtf"
$AuditPath = Join-Path $ProjectRoot "audits\gencode_m25_reference_files.tsv"

if (-not (Test-Path -LiteralPath $Gzip)) { throw "gzip executable missing: $Gzip" }
$Expected = @{
    $FastaGz = "3bc591be24b77f710b6ba5d41022fc5a"
    $GtfGz = "c5125258a0a2c5250ddb4c192abbf4e8"
}
foreach ($Path in @($FastaGz, $GtfGz)) {
    if (-not (Test-Path -LiteralPath $Path)) { throw "Reference archive missing: $Path" }
    $Observed = (Get-FileHash -LiteralPath $Path -Algorithm MD5).Hash.ToLower()
    if ($Observed -ne $Expected[$Path]) { throw "MD5 mismatch for $Path" }
    & $Gzip -t $Path
    if ($LASTEXITCODE -ne 0) { throw "gzip integrity test failed for $Path" }
}

if (-not (Test-Path -LiteralPath $Fasta)) {
    & $Gzip -dk $FastaGz
    if ($LASTEXITCODE -ne 0) { throw "FASTA decompression failed" }
}
if (-not (Test-Path -LiteralPath $Gtf)) {
    & $Gzip -dk $GtfGz
    if ($LASTEXITCODE -ne 0) { throw "GTF decompression failed" }
}

$Files = @($FastaGz, $GtfGz, $Fasta, $Gtf)
$Audit = foreach ($Path in $Files) {
    $Item = Get-Item -LiteralPath $Path
    [pscustomobject]@{
        file = $Item.FullName.Substring($ProjectRoot.Length + 1).Replace('\','/')
        bytes = $Item.Length
        md5 = (Get-FileHash -LiteralPath $Path -Algorithm MD5).Hash.ToLower()
        sha256 = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLower()
        status = "PASS"
    }
}
if (Test-Path -LiteralPath $AuditPath) {
    $Prior = @(Import-Csv -LiteralPath $AuditPath -Delimiter "`t")
    foreach ($Row in $Audit) {
        $Old = @($Prior | Where-Object { $_.file -eq $Row.file })
        if ($Old.Count -eq 1 -and $Old[0].sha256 -ne $Row.sha256) {
            throw "refusing to replace a prior reference audit after SHA-256 changed: $($Row.file)"
        }
    }
}
$Audit | Export-Csv -LiteralPath $AuditPath -Delimiter "`t" -NoTypeInformation -Encoding utf8

Get-Item -LiteralPath $Fasta, $Gtf | Select-Object FullName, Length
