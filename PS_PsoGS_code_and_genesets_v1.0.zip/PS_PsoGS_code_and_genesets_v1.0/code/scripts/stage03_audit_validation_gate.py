#!/usr/bin/env python3
"""Freeze validation cohorts and feature coverage without computing expression effects."""

from __future__ import annotations

import csv
import gzip
import hashlib
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SAMPLE_MANIFEST = ROOT / "metadata/sample_manifest.tsv"
GSE30999_PAIRS = ROOT / "metadata/gse30999_metadata_pair_registry.tsv"
GSE121212_COUNTS = ROOT / "data/raw/validation/GSE121212/GSE121212_readcount.txt.gz"
GPL570_ANNOT = ROOT / "references/GPL570/GPL570.annot.gz"
CORE = ROOT / "genesets/PS_PsoGS_Core_v1.0.tsv"
INTERACTION = ROOT / "genesets/PS_PsoGS_Interaction_v1.0.tsv"
SEP = ROOT / "genesets/SEP_v1.0.tsv"
CONFIG = ROOT / "config/stage03_validation_gate.yaml"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t",
                                lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    checks: list[dict[str, object]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": observed, "expected": expected,
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            write_tsv(ROOT / "audits/stage03_validation_gate_checks.tsv", checks)
            raise AssertionError(f"{check_id}: observed {observed!r}; expected {expected!r}")

    samples = read_tsv(SAMPLE_MANIFEST)
    s30999 = [row for row in samples if row["dataset_id"] == "GSE30999"]
    s121212 = [row for row in samples if row["dataset_id"] == "GSE121212"]
    check("GSE30999_sample_rows", len(s30999), 170)
    check("GSE30999_unique_GSM", len({row["sample_id"] for row in s30999}), 170)
    check("GSE30999_unique_subjects", len({row["donor_or_animal_id"] for row in s30999}), 89)
    check("GSE30999_platform", {row["platform_id"] for row in s30999}, {"GPL570"})
    check("GSE121212_sample_rows", len(s121212), 147)
    check("GSE121212_unique_GSM", len({row["sample_id"] for row in s121212}), 147)
    check("GSE121212_unique_subjects", len({row["donor_or_animal_id"] for row in s121212}), 93)
    check("GSE121212_platform", {row["platform_id"] for row in s121212}, {"GPL16791"})

    pairs30999 = read_tsv(GSE30999_PAIRS)
    eligible30999 = [row for row in pairs30999
                     if row["metadata_pair_status"] == "COMPLETE_EXACT_ID_PAIR"]
    held30999 = [row for row in pairs30999 if row["metadata_pair_status"] == "SINGLETON_UNRESOLVED"]
    check("GSE30999_pair_registry_subjects", len(pairs30999), 89)
    check("GSE30999_exact_pairs", len(eligible30999), 81)
    check("GSE30999_singleton_subjects", len(held30999), 8)
    check("GSE30999_exact_pair_samples",
          len({gsm for row in eligible30999 for gsm in (row["nl_gsm"], row["ls_gsm"])}), 162)
    check("GSE30999_held_sample_balance",
          (sum(bool(row["nl_gsm"]) for row in held30999),
           sum(bool(row["ls_gsm"]) for row in held30999)), (4, 4))

    by_donor: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
    for row in s121212:
        by_donor[(row["disease_state"], row["donor_or_animal_id"])].append(row)
    pair_rows121212: list[dict[str, object]] = []
    for (disease, donor), donor_rows in sorted(by_donor.items()):
        by_skin = {row["skin_type"]: row["sample_id"] for row in donor_rows}
        if disease == "PSO":
            pair_type = "PSO_PRIMARY" if set(by_skin) == {"lesional", "non-lesional"} else "PSO_UNMATCHED"
            status = "PRIMARY_INCLUDE" if pair_type == "PSO_PRIMARY" else "HOLD_PRIMARY_UNPAIRED"
        elif disease == "AD" and set(by_skin) == {"lesional", "non-lesional"}:
            pair_type, status = "AD_ORDINARY_SPECIFICITY", "SPECIFICITY_INCLUDE"
        elif disease == "AD" and set(by_skin) == {"chronic_lesion", "non-lesional"}:
            pair_type, status = "AD_CHRONIC_SENSITIVITY", "SENSITIVITY_INCLUDE"
        elif disease == "CTRL" and set(by_skin) == {"healthy"}:
            pair_type, status = "HEALTHY_REFERENCE", "REFERENCE_INCLUDE"
        else:
            pair_type, status = "UNEXPECTED", "HOLD"
        pair_rows121212.append({
            "dataset_id": "GSE121212", "donor_id": donor, "disease": disease,
            "lesional_gsm": by_skin.get("lesional", ""),
            "chronic_lesion_gsm": by_skin.get("chronic_lesion", ""),
            "nonlesional_gsm": by_skin.get("non-lesional", ""),
            "healthy_gsm": by_skin.get("healthy", ""), "n_samples": len(donor_rows),
            "pair_type": pair_type, "lock_status": status,
            "reason": "sample-title donor and skin labels; no expression-based matching",
        })
    pair_counts = Counter(row["pair_type"] for row in pair_rows121212)
    check("GSE121212_pair_strata", pair_counts,
          Counter({"HEALTHY_REFERENCE": 38, "PSO_PRIMARY": 27,
                   "AD_ORDINARY_SPECIFICITY": 21, "AD_CHRONIC_SENSITIVITY": 6,
                   "PSO_UNMATCHED": 1}))
    write_tsv(ROOT / "metadata/gse121212_pair_registry.tsv", pair_rows121212)

    count_hash = sha256(GSE121212_COUNTS)
    with gzip.open(GSE121212_COUNTS, "rt", encoding="utf-8-sig", errors="strict") as handle:
        header = handle.readline().rstrip("\r\n").split("\t")
        count_titles = header[1:]
        feature_ids: list[str] = []
        column_counts: set[int] = set()
        for line in handle:
            # Deliberately retain only the feature label and field count; numeric values are not parsed.
            feature_ids.append(line.split("\t", 1)[0])
            column_counts.add(line.count("\t") + 1)
    check("GSE121212_count_header_samples", len(count_titles), 147)
    check("GSE121212_count_titles_unique", len(set(count_titles)), 147)
    check("GSE121212_count_title_set_matches_metadata", set(count_titles),
          {row["sample_title"] for row in s121212})
    check("GSE121212_count_title_order_matches_metadata", count_titles,
          [row["sample_title"] for row in s121212])
    check("GSE121212_count_rows", len(feature_ids), 31364)
    check("GSE121212_count_unique_features", len(set(feature_ids)), 31362)
    duplicate_features = sorted(key for key, value in Counter(feature_ids).items() if value > 1)
    check("GSE121212_duplicate_feature_labels", duplicate_features, ["1-Mar", "2-Mar"])
    check("GSE121212_rectangular_shape", column_counts, {148})

    with gzip.open(GPL570_ANNOT, "rt", encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            if line.startswith("ID\t"):
                annot_header = line.rstrip("\r\n").split("\t")
                break
        index = {name: idx for idx, name in enumerate(annot_header)}
        unique_entrez: set[str] = set()
        annotated_probes = 0
        unique_entrez_probes = 0
        malformed_rows = 0
        end_markers = 0
        for line in handle:
            if line.startswith("!platform_table_end"):
                end_markers += 1
                continue
            fields = line.rstrip("\r\n").split("\t")
            if len(fields) <= index["Gene ID"]:
                malformed_rows += 1
                continue
            annotated_probes += 1
            entrez_ids = {item.strip() for item in fields[index["Gene ID"]].split("///")
                          if item.strip().isdigit()}
            if len(entrez_ids) == 1:
                unique_entrez_probes += 1
                unique_entrez.update(entrez_ids)
    check("GPL570_annotation_rows", annotated_probes, 54675)
    check("GPL570_malformed_rows", malformed_rows, 0)
    check("GPL570_platform_end_marker", end_markers, 1)
    check("GPL570_unique_probe_ids_rule_nonempty", unique_entrez_probes > 30000, True)
    check("GPL570_unique_entrez_universe_nonempty", len(unique_entrez) > 15000, True)

    signature_tables = {
        "Core": read_tsv(CORE), "Interaction": read_tsv(INTERACTION), "SEP": read_tsv(SEP)
    }
    signature_sets: dict[str, list[dict[str, str]]] = dict(signature_tables)
    signature_sets["SEP_UP"] = [row for row in signature_tables["SEP"] if row["sep_direction"] == "UP"]
    signature_sets["SEP_DOWN"] = [row for row in signature_tables["SEP"] if row["sep_direction"] == "DOWN"]
    expected_sizes = {"Core": 4976, "Interaction": 4085, "SEP": 2716,
                      "SEP_UP": 1399, "SEP_DOWN": 1317}
    rna_symbols = set(feature_ids)
    coverage_rows: list[dict[str, object]] = []
    for signature_id, rows in signature_sets.items():
        check(f"signature_size::{signature_id}", len(rows), expected_sizes[signature_id])
        for dataset_id, feature_universe, key, mapping_rule in (
            ("GSE30999", unique_entrez, "selected_human_entrez_id",
             "GPL570 exactly-one-numeric-Entrez probes; gene median frozen for later use"),
            ("GSE121212", rna_symbols, "human_gene_symbol",
             "exact frozen symbol; duplicate labels summed; no alias rescue from outcomes"),
        ):
            members = {row[key] for row in rows}
            measured = members & feature_universe
            fraction = len(measured) / len(members)
            coverage_rows.append({
                "dataset_id": dataset_id, "signature_id": signature_id,
                "frozen_members": len(members), "measurable_members": len(measured),
                "missing_members": len(members - measured),
                "coverage_fraction": f"{fraction:.9f}", "minimum_required": "0.70",
                "coverage_status": "PASS" if fraction >= 0.70 else "FAIL",
                "mapping_rule": mapping_rule,
            })
            check(f"coverage_gate::{dataset_id}::{signature_id}", fraction >= 0.70, True)
    write_tsv(ROOT / "metadata/stage03_platform_coverage.tsv", coverage_rows)

    eligible_gsms30999 = {gsm for row in eligible30999 for gsm in (row["nl_gsm"], row["ls_gsm"])}
    pair_status121212 = {row["donor_id"]: row["lock_status"] for row in pair_rows121212}
    sample_lock: list[dict[str, object]] = []
    for row in s30999 + s121212:
        if row["dataset_id"] == "GSE30999":
            status = "PRIMARY_INCLUDE" if row["sample_id"] in eligible_gsms30999 else "HOLD_UNRESOLVED_PAIR"
            role = "PRIMARY_PAIRED_PSORIASIS" if status == "PRIMARY_INCLUDE" else "EXCLUDED_PRIMARY"
        else:
            status = pair_status121212[row["donor_or_animal_id"]]
            role = {"PRIMARY_INCLUDE": "PRIMARY_PAIRED_PSORIASIS",
                    "HOLD_PRIMARY_UNPAIRED": "EXCLUDED_PRIMARY",
                    "SPECIFICITY_INCLUDE": "AD_SPECIFICITY",
                    "SENSITIVITY_INCLUDE": "AD_CHRONIC_SENSITIVITY",
                    "REFERENCE_INCLUDE": "HEALTHY_REFERENCE"}[status]
        sample_lock.append({
            "dataset_id": row["dataset_id"], "sample_id": row["sample_id"],
            "sample_title": row["sample_title"], "donor_id": row["donor_or_animal_id"],
            "disease_state": row["disease_state"], "skin_type": row["skin_type"],
            "platform_id": row["platform_id"], "analysis_role": role,
            "lock_status": status,
            "lock_reason": "metadata-defined before numeric validation effect analysis",
        })
    check("sample_lock_rows", len(sample_lock), 317)
    check("sample_lock_unique_dataset_GSM",
          len({(row["dataset_id"], row["sample_id"]) for row in sample_lock}), 317)
    lock_counts = Counter((row["dataset_id"], row["lock_status"]) for row in sample_lock)
    check("sample_lock_primary_counts",
          (lock_counts[("GSE30999", "PRIMARY_INCLUDE")],
           lock_counts[("GSE30999", "HOLD_UNRESOLVED_PAIR")],
           lock_counts[("GSE121212", "PRIMARY_INCLUDE")],
           lock_counts[("GSE121212", "HOLD_PRIMARY_UNPAIRED")]), (162, 8, 54, 1))
    write_tsv(ROOT / "metadata/stage03_validation_sample_lock.tsv", sample_lock)

    cohort_lock = [
        {"dataset_id": "GSE30999", "analysis_stratum": "PRIMARY_PAIRED_PSORIASIS",
         "independent_units": 81, "samples": 162, "inclusion_status": "PASS_LOCKED",
         "statistical_unit": "paired patient", "limitation": "8 singleton samples (4 reported pairs) remain HOLD"},
        {"dataset_id": "GSE121212", "analysis_stratum": "PRIMARY_PAIRED_PSORIASIS",
         "independent_units": 27, "samples": 54, "inclusion_status": "PASS_LOCKED",
         "statistical_unit": "paired patient", "limitation": "PSO_034 lesion is unmatched and excluded"},
        {"dataset_id": "GSE121212", "analysis_stratum": "AD_ORDINARY_SPECIFICITY",
         "independent_units": 21, "samples": 42, "inclusion_status": "PASS_LOCKED_SECONDARY",
         "statistical_unit": "paired patient", "limitation": "specificity analysis; not psoriasis replication"},
        {"dataset_id": "GSE121212", "analysis_stratum": "AD_CHRONIC_SENSITIVITY",
         "independent_units": 6, "samples": 12, "inclusion_status": "PASS_LOCKED_SENSITIVITY",
         "statistical_unit": "paired patient", "limitation": "chronic lesions kept separate"},
        {"dataset_id": "GSE121212", "analysis_stratum": "HEALTHY_REFERENCE",
         "independent_units": 38, "samples": 38, "inclusion_status": "PASS_LOCKED_REFERENCE",
         "statistical_unit": "independent person", "limitation": "unpaired descriptive reference only"},
    ]
    write_tsv(ROOT / "metadata/stage03_validation_cohort_lock.tsv", cohort_lock)

    input_paths = [SAMPLE_MANIFEST, GSE30999_PAIRS, GSE121212_COUNTS, GPL570_ANNOT,
                   CORE, INTERACTION, SEP, CONFIG]
    input_manifest = [{"artifact_id": path.name, "path": path.relative_to(ROOT).as_posix(),
                       "bytes": path.stat().st_size, "sha256": sha256(path),
                       "role": "Stage03_gate_input", "numeric_effects_computed": "NO"}
                      for path in input_paths]
    write_tsv(ROOT / "metadata/stage03_validation_input_manifest.tsv", input_manifest)
    check("stage03_input_manifest_rows", len(input_manifest), 8)
    check("numeric_expression_effects_computed", False, False)
    check("numeric_expression_values_parsed", False, False,
          "count matrix numeric fields were not parsed; only header, feature labels and shape")
    write_tsv(ROOT / "audits/stage03_validation_gate_checks.tsv", checks)
    print(f"PASS: locked validation cohorts and platform coverage with {len(checks)} checks; "
          "numeric expression effects not computed")


if __name__ == "__main__":
    main()
