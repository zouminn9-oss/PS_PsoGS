#!/usr/bin/env python3
"""Validate the frozen layered PS-Reference and ontology snapshots."""

from __future__ import annotations

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    registry = read_tsv(ROOT / "metadata" / "ps_reference_registry.tsv")
    design = read_tsv(ROOT / "audits" / "ps_reference_design_audit.tsv")
    ontology = read_tsv(ROOT / "metadata" / "endocrine_ontology_registry.tsv")
    members = read_tsv(ROOT / "genesets" / "endocrine_go_exact_2026-09-10.tsv")
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    check("registry_rows", len(registry), 9)
    check("registry_unique_ids", len({r["resource_id"] for r in registry}), 9)
    check("no_automatic_directional_scores", sum(r["automatic_directional_score"] == "NO" for r in registry), 9)
    check("no_automatic_core_eligibility", sum(r["automatic_core_eligibility"] == "NO" for r in registry), 9)
    check("gse212126_mouse_factorial_pass", next(
        r["freeze_status"] for r in registry if r["resource_id"] == "GSE212126_FACTORIAL"
    ), "PASS_F1_SOURCE")
    check("gse270712_remains_partial_hold", next(r["freeze_status"] for r in registry if r["resource_id"] == "GSE270712_SCRNA"), "PARTIAL_HOLD")

    check("design_branches", len(design), 4)
    check("gse270713_design_samples", sum(int(r["sample_records"]) for r in design if r["dataset_id"] == "GSE270713"), 36)
    check("gse270713_three_equal_branches", ",".join(sorted(r["sample_records"] for r in design if r["dataset_id"] == "GSE270713")), "12,12,12")
    check("gse26487_design_samples", sum(int(r["sample_records"]) for r in design if r["dataset_id"] == "GSE26487"), 20)
    check("design_expression_not_accessed", sum(r["expression_matrix_accessed"] == "NO" for r in design), 4)
    check("design_no_core_generation", sum(r["core_member_generation"] == "NO" for r in design), 4)

    check("ontology_snapshots", len(ontology), 6)
    check("ontology_terms", len({r["go_id"] for r in ontology}), 3)
    check("ontology_species", len({r["species"] for r in ontology}), 2)
    check("ontology_exact_only", sum(r["go_usage"] == "exact" for r in ontology), 6)
    check("ontology_no_descendants", sum(r["descendants_included"] == "NO" for r in ontology), 6)
    check("ontology_all_pass", sum(r["status"] == "PASS" for r in ontology), 6)
    check("ontology_annotation_rows", sum(int(r["annotation_rows"]) for r in ontology), 165)

    check("ontology_term_symbol_rows", len(members), 108)
    check("ontology_member_annotations", sum(int(r["annotation_count"]) for r in members), 165)
    check("ontology_human_hgnc_pass", sum(r["hgnc_exact_status"] == "PASS_EXACT_APPROVED_SYMBOL" for r in members), 46)
    check("ontology_human_hgnc_hold", sum(r["hgnc_exact_status"] == "HOLD_NOT_EXACT_HGNC_APPROVED" for r in members), 9)
    check("ontology_mouse_rows", sum(r["hgnc_exact_status"] == "NOT_APPLICABLE_MOUSE" for r in members), 53)
    check("ontology_nondirectional", sum(r["direction"] == "NONE_ONTOLOGY_ANNOTATION" for r in members), 108)
    check("ontology_no_core_generation", sum(r["core_member_generation"] == "NO" for r in members), 108)

    write_tsv(ROOT / "audits" / "ps_reference_integrity_checks.tsv", checks)
    print(f"PASS: {len(checks)} PS-Reference integrity checks")


if __name__ == "__main__":
    main()
