#!/usr/bin/env python3
"""Audit, QC, doublet-filter, and score the independent GSE162183 matrix."""
from __future__ import annotations

import gzip
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))
sys.path.insert(0, str(ROOT / "scripts"))

import numpy as np
import pandas as pd
from scipy import sparse
import scrublet as scr
from stage04_prepare_discovery_sparse import rank_components

INPUT = ROOT / "data/raw/single_cell/GSE162183/GSE162183_Raw_gene_counts_matrix.tab.gz"
OUT = ROOT / "data/processed/stage04"
RES = ROOT / "results/stage04/qc"
SEED = 20260911
MIN_DETECTED = 20


def mad(values):
    median = float(np.median(values))
    return median, float(np.median(np.abs(values - median)))


def program_symbols():
    core = pd.read_csv(ROOT / "genesets/PS_PsoGS_Core_v1.0.tsv", sep="\t")
    sep = pd.read_csv(ROOT / "genesets/SEP_v1.0.tsv", sep="\t")
    return {
        "core_up": set(core.loc[core["core_direction_class"].str.endswith("UP"), "human_gene_symbol"]),
        "core_down": set(core.loc[core["core_direction_class"].str.endswith("DOWN"), "human_gene_symbol"]),
        "sep_up": set(sep.loc[sep["sep_direction"] == "UP", "human_gene_symbol"]),
        "sep_down": set(sep.loc[sep["sep_direction"] == "DOWN", "human_gene_symbol"]),
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    RES.mkdir(parents=True, exist_ok=True)
    with gzip.open(INPUT, "rb") as handle:
        header = handle.readline().rstrip(b"\r\n").split(b"\t")[1:]
        cell_ids = [x.decode("ascii") for x in header]
        donors = np.array([x.split("_10x_", 1)[0] for x in cell_ids], dtype=object)
        n_cells = len(cell_ids)
        counts = np.zeros(n_cells, dtype=np.int64)
        features = np.zeros(n_cells, dtype=np.int32)
        mito = np.zeros(n_cells, dtype=np.int64)
        genes = []
        gene_detected = []
        gene_sum = []
        maximum = 0
        for gene_i, line in enumerate(handle):
            symbol_raw, values_raw = line.rstrip(b"\r\n").split(b"\t", 1)
            symbol = symbol_raw.decode("utf-8")
            values = np.fromstring(values_raw, dtype=np.int32, sep="\t")
            if values.size != n_cells or np.any(values < 0):
                raise AssertionError(f"invalid count row {gene_i + 1}: {symbol}")
            genes.append(symbol)
            nonzero = values > 0
            counts += values
            features += nonzero
            if symbol.startswith("MT-"):
                mito += values
            gene_detected.append(int(nonzero.sum()))
            gene_sum.append(int(values.sum()))
            maximum = max(maximum, int(values.max(initial=0)))
            if (gene_i + 1) % 2000 == 0:
                print(f"PROFILE genes={gene_i + 1}", flush=True)
    percent_mito = np.divide(100.0 * mito, counts, out=np.zeros(n_cells), where=counts > 0)
    qc = pd.DataFrame({"cell_id": cell_ids, "donor_id": donors,
                       "condition": np.where(np.char.startswith(donors.astype(str), "Psor"), "Psoriasis", "Control"),
                       "n_counts": counts, "n_features": features, "mito_counts": mito,
                       "percent_mito": percent_mito})
    summaries = []
    qc["hard_threshold_pass"] = False
    qc["low_quality_outlier"] = False
    qc["high_count_feature_flag"] = False
    qc["qc_pass_pre_doublet"] = False
    for donor in sorted(set(donors)):
        idx = np.flatnonzero(donors == donor)
        log_counts = np.log10(counts[idx] + 1)
        log_features = np.log10(features[idx] + 1)
        med_c, mad_c = mad(log_counts); med_f, mad_f = mad(log_features); med_m, mad_m = mad(percent_mito[idx])
        low_c = med_c - 3 * mad_c if mad_c > 0 else -math.inf
        high_c = med_c + 3 * mad_c if mad_c > 0 else math.inf
        low_f = med_f - 3 * mad_f if mad_f > 0 else -math.inf
        high_f = med_f + 3 * mad_f if mad_f > 0 else math.inf
        high_m = min(20.0, med_m + 3 * mad_m) if mad_m > 0 else 20.0
        hard = (counts[idx] >= 500) & (features[idx] >= 200) & (percent_mito[idx] <= 20)
        low = (log_counts < low_c) | (log_features < low_f) | (percent_mito[idx] > high_m)
        high = (log_counts > high_c) | (log_features > high_f)
        passed = hard & ~low
        qc.loc[idx, "hard_threshold_pass"] = hard
        qc.loc[idx, "low_quality_outlier"] = low
        qc.loc[idx, "high_count_feature_flag"] = high
        qc.loc[idx, "qc_pass_pre_doublet"] = passed
        summaries.append({"donor_id": donor, "condition": qc.loc[idx[0], "condition"], "input_cells": len(idx),
                          "pre_doublet_pass": int(passed.sum()), "qc_fail": int((~passed).sum()),
                          "high_count_feature_flags": int(high.sum()), "median_counts": float(np.median(counts[idx])),
                          "median_features": float(np.median(features[idx])), "median_percent_mito": float(np.median(percent_mito[idx]))})
    pre_mask = qc["qc_pass_pre_doublet"].to_numpy(bool)
    gene_keep = np.asarray(gene_detected) >= MIN_DETECTED
    kept_genes = np.asarray(genes, dtype=object)[gene_keep]
    data_parts = []; row_parts = []; col_parts = []
    with gzip.open(INPUT, "rb") as handle:
        handle.readline()
        kept_row = 0
        for gene_i, line in enumerate(handle):
            if not gene_keep[gene_i]:
                continue
            values = np.fromstring(line.rstrip(b"\r\n").split(b"\t", 1)[1], dtype=np.int32, sep="\t")[pre_mask]
            nz = np.flatnonzero(values)
            if len(nz):
                data_parts.append(values[nz])
                row_parts.append(np.full(len(nz), kept_row, dtype=np.int32))
                col_parts.append(nz.astype(np.int32, copy=False))
            kept_row += 1
    data = np.concatenate(data_parts); rows = np.concatenate(row_parts); cols = np.concatenate(col_parts)
    matrix = sparse.coo_matrix((data, (rows, cols)), shape=(len(kept_genes), int(pre_mask.sum())), dtype=np.int32).T.tocsr()
    pre_obs = qc.loc[pre_mask].reset_index(drop=True)
    predicted = np.zeros(len(pre_obs), dtype=bool)
    doublet_score = np.full(len(pre_obs), np.nan)
    doublet_rows = []
    for donor in sorted(pre_obs["donor_id"].unique()):
        idx = np.flatnonzero(pre_obs["donor_id"].to_numpy() == donor)
        engine = scr.Scrublet(matrix[idx], expected_doublet_rate=0.06, random_state=SEED)
        score, call = engine.scrub_doublets(min_counts=2, min_cells=3, min_gene_variability_pctl=85,
                                            n_prin_comps=min(30, max(2, len(idx) // 4)),
                                            use_approx_neighbors=False, verbose=False)
        predicted[idx] = call
        doublet_score[idx] = score
        doublet_rows.append({"donor_id": donor, "pre_doublet_cells": len(idx), "predicted_doublets": int(call.sum()),
                             "post_doublet_cells": int((~call).sum()), "predicted_doublet_fraction": float(call.mean()),
                             "scrublet_threshold": float(engine.threshold_), "scrublet_status": "PASS"})
    final = matrix[~predicted]
    obs = pre_obs.loc[~predicted].reset_index(drop=True)
    obs["scrublet_score"] = doublet_score[~predicted]
    obs["predicted_doublet"] = False
    programs = program_symbols()
    masks = {name: np.array([symbol in members for symbol in kept_genes], dtype=bool) for name, members in programs.items()}
    sizes = {name: int(mask.sum()) for name, mask in masks.items()}
    components = rank_components(final, masks, sizes)
    for name, values in components.items():
        obs[name] = values
    obs["ucell_core_directed"] = obs["ucell_core_up"] - obs["ucell_core_down"]
    obs["ucell_sep_directed"] = obs["ucell_sep_up"] - obs["ucell_sep_down"]
    obs["rankmean_core_directed"] = obs["rankmean_core_up"] - obs["rankmean_core_down"]
    obs["rankmean_sep_directed"] = obs["rankmean_sep_up"] - obs["rankmean_sep_down"]

    sparse.save_npz(OUT / "gse162183_counts_qc.npz", final, compressed=True)
    obs.to_csv(OUT / "gse162183_cell_metadata_unannotated.tsv.gz", sep="\t", index=False, compression="gzip")
    pd.DataFrame({"matrix_column": np.arange(len(kept_genes)), "human_gene_symbol": kept_genes,
                  "detected_input_cells": np.asarray(gene_detected)[gene_keep],
                  "total_counts_input_cells": np.asarray(gene_sum)[gene_keep]}).to_csv(
                      OUT / "gse162183_genes.tsv", sep="\t", index=False)
    pd.DataFrame(summaries).to_csv(RES / "gse162183_qc_by_donor.tsv", sep="\t", index=False)
    pd.DataFrame(doublet_rows).to_csv(RES / "gse162183_scrublet_by_donor.tsv", sep="\t", index=False)
    coverage = pd.DataFrame([{"program_component": name, "frozen_genes": len(programs[name]),
                              "detected_ge20_cells": sizes[name], "coverage_fraction": sizes[name] / len(programs[name]),
                              "ucell_max_rank": 5000} for name in programs])
    coverage.to_csv(RES / "gse162183_program_coverage.tsv", sep="\t", index=False)
    checks = pd.DataFrame([
        {"check_id": "input_cells", "observed": n_cells, "expected": 24234},
        {"check_id": "gene_rows", "observed": len(genes), "expected": 19968},
        {"check_id": "six_donors", "observed": len(set(donors)), "expected": 6},
        {"check_id": "three_per_condition", "observed": qc.groupby("condition")["donor_id"].nunique().min(), "expected": 3},
        {"check_id": "positive_integer_counts", "observed": maximum > 0, "expected": True},
        {"check_id": "all_donors_scrublet_pass", "observed": len(doublet_rows), "expected": 6},
        {"check_id": "post_doublet_cells_gt10000", "observed": len(obs) > 10000, "expected": True},
        {"check_id": "program_coverage_ge70pct", "observed": bool((coverage["coverage_fraction"] >= 0.70).all()), "expected": True},
    ])
    checks["status"] = np.where(checks["observed"].astype(str) == checks["expected"].astype(str), "PASS", "FAIL")
    checks.to_csv(ROOT / "audits/stage04_replication_qc_checks.tsv", sep="\t", index=False)
    if checks["status"].eq("FAIL").any():
        raise AssertionError("GSE162183 QC gate failed")
    print(f"PASS: input={n_cells}, pre_doublet={int(pre_mask.sum())}, final={len(obs)}, genes={len(kept_genes)}")


if __name__ == "__main__":
    main()
