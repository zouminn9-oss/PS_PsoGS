param(
    [int]$StartAt = 1,
    [int]$StopAfter = 12
)

$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$AuditPath = Join-Path $ProjectRoot "audits\gse212126_sra_audit.tsv"
$OutputRoot = Join-Path $ProjectRoot "data\raw\gse212126_sra"
$LogRoot = Join-Path $ProjectRoot "logs\stage02"
$StatePath = Join-Path $ProjectRoot "audits\gse212126_sra_download_state.tsv"
$Validate = Join-Path $ProjectRoot "tools\sratoolkit\sratoolkit.3.4.1-win64\bin\vdb-validate.exe"
$OfflineConfig = Join-Path $ProjectRoot "config\sra_toolkit_offline\user-settings.mkfg"
$MinimumFreeBytes = 250000000000

New-Item -ItemType Directory -Force -Path $OutputRoot, $LogRoot | Out-Null
if (-not (Test-Path -LiteralPath $OfflineConfig)) { throw "offline SRA configuration missing: $OfflineConfig" }
$env:NCBI_SETTINGS = $OfflineConfig
$Rows = @(Import-Csv -LiteralPath $AuditPath -Delimiter "`t" | Sort-Object srr)
if ($Rows.Count -ne 12) { throw "Expected 12 SRA audit rows, found $($Rows.Count)" }
if ($StartAt -lt 1 -or $StopAfter -lt $StartAt -or $StopAfter -gt $Rows.Count) {
    throw "Invalid inclusive range StartAt=$StartAt StopAfter=$StopAfter"
}

$State = if (Test-Path -LiteralPath $StatePath) {
    @(Import-Csv -LiteralPath $StatePath -Delimiter "`t" | Select-Object srr,gsm,
        expected_bytes_from_cached_xml,downloaded_bytes,expected_md5,observed_md5,
        transport,download_action,integrity_status,vdb_validate_status,completed_at,file)
} else { @() }
for ($Index = $StartAt - 1; $Index -le $StopAfter - 1; $Index++) {
    $Row = $Rows[$Index]
    $Run = $Row.srr
    $RunDir = Join-Path $OutputRoot $Run
    $RunFile = Join-Path $RunDir "${Run}.sra"
    $LogFile = Join-Path $LogRoot "${Run}_download.log"
    New-Item -ItemType Directory -Force -Path $RunDir | Out-Null

    $Drive = Get-PSDrive -Name D
    if ($Drive.Free -lt $MinimumFreeBytes) {
        throw "Free D: space $($Drive.Free) is below frozen minimum $MinimumFreeBytes"
    }
    $DownloadUrl = $Row.normalized_sra_url -replace '^https:', 'http:'
    $DownloadAction = "DOWNLOAD_OR_RESUME"
    $ExistingMd5 = if (Test-Path -LiteralPath $RunFile) {
        (Get-FileHash -LiteralPath $RunFile -Algorithm MD5).Hash.ToLower()
    } else { "" }
    if ($ExistingMd5 -eq $Row.normalized_sra_md5) {
        $DownloadAction = "REUSE_EXISTING_OFFICIAL_MD5_PASS"
        "REUSE`t$(Get-Date -Format o)`t$Run`tofficial_md5_already_passed" | Out-File -LiteralPath $LogFile -Encoding utf8 -Append
    } else {
        "DOWNLOAD_OR_RESUME`t$(Get-Date -Format o)`t$Run`t$DownloadUrl" | Out-File -LiteralPath $LogFile -Encoding utf8 -Append
        & curl.exe -L --fail --retry 8 --retry-all-errors --retry-delay 5 -C - --silent --show-error -o $RunFile $DownloadUrl 2>&1 | Tee-Object -FilePath $LogFile -Append
        if ($LASTEXITCODE -ne 0) { throw "Download failed for $Run with exit code $LASTEXITCODE" }
    }

    $ObservedBytes = (Get-Item -LiteralPath $RunFile).Length
    $ObservedMd5 = (Get-FileHash -LiteralPath $RunFile -Algorithm MD5).Hash.ToLower()
    $Status = if ($ObservedMd5 -eq $Row.normalized_sra_md5) { "PASS" } else { "FAIL" }
    if ($Status -ne "PASS") { throw "MD5 mismatch for $Run" }
    & $Validate $RunFile 2>&1 | Tee-Object -FilePath $LogFile -Append
    if ($LASTEXITCODE -ne 0) { throw "vdb-validate failed for $Run" }

    $State = @($State | Where-Object { $_.srr -ne $Run })
    $State += [pscustomobject]@{
        srr = $Run
        gsm = $Row.gsm
        expected_bytes_from_cached_xml = $Row.compressed_size_bytes
        downloaded_bytes = $ObservedBytes
        expected_md5 = $Row.normalized_sra_md5
        observed_md5 = $ObservedMd5
        transport = "HTTP_AWS_PUBLIC_OBJECT"
        download_action = $DownloadAction
        integrity_status = $Status
        vdb_validate_status = "PASS"
        completed_at = (Get-Date -Format o)
        file = $RunFile.Substring($ProjectRoot.Length + 1).Replace('\','/')
    }
    $State | Export-Csv -LiteralPath $StatePath -Delimiter "`t" -NoTypeInformation -Encoding utf8
}

"PASS: retained, MD5-verified and vdb-validated $($State.Count) run state row(s)" 
