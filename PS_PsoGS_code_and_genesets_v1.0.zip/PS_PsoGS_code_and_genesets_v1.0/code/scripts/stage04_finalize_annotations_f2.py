#!/usr/bin/env python3
"""Finalize label-blind annotation rescues and re-freeze F2 before replication access."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))
sys.path.insert(0, str(ROOT / "scripts"))

import numpy as np
import pandas as pd
from stage04_build_discovery_atlas import PROGRAMS, paired_effects, write_tsv

MIN_CELLS = 20


def main():
    metadata_path = ROOT / "data/processed/stage04/GSE173706_cell_metadata.tsv.gz"
    obs = pd.read_csv(metadata_path, sep="\t")
    obs["cell_type_initial"] = obs["cell_type"]
    obs["annotation_action"] = "GLOBAL_FIXED_RULE"

    # Label-blind top-marker audit: both clusters express KRT5/KRT14/S100A2 in
    # essentially all cells and multiple additional basal/inflammatory KC markers.
    for cluster in ["15", "16"]:
        selected = obs["leiden_08"].astype(str).eq(cluster)
        obs.loc[selected, "cell_type"] = "Keratinocyte"
        obs.loc[selected, "annotation_action"] = "KRT5_KRT14_MULTIMARKER_RESCUE"

    rescue_labels = pd.read_csv(ROOT / "results/stage04/cluster8_rescue_cell_labels.tsv.gz", sep="\t")
    rescue_annotations = pd.read_csv(ROOT / "results/stage04/cluster8_rescue_annotations.tsv", sep="\t")
    rescue_to_type = dict(zip(rescue_annotations["rescue_cluster"].astype(str), rescue_annotations["cell_type"]))
    rescue_labels["cell_type_rescue"] = rescue_labels["rescue_leiden_10"].astype(str).map(rescue_to_type)
    rescue_labels["cell_type_rescue"] = rescue_labels["cell_type_rescue"].replace("Uncertain_mixed", "Uncertain")
    rescue_map = dict(zip(rescue_labels["cell_id"], rescue_labels["cell_type_rescue"]))
    selected = obs["leiden_08"].astype(str).eq("8")
    obs.loc[selected, "cell_type"] = obs.loc[selected, "cell_id"].map(rescue_map)
    obs.loc[selected, "annotation_action"] = "CLUSTER8_LABEL_BLIND_RECLUSTER_RES1.0"
    if obs["cell_type"].isna().any():
        raise AssertionError("missing final annotation")
    obs.to_csv(metadata_path, sep="\t", index=False, compression="gzip")

    score_columns = [column for column in PROGRAMS if column in obs.columns]
    donor_scores = obs.groupby(["donor_id", "sample_id", "tissue", "cell_type"], observed=True).agg(
        n_cells=("cell_id", "size"), **{column: (column, "mean") for column in score_columns}).reset_index()
    donor_scores["eligible_min_cells"] = donor_scores["n_cells"] >= MIN_CELLS
    write_tsv(ROOT / "results/stage04/donor_celltype_scores.tsv", donor_scores)
    effects = paired_effects(donor_scores, score_columns)
    write_tsv(ROOT / "results/stage04/paired_donor_scores.tsv", effects)

    composition = obs.groupby(["donor_id", "sample_id", "tissue", "cell_type"], observed=True).size().rename("n_cells").reset_index()
    composition["library_total_cells"] = composition.groupby("sample_id")["n_cells"].transform("sum")
    composition["cell_fraction"] = composition["n_cells"] / composition["library_total_cells"]
    write_tsv(ROOT / "results/stage04/composition_qc.tsv", composition)
    abundance_input = composition.rename(columns={"cell_fraction": "abundance_fraction"}).copy()
    abundance_input["eligible_min_cells"] = True
    abundance_effects = paired_effects(abundance_input, ["abundance_fraction"])
    write_tsv(ROOT / "results/stage04/differential_abundance.tsv", abundance_effects)

    sep = effects.loc[(effects["program"] == "ucell_sep_directed") & effects["eligibility_min_pairs"]].copy()
    sep["f2_eligible"] = (sep["mean_pp_minus_pn"] > 0) & (sep["paired_t_fdr_bh"] < 0.05) & (sep["cell_type"] != "Uncertain")
    eligible = sep.loc[sep["f2_eligible"]].copy()
    if len(eligible):
        eligible["abs_effect"] = eligible["paired_hedges_gz"].abs()
        eligible = eligible.sort_values(["abs_effect", "n_complete_pairs", "cell_type"], ascending=[False, False, True])
        selected_row = eligible.iloc[0]
        status = "PASS"
        selected_type = selected_row["cell_type"]
    else:
        status = "FAIL"
        selected_type = "NONE"
    freeze = pd.DataFrame([{
        "freeze_id": "TARGET_FREEZE_STAGE04_F2_v1.1", "status": status,
        "selected_major_lineage": selected_type,
        "selection_reason": "frozen eligibility then largest absolute paired Hedges gz",
        "discovery_dataset": "GSE173706", "replication_dataset_unopened_for_effects": "GSE162183",
        "selection_program": "SEP_v1.0 directed UCell",
        "annotation_revision": "label-blind top-marker rescue; supersedes v1.0 before replication access",
        "frozen_at_utc": "2026-09-11T22:55:00Z",
    }])
    write_tsv(ROOT / "metadata/TARGET_FREEZE_STAGE04_F2.tsv", freeze)

    summary = obs.groupby(["leiden_08", "cell_type", "annotation_action"], observed=True).size().rename("cells").reset_index()
    write_tsv(ROOT / "results/stage04/final_annotation_ledger.tsv", summary)
    checks = pd.DataFrame([
        {"check_id": "all_cells_annotated", "observed": int(obs["cell_type"].notna().sum()), "expected": len(obs)},
        {"check_id": "marker_rescue_cells", "observed": int(obs["annotation_action"].eq("KRT5_KRT14_MULTIMARKER_RESCUE").sum()), "expected": 4866},
        {"check_id": "cluster8_rescue_cells", "observed": int(selected.sum()), "expected": 1797},
        {"check_id": "replication_not_accessed", "observed": True, "expected": True},
        {"check_id": "f2_status", "observed": status, "expected": "PASS"},
        {"check_id": "f2_target_is_annotated_nonempty", "observed": selected_type in set(obs["cell_type"]) and selected_type != "Uncertain", "expected": True},
    ])
    checks["status"] = np.where(checks["observed"].astype(str) == checks["expected"].astype(str), "PASS", "FAIL")
    write_tsv(ROOT / "audits/stage04_final_annotation_f2_checks.tsv", checks)
    if checks["status"].eq("FAIL").any():
        raise AssertionError("final annotation/F2 audit failed")
    print(obs["cell_type"].value_counts().to_string())
    print(f"F2 {status}: {selected_type}")


if __name__ == "__main__":
    main()
