#!/usr/bin/env python3
"""Build the frozen Ensembl-100 orthology ledger and discovery signatures."""

from __future__ import annotations

import csv
import gzip
import hashlib
import math
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MOUSE_FILES = {
    "S0": ROOT / "results/stage02/factorial_edger/gse212126_S0_all_genes.tsv",
    "SD": ROOT / "results/stage02/factorial_edger/gse212126_SD_all_genes.tsv",
    "I": ROOT / "results/stage02/factorial_edger/gse212126_I_all_genes.tsv",
}
HUMAN_H = ROOT / "results/stage02/gse13355/gse13355_H_paired_all_genes.tsv"
HOMOLOGY_FILES = {
    "mouse_protein_default": ROOT / "references/ensembl_release100_compara/Compara.100.mouse.protein_default.homologies.tsv.gz",
    "mouse_ncrna_default": ROOT / "references/ensembl_release100_compara/Compara.100.mouse.ncrna_default.homologies.tsv.gz",
    "human_protein_default": ROOT / "references/ensembl_release100_compara/Compara.100.human.protein_default.homologies.tsv.gz",
    "human_ncrna_default": ROOT / "references/ensembl_release100_compara/Compara.100.human.ncrna_default.homologies.tsv.gz",
}
HUMAN_ENTREZ = ROOT / "references/ensembl_release100_human/Homo_sapiens.GRCh38.100.entrez.tsv.gz"
CONFIG = ROOT / "config/stage02_cross_species_signatures.yaml"

RAW_SUBSET = ROOT / "references/ensembl_release100_compara/mouse_human_homologies_to_human.tsv.gz"
ORTHOLOGY_LEDGER = ROOT / "metadata/mouse_human_orthology_ensembl100_ledger.tsv.gz"
RESULT_DIR = ROOT / "results/stage02/signatures"
CROSS_LEDGER = RESULT_DIR / "cross_species_gene_ledger.tsv.gz"
STATS = RESULT_DIR / "signature_statistics.tsv"
GENESET_DIR = ROOT / "genesets"
CORE_TSV = GENESET_DIR / "PS_PsoGS_Core_v1.0.tsv"
CORE_GMT = GENESET_DIR / "PS_PsoGS_Core_v1.0.gmt"
INTERACTION_TSV = GENESET_DIR / "PS_PsoGS_Interaction_v1.0.tsv"
INTERACTION_GMT = GENESET_DIR / "PS_PsoGS_Interaction_v1.0.gmt"
SEP_TSV = GENESET_DIR / "SEP_v1.0.tsv"
SEP_GMT = GENESET_DIR / "SEP_v1.0.gmt"
F1_MANIFEST = ROOT / "metadata/signature_f1_manifest.tsv"

FDR_CUTOFF = 0.05


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def f(value: str) -> float:
    return float(value)


def sign(value: float) -> str:
    if value > 0:
        return "UP"
    if value < 0:
        return "DOWN"
    return "ZERO"


def write_tsv(path: Path, rows: list[dict[str, object]], fields: list[str], gzip_output: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if gzip_output else open
    kwargs = {"newline": "", "encoding": "utf-8"}
    if gzip_output:
        kwargs["compresslevel"] = 9
    with opener(path, "wt" if gzip_output else "w", **kwargs) as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fields,
            delimiter="\t",
            lineterminator="\n",
            extrasaction="ignore",
        )
        writer.writeheader()
        writer.writerows(rows)


def load_mouse_results() -> tuple[dict[str, dict[str, str]], dict[str, dict[str, dict[str, str]]]]:
    by_estimand: dict[str, dict[str, dict[str, str]]] = {}
    for estimand, path in MOUSE_FILES.items():
        rows = read_tsv(path)
        table: dict[str, dict[str, str]] = {}
        for row in rows:
            base_id = row["gene_id"].split(".", 1)[0]
            if base_id in table:
                raise RuntimeError(f"Duplicate mouse base ID in {estimand}: {base_id}")
            table[base_id] = row
        by_estimand[estimand] = table
    id_sets = {estimand: set(table) for estimand, table in by_estimand.items()}
    if len({frozenset(ids) for ids in id_sets.values()}) != 1:
        raise RuntimeError("S0, SD and I mouse gene universes differ")
    sd = by_estimand["SD"]
    return sd, by_estimand


def load_human_entrez() -> dict[str, set[str]]:
    mapping: dict[str, set[str]] = defaultdict(set)
    with gzip.open(HUMAN_ENTREZ, "rt", newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            xref = row["xref"].strip()
            if xref.isdigit():
                mapping[row["gene_stable_id"]].add(xref)
    return mapping


def load_mouse_human_homologies() -> tuple[list[dict[str, str]], dict[str, set[str]], dict[str, set[str]], dict[str, set[str]]]:
    raw_rows: list[dict[str, str]] = []
    one2one_mouse_to_human: dict[str, set[str]] = defaultdict(set)
    one2one_human_to_mouse: dict[str, set[str]] = defaultdict(set)
    types_by_mouse: dict[str, set[str]] = defaultdict(set)
    seen: set[tuple[str, str, str, str]] = set()

    for source_tree, path in HOMOLOGY_FILES.items():
        with gzip.open(path, "rt", newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle, delimiter="\t")
            for row in reader:
                if row["species"] == "mus_musculus" and row["homology_species"] == "homo_sapiens":
                    normalized = dict(row)
                    source_orientation = "mouse_left"
                elif row["species"] == "homo_sapiens" and row["homology_species"] == "mus_musculus":
                    normalized = dict(row)
                    normalized["gene_stable_id"] = row["homology_gene_stable_id"]
                    normalized["protein_stable_id"] = row["homology_protein_stable_id"]
                    normalized["species"] = "mus_musculus"
                    normalized["identity"] = row["homology_identity"]
                    normalized["homology_gene_stable_id"] = row["gene_stable_id"]
                    normalized["homology_protein_stable_id"] = row["protein_stable_id"]
                    normalized["homology_species"] = "homo_sapiens"
                    normalized["homology_identity"] = row["identity"]
                    source_orientation = "mouse_right_normalized"
                else:
                    continue
                key = (
                    normalized["gene_stable_id"],
                    normalized["homology_gene_stable_id"],
                    normalized["homology_type"],
                    normalized["homology_id"],
                )
                if key in seen:
                    continue
                seen.add(key)
                out = {
                    "source_tree": source_tree,
                    "source_orientation": source_orientation,
                    **normalized,
                }
                raw_rows.append(out)
                mouse_id = normalized["gene_stable_id"]
                human_id = normalized["homology_gene_stable_id"]
                types_by_mouse[mouse_id].add(normalized["homology_type"])
                if normalized["homology_type"] == "ortholog_one2one":
                    one2one_mouse_to_human[mouse_id].add(human_id)
                    one2one_human_to_mouse[human_id].add(mouse_id)

    raw_rows.sort(
        key=lambda row: (
            row["gene_stable_id"],
            row["homology_gene_stable_id"],
            row["homology_type"],
            row["homology_id"],
        )
    )
    if not raw_rows:
        raise RuntimeError("No mouse-to-human homology rows were found")
    write_tsv(RAW_SUBSET, raw_rows, list(raw_rows[0]), gzip_output=True)
    return raw_rows, one2one_mouse_to_human, one2one_human_to_mouse, types_by_mouse


def interaction_class(s0: float, sd: float) -> str:
    if sign(s0) != sign(sd):
        return "reversal"
    if abs(sd) > abs(s0):
        return "augmentation"
    if abs(sd) < abs(s0):
        return "attenuation"
    return "unchanged_magnitude"


def write_gmt(path: Path, sets: list[tuple[str, str, list[str]]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        for name, description, genes in sets:
            unique = sorted(set(genes))
            handle.write("\t".join([name, description, *unique]) + "\n")


def main() -> None:
    for required in [*MOUSE_FILES.values(), HUMAN_H, *HOMOLOGY_FILES.values(), HUMAN_ENTREZ, CONFIG]:
        if not required.is_file():
            raise FileNotFoundError(required)

    sd_table, mouse = load_mouse_results()
    if len(sd_table) != 18484:
        raise RuntimeError(f"Expected 18,484 mouse genes, observed {len(sd_table):,}")
    human_rows = read_tsv(HUMAN_H)
    human_h = {row["entrez_id"]: row for row in human_rows}
    if len(human_h) != len(human_rows):
        raise RuntimeError("Human H Entrez IDs are not unique")

    human_entrez = load_human_entrez()
    raw_rows, mouse_to_human, human_to_mouse, types_by_mouse = load_mouse_human_homologies()

    orthology_rows: list[dict[str, object]] = []
    cross_rows: list[dict[str, object]] = []
    for mouse_id in sorted(sd_table):
        source = sd_table[mouse_id]
        targets = sorted(mouse_to_human.get(mouse_id, set()))
        observed_types = sorted(types_by_mouse.get(mouse_id, set()))
        human_id = targets[0] if len(targets) == 1 else ""

        if not targets:
            ensembl_status = "HOLD_NO_ONE2ONE"
        elif len(targets) != 1:
            ensembl_status = "HOLD_AMBIGUOUS_MOUSE_TARGET"
        elif len(human_to_mouse.get(human_id, set())) != 1:
            ensembl_status = "HOLD_NONRECIPROCAL_ONE2ONE"
        else:
            ensembl_status = "PASS_RECIPROCAL_ONE2ONE"

        entrez_ids = sorted(human_entrez.get(human_id, set())) if human_id else []
        if ensembl_status != "PASS_RECIPROCAL_ONE2ONE":
            final_status = ensembl_status
        elif len(entrez_ids) == 0:
            final_status = "HOLD_NO_HUMAN_ENTREZ"
        elif len(entrez_ids) > 1:
            final_status = "HOLD_AMBIGUOUS_HUMAN_ENTREZ"
        else:
            final_status = "PASS_RELIABLE_ONE2ONE_ENTREZ"

        entrez_id = entrez_ids[0] if len(entrez_ids) == 1 else ""
        hrow = human_h.get(entrez_id)
        analysis_status = (
            "PASS_JOINED_H"
            if final_status == "PASS_RELIABLE_ONE2ONE_ENTREZ" and hrow is not None
            else ("HOLD_NO_H_RESULT" if final_status == "PASS_RELIABLE_ONE2ONE_ENTREZ" else final_status)
        )

        ortho = {
            "mouse_gene_id_versioned": source["gene_id"],
            "mouse_ensembl_gene_id": mouse_id,
            "mouse_gene_name": source["gene_name"],
            "mouse_gene_type": source["gene_type"],
            "observed_mouse_human_orthology_types": ";".join(observed_types) or "NONE",
            "one2one_human_targets": ";".join(targets),
            "selected_human_ensembl_gene_id": human_id,
            "reciprocal_mouse_source_count": len(human_to_mouse.get(human_id, set())) if human_id else 0,
            "release100_human_entrez_ids": ";".join(entrez_ids),
            "selected_human_entrez_id": entrez_id,
            "ensembl_one2one_status": ensembl_status,
            "orthology_status": final_status,
            "analysis_join_status": analysis_status,
            "orthology_provider": "Ensembl Compara",
            "orthology_release": 100,
            "mouse_assembly": "GRCm38",
            "human_assembly": "GRCh38",
        }
        orthology_rows.append(ortho)

        s0 = mouse["S0"][mouse_id]
        sd = mouse["SD"][mouse_id]
        interaction = mouse["I"][mouse_id]
        s0_fc, sd_fc, i_fc = f(s0["logFC"]), f(sd["logFC"]), f(interaction["logFC"])
        h_fc = f(hrow["logFC"]) if hrow else math.nan
        sd_sig = f(sd["FDR"]) < FDR_CUTOFF
        i_sig = f(interaction["FDR"]) < FDR_CUTOFF
        h_sig = hrow is not None and f(hrow["FDR"]) < FDR_CUTOFF
        core = analysis_status == "PASS_JOINED_H" and sd_sig and h_sig
        concordant = core and sign(sd_fc) == sign(h_fc)
        interaction_member = core and i_sig
        sep = core and concordant
        i_class = interaction_class(s0_fc, sd_fc) if interaction_member else "NOT_INTERACTION_MEMBER"
        high_conf = (
            sep
            and i_sig
            and sign(i_fc) == sign(sd_fc) == sign(h_fc)
            and abs(sd_fc) > abs(s0_fc)
        )
        if not core:
            direction_class = "NOT_CORE"
        elif concordant:
            direction_class = f"CONCORDANT_{sign(sd_fc)}"
        else:
            direction_class = f"DISCORDANT_MOUSE_{sign(sd_fc)}_HUMAN_{sign(h_fc)}"

        cross_rows.append(
            {
                **ortho,
                "human_gene_symbol": hrow["gene_symbol"] if hrow else "",
                "S0_logFC": s0["logFC"],
                "S0_FDR": s0["FDR"],
                "SD_logFC": sd["logFC"],
                "SD_FDR": sd["FDR"],
                "I_logFC": interaction["logFC"],
                "I_FDR": interaction["FDR"],
                "H_logFC": hrow["logFC"] if hrow else "",
                "H_FDR": hrow["FDR"] if hrow else "",
                "SD_significant": str(sd_sig).upper(),
                "I_significant": str(i_sig).upper(),
                "H_significant": str(h_sig).upper(),
                "core_member": str(core).upper(),
                "core_direction_class": direction_class,
                "interaction_member": str(interaction_member).upper(),
                "interaction_class": i_class,
                "sep_member": str(sep).upper(),
                "sep_direction": sign(sd_fc) if sep else "NOT_SEP",
                "high_confidence_sep_interaction": str(high_conf).upper(),
            }
        )

    write_tsv(ORTHOLOGY_LEDGER, orthology_rows, list(orthology_rows[0]), gzip_output=True)
    write_tsv(CROSS_LEDGER, cross_rows, list(cross_rows[0]), gzip_output=True)

    core_rows = [row for row in cross_rows if row["core_member"] == "TRUE"]
    interaction_rows = [row for row in cross_rows if row["interaction_member"] == "TRUE"]
    sep_rows = [row for row in cross_rows if row["sep_member"] == "TRUE"]
    signature_fields = [
        "human_gene_symbol", "selected_human_entrez_id", "selected_human_ensembl_gene_id",
        "mouse_ensembl_gene_id", "mouse_gene_id_versioned", "mouse_gene_name",
        "S0_logFC", "S0_FDR", "SD_logFC", "SD_FDR", "I_logFC", "I_FDR",
        "H_logFC", "H_FDR", "core_direction_class", "interaction_class",
        "sep_direction", "high_confidence_sep_interaction", "orthology_release",
    ]
    write_tsv(CORE_TSV, core_rows, signature_fields)
    write_tsv(INTERACTION_TSV, interaction_rows, signature_fields)
    write_tsv(SEP_TSV, sep_rows, signature_fields)

    symbols = lambda rows: [str(row["human_gene_symbol"]) for row in rows]
    write_gmt(
        CORE_GMT,
        [
            ("PS_PsoGS_Core_v1.0", "All Core genes; direction strata follow", symbols(core_rows)),
            *[
                (
                    f"PS_PsoGS_Core_{group}_v1.0",
                    f"Core direction stratum {group}",
                    symbols([row for row in core_rows if row["core_direction_class"] == group]),
                )
                for group in (
                    "CONCORDANT_UP", "CONCORDANT_DOWN",
                    "DISCORDANT_MOUSE_UP_HUMAN_DOWN", "DISCORDANT_MOUSE_DOWN_HUMAN_UP",
                )
            ],
        ],
    )
    write_gmt(
        INTERACTION_GMT,
        [
            ("PS_PsoGS_Interaction_v1.0", "Core genes with formal CRS:IMQ FDR<0.05", symbols(interaction_rows)),
            *[
                (
                    f"PS_PsoGS_Interaction_{group}_v1.0",
                    f"Interaction class {group}",
                    symbols([row for row in interaction_rows if row["interaction_class"] == group]),
                )
                for group in ("augmentation", "attenuation", "reversal", "unchanged_magnitude")
            ],
        ],
    )
    write_gmt(
        SEP_GMT,
        [
            ("SEP_UP_v1.0", "Core genes with concordant positive mouse SD and human H effects", symbols([row for row in sep_rows if row["sep_direction"] == "UP"])),
            ("SEP_DOWN_v1.0", "Core genes with concordant negative mouse SD and human H effects", symbols([row for row in sep_rows if row["sep_direction"] == "DOWN"])),
            ("SEP_HighConfidence_Interaction_v1.0", "SEP genes satisfying the frozen high-confidence interaction rule", symbols([row for row in sep_rows if row["high_confidence_sep_interaction"] == "TRUE"])),
        ],
    )

    counts: list[tuple[str, object]] = [
        ("mouse_genes_total", len(cross_rows)),
        ("mouse_human_homology_rows_total", len(raw_rows)),
        ("pass_reciprocal_one2one", sum(row["ensembl_one2one_status"] == "PASS_RECIPROCAL_ONE2ONE" for row in orthology_rows)),
        ("pass_reliable_one2one_entrez", sum(row["orthology_status"] == "PASS_RELIABLE_ONE2ONE_ENTREZ" for row in orthology_rows)),
        ("pass_joined_h", sum(row["analysis_join_status"] == "PASS_JOINED_H" for row in orthology_rows)),
        ("core_total", len(core_rows)),
        ("core_concordant_up", sum(row["core_direction_class"] == "CONCORDANT_UP" for row in core_rows)),
        ("core_concordant_down", sum(row["core_direction_class"] == "CONCORDANT_DOWN" for row in core_rows)),
        ("core_discordant", sum(str(row["core_direction_class"]).startswith("DISCORDANT") for row in core_rows)),
        ("interaction_total", len(interaction_rows)),
        ("interaction_augmentation", sum(row["interaction_class"] == "augmentation" for row in interaction_rows)),
        ("interaction_attenuation", sum(row["interaction_class"] == "attenuation" for row in interaction_rows)),
        ("interaction_reversal", sum(row["interaction_class"] == "reversal" for row in interaction_rows)),
        ("sep_total", len(sep_rows)),
        ("sep_up", sum(row["sep_direction"] == "UP" for row in sep_rows)),
        ("sep_down", sum(row["sep_direction"] == "DOWN" for row in sep_rows)),
        ("high_confidence_sep_interaction", sum(row["high_confidence_sep_interaction"] == "TRUE" for row in sep_rows)),
        ("validation_expression_files_read", 0),
    ]
    write_tsv(STATS, [{"metric": key, "value": value} for key, value in counts], ["metric", "value"])

    frozen_at = datetime.now(timezone.utc).isoformat()
    artifact_specs = [
        ("source_mouse_S0_effects", MOUSE_FILES["S0"], len(mouse["S0"])),
        ("source_mouse_SD_effects", MOUSE_FILES["SD"], len(mouse["SD"])),
        ("source_mouse_I_effects", MOUSE_FILES["I"], len(mouse["I"])),
        ("source_human_H_effects", HUMAN_H, len(human)),
        ("source_mouse_protein_homologies", HOMOLOGY_FILES["mouse_protein_default"], "source_input"),
        ("source_mouse_ncrna_homologies", HOMOLOGY_FILES["mouse_ncrna_default"], "source_input"),
        ("source_human_protein_homologies", HOMOLOGY_FILES["human_protein_default"], "source_input"),
        ("source_human_ncrna_homologies", HOMOLOGY_FILES["human_ncrna_default"], "source_input"),
        ("source_human_entrez_xref", HUMAN_ENTREZ, "source_input"),
        ("orthology_raw_subset", RAW_SUBSET, len(raw_rows)),
        ("orthology_ledger", ORTHOLOGY_LEDGER, len(orthology_rows)),
        ("cross_species_ledger", CROSS_LEDGER, len(cross_rows)),
        ("core_tsv", CORE_TSV, len(core_rows)),
        ("core_gmt", CORE_GMT, 5),
        ("interaction_tsv", INTERACTION_TSV, len(interaction_rows)),
        ("interaction_gmt", INTERACTION_GMT, 5),
        ("sep_tsv", SEP_TSV, len(sep_rows)),
        ("sep_gmt", SEP_GMT, 3),
        ("signature_statistics", STATS, len(counts)),
        ("frozen_config", CONFIG, 1),
    ]
    manifest_rows = [
        {
            "artifact_id": artifact_id,
            "path": path.relative_to(ROOT).as_posix(),
            "records_or_sets": records,
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
            "frozen_at_utc": frozen_at,
            "signature_version": "v1.0",
        }
        for artifact_id, path, records in artifact_specs
    ]
    write_tsv(
        F1_MANIFEST,
        manifest_rows,
        ["artifact_id", "path", "records_or_sets", "bytes", "sha256", "frozen_at_utc", "signature_version"],
    )

    print(f"Core={len(core_rows):,}; Interaction={len(interaction_rows):,}; SEP={len(sep_rows):,}")
    print(f"F1 manifest: {F1_MANIFEST}")


if __name__ == "__main__":
    main()
