#!/usr/bin/env python3
"""Independent integrity checks for frozen GSE13355 RMA and paired H analysis."""

from __future__ import annotations

import csv
import gzip
import hashlib
import math
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t",
                                lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def bh_adjust(pvalues: list[float]) -> list[float]:
    n = len(pvalues)
    order = sorted(range(n), key=pvalues.__getitem__)
    adjusted = [1.0] * n
    running = 1.0
    for rank_index in range(n - 1, -1, -1):
        original_index = order[rank_index]
        rank = rank_index + 1
        running = min(running, pvalues[original_index] * n / rank, 1.0)
        adjusted[original_index] = running
    return adjusted


def main() -> None:
    checks: list[dict[str, object]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": observed, "expected": expected,
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: {observed!r} != {expected!r}")

    archive = ROOT / "data" / "raw" / "GSE13355" / "GSE13355_RAW.tar"
    raw_audit = read_tsv(ROOT / "audits" / "stage02_gse13355" /
                         "gse13355_raw_archive_checks.tsv")
    cel_registry = read_tsv(ROOT / "audits" / "stage02_gse13355" /
                            "gse13355_cel_file_registry.tsv")
    pairs = read_tsv(ROOT / "metadata" / "gse13355_pp_pn_pair_registry.tsv")
    qc = read_tsv(ROOT / "results" / "stage02" / "gse13355" /
                  "gse13355_array_qc.tsv")
    design = read_tsv(ROOT / "results" / "stage02" / "gse13355" /
                      "gse13355_paired_design.tsv")
    results = read_tsv(ROOT / "results" / "stage02" / "gse13355" /
                       "gse13355_H_paired_all_genes.tsv")
    statistics_rows = read_tsv(ROOT / "results" / "stage02" / "gse13355" /
                               "gse13355_analysis_statistics.tsv")
    statistics = {row["metric"]: row for row in statistics_rows}
    software = read_tsv(ROOT / "metadata" / "stage02_gse13355_software_manifest.tsv")

    check("gse13355_archive_bytes", archive.stat().st_size, 955_514_880)
    check("gse13355_archive_sha256", sha256_file(archive),
          "47756971cd9fb9f9f1383944dffa70a9bcf0d8264ebfabf2442916f51411c4ac")
    check("gse13355_raw_audit_checks", (len(raw_audit), {row["status"] for row in raw_audit}),
          (15, {"PASS"}))
    check("gse13355_cel_registry", len(cel_registry), 180)
    check("gse13355_cel_gzip_crc", {row["gzip_crc_status"] for row in cel_registry}, {"PASS"})
    check("gse13355_cel_headers", {row["cel_header_status"] for row in cel_registry}, {"PASS"})
    cel_files = list((ROOT / "data" / "raw" / "GSE13355" / "CEL").glob("GSM*.CEL.gz"))
    check("gse13355_extracted_cel_count", len(cel_files), 180)
    check("gse13355_extracted_cel_names", {path.name for path in cel_files},
          {row["archive_member"] for row in cel_registry})

    check("gse13355_pair_rows", len(pairs), 58)
    check("gse13355_unique_pair_patients", len({row["patient_id"] for row in pairs}), 58)
    check("gse13355_pair_metadata_pass", {row["pair_metadata_status"] for row in pairs},
          {"PASS_EXACT_PATIENT_ID"})
    check("gse13355_pair_raw_pass", {row["raw_cel_status"] for row in pairs},
          {"PASS_RAW_CEL_AUDIT"})
    check("gse13355_pair_role", {row["development_role"] for row in pairs},
          {"HUMAN_DISCOVERY_ONLY"})

    check("gse13355_qc_rows", len(qc), 180)
    check("gse13355_qc_identity", {row["gsm"] for row in qc}, {row["gsm"] for row in cel_registry})
    check("gse13355_qc_conditions", Counter(row["condition"] for row in qc),
          Counter({"NN": 64, "PN": 58, "PP": 58}))
    check("gse13355_qc_all_finite",
          all(math.isfinite(float(row[key])) for row in qc for key in
              ("raw_log2_pm_median", "raw_log2_pm_iqr", "rle_median", "rle_iqr",
               "PC1", "PC2", "PC3", "pca_distance5")), True)
    check("gse13355_soft_qc_flags_report_only",
          sum(row["soft_qc_flag"] == "TRUE" for row in qc), 1)
    check("gse13355_primary_exclusions",
          sum(row["primary_exclusion"] == "TRUE" for row in qc), 0)
    check("gse13355_exclusion_rule", {row["exclusion_rule"] for row in qc},
          {"unreadable_or_corrupt_CEL_only"})

    check("gse13355_design_rows", len(design), 116)
    check("gse13355_design_unique_gsm", len({row["gsm"] for row in design}), 116)
    check("gse13355_design_rank_columns",
          {(row["design_rank"], row["design_columns"]) for row in design}, {("59", "59")})
    by_patient: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in design:
        by_patient[row["patient_id"]].append(row)
    check("gse13355_design_patient_count", len(by_patient), 58)
    check("gse13355_design_each_pair",
          all(Counter(row["condition"] for row in rows) == Counter({"PN": 1, "PP": 1})
              for rows in by_patient.values()), True)

    check("gse13355_result_rows", len(results), 20826)
    check("gse13355_result_unique_entrez", len({row["entrez_id"] for row in results}), 20826)
    check("gse13355_result_unique_symbol", len({row["gene_symbol"] for row in results}), 20826)
    check("gse13355_result_estimand", {row["estimand"] for row in results}, {"H_PP_minus_PN"})
    check("gse13355_result_unit", {row["statistical_unit"] for row in results}, {"paired_patient"})
    check("gse13355_result_n_pairs", {row["n_pairs"] for row in results}, {"58"})
    numeric_keys = ("logFC", "AveExpr", "t", "PValue", "FDR", "B")
    check("gse13355_result_all_finite",
          all(math.isfinite(float(row[key])) for row in results for key in numeric_keys), True)
    check("gse13355_pvalue_bounds",
          all(0 <= float(row["PValue"]) <= 1 for row in results), True)
    check("gse13355_fdr_bounds", all(0 <= float(row["FDR"]) <= 1 for row in results), True)
    pvalues = [float(row["PValue"]) for row in results]
    reported_fdr = [float(row["FDR"]) for row in results]
    recalculated_fdr = bh_adjust(pvalues)
    max_bh_delta = max(abs(a - b) for a, b in zip(reported_fdr, recalculated_fdr))
    check("gse13355_bh_recalculation", max_bh_delta < 1e-12, True,
          f"max absolute difference={max_bh_delta:.3e}")
    check("gse13355_significance_recalculation",
          all((float(row["FDR"]) < 0.05) == (row["significant_FDR_0_05"] == "TRUE")
              for row in results), True)
    check("gse13355_direction_recalculation",
          all(row["direction"] == ("UP" if float(row["logFC"]) > 0 else
                                    "DOWN" if float(row["logFC"]) < 0 else "ZERO")
              for row in results), True)
    check("gse13355_H_significant", sum(float(row["FDR"]) < 0.05 for row in results), 12362)
    check("gse13355_H_up_significant",
          sum(float(row["FDR"]) < 0.05 and row["direction"] == "UP" for row in results), 6445)
    check("gse13355_H_down_significant",
          sum(float(row["FDR"]) < 0.05 and row["direction"] == "DOWN" for row in results), 5917)

    expression_path = (ROOT / "results" / "stage02" / "gse13355" /
                       "gse13355_rma_gene_expression.tsv.gz")
    result_logfc = {row["entrez_id"]: float(row["logFC"]) for row in results}
    with gzip.open(expression_path, "rt", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle, delimiter="\t")
        header = next(reader)
        check("gse13355_expression_columns", len(header), 182)
        gsm_to_index = {gsm: index for index, gsm in enumerate(header)}
        pair_indices = [(gsm_to_index[row["pn_gsm"]], gsm_to_index[row["pp_gsm"]])
                        for row in pairs]
        expression_rows = 0
        expression_genes: set[str] = set()
        max_effect_delta = 0.0
        for row in reader:
            expression_rows += 1
            gene = row[0]
            expression_genes.add(gene)
            mean_difference = sum(float(row[pp]) - float(row[pn])
                                  for pn, pp in pair_indices) / 58
            max_effect_delta = max(max_effect_delta, abs(mean_difference - result_logfc[gene]))
    check("gse13355_expression_rows", expression_rows, 20826)
    check("gse13355_expression_gene_alignment", expression_genes, set(result_logfc))
    check("gse13355_logfc_equals_mean_paired_difference", max_effect_delta < 1e-12, True,
          f"max absolute difference={max_effect_delta:.3e}")

    check("gse13355_statistics_rows", len(statistics_rows), 16)
    expected_statistics = {"raw_arrays": 180, "NN_arrays_qc_only": 64,
                           "paired_patients": 58, "paired_arrays": 116,
                           "GPL570_probe_sets": 54675, "unique_entrez_mapped_probes": 43122,
                           "modeled_unique_genes": 20826, "design_rank": 59,
                           "design_columns": 59, "residual_df": 57,
                           "soft_qc_flags_report_only": 1, "primary_sample_exclusions": 0,
                           "H_FDR_lt_0.05": 12362, "H_up_FDR_lt_0.05": 6445,
                           "H_down_FDR_lt_0.05": 5917,
                           "validation_expression_accessed": 0}
    check("gse13355_statistics_values",
          {key: int(float(statistics[key]["value"])) for key in expected_statistics},
          expected_statistics)
    check("gse13355_software_components", len(software), 12)
    check("gse13355_software_project_local",
          all((row["component"] == "R" or "r_libs/stage02_human" in
               row["library_path"].replace("\\", "/")) for row in software), True)
    check("gse13355_affy_version",
          {row["version"] for row in software if row["component"] == "affy"}, {"1.84.0"})
    check("gse13355_limma_version",
          {row["version"] for row in software if row["component"] == "limma"}, {"3.62.2"})

    config = (ROOT / "config" / "stage02_gse13355.yaml").read_text(encoding="utf-8")
    analysis_script = (ROOT / "scripts" / "stage02_analyze_gse13355.R").read_text(encoding="utf-8")
    check("gse13355_config_primary_contrast", "primary_contrast: PP_minus_PN" in config, True)
    check("gse13355_config_no_effect_threshold", "effect_size_threshold: none" in config, True)
    check("gse13355_validation_absent_from_analysis",
          "GSE30999" not in analysis_script and "GSE121212" not in analysis_script, True)
    check("gse13355_session_info_exists",
          (ROOT / "results" / "stage02" / "gse13355" /
           "gse13355_sessionInfo.txt").stat().st_size > 1000, True)

    audit_path = ROOT / "audits" / "stage02_gse13355" / "gse13355_analysis_checks.tsv"
    write_tsv(audit_path, checks)
    print(f"PASS: {len(checks)} GSE13355 raw, pairing, RMA and paired-model checks; "
          f"BH max delta={max_bh_delta:.3e}; effect max delta={max_effect_delta:.3e}")


if __name__ == "__main__":
    main()
