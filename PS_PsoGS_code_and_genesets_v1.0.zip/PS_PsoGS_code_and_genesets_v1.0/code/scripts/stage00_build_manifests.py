#!/usr/bin/env python3
"""Build Stage 00 project manifests from explicitly audited facts.

The tables generated here describe designs and planned outputs. They do not mark
an analysis as complete merely because an input accession exists.
"""

from __future__ import annotations

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATE = "2026-09-12"


def write_tsv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def D(dataset_id, modality, organism, tissue, n, units, design, role, processed, raw, clinical, pairing, eligibility, status, risk, source):
    return {
        "dataset_id": dataset_id,
        "modality": modality,
        "organism": organism,
        "tissue_or_cell": tissue,
        "public_sample_records": str(n),
        "audited_independent_units": units,
        "design": design,
        "frozen_role": role,
        "processed_data": processed,
        "raw_data": raw,
        "clinical_or_covariate_fields": clinical,
        "pairing_or_repeated_structure": pairing,
        "confirmatory_eligibility": eligibility,
        "stage00_status": status,
        "key_risk_or_open_issue": risk,
        "source_url": source,
        "accessed_local_date": DATE,
    }


datasets = [
    D("GSE70603", "Agilent expression array", "Homo sapiens", "CD14+ monocytes", 180, "60 people", "control-history and early-adversity groups; each person at -45, +45, +180 min around one laboratory stressor", "PS-Reference actual human stress", "log2 quantile-normalized values in GEO sample tables", "2.2 GB custom Agilent feature-extraction TXT archive", "age; gender; adversity group in source_name; cortisol/ACTH not yet found in GEO fields", "60 complete three-timepoint subject labels", "PARTIAL: within-person temporal response; no unstressed time-control arm", "PARTIAL", "time and sampling effects cannot be separated from stress; A/B group must be decoded from source_name, not guessed", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE70603"),
    D("GSE212126", "bulk RNA-seq", "Mus musculus", "dorsal skin", 12, "12 independent unpooled mice; one RNA-seq library per mouse (user-confirmed 2026-09-10; anonymous project IDs)", "Control, CRS, IMQ, CRS+IMQ; n=3 independent mice per group; day 29", "Stage 02 factorial discovery", "two 55,401-gene workbooks with 6 FPKM columns each and pairwise statistics", "12 paired-end NovaSeq 6000 SRA runs; 23,679,415,090 compressed bytes; 12/12 SRA, FASTQ and BAM audits passed; 55,487-gene strandSpecific=2 matrix and edgeR S0/SD/I exported", "treatment; strain; day", "unpaired independent-animal groups", "PASS for mouse factorial inference and frozen F1 discovery input", "PASS_WITH_USER_CONFIRMED_ANIMAL_PROVENANCE", "animal independence and no pooling are user-confirmed but original animal IDs/source document are not archived locally; FPKM workbooks were not used as counts; broad differential signals require cautious interpretation", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE212126"),
    D("GSE270712", "10x scRNA-seq", "Mus musculus", "whole dorsal skin", 6, "6 pooled condition libraries; primary paper states 3 animals pooled per condition", "Control, stress, SA, SA+stress, and two unresolved SB-labelled libraries", "PS-Reference skin actual-stress context only", "per-sample MTX/features/barcodes; 240.9 MB series archive not downloaded", "SRA available", "treatment; genotype", "one pooled library per condition", "DESCRIPTIVE ONLY; no animal-level confirmatory inference", "PARTIAL", "no library-level biological replication; GSM8350489/490 canonical conditions are blank and HOLD because title/treatment/file fields conflict", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270712"),
    D("GSE270713", "bulk RNA-seq", "Homo sapiens; Mus musculus", "primary dermal/adipose fibroblasts and infected mouse skin", 36, "triplicate labels; exact donor/animal independence unresolved", "adrenaline/ADM in vitro; restraint stress and adrenalectomy in SA-infected mice", "PS-Reference neuroendocrine and skin-mechanism annotation", "three normalized-count tables", "SRA available", "cell identity; treatment; genotype", "nominal triplicates; no pairing", "PARTIAL: annotation/exploration pending unit audit", "PARTIAL", "normalized counts may not be integer counts; mixed species and experimental systems must remain separated", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270713"),
    D("GSE26487", "Affymetrix expression array", "Homo sapiens", "primary epidermal keratinocytes", 20, "2 independent cell batches, not 2 donors", "dexamethasone vs untreated at 1,4,24,48,72 h in two batches", "PS-Reference glucocorticoid mechanism annotation", "normalized log2 values", "20 CEL files in raw archive", "treatment; duration; batch label", "time-matched culture batches; destructive harvest", "EXPLORATORY/SENSITIVITY only because n=2 batches", "PARTIAL", "pharmacologic glucocorticoid exposure is not psychological stress", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE26487"),
    D("GSE13355", "Affymetrix expression array", "Homo sapiens", "skin", 180, "58 psoriasis patients plus 64 healthy controls", "58 paired PP/PN biopsies; 64 unpaired healthy NN", "human psoriasis discovery; only PP-PN develops Core/SEP", "all-180-array raw-CEL RMA frozen; 20,826 unique current-symbol genes", "180/180 CEL.gz audited; official-size 955,514,880-byte tar; SHA-256 47756971cd9fb9f9f1383944dffa70a9bcf0d8264ebfabf2442916f51411c4ac", "skin class; public sample-level sex/batch covariates remain sparse; one PN array has a report-only RLE-IQR soft flag", "58 exact patient-ID PP-PN pairs; 0 primary exclusions", "PASS for paired H=PP-PN discovery and frozen F1 input; 54/54 independent checks PASS", "PASS_RAW_RMA_PAIRED_MODEL", "do not use NN-vs-PP as primary development; GSM337287 soft flag retained under frozen rule; F1 retains all direction-discordant Core genes", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE13355"),
    D("GSE30999", "Affymetrix expression array", "Homo sapiens", "skin", 170, "primary paper: 89 biopsy participants and 85 analyzed pairs; public records: 89 subject IDs", "baseline lesional/non-lesional biopsies", "frozen-signature independent validation", "processed values in GEO; expression not accessed during pairing audit", "170 CEL files in raw archive", "subject; biopsy type", "81 exact public-ID pairs plus 8 singleton IDs", "PARTIAL: primary validation restricted to 81 exact-ID pairs unless source mapping recovers four reported pairs", "PARTIAL", "paper reports 85 paired analyses and 3 low-QC sample exclusions, but current public IDs do not reveal the remaining four pair mappings; never infer pairs from expression before F1", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE30999"),
    D("GSE121212", "bulk RNA-seq", "Homo sapiens", "skin", 147, "27 AD; 28 psoriasis; 38 healthy controls", "paired lesional/non-lesional disease skin plus healthy controls", "frozen-signature cross-platform validation and psoriasis-vs-AD effect-difference test", "5.4 MB read-count matrix", "SRA SRP165679", "disease; skin type", "27 psoriasis lesions and 27 non-lesions form complete pairs; one additional psoriasis lesion lacks a mate", "PASS with explicit pair restriction", "PASS", "AD chronic-lesion subset is not interchangeable with ordinary lesional samples", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE121212"),
    D("GSE173706", "10x scRNA-seq", "Homo sapiens", "full-thickness skin", 33, "22 canonical donors: 8 healthy and 14 psoriasis", "healthy normal, psoriasis peripheral-normal, psoriasis lesional", "single-cell discovery", "per-sample raw-count CSV files; 251.9 MB archive", "SRA SRP318151", "subject status; tissue type", "11 psoriasis donors have PN-PP pairs; 3 have PP only; 8 healthy have NS only", "PASS for donor-level pseudobulk after identity/QC audit", "PASS", "GSM5277178 subject/title typo 3696 was corrected to canonical donor 30696 from three concordant sample-code fields and primary paired design; raw value retained in audit", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE173706"),
    D("GSE162183", "10x scRNA-seq", "Homo sapiens", "full-thickness skin", 6, "3 psoriasis and 3 healthy labelled samples", "unpaired psoriasis lesion vs healthy skin", "independent single-cell replication", "raw-count table and Loom with patient IDs/embeddings", "not in GEO; human reads referenced at GSA HRA004936", "disease state", "unpaired", "PASS for donor-level replication; not suitable for paired lesion analysis", "PARTIAL", "public processed counts suffice for pseudobulk; splice-aware reconstruction/RegVelo remains blocked without accessible reads", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE162183"),
    D("GSE225475", "10x Visium spatial transcriptomics", "Homo sapiens", "skin sections", 6, "2 healthy and 4 psoriasis section libraries; no public donor IDs", "five fresh-frozen Visium sections and one FFPE Visium section", "spatial localization and descriptive module mapping", "per-sample archives contain matrix, staining image and spatial coordinates", "SRA available", "disease state; tissue storage", "one section/library per label; 20 micrometre frozen or 5 micrometre FFPE sections; 55 micrometre capture spots", "PARTIAL: descriptive spatial analysis after file-level QC; proximity/co-localization blocked by source-reported quality limits", "PARTIAL", "same publication/reference as GSE173706 with donor overlap unresolved; FFPE and frozen chemistry must remain separated; no spatial metabolomics", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE225475"),
    D("GSE228421", "10x scRNA-seq", "Homo sapiens", "skin biopsy", 20, "5 patients", "each patient: day0 lesional+non-lesional, day3 lesion, day14 lesion during risankizumab", "paired treatment-remodeling mechanism", "20 official raw UMI matrix triplets; all processed with per-library QC, Scrublet and frozen label transfer; 223,828 retained cells", "official 2,651,084,800-byte GEO RAW tar archived; reads not in GEO; submitter indicates dbGaP", "GEO disease state/time; no additional response-training fields used", "5 complete four-sample patient labels", "PASS for paired descriptive mechanism; FAIL for general response prediction because cohort selected for later clearance and n=5", "PASS_WITH_SMALL_N_LIMITATION", "patient is the statistical unit; exact two-sided Wilcoxon P cannot be below 0.0625 at n=5; do not train a general response model", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE228421"),
    D("GSE117468", "Affymetrix expression array", "Homo sapiens", "lesional/non-lesional skin", 565, "133 public patient IDs", "BL/W4/W12 samples across brodalumab 140/210, placebo and ustekinumab", "bulk treatment change; restricted conditional baseline prediction", "official submitted GCRMA matrix aggregated to 20,695 genes", "official 123,129,741-byte series matrix and GPL570 annotation archived", "patient ID; treatment; visit; tissue; PASI; age; BMI; weight; race; no sex field", "124 BL LS/NL pairs; 112 LS BL-W12 pairs; 105 complete BL/W12 LS/NL sets; restricted brodalumab prediction n=74 with PASI75 62/12", "PASS for longitudinal effects; internal prediction sensitivity only", "PASS_WITH_PREDICTION_BLOCKS", "M1 comparison signatures, external response cohort and matched multiview data absent; M0+SEP is not canonical M2; all performance intervals remain internal", "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE117468"),
]


overlaps = [
    {"resource_a": "GSE173706", "resource_b": "GSE225475", "overlap_level": "SAME_PUBLICATION_AND_REFERENCE_INTEGRATION", "exact_subject_overlap": "UNRESOLVED_NO_PUBLIC_SPATIAL_DONOR_IDS", "independence_for_validation": "NO", "evidence": "PMID 37308489 assigns scRNA to GSE173706 and spatial data to GSE225475; GEO spatial records expose NS1/NS2/PP1-PP4 but no donor identifiers", "action": "treat as complementary modalities; never call GSE225475 an independent replication of GSE173706; do not assert donors are shared or distinct", "status": "PARTIAL_HOLD", "source_url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC10261041/"},
    {"resource_a": "GSE173706", "resource_b": "GSE162183", "overlap_level": "DIFFERENT_PUBLICATIONS_AND_SUBMITTERS", "exact_subject_overlap": "NO_MATCHING_PUBLIC_LABELS_SEEN", "independence_for_validation": "PROVISIONAL_YES", "evidence": "distinct accessions, studies, submitters and sample labels", "action": "confirm publication cohort provenance before Stage 04 freeze", "status": "PARTIAL", "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE162183"},
    {"resource_a": "GSE13355", "resource_b": "GSE30999", "overlap_level": "DIFFERENT_STUDIES", "exact_subject_overlap": "NO_MATCHING_PUBLIC_LABELS_SEEN", "independence_for_validation": "PROVISIONAL_YES", "evidence": "different enrollment descriptions and subject identifier systems", "action": "retain GSE30999 as frozen validation; resolve its internal ID mismatch", "status": "PARTIAL", "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE30999"},
    {"resource_a": "GSE13355", "resource_b": "GSE121212", "overlap_level": "DIFFERENT_PLATFORM_AND_COHORT", "exact_subject_overlap": "NO_MATCHING_PUBLIC_LABELS_SEEN", "independence_for_validation": "PROVISIONAL_YES", "evidence": "Affymetrix 2009 cohort vs HiSeq 2019 cohort", "action": "retain GSE121212 as cross-platform validation", "status": "PARTIAL", "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE121212"},
    {"resource_a": "GSE270712", "resource_b": "GSE270713", "overlap_level": "SAME_PUBLICATION;DIFFERENT_ASSAYS", "exact_subject_overlap": "RELATED_EXPERIMENTAL_SYSTEMS", "independence_for_validation": "NO", "evidence": "both support PMID 40215323", "action": "use as mechanistic context, not mutual validation", "status": "PASS", "source_url": "https://pubmed.ncbi.nlm.nih.gov/40215323/"},
]


resources = [
    {"resource_id": "CTRA_KOHRT2016", "class": "fixed human adversity signature", "direction": "19 positive; 34 inverse", "membership_rule": "exact 53 indicators reported in full text; preserve raw names and map against frozen HGNC snapshot", "use": "PS-Reference only; never a psoriasis-trained feature set", "status": "PASS", "status_detail": "53 source members and 53 unique HGNC mappings frozen against 2026-09-10 snapshot", "source_url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC4961140/"},
    {"resource_id": "GSE70603_STRESS_RESPONSE", "class": "actual laboratory psychosocial stress", "direction": "timepoint-specific paired effects", "membership_rule": "FDR<0.05 in either pre-specified within-subject +45 vs -45 or +180 vs -45 contrast; retain timepoint and direction; do not use as a pure stress causal contrast", "use": "PS-Reference evidence stratum only", "status": "PASS", "status_detail": "60-person paired analysis and 57 integrity checks passed; 4,426 raw candidate symbols, of which 3,871 pass one-to-one HGNC mapping; no unstressed time-control arm", "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE70603"},
    {"resource_id": "GSE212126_FACTORIAL", "class": "actual mouse chronic restraint stress in psoriasis-like inflammation", "direction": "conditional S0/SD/I directions", "membership_rule": "use only audited strandSpecific=2 edgeR outputs and Ensembl Compara release-100 reciprocal 1:1 mapping; F1 frozen", "use": "sole experimental stress source for frozen PS-PsoGS-Core", "status": "PASS_F1_SOURCE", "status_detail": "12 independent unpooled mice user-confirmed; 12/12 reconstruction, count and model audits plus F1 mapping passed; public FPKM workbooks were not used", "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE212126"},
    {"resource_id": "GSE270712_SCRNA", "class": "actual mouse restraint-stress skin context", "direction": "none for confirmatory membership", "membership_rule": "no gene-member generation; descriptive-only cell-state context", "use": "PS-Reference descriptive mechanism layer", "status": "PARTIAL_HOLD", "status_detail": "one pooled library per condition and two SB labels unresolved", "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270712"},
    {"resource_id": "GSE270713_MDFB", "class": "adrenaline neuroendocrine proxy in mouse fibroblast culture", "direction": "none for automatic scoring", "membership_rule": "three culture libraries per condition; source animal/batch independence unresolved", "use": "mechanism annotation and sensitivity only", "status": "PARTIAL", "status_detail": "must not be renamed psychological stress", "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270713"},
    {"resource_id": "GSE270713_HPAD", "class": "adrenaline neuroendocrine proxy in human preadipocyte culture", "direction": "none for automatic scoring", "membership_rule": "three culture libraries per condition; no independent human donors", "use": "mechanism annotation and sensitivity only", "status": "PARTIAL", "status_detail": "commercial cell source must not be treated as donor replication", "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270713"},
    {"resource_id": "GSE270713_SKIN", "class": "actual mouse restraint-stress/ADX skin context", "direction": "none for automatic scoring", "membership_rule": "no gene-member generation until animal identities and count scale pass", "use": "descriptive mechanism context; not a GSE212126 substitute", "status": "PARTIAL", "status_detail": "animal IDs unresolved; deposited tables are normalized counts", "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270713"},
    {"resource_id": "GSE26487_DEX_KERATINOCYTE", "class": "dexamethasone pharmacologic proxy in human keratinocytes", "direction": "none for automatic scoring", "membership_rule": "two cell batches per time-treatment cell; no explicit donor identities", "use": "glucocorticoid sensitivity annotation only", "status": "PARTIAL", "status_detail": "drug exposure is not psychological stress", "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE26487"},
    {"resource_id": "ENDOCRINE_ONTOLOGY_REGISTRY", "class": "QuickGO exact functional annotations", "direction": "non-directional", "membership_rule": "GO:0071872, GO:0071874 and GO:0071385; human/mouse exact direct annotations; no descendants; API snapshot checksums frozen", "use": "PS-PsoGS-Reference annotation only; never automatic Core eligibility", "status": "PASS", "status_detail": "6 term-species snapshots, 165 annotations, 108 term-symbol rows; 46 human HGNC PASS and 9 human HOLD", "source_url": "https://www.ebi.ac.uk/QuickGO/"},
    {"resource_id": "DOI_10.1016_j.breast.2025.104678", "class": "narrative/method reference only", "direction": "FORBIDDEN_AS_GENE_SOURCE", "membership_rule": "none of its 374 genes may enter candidates, seeds, features or priors", "use": "organization reference only", "status": "PASS", "status_detail": "exclusion rule active", "source_url": "https://doi.org/10.1016/j.breast.2025.104678"},
    {"resource_id": "CLUE_CMAP_LINCS", "class": "perturbational connectivity", "direction": "query original disease UP/DOWN for negative connectivity", "membership_rule": "queries frozen at F3; aggregate by declared cell/dose/time rule; tau is not a p-value", "use": "Stage 08 only", "status": "BLOCKED", "status_detail": "service reachable but login required; public download route not frozen", "source_url": "https://clue.io/"},
]


ctra_up = ["IL1A","IL1B","IL6","IL8","TNF","PTGS1","PTGS2","FOS","FOSB","FOSL1","FOSL2","JUN","JUNB","JUND","NFKB1","NFKB2","REL","RELA","RELB"]
ctra_down = ["GBP1","IFI16","IFI27","IFI27L1","IFI27L2","IFI30","IFI35","IFI44","IFI44L","IFI6","IFIH1","IFIT1","IFIT2","IFIT3","IFIT5","IFIT1L","IFITM1","IFITM2","IFITM3","IFITM4P","IFITM5","IFNB1","IRF2","IRF7","IRF8","MX1","MX2","OAS1","OAS2","OAS3","OASL","IGJ","IGLL1","IGLL3"]
legacy_map = {"IL8": ("CXCL8", "HGNC_PREVIOUS_SYMBOL"), "IGJ": ("JCHAIN", "HGNC_PREVIOUS_SYMBOL"), "IFIT1L": ("IFIT1B", "HGNC_PREVIOUS_SYMBOL"), "IGLL3": ("IGLL3P", "HGNC_PREVIOUS_SYMBOL")}
ctra_rows = []
for symbol, direction in [(g, "UP") for g in ctra_up] + [(g, "DOWN") for g in ctra_down]:
    normalized, mapping = legacy_map.get(symbol, (symbol, "HGNC_APPROVED_SYMBOL_2026-09-10"))
    ctra_rows.append({"raw_symbol": symbol, "normalized_symbol": normalized, "direction": direction, "weight": "1" if direction == "UP" else "-1", "mapping_status": mapping, "source": "Kohrt et al. 2016 PNAS", "doi": "10.1073/pnas.1601301113", "eligibility": "PS_REFERENCE_FIXED_ONLY"})


signature_registry = [
    {"signature_id": "CTRA_KOHRT2016_v1.1_HGNC_2026-09-10", "layer": "PS-Reference", "members": "53", "up_members": "19", "down_members": "34", "development_inputs": "published fixed list plus frozen HGNC complete-set snapshot", "validation_inputs": "not applicable", "freeze_status": "SOURCE_MEMBERS_AND_HGNC_MAPPING_FROZEN", "allowed_use": "reference/annotation", "forbidden_use": "do not relabel as skin or psoriasis-specific", "file": "genesets/ctra_kohrt2016_v1.1_hgnc_2026-09-10.tsv"},
    {"signature_id": "GSE70603_TIME_LOCKED_v1.1_HGNC_2026-09-10", "layer": "PS-Reference evidence stratum", "members": "4426", "up_members": "timepoint-specific", "down_members": "timepoint-specific", "development_inputs": "GSE70603 processed log2 matrix; 60 paired people; pre-specified +45/-45 and +180/-45 contrasts", "validation_inputs": "none", "freeze_status": "ANALYSIS_RULE_FROZEN;3871_HGNC_PASS;555_HELD", "allowed_use": "time-locked laboratory stress reference evidence with timepoint/direction retained", "forbidden_use": "not a pure stress causal signature; no unstressed time-control; do not use held mappings", "file": "genesets/GSE70603_time_locked_stress_v1.1_hgnc_2026-09-10.tsv"},
    {"signature_id": "PS_REFERENCE_v0.1", "layer": "PS-Reference", "members": "TBD", "up_members": "TBD", "down_members": "TBD", "development_inputs": "CTRA; GSE70603; audited actual-stress and endocrine resources", "validation_inputs": "none at Stage 01", "freeze_status": "NOT_FROZEN", "allowed_use": "candidate retrieval with evidence strata", "forbidden_use": "no unstratified union score", "file": "genesets/PS_Reference_v0.1.gmt"},
    {"signature_id": "PS_PsoGS_Core_v1.0", "layer": "PS-PsoGS-Core", "members": "4976", "up_members": "1399_concordant", "down_members": "1317_concordant", "development_inputs": "GSE212126 SD plus GSE13355 paired PP-PN through Ensembl Compara release 100 reciprocal 1:1 orthology", "validation_inputs": "GSE30999; GSE121212 (not accessed before F1)", "freeze_status": "PASS_F1_2026-09-11", "allowed_use": "frozen discovery signature; 2260 direction-discordant members explicitly retained", "forbidden_use": "validation data cannot alter membership; discordant members have no unified directed-score sign", "file": "genesets/PS_PsoGS_Core_v1.0.gmt"},
    {"signature_id": "PS_PsoGS_Interaction_v1.0", "layer": "PS-PsoGS-Interaction", "members": "4085", "up_members": "NA_CLASSIFIED", "down_members": "NA_CLASSIFIED", "development_inputs": "Core plus formal CRS:IMQ interaction in GSE212126", "validation_inputs": "annotation only", "freeze_status": "PASS_F1_2026-09-11", "allowed_use": "423 augmentation; 141 attenuation; 3521 reversal by frozen signed-effect rule", "forbidden_use": "interaction significance or class is not automatically exacerbation or causality", "file": "genesets/PS_PsoGS_Interaction_v1.0.gmt"},
    {"signature_id": "SEP_v1.0", "layer": "SEP", "members": "2716", "up_members": "1399", "down_members": "1317", "development_inputs": "Core genes with concordant GSE212126 SD and GSE13355 lesion directions", "validation_inputs": "GSE30999; GSE121212 (not accessed before F1)", "freeze_status": "PASS_F1_2026-09-11", "allowed_use": "frozen directed scoring and Stage 08 Q1; 1530 high-confidence SEP-Interaction members", "forbidden_use": "do not call every member causal; validation cannot change direction or weight", "file": "genesets/SEP_v1.0.gmt"},
]


gene_ledger = []
for row in ctra_rows:
    gene_ledger.append({"raw_symbol": row["raw_symbol"], "normalized_symbol": row["normalized_symbol"], "evidence_source": "CTRA_KOHRT2016_v1.0", "evidence_type": "human_adversity_fixed_signature", "organism": "Homo sapiens", "tissue_or_cell": "dried blood spot / immune-cell-weighted transcriptome", "stress_or_perturbation": "war-related adversity/PTSD/resilience context", "contrast": "published fixed CTRA indicator", "direction": row["direction"], "effect": "", "uncertainty": "", "evidence_level": "REFERENCE_FIXED", "core_eligibility": "ANNOTATION_ONLY", "source_url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC4961140/", "notes": row["mapping_status"]})

gse70603_mapped_path = ROOT / "genesets" / "GSE70603_time_locked_stress_v1.1_hgnc_2026-09-10.tsv"
if gse70603_mapped_path.exists():
    for row in read_tsv(gse70603_mapped_path):
        eligibility = "ANNOTATION_ONLY" if row["mapping_status"] == "PASS" else "HOLD_HGNC_MAPPING"
        for timepoint, contrast, effect_key, fdr_key, direction_key in (
            ("+45", "+45 vs -45 minutes", "effect_plus45_log2", "fdr_plus45", "direction_plus45"),
            ("+180", "+180 vs -45 minutes", "effect_plus180_log2", "fdr_plus180", "direction_plus180"),
        ):
            if float(row[fdr_key]) >= 0.05:
                continue
            gene_ledger.append({
                "raw_symbol": row["raw_symbol"],
                "normalized_symbol": row["current_hgnc_symbol"],
                "evidence_source": "GSE70603_TIME_LOCKED_v1.1",
                "evidence_type": "human_laboratory_stress_time_locked_within_person",
                "organism": "Homo sapiens",
                "tissue_or_cell": "CD14+ monocytes",
                "stress_or_perturbation": "one laboratory psychosocial stressor; no unstressed time-control",
                "contrast": contrast,
                "direction": row[direction_key],
                "effect": row[effect_key],
                "uncertainty": f"FDR_BH={row[fdr_key]}",
                "evidence_level": "PAIRED_TIME_LOCKED_RESPONSE",
                "core_eligibility": eligibility,
                "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE70603",
                "notes": f"timepoint={timepoint}; response_class={row['response_class']}; "
                         f"mapping={row['mapping_status']}:{row['mapping_route']}",
            })


def panel(fig, letter, title, question, datasets_used, input_table, unit, method, plot, dependencies, evidence, caption, conditional="NO", status="PLANNED", qa_status="NOT_RENDERED", figure_ready="NO"):
    slug = f"fig{fig}{letter.lower()}"
    return {
        "figure_id": f"Figure {fig}", "panel_id": f"{fig}{letter}", "panel_title": title,
        "research_question": question, "dataset_inputs": datasets_used, "input_table": input_table,
        "statistical_unit": unit, "analysis_method": method, "plot_type": plot,
        "dependencies": dependencies, "analysis_script": f"scripts/figures/{slug}_analysis.R",
        "plot_script": f"scripts/figures/{slug}_plot.R", "source_data": f"figures/source_data/{slug}.tsv",
        "statistics_file": f"results/figures/{slug}_statistics.tsv", "config_file": f"config/figures/{slug}.yaml",
        "vector_output": f"figures/panels/{slug}.svg", "preview_output": f"figures/previews/{slug}.png",
        "evidence_level": evidence, "planned_caption": caption, "conditional": conditional,
        "status": status, "qa_status": qa_status, "figure_ready": figure_ready,
    }


panels = []

# Figure 1 — discovery and signature construction (10 panels)
panels.extend([
    panel(1,"A","Evidence-governed workflow","How are discovery, freezing and validation separated?","all audited resources","metadata/dataset_manifest.tsv;metadata/signature_registry.tsv;metadata/gse212126_library_animal_registry.tsv;audits/gse212126_user_confirmation.tsv;panel_manifest.tsv","dataset/stage","protocol map","gated workflow schematic","Stage 00 audit","design evidence","Pre-specified gates and data isolation; no biological result.",status="PASS",qa_status="PASS_RENDER_DATA_PRINT",figure_ready="YES"),
    panel(1,"B","Psychological-stress evidence strata","Which reference sources are actual stress, endocrine proxies or annotations?","CTRA;GSE70603;GSE212126;GSE270712;GSE270713;GSE26487;QuickGO exact","metadata/ps_reference_registry.tsv","resource","evidence-stratum audit","evidence map","resource provenance audit","reference evidence","Reference layers remain separate; overlap does not imply causality.",status="PASS",qa_status="PASS_RENDER_DATA_PRINT",figure_ready="YES"),
    panel(1,"C","Factorial mouse design and estimands","What are S0, SD and the CRS:IMQ interaction?","GSE212126","metadata/gse212126_library_animal_registry.tsv;audits/gse212126_user_confirmation.tsv","animal/library","factorial design specification","design schematic","independent-animal and no-pooling confirmation; design definitions do not require expression display","design evidence","S0=CRS-Ctrl; SD=CRS+IMQ-IMQ; I=SD-S0; the count/model gate now passes while this panel remains a design specification.",status="PASS",qa_status="PASS_RENDER_DATA_PRINT",figure_ready="YES"),
    panel(1,"D","Candidate evidence overlap","How do independent stress resources nominate candidate genes without forcing agreement?","CTRA;GSE70603;QuickGO exact endocrine terms","metadata/gene_evidence_ledger.tsv;genesets/endocrine_go_exact_2026-09-10.tsv","gene-by-source","stratified evidence count","UpSet/evidence matrix","PS-Reference freeze","reference evidence","Counts evidence by source and class; no unstratified union score.",status="PASS",qa_status="PASS_RENDER_DATA_PRINT",figure_ready="YES"),
    panel(1,"E","GSE212126 sample QC","Do raw counts support the four-group design and replicate structure?","GSE212126","results/stage02/factorial_edger/gse212126_library_QC.tsv;results/stage02/factorial_edger/gse212126_PCA_coordinates.tsv;results/stage02/counts/gse212126_strand_decision.tsv;metadata/gse212126_library_animal_registry.tsv","independent mouse/library","library QC, assignment audit and PCA","PCA/QC composite","12/12 SRA/FASTQ/BAM and count/model audits PASS","discovery QC","All libraries consistently support reverse-stranded counting, have comparable assigned-fragment depth and form four-group structure in PCA; these are QC observations, not mechanistic proof.",status="PASS",qa_status="PASS_RENDER_DATA_PRINT",figure_ready="YES"),
    panel(1,"F","Stress effects with and without psoriasis","Which genes have reliable S0 and SD effects?","GSE212126","results/stage02/factorial_edger/gse212126_S0_all_genes.tsv;results/stage02/factorial_edger/gse212126_SD_all_genes.tsv","gene across 12 independent mice","edgeR robust quasi-likelihood factorial model; BH within each predefined contrast family","paired effect plot/volcano","Figure 1E PASS","discovery inference","All 18,484 genes shown; 5,388 significant in both estimands, 3,752 S0-only, 3,593 SD-only and 5,751 neither; no effect threshold or post hoc gene selection.",status="PASS",qa_status="PASS_RENDER_DATA_PRINT",figure_ready="YES"),
    panel(1,"G","Formal interaction classification","Which Core genes show augmentation, attenuation or reversal?","GSE212126;GSE13355;Ensembl Compara 100","results/stage02/signatures/cross_species_gene_ledger.tsv.gz;audits/stage02_orthology/signature_f1_checks.tsv","gene across 12 independent mice; paired human discovery supports Core membership","Core plus predefined CRS:IMQ interaction BH-FDR<0.05; frozen S0/SD sign-and-magnitude classes","interaction quadrant","F1 PASS","discovery inference","All 4,085 Interaction members shown: 423 augmentation, 141 attenuation, 3,521 reversal; interaction classes are descriptive and not automatically exacerbation or causality.",status="PASS",qa_status="PASS_RENDER_DATA_PRINT",figure_ready="YES"),
    panel(1,"H","Mouse–human discovery concordance","Which genes support both mouse SD and paired human PP-PN effects?","GSE212126;GSE13355;Ensembl Compara 100","results/stage02/signatures/cross_species_gene_ledger.tsv.gz","gene; 58 paired human patients; 12 independent mice","frozen reciprocal 1:1 ortholog join plus paired human model","effect-size scatter","F1 PASS","cross-species discovery","Human discovery is paired PP-PN; all 4,976 Core genes including 2,260 directional conflicts remain visible; validation cohorts are not used.",status="PASS",qa_status="PASS_RENDER_DATA_PRINT",figure_ready="YES"),
    panel(1,"I","Core/interaction/SEP evidence ledger","What evidence and direction does every retained gene carry?","GSE212126;GSE13355;PS-Reference;Ensembl Compara 100","results/stage02/signatures/cross_species_gene_ledger.tsv.gz;metadata/gene_evidence_ledger.tsv;genesets/endocrine_go_exact_2026-09-10.tsv","gene-by-evidence-source","frozen rule-based classification and evidence annotation","annotated heatmap","F1 PASS; Figure 1H","signature provenance","All 4,976 Core rows are retained; Interaction, SEP, direction conflicts and annotation-only PS-Reference overlaps remain distinguishable.",status="PASS",qa_status="PASS_RENDER_DATA_PRINT",figure_ready="YES"),
    panel(1,"J","Frozen signature overview","What exactly is frozen before validation?","GSE212126;GSE13355;Ensembl Compara 100","metadata/signature_registry.tsv;metadata/signature_f1_manifest.tsv","signature/artifact","F1 checksum and rule freeze","signed membership plot","F1 PASS; Figures 1F-I","freeze artifact","Membership, direction, release-100 orthology, source hashes and score coverage rules are frozen before Figure 2.",status="PLANNED"),
])

# Figure 2 — locked bulk validation and specificity (10 panels)
panels.extend([
    panel(2,"A","Validation cohort partition","Are validation samples paired, independent and untouched during development?","GSE30999;GSE121212","metadata/sample_manifest.tsv","patient","locked-cohort audit","cohort flow diagram","F1 signature freeze","validation design","Only unambiguous pairs enter primary validation.",status="BLOCKED"),
    panel(2,"B","Within-person PS-PsoGS/SEP shifts","Do frozen scores rise or fall in psoriasis lesions?","GSE30999;GSE121212","results/stage03/paired_scores.tsv","patient","paired model with cohort-specific preprocessing","paired raincloud","Figure 2A PASS","independent validation","Patient-level paired differences with CI and exact n.",status="BLOCKED"),
    panel(2,"C","Cross-cohort score effects","Are validation effects consistent across array and RNA-seq cohorts?","GSE30999;GSE121212","results/stage03/score_meta.tsv","cohort effect estimate","fixed/random-effects sensitivity","forest plot","Figure 2B","independent validation","Cohorts are summarized without re-tuning membership.",status="BLOCKED"),
    panel(2,"D","Gene-level directional replication","Which frozen genes replicate their discovery direction?","GSE30999;GSE121212","results/stage03/gene_replication.tsv","gene-by-cohort","paired effect estimation; BH reported descriptively","direction heatmap","F1 signature freeze","independent validation","Replication rate and discordance are both shown.",status="BLOCKED"),
    panel(2,"E","Psoriasis-versus-AD specificity","Are lesion effects stronger or different in psoriasis than AD?","GSE121212","results/stage03/pso_ad_interaction.tsv","patient","direct disease-by-tissue interaction","interaction forest","Figure 2A PASS","specificity validation","Direct effect-difference test; separate AD chronic lesions.",status="BLOCKED"),
    panel(2,"F","Specificity comparator programs","Does the signature add information beyond inflammation, IFN and proliferation programs?","GSE30999;GSE121212","results/stage03/comparator_scores.tsv","patient","paired multivariable model","coefficient/partial-R2 plot","comparator signatures frozen","specificity analysis","Comparator results prevent relabeling generic inflammation as stress-specific.",status="BLOCKED"),
    panel(2,"G","Matched-random signature null","Is performance above matched random gene sets?","GSE30999;GSE121212","results/stage03/random_signature_null.tsv","random gene set within cohort","expression/size-matched permutation","null distribution","F1 signature freeze","validation sensitivity","Random sets are generated without seeing outcome labels.",status="BLOCKED"),
    panel(2,"H","Overlap and covariate sensitivity","Are results robust to array probe mapping, overlapping samples and available covariates?","GSE30999;GSE121212","results/stage03/sensitivity.tsv","patient","pre-specified sensitivity models","multiverse specification plot","metadata discrepancies adjudicated","validation sensitivity","Only pre-specified variants are reported; no model shopping.",status="BLOCKED"),
    panel(2,"I","Score coverage and influence","Are validation scores driven by missing genes or single influential members?","GSE30999;GSE121212","results/stage03/score_coverage.tsv","sample and gene","coverage and leave-one-gene-out analysis","coverage/influence plot","F1 signature freeze","measurement QA","Low-coverage scores are withheld under the frozen rule.",status="BLOCKED"),
    panel(2,"J","Validation evidence matrix","Which claims pass, fail or remain uncertain across both cohorts?","GSE30999;GSE121212","results/stage03/claim_matrix.tsv","claim-by-cohort","claim-level adjudication","traffic-light evidence matrix","Figures 2B-I","validation synthesis","Negative and discordant results remain visible.",status="BLOCKED"),
])

# Figure 3 — donor-aware single-cell localization (12 panels)
panels.extend([
    panel(3,"A","Integrated skin atlas","What major cell states are observed after per-donor QC?","GSE173706","data/processed/GSE173706_cell_metadata.tsv","cell for display; donor for inference","QC-aware integration","UMAP","F1 freeze; donor ID adjudication","single-cell descriptive","Embedding is descriptive and not a replicate count.",status="PLANNED"),
    panel(3,"B","Cell-type annotation evidence","Are labels supported by multiple canonical markers?","GSE173706","results/stage04/annotation_markers.tsv","cell cluster","marker specificity and reference checks","dot plot","Figure 3A","single-cell annotation","Ambiguous states remain explicitly uncertain.",status="PLANNED"),
    panel(3,"C","Donor and library composition","Are clusters dominated by a donor or tissue class?","GSE173706","results/stage04/composition_qc.tsv","donor/library","composition audit","stacked bars","Figure 3A","single-cell QC","Shows cell yield, not differential abundance inference.",status="PLANNED"),
    panel(3,"D","Condition-faceted atlas","Where do healthy, peripheral-normal and lesional cells map?","GSE173706","data/processed/GSE173706_cell_metadata.tsv","cell for display","fixed embedding facets","faceted UMAP","Figure 3A","single-cell descriptive","Axes and embedding are shared across conditions.",status="PLANNED"),
    panel(3,"E","Core score localization","Which cell types express the frozen Core program?","GSE173706","results/stage04/cell_scores.tsv","cell for display; donor-celltype pseudobulk for inference","UCell component scores","UMAP/violin","F1 Core freeze; >=70% coverage","single-cell localization","UP, DOWN and directed score are reported separately.",status="BLOCKED"),
    panel(3,"F","SEP score localization","Which cell types express the concordant SEP program?","GSE173706","results/stage04/cell_scores.tsv","cell for display; donor-celltype pseudobulk for inference","UCell component scores","dot/violin","F1 SEP freeze; >=70% coverage","single-cell localization","No direction flipping is allowed.",status="BLOCKED"),
    panel(3,"G","Donor-level cell-state effects","Which cell types show reproducible lesion-associated score changes?","GSE173706","results/stage04/donor_celltype_scores.tsv","donor","pseudobulk/mixed model","effect-size heatmap","Figures 3B,E-F","single-cell inference","Donor is the statistical replicate.",status="BLOCKED"),
    panel(3,"H","Within-donor paired effects","Do paired peripheral-normal and lesional libraries support within-person changes?","GSE173706","results/stage04/paired_donor_scores.tsv","paired donor","paired model","paired slope plot","donor identity audit PASS","single-cell inference","Unpaired donors are excluded from the primary paired contrast.",status="BLOCKED"),
    panel(3,"I","Focused stromal/epithelial atlas","Which subtypes carry the largest validated programs?","GSE173706","results/stage04/subatlas_metadata.tsv","cell for display; donor for inference","targeted reclustering after global audit","sub-UMAP","Figures 3G-H","single-cell localization","Subclustering is limited to pre-specified candidate compartments.",status="BLOCKED"),
    panel(3,"J","Differential abundance","Do cell-state proportions change at donor level?","GSE173706","results/stage04/differential_abundance.tsv","donor","compositional model","effect forest","minimum donor/cell thresholds","single-cell inference","Abundance and within-cell expression are not conflated.",status="PLANNED"),
    panel(3,"K","Independent scRNA replication","Do principal cell-type effects replicate in a separate cohort?","GSE162183","results/stage04/GSE162183_replication.tsv","donor","pseudobulk replication","effect forest","cell-label harmonization frozen","independent single-cell replication","Unpaired psoriasis-vs-healthy estimates are interpreted accordingly.",status="BLOCKED"),
    panel(3,"L","Composition versus within-cell signal","How much bulk score change is attributable to composition versus cell-intrinsic expression?","GSE173706;GSE162183","results/stage04/composition_decomposition.tsv","donor/cohort","counterfactual decomposition sensitivity","decomposition bars","Figures 3G,J,K","mechanistic synthesis","Reported as a model-based decomposition, not causal proof.",status="BLOCKED"),
])

# Figure 4 — state transitions and regulatory context (10 panels)
panels.extend([
    panel(4,"A","Trajectory root evidence","Which healthy-like state is a defensible trajectory root?","GSE173706","results/stage04/trajectory_root.tsv","donor-cell state","marker and condition enrichment audit","root evidence plot","Figure 3I","trajectory design","Root is selected without optimizing endpoint association.",status="PLANNED"),
    panel(4,"B","Monocle2 trajectory","Is there a reproducible healthy-to-lesional state continuum?","GSE173706","results/stage04/monocle2_pseudotime.tsv","cell for display; donor for inference","Monocle2","trajectory","Figure 4A PASS","trajectory descriptive","Pseudotime is an ordering, not elapsed time.",status="PLANNED"),
    panel(4,"C","scTour trajectory sensitivity","Does a second method recover the principal ordering?","GSE173706","results/stage04/sctour_pseudotime.tsv","cell for display; donor for inference","scTour","trajectory","Figure 4A PASS; environment dependency","trajectory sensitivity","Method disagreement is reported, not tuned away.",status="PLANNED"),
    panel(4,"D","Trajectory-method concordance","How concordant are Monocle2 and scTour by donor and state?","GSE173706","results/stage04/trajectory_concordance.tsv","donor-cell state","rank concordance and endpoint agreement","concordance plot","Figures 4B-C","trajectory sensitivity","Concordance is summarized across donors.",status="PLANNED"),
    panel(4,"E","Core and SEP along pseudotime","Where do frozen programs change along the state continuum?","GSE173706","results/stage04/scores_pseudotime.tsv","donor-cell state","GAM with donor blocking","smooth curves","F1 freeze; Figure 4B","trajectory association","Confidence bands and donor support are shown.",status="BLOCKED"),
    panel(4,"F","Barrier and differentiation markers","Do established epidermal/stromal functions change with the signature?","GSE173706","results/stage04/barrier_pseudotime.tsv","donor-cell state","GAM with fixed marker registry","multi-gene curves","Figure 4B","trajectory association","Markers were selected by biological role, not curve shape.",status="PLANNED"),
    panel(4,"G","Co-varying gene modules","Which modules track the frozen signature across donors and states?","GSE173706","results/stage04/pseudotime_modules.tsv","donor-cell state","module clustering with held-out donor sensitivity","module heatmap","Figures 4B,E","exploratory mechanism","Modules are exploratory and not added to the frozen signature.",status="BLOCKED"),
    panel(4,"H","Transcription-factor activity","Which regulons covary with the lesion-associated program?","GSE173706","results/stage04/tf_activity.tsv","donor-cell state","DoRothEA/decoupleR with frozen network version","activity heatmap","Figure 3 QC; network freeze","mechanistic association","Activity is inferred from expression, not directly measured binding.",status="PLANNED"),
    panel(4,"I","Regulatory association network","Which TF–target relations connect to Core/SEP genes?","GSE173706;public regulon database","results/stage04/regulatory_network.tsv","gene/regulon","evidence-filtered network overlay","network graph","Figures 4G-H","mechanistic association","Edge provenance and evidence class are retained.",status="BLOCKED"),
    panel(4,"J","Donor/root sensitivity","Are trajectory claims robust to donor removal and plausible roots?","GSE173706","results/stage04/trajectory_sensitivity.tsv","donor","leave-one-donor-out and root sensitivity","stability plot","Figures 4A-I","trajectory QA","Unstable transitions are downgraded or omitted.",status="PLANNED"),
])

# Figure 5 — intercellular communication and metabolic context (12 panels)
panels.extend([
    panel(5,"A","Prioritized multicellular network","Which cell states and pathways are carried forward from Figure 3?","GSE173706","results/stage05/focus_registry.tsv","cell type/pathway","pre-specified prioritization","network overview","Figure 3 PASS","mechanistic design","Only validated cell states enter focused analyses.",status="BLOCKED"),
    panel(5,"B","Donor-level expression effects","Are ligand and receptor changes reproducible across donors?","GSE173706","results/stage05/ligand_receptor_pseudobulk.tsv","donor-celltype","pseudobulk differential expression","effect forest","Figure 3 annotation freeze","single-cell inference","Cell count is not used as biological n.",status="PLANNED"),
    panel(5,"C","Communication method concordance","Which interactions agree between CellChat and CellPhoneDB?","GSE173706","results/stage05/communication_concordance.tsv","donor/interaction","two-method consensus","agreement matrix","Figure 5B; database versions frozen","communication association","Method-specific results remain separately auditable.",status="PLANNED"),
    panel(5,"D","Ligand–receptor–target evidence","Which candidate communications connect to frozen targets?","GSE173706","results/stage05/lr_target_matrix.tsv","interaction-by-target","expression plus curated-target evidence","evidence heatmap","Figures 5B-C","mechanistic association","Expression co-occurrence does not establish signaling.",status="BLOCKED"),
    panel(5,"E","NicheNet ligand prioritization","Which receiver-target programs are most compatible with observed senders?","GSE173706","results/stage05/nichenet.tsv","donor/ligand","NicheNet with declared background","ligand activity plot","Figure 5D","mechanistic prediction","Predictions require external or treatment support for stronger claims.",status="PLANNED"),
    panel(5,"F","Metabolic RNA-program map","Which cell states express pre-specified metabolic pathways?","GSE173706","results/stage05/metabolic_scores.tsv","cell for display; donor for inference","pathway scoring","UMAP/dot plot","pathway registry frozen","metabolic association","Transcript programs are not metabolite abundance.",status="PLANNED"),
    panel(5,"G","Donor-level metabolic effects","Which metabolic programs change at donor level?","GSE173706","results/stage05/metabolic_pseudobulk.tsv","donor-celltype","pseudobulk/mixed model","effect heatmap","Figure 5F","single-cell inference","Multiplicity and donor counts are reported.",status="PLANNED"),
    panel(5,"H","Predicted metabolic flux","What flux changes are predicted from expression?","GSE173706","results/stage05/scfea_flux.tsv","cell aggregated to donor-celltype","scFEA prediction","flux heatmap","input/network compatibility PASS","model-derived prediction","Clearly labelled predicted flux; no metabolomics claim.",status="PLANNED"),
    panel(5,"I","Signature–metabolism concordance","Do frozen scores covary with metabolic programs across donors?","GSE173706","results/stage05/score_metabolism.tsv","donor-celltype","partial association with condition adjustment","association plot","Figures 3G,5G-H","mechanistic association","Association does not establish directionality.",status="BLOCKED"),
    panel(5,"J","Communication–metabolism coupling","Are prioritized communication and metabolism changes coordinated?","GSE173706","results/stage05/communication_metabolism.tsv","donor","pre-specified multilevel association","bipartite network","Figures 5C,G","exploratory mechanism","Edges failing donor-level stability are removed.",status="PLANNED"),
    panel(5,"K","Database and subsampling sensitivity","Do communication conclusions survive database choice and balanced cell subsampling?","GSE173706","results/stage05/communication_sensitivity.tsv","donor/interaction","database/subsampling sensitivity","stability plot","Figure 5C","communication QA","Only stable interactions advance.",status="PLANNED"),
    panel(5,"L","Evidence-bounded mechanism model","What multicellular model is supported, predicted or unresolved?","GSE173706;GSE162183","results/stage05/mechanism_evidence.tsv","claim","evidence grading","mechanism schematic","Figures 3-5","synthesis","Measured associations and predictions use distinct visual encodings.",status="BLOCKED"),
])

# Figure 6 — spatial localization (12 panels)
panels.extend([
    panel(6,"A","Histology and section QC","Are all Visium sections analyzable at readable scale?","GSE225475","results/stage06/section_qc.tsv","section","image/spot QC","histology montage","scale and section IDs verified","spatial QC","No synthetic histology or missing scale bars.",status="PLANNED"),
    panel(6,"B","Anatomical compartment map","Where are epidermal, dermal and immune-rich regions?","GSE225475","results/stage06/compartments.tsv","spot nested in section","marker-based compartment annotation","spatial map","Figure 6A","spatial annotation","Annotations include uncertainty and source markers.",status="PLANNED"),
    panel(6,"C","Cell-state mapping","Where do Figure 3 cell states localize spatially?","GSE225475;GSE173706","results/stage06/cell_mapping.tsv","spot/section","reference mapping with held-out markers","spatial proportions","Figure 3 annotation freeze","spatial inference","Same-publication modalities are complementary, not independent validation.",status="BLOCKED"),
    panel(6,"D","Core spatial score","Where is the frozen Core program enriched?","GSE225475","results/stage06/spatial_scores.tsv","spot/section","directed score with coverage rule","spatial heatmap","F1 freeze; Figure 6A","spatial localization","Section-level support accompanies spot maps.",status="BLOCKED"),
    panel(6,"E","SEP spatial score","Where is the frozen SEP program enriched?","GSE225475","results/stage06/spatial_scores.tsv","spot/section","directed score with coverage rule","spatial heatmap","F1 freeze; Figure 6A","spatial localization","UP and DOWN components are retained.",status="BLOCKED"),
    panel(6,"F","Ligand/receptor/target localization","Do prioritized communication components occupy compatible neighborhoods?","GSE225475","results/stage06/lr_target_spatial.tsv","spot/section","spatial co-localization","multi-layer spatial map","Figure 5D","spatial association","Co-localization is not proof of signaling.",status="BLOCKED"),
    panel(6,"G","Metabolic RNA-program localization","Where do predicted metabolic transcript programs localize?","GSE225475","results/stage06/metabolic_spatial.tsv","spot/section","pathway scoring","spatial heatmap","Figure 5F","spatial association","No spatial metabolomics claim.",status="PLANNED"),
    panel(6,"H","Local co-occurrence","Are signature-high spots adjacent to prioritized cell states or pathways?","GSE225475","results/stage06/local_colocalization.tsv","spot nested in section","local bivariate association","local association map","Figures 6B-G; file-level QC must overturn the source-reported proximity limitation","spatial association","Currently blocked because the primary paper reports that data quality did not support spatial proximity analysis.",status="BLOCKED"),
    panel(6,"I","Constrained spatial permutation","Does co-occurrence exceed structure-preserving null expectations?","GSE225475","results/stage06/spatial_permutation.tsv","section","within-section constrained permutation","null distribution","Figure 6H PASS; permutation plan frozen","spatial inference","Not run unless a valid local co-occurrence statistic passes the source-quality gate.",status="BLOCKED"),
    panel(6,"J","Border-distance gradients","How do programs change from epidermal/dermal or lesion borders?","GSE225475","results/stage06/distance_gradients.tsv","spot nested in section","distance GAM with section effects","distance curves","validated boundary annotation; file-level image and quality gate","spatial association","Scale is known, but source-reported low resolution and incomplete coverage currently block distance inference.",status="BLOCKED"),
    panel(6,"K","Across-section consistency","Are spatial effects consistent across all six sections?","GSE225475","results/stage06/section_effects.tsv","section","section-level effect synthesis","forest/small multiples","Figures 6D-J; frozen and FFPE branches analyzed separately","spatial inference","Individual sections remain visible; frozen and FFPE assays are not pooled as exchangeable replicates.",status="BLOCKED"),
    panel(6,"L","Reference and donor-overlap sensitivity","Do conclusions depend on reference choice or unresolved donor overlap?","GSE225475;GSE173706;GSE162183","results/stage06/reference_sensitivity.tsv","section/reference","reference-transfer sensitivity","stability plot","donor overlap audit","spatial QA","Independence limits are explicitly reported.",status="PLANNED"),
])

# Figure 7 — longitudinal treatment remodeling and conditional prediction (12 panels)
panels.extend([
    panel(7,"A","Treatment-cohort designs","Which visits, tissues and patients support mechanism versus prediction?","GSE228421;GSE117468","metadata/sample_manifest.tsv;metadata/gse117468_patient_registry.tsv;audits/gse117468_cohort_summary.tsv;metadata/dataset_manifest.tsv","patient","cohort flow audit","design schematic","clinical-field audit complete","treatment design","GSE228421 is mechanism-only; GSE117468 public prediction cohort is capped at 74 and remains internal.",status="PASS",qa_status="PASS_RENDER_DATA_PRINT",figure_ready="YES"),
    panel(7,"B","Paired treatment score changes","Do frozen scores change from baseline within patients?","GSE228421;GSE117468","results/stage07/paired_score_changes.tsv","patient","paired longitudinal model","spaghetti/forest","F1 freeze; complete-case rules","treatment association","Within-patient effects and exact visit windows are shown.",status="BLOCKED"),
    panel(7,"C","Cell-proportion remodeling","Which cell states change during risankizumab treatment?","GSE228421","results/stage07/cell_proportions.tsv","patient","paired compositional analysis","trajectory bars","cell annotation freeze","treatment mechanism","Five selected responders limit generalization.",status="PLANNED"),
    panel(7,"D","Within-cell expression remodeling","Which cell-intrinsic programs change after treatment?","GSE228421","results/stage07/pseudobulk_time.tsv","patient-celltype","paired pseudobulk time model","effect heatmap","minimum cell thresholds","treatment mechanism","Patient, not cell, is the replicate.",status="PLANNED"),
    panel(7,"E","Communication remodeling","Do prioritized interactions diminish or persist under treatment?","GSE228421","results/stage07/communication_time.tsv","patient","paired interaction summary","network difference","Figure 5 focus registry","treatment mechanism","Method-derived communication is reported as prediction.",status="PLANNED"),
    panel(7,"F","Metabolic remodeling","Do pre-specified metabolic RNA programs change with treatment?","GSE228421","results/stage07/metabolism_time.tsv","patient-celltype","paired pathway model","effect heatmap","Figure 5 pathway registry","treatment mechanism","No metabolite measurement is implied.",status="PLANNED"),
    panel(7,"G","Residual program at day 14","Which cell states retain the frozen program despite early treatment?","GSE228421","results/stage07/residual_program.tsv","patient-celltype","paired residual analysis","dot/heatmap","Figures 7B-D","treatment mechanism","Residual expression is not treatment resistance proof.",status="BLOCKED"),
    panel(7,"H","Bulk treatment and tissue effects","How do scores vary by arm, visit and LS/NL status?","GSE117468","results/stage07/bulk_longitudinal.tsv","patient","mixed model with patient intercept","effect plot","F1 freeze; patient-level mixed-model specification","treatment association","Arms and tissue types are modeled explicitly.",status="BLOCKED"),
    panel(7,"I","Baseline model comparison","Does a baseline signature improve internal outcome prediction over clinical covariates?","GSE117468","results/stage07/model_comparison.tsv","patient","nested CV comparing M0/M1/M2","performance plot","F1 freeze; locked brodalumab n=74 outcome; patient-level nested CV","conditional prediction","Internal estimates only; no claim without external validation.",conditional="YES",status="BLOCKED"),
    panel(7,"J","Calibration and residual diagnostics","Are conditional predictions calibrated and technically credible?","GSE117468","results/stage07/calibration.tsv","held-out patient","nested-CV calibration/residual checks","calibration plot","Figure 7I feasible and executed","conditional prediction QA","No optimistic training-set metric is presented.",conditional="YES",status="BLOCKED"),
    panel(7,"K","Panel stability","Which genes are stably selected across resamples?","GSE117468","results/stage07/panel_stability.tsv","resampling fold/patient","selection-frequency analysis","stability path","Figure 7I feasible and executed","conditional prediction QA","Panel size is not tuned on a locked external cohort.",conditional="YES",status="BLOCKED"),
    panel(7,"L","Multi-view fusion ablation","Does matched multi-omic fusion add value beyond single views?","no eligible matched cohort currently","results/stage07/multiview_ablation.tsv","patient","MOGONET ablation","performance comparison","matched multi-view patient matrix","conditional method","Blocked because current modalities are not matched views on the same patients.",conditional="YES",status="BLOCKED"),
])

# Figure 8 — evidence-axis drug prioritization (12 panels)
panels.extend([
    panel(8,"A","Frozen perturbation queries","Which original and mechanism-focused UP/DOWN queries are submitted?","SEP;Core;validated cell-specific programs","results/stage08/query_registry.tsv","query","F3 checksum freeze","query schematic","F3 freeze after Figures 1-3","drug-prioritization design","Q1/Q2/Q3 remain separate and directional.",status="BLOCKED"),
    panel(8,"B","Connectivity evidence matrix","Which perturbagens reverse Q1, Q2 and Q3 across contexts?","LINCS/CLUE or frozen public equivalent","results/stage08/connectivity.tsv","perturbagen-context","declared tau aggregation","connectivity heatmap","public reproducible route frozen","perturbational evidence","Tau is not treated as a p-value.",status="BLOCKED"),
    panel(8,"C","Query-specific rankings","How different are disease, interaction and cell-specific reversal rankings?","LINCS/CLUE;Q1-Q3","results/stage08/query_rankings.tsv","perturbagen","rank comparison","rank scatter","Figure 8B","perturbational evidence","Disagreement is retained as biological/context uncertainty.",status="BLOCKED"),
    panel(8,"D","Multi-objective evidence scores","Which candidates perform across reversal, context and feasibility axes?","Stage08 evidence registry","results/stage08/multiobjective.tsv","perturbagen","pre-specified multi-objective ranking","Pareto plot","weights frozen before ranking","integrated prioritization","No single opaque weighted score replaces component evidence.",status="BLOCKED"),
    panel(8,"E","Cell/dose/time consistency","Are reversal signals robust across available perturbational contexts?","LINCS/CLUE","results/stage08/context_consistency.tsv","perturbagen-context","heterogeneity/stability analysis","context plot","Figure 8B","perturbational sensitivity","Context dependence is a result, not an inconvenience.",status="BLOCKED"),
    panel(8,"F","Signature sensitivity","Do candidates remain prioritized across Core, SEP and component queries?","LINCS/CLUE;frozen signatures","results/stage08/signature_sensitivity.tsv","perturbagen-query","rank stability","stability heatmap","Figures 8B-C","perturbational sensitivity","Validation data do not redefine the query.",status="BLOCKED"),
    panel(8,"G","Toxicity and differentiation risk","Which reversals may reflect nonspecific cytotoxicity or dedifferentiation?","LINCS metadata;public toxicity annotations","results/stage08/toxicity_flags.tsv","perturbagen-context","toxicity/differentiation flagging","risk matrix","annotation sources frozen","safety/context evidence","Risk flags reduce priority rather than being hidden.",status="BLOCKED"),
    panel(8,"H","BeyondCell cell-state sensitivity","Which cell states are predicted to be most perturbable?","validated single-cell atlas;perturbation reference","results/stage08/beyondcell.tsv","donor-celltype/perturbagen","BeyondCell","cell-state heatmap","Figure 3 PASS; compatible reference","model-derived prediction","Prediction is not experimental drug response.",status="BLOCKED"),
    panel(8,"I","Drug–target–cell–space network","How do candidates connect to validated targets, cell states and spatial regions?","Figures 3-6;drug-target databases","results/stage08/drug_network.tsv","evidence edge","provenance-weighted network","network graph","Figures 3-6 evidence gates","integrated hypothesis","Each edge exposes measured, curated or predicted status.",status="BLOCKED"),
    panel(8,"J","Independent perturbation support","Do external drug datasets reproduce reversal without reuse of query data?","independent public perturbation datasets","results/stage08/external_drug_validation.tsv","independent experiment","pre-specified replication test","effect forest","eligible dataset identified before testing","independent validation","No external dataset means the claim remains computational.",status="BLOCKED"),
    panel(8,"K","Human and translational evidence","What exposure, regulatory, clinical and human-stress evidence constrains each candidate?","DrugBank/ChEMBL/regulatory/public clinical literature","results/stage08/translational_evidence.tsv","candidate/evidence source","auditable evidence grading","evidence table","sources and dates frozen","translational annotation","Absence of evidence is not encoded as evidence of absence.",status="BLOCKED"),
    panel(8,"L","Final candidate hierarchy","Which candidates are prioritized, deprioritized or unresolved and why?","all Stage08 evidence","results/stage08/final_hierarchy.tsv","candidate","claim-level adjudication","ranked evidence matrix","Figures 8B-K","synthesis","Hierarchy includes negative evidence, conflicts and next validation experiment.",status="BLOCKED"),
])

# Durable completion overrides: preserve completed panel states if the Stage 00
# manifest builder is rerun after later-stage analyses.
completed_panel_ids = {
    *(f"1{x}" for x in "ABCDEFGHIJ"),
    "2A", "2B", "2C", "2D", "2E", "2G", "2H", "2I", "2J",
    *(f"3{x}" for x in "ABCDEFGHIJKL"),
    "4A", "4H",
    "5A", "5B", "5D", "5F", "5G", "5I", "5J", "5L",
    "6A", "6B", "6C", "6D", "6E", "6F", "6G", "6K", "6L",
    *(f"7{x}" for x in "ABCDEFGHIJ"),
    *(f"8{x}" for x in "ABCDEF"),
}
for row in panels:
    if row["panel_id"] in completed_panel_ids:
        row["status"] = "PASS"
        row["qa_status"] = "PASS_RENDER_DATA_PRINT"
        row["figure_ready"] = "YES"
    if row["figure_id"] == "Figure 3":
        row["analysis_script"] = "scripts/figures/figure3_analysis.py"
        row["plot_script"] = "scripts/figures/figure3_plot.py"
    if row["panel_id"] in {"4A", "4H", "5A", "5B", "5D", "5F", "5G", "5I", "5J", "5L"}:
        row["analysis_script"] = "scripts/figures/figure45_analysis.py"
        row["plot_script"] = "scripts/figures/figure45_plot.py"
    if row["panel_id"] in {"6A", "6B", "6C", "6D", "6E", "6F", "6G", "6K", "6L"}:
        row["analysis_script"] = "scripts/figures/figure6_analysis.py"
        row["plot_script"] = "scripts/figures/figure6_plot.py"
    if row["panel_id"] in {"7H", "7I", "7J"}:
        row["analysis_script"] = "scripts/figures/figure7_bulk_analysis.py"
        row["plot_script"] = "scripts/figures/figure7_bulk_plot.py"
    if row["panel_id"] in {"7B", "7C", "7D", "7E", "7F", "7G"}:
        row["analysis_script"] = "scripts/figures/figure7_singlecell_analysis.py"
        row["plot_script"] = "scripts/figures/figure7_singlecell_plot.py"
    if row["panel_id"] in {"8A", "8B", "8C", "8D", "8E", "8F"}:
        row["analysis_script"] = "scripts/figures/figure8_analysis.py"
        row["plot_script"] = "scripts/figures/figure8_plot.py"
    if row["panel_id"] == "2B":
        row["input_table"] = "results/stage03/scores/paired_scores.tsv;results/stage03/scores/paired_score_statistics.tsv;audits/stage03_bulk_validation_checks.tsv"

terminal_blocked_panels = {
    "2F": "BLOCKED_MISSING_FROZEN_COMPARATOR_SIGNATURES",
    "4B": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY",
    "4C": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY",
    "4D": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY",
    "4E": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY",
    "4F": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY",
    "4G": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY",
    "4I": "BLOCKED_NO_FDR_SIGNIFICANT_TF",
    "4J": "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY",
    "5C": "BLOCKED_NO_SECOND_COMMUNICATION_METHOD",
    "5E": "BLOCKED_NO_FROZEN_NICHENET_NETWORK",
    "5H": "BLOCKED_NO_VALIDATED_FLUX_INPUT",
    "5K": "BLOCKED_NO_SECOND_DATABASE_METHOD",
    "6H": "BLOCKED_BY_PRIMARY_PAPER_QUALITY_LIMITATION",
    "6I": "BLOCKED_BY_PRIMARY_PAPER_QUALITY_LIMITATION",
    "6J": "BLOCKED_BY_PRIMARY_PAPER_QUALITY_LIMITATION",
    "7K": "BLOCKED_ONLY_12_NONEVENTS_AND_NO_PRESPECIFIED_SELECTION",
    "7L": "BLOCKED_NO_MATCHED_MULTIVIEW_PATIENT_MATRIX",
    "8G": "BLOCKED_NO_FROZEN_RISK_ANNOTATIONS",
    "8H": "BLOCKED_NO_COMPATIBLE_VALIDATED_PERTURBATION_REFERENCE",
    "8I": "BLOCKED_NO_FROZEN_DRUG_TARGET_NETWORK_AND_SPATIAL_LR",
    "8J": "BLOCKED_NO_PREIDENTIFIED_INDEPENDENT_SKIN_DATASET",
    "8K": "BLOCKED_NO_AUDITED_TRANSLATIONAL_EVIDENCE_MATRIX",
    "8L": "BLOCKED_NO_INDEPENDENT_HUMAN_STRESS_OR_SKIN_DRUG_VALIDATION",
}
for row in panels:
    if row["panel_id"] in terminal_blocked_panels:
        row["status"] = terminal_blocked_panels[row["panel_id"]]
        row["qa_status"] = "NOT_RENDERED_INPUT_BLOCK"
        row["figure_ready"] = "NO"


def main():
    write_tsv(ROOT / "metadata" / "dataset_manifest.tsv", datasets)
    write_tsv(ROOT / "metadata" / "donor_overlap_audit.tsv", overlaps)
    write_tsv(ROOT / "metadata" / "resource_manifest.tsv", resources)
    write_tsv(ROOT / "metadata" / "signature_registry.tsv", signature_registry)
    write_tsv(ROOT / "metadata" / "gene_evidence_ledger.tsv", gene_ledger)
    write_tsv(ROOT / "genesets" / "ctra_kohrt2016_v1.0.tsv", ctra_rows)
    write_tsv(ROOT / "panel_manifest.tsv", panels)
    print(f"wrote {len(datasets)} datasets, {len(ctra_rows)} CTRA genes, and {len(panels)} panels")


if __name__ == "__main__":
    main()
