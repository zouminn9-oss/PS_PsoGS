#!/usr/bin/env python3
"""Validate Stage 00 manifests and emit machine-readable design checks."""

from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read_tsv(path: Path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def paired_count(rows, type_fn, required=("LS", "NL")):
    by_id = defaultdict(set)
    for row in rows:
        donor = row["donor_or_animal_id"]
        sample_type = type_fn(row)
        if donor and sample_type:
            by_id[donor].add(sample_type)
    needed = set(required)
    return sum(needed.issubset(types) for types in by_id.values()), len(by_id)


def main():
    datasets = read_tsv(ROOT / "metadata" / "dataset_manifest.tsv")
    samples = read_tsv(ROOT / "metadata" / "sample_manifest.tsv")
    panels = read_tsv(ROOT / "panel_manifest.tsv")
    ctra = read_tsv(ROOT / "genesets" / "ctra_kohrt2016_v1.0.tsv")
    ctra_hgnc = read_tsv(ROOT / "genesets" / "ctra_kohrt2016_v1.1_hgnc_2026-09-10.tsv")
    workbooks = read_tsv(ROOT / "audits" / "gse212126_workbook_audit.tsv")
    sra = read_tsv(ROOT / "audits" / "gse212126_sra_audit.tsv")
    animal_registry = read_tsv(ROOT / "metadata" / "gse212126_library_animal_registry.tsv")
    animal_confirmation = read_tsv(ROOT / "audits" / "gse212126_user_confirmation.tsv")
    g30999_pairs = read_tsv(ROOT / "metadata" / "gse30999_metadata_pair_registry.tsv")

    checks = []

    def check(check_id, observed, expected, note=""):
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": observed, "expected": expected,
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    check("dataset_count", len(datasets), 13)
    check("sample_record_count", len(samples), 1381)
    expected_samples = {"GSE117468":565,"GSE121212":147,"GSE13355":180,"GSE162183":6,
                        "GSE173706":33,"GSE212126":12,"GSE225475":6,"GSE228421":20,
                        "GSE26487":20,"GSE270712":6,"GSE270713":36,"GSE30999":170,"GSE70603":180}
    observed_samples = Counter(row["dataset_id"] for row in samples)
    for dataset_id, expected in expected_samples.items():
        check(f"samples_{dataset_id}", observed_samples[dataset_id], expected)

    check("ctra_total", len(ctra), 53)
    check("ctra_up", sum(row["direction"] == "UP" for row in ctra), 19)
    check("ctra_down", sum(row["direction"] == "DOWN" for row in ctra), 34)
    check("ctra_hgnc_total", len(ctra_hgnc), 53)
    check("ctra_hgnc_all_pass", sum(row["mapping_status"] == "PASS" for row in ctra_hgnc), 53)
    check("ctra_hgnc_unique_symbols", len({row["current_hgnc_symbol"] for row in ctra_hgnc}), 53)
    check("panel_total", len(panels), 90)
    check("panel_id_unique", len({row["panel_id"] for row in panels}), 90)
    expected_panel_counts = {"Figure 1":10,"Figure 2":10,"Figure 3":12,"Figure 4":10,
                             "Figure 5":12,"Figure 6":12,"Figure 7":12,"Figure 8":12}
    observed_panel_counts = Counter(row["figure_id"] for row in panels)
    for figure_id, expected in expected_panel_counts.items():
        check(f"panels_{figure_id.replace(' ', '_')}", observed_panel_counts[figure_id], expected)
    required_panel_fields = ["research_question","dataset_inputs","statistical_unit","analysis_script",
                             "plot_script","source_data","statistics_file","config_file","vector_output",
                             "preview_output","status","qa_status"]
    incomplete = sum(any(not row[field] for field in required_panel_fields) for row in panels)
    check("panels_required_fields_complete", incomplete, 0)
    ready_panels = [row for row in panels if row["figure_ready"] == "YES"]
    check("figure_ready_count", len(ready_panels), 66)
    check("figure_ready_ids", ",".join(sorted(row["panel_id"] for row in ready_panels)), "1A,1B,1C,1D,1E,1F,1G,1H,1I,1J,2A,2B,2C,2D,2E,2G,2H,2I,2J,3A,3B,3C,3D,3E,3F,3G,3H,3I,3J,3K,3L,4A,4H,5A,5B,5D,5F,5G,5I,5J,5L,6A,6B,6C,6D,6E,6F,6G,6K,6L,7A,7B,7C,7D,7E,7F,7G,7H,7I,7J,8A,8B,8C,8D,8E,8F")
    check("figure_ready_status_pass", sum(row["status"] == "PASS" for row in ready_panels), 66)
    check("figure_ready_qa_pass",
          sum(row["qa_status"] == "PASS_RENDER_DATA_PRINT" for row in ready_panels), 66)
    artifact_fields = ["analysis_script", "plot_script", "source_data", "statistics_file",
                       "config_file", "vector_output", "preview_output"]
    missing_ready_artifacts = sum(
        not all((ROOT / row[field]).is_file() for field in artifact_fields)
        for row in ready_panels
    )
    check("figure_ready_artifacts_complete", missing_ready_artifacts, 0)
    ready_captions_missing = sum(
        not (ROOT / "figures" / "captions" / f"fig{row['panel_id'].lower()}.md").is_file()
        for row in ready_panels
    )
    check("figure_ready_captions_complete", ready_captions_missing, 0)

    check("gse212126_workbooks", len(workbooks), 2)
    check("gse212126_all_fpkm_blocked",
          sum(row["formal_interaction_input_status"] == "FAIL_FPKM_NOT_RAW_COUNTS" for row in workbooks), 2)
    check("gse212126_gene_ids_each", ",".join(sorted(row["unique_gene_id_count"] for row in workbooks)), "55401,55401")
    check("gse212126_sra_records", len(sra), 12)
    check("gse212126_unique_biosamples", len({row["biosample"] for row in sra}), 12)
    check("gse212126_unique_runs", len({row["srr"] for row in sra}), 12)
    check("gse212126_paired_layout", sum(row["library_layout"] == "PAIRED" for row in sra), 12)
    check("gse212126_sra_compressed_bytes", sum(int(row["compressed_size_bytes"]) for row in sra), 23679415090)
    check("gse212126_two_reads_per_spot", sum(row["read_count_per_spot"] == "2" for row in sra), 12)
    check("gse212126_original_fastq_pairs", sum(len(row["original_fastq_names"].split("|")) == 2 for row in sra), 12)
    check("gse212126_confirmation_rows", len(animal_confirmation), 1)
    check("gse212126_animal_gate", animal_confirmation[0]["animal_gate_status"], "PASS_USER_CONFIRMED")
    check("gse212126_blocker_at_confirmation", animal_confirmation[0]["remaining_stage02_blocker"], "RAW_INTEGER_COUNTS_NOT_YET_RECONSTRUCTED")
    check("gse212126_animal_registry_rows", len(animal_registry), 12)
    check("gse212126_unique_confirmed_animals", len({row["canonical_animal_id"] for row in animal_registry}), 12)
    check("gse212126_one_library_per_animal", sum(row["libraries_per_animal"] == "1" for row in animal_registry), 12)
    check("gse212126_one_animal_per_library", sum(row["animals_per_library"] == "1" for row in animal_registry), 12)
    check("gse212126_no_pooling", sum(row["pooling_status"] == "NO_POOLING_USER_CONFIRMED" for row in animal_registry), 12)
    check("gse212126_independence_pass", sum(row["independence_status"] == "PASS_USER_CONFIRMED_ONE_LIBRARY_PER_INDEPENDENT_MOUSE" for row in animal_registry), 12)
    check("gse212126_registry_gsm_matches_sra", {row["gsm"] for row in animal_registry} == {row["gsm"] for row in sra}, True)
    check("gse212126_registry_srr_matches_sra", {row["srr"] for row in animal_registry} == {row["srr"] for row in sra}, True)

    by_dataset = defaultdict(list)
    for row in samples:
        by_dataset[row["dataset_id"]].append(row)

    n_pair, n_ids = paired_count(by_dataset["GSE30999"],
        lambda r: "LS" if r["sample_title"].endswith("_LS") else "NL" if r["sample_title"].endswith("_NL") else "")
    check("gse30999_unambiguous_pairs", n_pair, 81, "Series narrative says 85; primary validation must use audited pairs.")
    check("gse30999_parsed_ids", n_ids, 89)
    check("gse30999_pair_registry_rows", len(g30999_pairs), 89)
    check("gse30999_pair_registry_exact", sum(row["metadata_pair_status"] == "COMPLETE_EXACT_ID_PAIR" for row in g30999_pairs), 81)
    check("gse30999_pair_registry_expression_unused", sum(row["expression_data_accessed_for_pairing"] == "NO" for row in g30999_pairs), 89)

    pso = [r for r in by_dataset["GSE121212"] if r["donor_or_animal_id"].startswith("PSO_")]
    n_pair, n_ids = paired_count(pso, lambda r: "LS" if r["skin_type"] == "lesional" else "NL" if r["skin_type"] == "non-lesional" else "")
    check("gse121212_psoriasis_pairs", n_pair, 27)
    check("gse121212_psoriasis_ids", n_ids, 28)

    g117 = by_dataset["GSE117468"]
    g117_by_id = defaultdict(set)
    for row in g117:
        title = row["sample_title"]
        tissue = "LS" if "Tissue:LS" in title else "NL" if "Tissue:NL" in title else ""
        if row["donor_or_animal_id"] and tissue:
            g117_by_id[row["donor_or_animal_id"]].add((row["timepoint_or_visit"], tissue))
    check("gse117468_public_patient_ids", len(g117_by_id), 133)
    check("gse117468_baseline_pairs", sum({("BL","LS"),("BL","NL")}.issubset(v) for v in g117_by_id.values()), 124)
    check("gse117468_ls_bl_w12", sum({("BL","LS"),("W12","LS")}.issubset(v) for v in g117_by_id.values()), 112)
    check("gse117468_complete_four_cell", sum({("BL","LS"),("BL","NL"),("W12","LS"),("W12","NL")}.issubset(v) for v in g117_by_id.values()), 105)

    g228_ids = {row["donor_or_animal_id"] for row in by_dataset["GSE228421"] if row["donor_or_animal_id"]}
    check("gse228421_patient_ids", len(g228_ids), 5)

    write_tsv(ROOT / "audits" / "stage00_integrity_checks.tsv", checks)
    print(f"PASS: {len(checks)} Stage 00 integrity checks")


if __name__ == "__main__":
    main()
