from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))

import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats
import yaml


CFG = yaml.safe_load((ROOT / "config/stage05_mechanism_gate.yaml").read_text(encoding="utf-8"))
OUT = ROOT / "results/stage05"
AUDIT = ROOT / "audits"
OUT.mkdir(parents=True, exist_ok=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def bh(p):
    x = np.asarray(p, float)
    out = np.full(len(x), np.nan)
    good = np.isfinite(x)
    vals = x[good]
    if not len(vals):
        return out
    order = np.argsort(vals)
    ranked = vals[order]
    adj = ranked * len(ranked) / np.arange(1, len(ranked) + 1)
    adj = np.minimum.accumulate(adj[::-1])[::-1]
    tmp = np.empty(len(vals)); tmp[order] = np.minimum(adj, 1.0)
    out[np.where(good)[0]] = tmp
    return out


def paired_summary(pn: pd.Series, pp: pd.Series):
    common = sorted(set(pn.dropna().index) & set(pp.dropna().index))
    d = np.asarray([pp.loc[i] - pn.loc[i] for i in common], float)
    n = len(d)
    if n < 2:
        return n, np.nan, np.nan, np.nan, np.nan, np.nan, common, d
    mean = float(d.mean()); sd = float(d.std(ddof=1)); se = sd / math.sqrt(n)
    ci = stats.t.interval(0.95, n - 1, loc=mean, scale=se) if sd > 0 else (mean, mean)
    p = float(stats.ttest_1samp(d, 0).pvalue) if sd > 0 else (0.0 if mean != 0 else 1.0)
    gz = mean / sd * (1 - 3 / (4 * n - 5)) if sd > 0 else np.nan
    return n, mean, float(ci[0]), float(ci[1]), p, float(gz), common, d


meta_path = ROOT / "data/processed/stage04/gse173706_cell_metadata.tsv.gz"
count_path = ROOT / "data/processed/stage04/gse173706_selected_counts.npz"
gene_path = ROOT / "data/processed/stage04/gse173706_selected_genes.tsv"
meta = pd.read_csv(meta_path, sep="\t")
X = sp.load_npz(count_path).tocsr()
genes = pd.read_csv(gene_path, sep="\t")
assert X.shape == (len(meta), len(genes))

# Trajectory/root gate: inspect the frozen, label-blind fibroblast subatlas evidence.
sub = pd.read_csv(ROOT / "results/stage04/fibroblast_subtype_annotations.tsv", sep="\t")
named = sub.loc[~sub["fibroblast_subtype"].str.startswith("Uncertain")]
named_states = sorted(named["fibroblast_subtype"].unique())
state_donors = named.groupby("fibroblast_subtype")["donors"].max().to_dict()
state_dom = named.groupby("fibroblast_subtype")["max_single_donor_fraction"].max().to_dict()
traj_rows = [
    ("focus_state_frozen_before_stage05", True, "Fibroblast/SFRP2 target freeze v1.2 exists"),
    ("at_least_two_independently_named_states", len(named_states) >= int(CFG["trajectory"]["require_independently_named_states"]), f"named_states={','.join(named_states) or 'none'}"),
    ("each_named_state_has_minimum_donors", all(v >= int(CFG["trajectory"]["require_donors_per_state"]) for v in state_donors.values()) if state_donors else False, json.dumps(state_donors, sort_keys=True)),
    ("no_named_state_is_single_donor_dominated", all(v <= float(CFG["trajectory"]["maximum_single_donor_fraction"]) for v in state_dom.values()) if state_dom else False, json.dumps(state_dom, sort_keys=True)),
    ("root_can_be_defined_without_sep_direction", False, "No independently supported normal-to-terminal fibroblast state; using PN/low-SEP would be circular"),
    ("spliced_unspliced_available_for_regvelo", False, "Selected public matrices contain one count layer only"),
]
traj = pd.DataFrame(traj_rows, columns=["criterion", "pass", "evidence"])
traj["module_decision"] = "BLOCKED_NO_DEFENSIBLE_ROOT_AND_STATE_DIVERSITY"
traj.to_csv(OUT / "trajectory_input_gate.tsv", sep="\t", index=False)

# Create donor-tissue-celltype raw pseudobulks, retaining cell counts as an explicit gate.
min_cells = int(CFG["minimum_cells_per_donor_tissue_celltype"])
keys = meta[["donor_id", "tissue", "cell_type"]].astype(str).agg("|".join, axis=1)
levels, inv = np.unique(keys, return_inverse=True)
G = sp.csr_matrix((np.ones(len(inv)), (inv, np.arange(len(inv)))), shape=(len(levels), len(inv)))
pb_raw = (G @ X).tocsr()
idx = pd.DataFrame([x.split("|", 2) for x in levels], columns=["donor_id", "tissue", "cell_type"])
idx["n_cells"] = np.bincount(inv)
idx["total_counts"] = np.asarray(pb_raw.sum(axis=1)).ravel()
idx["eligible_min_cells"] = idx["n_cells"] >= min_cells

# Collapse duplicate symbols exactly by addition.
symbols = genes["human_gene_symbol"].fillna(genes["ensembl_gene_id"]).astype(str).str.upper().to_numpy(dtype=str)
unique_symbols, sym_inv = np.unique(symbols, return_inverse=True)
C = sp.csr_matrix((np.ones(len(symbols)), (np.arange(len(symbols)), sym_inv)), shape=(len(symbols), len(unique_symbols)))
pb = (pb_raw @ C).tocsr()
lib = np.asarray(pb.sum(axis=1)).ravel()
scale = np.divide(1e4, lib, out=np.zeros_like(lib, dtype=float), where=lib > 0)
logcpm = pb.multiply(scale[:, None]).tocsr()
logcpm.data = np.log1p(logcpm.data)
sp.save_npz(OUT / "donor_celltype_pseudobulk_log1p_cp10k.npz", logcpm)
idx.to_csv(OUT / "donor_celltype_pseudobulk_index.tsv", sep="\t", index=False)
pd.DataFrame({"matrix_column": np.arange(len(unique_symbols)), "gene_symbol": unique_symbols}).to_csv(OUT / "donor_celltype_pseudobulk_genes.tsv", sep="\t", index=False)
sym_col = {g: i for i, g in enumerate(unique_symbols)}

# Focus samples and helper for paired vectors.
focus = CFG["focus_cell_type"]
fib_rows = idx.index[(idx.cell_type == focus) & idx.eligible_min_cells].to_numpy()
fib_idx = idx.loc[fib_rows].reset_index().rename(columns={"index": "pb_row"})
fib_expr = logcpm[fib_rows].toarray()

# DoRothEA A-C signed target z-score activity at donor/tissue level.
dor_path = ROOT / "data/raw/stage05/omnipath_dorothea_20260911.tsv"
dor = pd.read_csv(dor_path, sep="\t", low_memory=False)
dor = dor[dor["dorothea_level"].isin(CFG["regulatory"]["confidence_levels"])].copy()
dor["tf"] = dor["source_genesymbol"].astype(str).str.upper()
dor["target_symbol"] = dor["target_genesymbol"].astype(str).str.upper()
dor["sign"] = np.where(dor["consensus_stimulation"].eq(True) & ~dor["consensus_inhibition"].eq(True), 1,
                       np.where(dor["consensus_inhibition"].eq(True) & ~dor["consensus_stimulation"].eq(True), -1, np.nan))
dor = dor.dropna(subset=["sign"])
dor = dor[dor.target_symbol.isin(sym_col)].copy()
dor = dor.groupby(["tf", "target_symbol"], as_index=False).agg(sign=("sign", "mean"), confidence=("dorothea_level", "min"))
dor = dor[dor["sign"].abs() == 1]
mu = fib_expr.mean(axis=0); sd = fib_expr.std(axis=0, ddof=1)
Z = np.divide(fib_expr - mu, sd, out=np.zeros_like(fib_expr), where=sd > 0)
tf_score_rows = []
for tf, d in dor.groupby("tf"):
    if len(d) < int(CFG["regulatory"]["minimum_targets"]):
        continue
    cols = np.array([sym_col[g] for g in d.target_symbol], int)
    signs = d.sign.to_numpy(float)
    vals = (Z[:, cols] * signs).mean(axis=1)
    for j, v in enumerate(vals):
        tf_score_rows.append({**fib_idx.loc[j, ["donor_id", "tissue", "n_cells"]].to_dict(), "tf": tf, "activity": v, "n_targets": len(d)})
tf_scores = pd.DataFrame(tf_score_rows)
tf_scores.to_csv(OUT / "fibroblast_dorothea_activity.tsv", sep="\t", index=False)
tf_eff = []
for tf, d in tf_scores.groupby("tf"):
    pn = d[d.tissue == "PN"].set_index("donor_id").activity
    pp = d[d.tissue == "PP"].set_index("donor_id").activity
    n, mean, lo, hi, p, gz, _, _ = paired_summary(pn, pp)
    tf_eff.append({"tf": tf, "n_pairs": n, "mean_pp_minus_pn": mean, "ci95_low": lo, "ci95_high": hi, "paired_t_p": p, "paired_hedges_gz": gz, "n_targets": int(d.n_targets.iloc[0]), "eligible": n >= int(CFG["minimum_complete_pairs"])})
tf_eff = pd.DataFrame(tf_eff)
tf_eff["fdr_bh"] = bh(tf_eff["paired_t_p"].where(tf_eff.eligible))
tf_eff.to_csv(OUT / "fibroblast_dorothea_paired_effects.tsv", sep="\t", index=False)

# CellPhoneDB v5 curated ligand-receptor expression compatibility; this is not the CPDB permutation method.
cpdir = ROOT / "data/raw/stage05/cellphonedb-v5.0.0/cellphonedb-data-5.0.0/data"
gene_in = pd.read_csv(cpdir / "gene_input.csv")
up2g = dict(zip(gene_in.uniprot.astype(str), gene_in.hgnc_symbol.astype(str).str.upper()))
complex_in = pd.read_csv(cpdir / "complex_input.csv")
complex_map = {}
for _, r in complex_in.iterrows():
    members = [up2g.get(str(r.get(f"uniprot_{i}")), "") for i in range(1, 6) if pd.notna(r.get(f"uniprot_{i}"))]
    members = [x for x in members if x]
    if members:
        complex_map[str(r.complex_name)] = tuple(members)
def partner_members(x):
    x = str(x)
    if x in complex_map:
        return complex_map[x]
    g = up2g.get(x)
    return (g,) if g else tuple()
inter = pd.read_csv(cpdir / "interaction_input.csv")
inter = inter[inter.directionality.astype(str) == CFG["communication"]["classification"]].copy()
lr = []
for _, r in inter.iterrows():
    a = partner_members(r.partner_a); b = partner_members(r.partner_b)
    if a and b and all(g in sym_col for g in a + b):
        lr.append({"interaction": str(r.interactors), "ligand_genes": "+".join(a), "receptor_genes": "+".join(b), "source": str(r.source), "classification": str(r.classification)})
lr = pd.DataFrame(lr).drop_duplicates(["ligand_genes", "receptor_genes"])
senders = CFG["communication"]["sender_cell_types"]
receiver = CFG["communication"]["receiver_cell_type"]
lr_rows = []
for sender in senders:
    srows = idx.index[(idx.cell_type == sender) & idx.eligible_min_cells].to_numpy()
    rrows = idx.index[(idx.cell_type == receiver) & idx.eligible_min_cells].to_numpy()
    smap = {(idx.at[i, "donor_id"], idx.at[i, "tissue"]): i for i in srows}
    rmap = {(idx.at[i, "donor_id"], idx.at[i, "tissue"]): i for i in rrows}
    for z in lr.itertuples(index=False):
        lc = [sym_col[g] for g in z.ligand_genes.split("+")]
        rc = [sym_col[g] for g in z.receptor_genes.split("+")]
        values = {}
        detected = []
        for k in sorted(set(smap) & set(rmap)):
            le = np.asarray(logcpm[smap[k], lc].toarray()).ravel()
            re = np.asarray(logcpm[rmap[k], rc].toarray()).ravel()
            lv = float(le.min()); rv = float(re.min())
            values[k] = math.sqrt(max(lv, 0) * max(rv, 0))
            detected.append(lv > 0 and rv > 0)
        pn = pd.Series({d: v for (d, t), v in values.items() if t == "PN"}, dtype=float)
        pp = pd.Series({d: v for (d, t), v in values.items() if t == "PP"}, dtype=float)
        n, mean, lo, hi, p, gz, _, _ = paired_summary(pn, pp)
        det = float(np.mean(detected)) if detected else 0.0
        eligible = n >= int(CFG["minimum_complete_pairs"]) and det >= float(CFG["communication"]["minimum_component_detection_fraction"])
        lr_rows.append({"sender": sender, "receiver": receiver, **z._asdict(), "n_pairs": n, "component_detection_fraction": det, "mean_pp_minus_pn": mean, "ci95_low": lo, "ci95_high": hi, "paired_t_p": p, "paired_hedges_gz": gz, "eligible": eligible})
lr_eff = pd.DataFrame(lr_rows)
lr_eff["fdr_bh"] = bh(lr_eff["paired_t_p"].where(lr_eff.eligible))
lr_eff.to_csv(OUT / "cellphonedb_v5_lr_paired_effects.tsv.gz", sep="\t", index=False, compression="gzip")

# Frozen Reactome metabolism programs scored from within-pseudobulk percentiles.
gmt = {}
with (ROOT / "data/raw/stage05/reactome-current/ReactomePathways.gmt").open(encoding="utf-8") as f:
    for line in f:
        parts = line.rstrip("\n").split("\t")
        if len(parts) >= 3:
            gmt[parts[1]] = (parts[0], [g.upper() for g in parts[2:]])
sep = set(pd.read_csv(ROOT / "genesets/SEP_v1.0.tsv", sep="\t")["human_gene_symbol"].astype(str).str.upper())
cell_cycle = set(gmt.get(CFG["metabolism"]["cell_cycle_pathway_id"], ("", []))[1])
ranks = np.apply_along_axis(stats.rankdata, 1, fib_expr) / fib_expr.shape[1]
met_rows = []
for pid in CFG["metabolism"]["pathway_ids"]:
    name, members = gmt[pid]
    avail = [g for g in members if g in sym_col]
    sens = [g for g in avail if g not in sep and g not in cell_cycle]
    for variant, use in [("primary", avail), ("remove_sep_cell_cycle", sens)]:
        if len(use) < 5:
            continue
        vals = ranks[:, [sym_col[g] for g in use]].mean(axis=1)
        for j, v in enumerate(vals):
            met_rows.append({**fib_idx.loc[j, ["donor_id", "tissue", "n_cells", "total_counts"]].to_dict(), "pathway_id": pid, "pathway": name, "variant": variant, "score": v, "n_genes": len(use), "sep_overlap": len(set(avail) & sep), "cell_cycle_overlap": len(set(avail) & cell_cycle)})
met_scores = pd.DataFrame(met_rows)
met_scores.to_csv(OUT / "fibroblast_reactome_metabolism_scores.tsv", sep="\t", index=False)
met_eff = []
for (pid, name, variant), d in met_scores.groupby(["pathway_id", "pathway", "variant"]):
    pn = d[d.tissue == "PN"].set_index("donor_id").score
    pp = d[d.tissue == "PP"].set_index("donor_id").score
    n, mean, lo, hi, p, gz, _, _ = paired_summary(pn, pp)
    rho, rho_p = stats.spearmanr(d.score, np.log1p(d.total_counts))
    met_eff.append({"pathway_id": pid, "pathway": name, "variant": variant, "n_pairs": n, "mean_pp_minus_pn": mean, "ci95_low": lo, "ci95_high": hi, "paired_t_p": p, "paired_hedges_gz": gz, "n_genes": int(d.n_genes.iloc[0]), "sep_overlap": int(d.sep_overlap.iloc[0]), "cell_cycle_overlap": int(d.cell_cycle_overlap.iloc[0]), "depth_spearman_rho": rho, "depth_spearman_p": rho_p, "eligible": n >= int(CFG["minimum_complete_pairs"])})
met_eff = pd.DataFrame(met_eff)
for variant in met_eff.variant.unique():
    mask = (met_eff.variant == variant) & met_eff.eligible
    met_eff.loc[mask, "fdr_bh"] = bh(met_eff.loc[mask, "paired_t_p"])
met_eff.to_csv(OUT / "fibroblast_reactome_metabolism_paired_effects.tsv", sep="\t", index=False)

files = [
    ROOT / "data/raw/stage05/cellphonedb-data-v5.0.0.zip",
    ROOT / "data/raw/stage05/ReactomePathways-current.gmt.zip",
    dor_path,
]
pd.DataFrame([{"file": str(p.relative_to(ROOT)).replace("\\", "/"), "bytes": p.stat().st_size, "sha256": sha256(p)} for p in files]).to_csv(OUT / "stage05_reference_manifest.tsv", sep="\t", index=False)

checks = [
    ("input_dimensions_match", X.shape == (len(meta), len(genes)), f"{X.shape}"),
    ("trajectory_gate_closed", not traj["pass"].all(), traj.module_decision.iloc[0]),
    ("pseudobulk_nonempty", pb.shape[0] > 0 and pb.nnz > 0, f"{pb.shape}; nnz={pb.nnz}"),
    ("tf_regulons_scored", len(tf_scores) > 0, f"TFs={tf_scores.tf.nunique() if len(tf_scores) else 0}"),
    ("lr_database_nonempty", len(lr) > 0, f"mapped_LR={len(lr)}"),
    ("lr_effects_written", len(lr_eff) > 0, f"tests={len(lr_eff)}"),
    ("metabolism_exact_programs", met_scores.pathway_id.nunique() == len(CFG["metabolism"]["pathway_ids"]), f"programs={met_scores.pathway_id.nunique()}"),
    ("reference_hashes_complete", all(len(sha256(p)) == 64 for p in files), f"files={len(files)}"),
]
audit = pd.DataFrame(checks, columns=["check", "pass", "detail"])
audit.to_csv(AUDIT / "stage05_mechanism_gate_checks.tsv", sep="\t", index=False)
if not audit["pass"].all():
    raise AssertionError(audit.loc[~audit["pass"]].to_string(index=False))

summary = {
    "trajectory_decision": traj.module_decision.iloc[0],
    "pseudobulk_groups": int(len(idx)),
    "eligible_fibroblast_groups": int(len(fib_idx)),
    "tf_count": int(tf_scores.tf.nunique()),
    "tf_fdr_lt_0_05": int(((tf_eff.fdr_bh < 0.05) & tf_eff.eligible).sum()),
    "mapped_cpdb_lr": int(len(lr)),
    "eligible_lr_tests": int(lr_eff.eligible.sum()),
    "lr_fdr_lt_0_05": int(((lr_eff.fdr_bh < 0.05) & lr_eff.eligible).sum()),
    "metabolism_programs": int(met_scores.pathway_id.nunique()),
    "metabolism_primary_fdr_lt_0_05": int(((met_eff.variant == "primary") & (met_eff.fdr_bh < 0.05)).sum()),
}
(OUT / "stage05_mechanism_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
print(f"PASS: {len(audit)} Stage 05 mechanism gate checks")
