#!/usr/bin/env python3
"""Audit the official GSE13355 RAW tar and every compressed CEL payload."""

from __future__ import annotations

import csv
import gzip
import hashlib
import re
import struct
import tarfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / "data" / "raw" / "GSE13355" / "GSE13355_RAW.tar"
EXPECTED_BYTES = 955_514_880
EXPECTED_SHA256 = "47756971cd9fb9f9f1383944dffa70a9bcf0d8264ebfabf2442916f51411c4ac"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t",
                                lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    samples = [row for row in read_tsv(ROOT / "metadata" / "sample_manifest.tsv")
               if row["dataset_id"] == "GSE13355"]
    expected_gsms = {row["sample_id"] for row in samples}
    checks: list[dict[str, object]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": observed, "expected": expected,
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: {observed!r} != {expected!r}")

    check("gse13355_archive_exists", ARCHIVE.is_file(), True)
    check("gse13355_archive_bytes", ARCHIVE.stat().st_size, EXPECTED_BYTES,
          "official HTTP Content-Length captured 2026-09-11")
    archive_sha = sha256_file(ARCHIVE)
    check("gse13355_archive_sha256", archive_sha, EXPECTED_SHA256,
          "local checksum frozen after range assembly")

    registry: list[dict[str, object]] = []
    with tarfile.open(ARCHIVE, mode="r:") as archive:
        members = archive.getmembers()
        regular = [member for member in members if member.isfile()]
        check("gse13355_tar_members", len(members), 180)
        check("gse13355_tar_regular_files", len(regular), 180)
        check("gse13355_tar_safe_flat_paths",
              all(Path(member.name).name == member.name and ".." not in Path(member.name).parts
                  for member in regular), True)
        pattern = re.compile(r"^(GSM\d+)\.CEL\.gz$")
        parsed = [(member, pattern.fullmatch(member.name)) for member in regular]
        check("gse13355_tar_cel_gz_names", all(match is not None for _, match in parsed), True)
        observed_gsms = {match.group(1) for _, match in parsed if match}
        check("gse13355_tar_gsm_set_matches_metadata", observed_gsms, expected_gsms)

        for index, (member, match) in enumerate(parsed, start=1):
            assert match is not None
            raw = archive.extractfile(member)
            if raw is None:
                raise AssertionError(f"cannot read {member.name}")
            digest = hashlib.sha256()
            uncompressed_bytes = 0
            first = b""
            with gzip.GzipFile(fileobj=raw, mode="rb") as decompressed:
                while True:
                    chunk = decompressed.read(4 * 1024 * 1024)
                    if not chunk:
                        break
                    if not first:
                        first = chunk[:16]
                    digest.update(chunk)
                    uncompressed_bytes += len(chunk)
            binary_magic = len(first) >= 4 and struct.unpack("<i", first[:4])[0] == 64
            text_magic = first.startswith(b"[CEL")
            registry.append({
                "gsm": match.group(1), "archive_member": member.name,
                "compressed_bytes": member.size, "uncompressed_bytes": uncompressed_bytes,
                "uncompressed_sha256": digest.hexdigest(),
                "cel_header_status": "PASS" if binary_magic or text_magic else "FAIL",
                "gzip_crc_status": "PASS", "archive_order": index,
            })

    check("gse13355_registry_rows", len(registry), 180)
    check("gse13355_unique_registry_gsm", len({row["gsm"] for row in registry}), 180)
    check("gse13355_all_gzip_crc", {row["gzip_crc_status"] for row in registry}, {"PASS"})
    check("gse13355_all_cel_headers", {row["cel_header_status"] for row in registry}, {"PASS"})
    check("gse13355_positive_compressed_bytes",
          all(int(row["compressed_bytes"]) > 0 for row in registry), True)
    check("gse13355_positive_uncompressed_bytes",
          all(int(row["uncompressed_bytes"]) > 0 for row in registry), True)
    check("gse13355_validation_expression_accessed", 0, 0)

    audit_dir = ROOT / "audits" / "stage02_gse13355"
    write_tsv(audit_dir / "gse13355_cel_file_registry.tsv", registry)
    write_tsv(audit_dir / "gse13355_raw_archive_checks.tsv", checks)
    print(f"PASS: official-size archive, {len(registry)} CEL gzip/headers, "
          f"{len(checks)} raw-data checks; sha256={archive_sha}")


if __name__ == "__main__":
    main()
