from pathlib import Path
import csv,sys
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import pandas as pd
from PIL import Image
checks=[]
def ck(n,p,d): checks.append((n,bool(p),str(d)))
for p in [f"7{x.lower()}" for x in "BCDEFG"]:
 files={"source":ROOT/f"figures/source_data/fig{p}.tsv","stats":ROOT/f"results/figures/fig{p}_statistics.tsv","config":ROOT/f"config/figures/fig{p}.yaml","svg":ROOT/f"figures/panels/fig{p}.svg","png":ROOT/f"figures/previews/fig{p}.png","caption":ROOT/f"figures/captions/fig{p}.md"}
 for k,f in files.items(): ck(f"{p}_{k}_exists",f.exists() and f.stat().st_size>0,f)
 ck(f"{p}_source_nonempty",len(pd.read_csv(files["source"],sep="\t"))>0,files["source"])
 ck(f"{p}_stats_nonempty",len(pd.read_csv(files["stats"],sep="\t"))>0,files["stats"])
 with Image.open(files["png"]) as im: ck(f"{p}_print_pixels",im.width>=900 and im.height>=600,f"{im.width}x{im.height}")
 ck(f"{p}_caption_complete",len(files["caption"].read_text(encoding="utf-8").split())>=35,"word-like tokens")
qc=pd.read_csv(ROOT/"results/stage07/gse228421/library_qc.tsv",sep="\t")
ck("twenty_libraries",len(qc)==20,len(qc)); ck("five_patients",qc.patient_id.nunique()==5,qc.patient_id.nunique()); ck("four_libraries_per_patient",qc.groupby("patient_id").size().eq(4).all(),qc.groupby("patient_id").size().to_dict()); ck("scrublet_all_pass",qc.scrublet_status.eq("PASS").all(),qc.scrublet_status.value_counts().to_dict())
transfer=pd.read_csv(ROOT/"results/stage07/gse228421/label_transfer_qc.tsv",sep="\t")
ck("frozen_transfer_model_all_libraries",transfer.model_source.eq("GSE173706 frozen Stage04 SGD label transfer").all(),transfer.model_source.unique())
ck("transfer_feature_coverage",transfer.transfer_features_mapped.min()>=3000,transfer.transfer_features_mapped.min())
effects=pd.read_csv(ROOT/"results/stage07/gse228421/within_celltype_program_effects.tsv",sep="\t")
ck("no_impossible_small_exact_p",not ((effects.n_patient_pairs==5)&(effects.wilcoxon_p<.0625-1e-12)).any(),effects.loc[effects.n_patient_pairs==5,"wilcoxon_p"].min())
with (ROOT/"panel_manifest.tsv").open(encoding="utf-8",newline="") as f: man={r["panel_id"]:r for r in csv.DictReader(f,delimiter="\t")}
for p in [f"7{x}" for x in "BCDEFG"]: ck(f"manifest_{p}_ready",man[p]["status"]=="PASS" and man[p]["figure_ready"]=="YES",man[p]["status"])
out=pd.DataFrame(checks,columns=["check","pass","detail"]); out.to_csv(ROOT/"audits/stage07_singlecell_figure_checks.tsv",sep="\t",index=False)
if not out["pass"].all(): raise AssertionError(out.loc[~out["pass"]].to_string(index=False))
print(f"PASS: Stage 07 single-cell Figure QA {len(out)}/{len(out)} checks")
