#!/usr/bin/env python3
"""Transfer frozen discovery labels and test the pre-frozen fibroblast F2 target."""
from pathlib import Path
import math
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))

import numpy as np
import pandas as pd
from scipy import sparse, stats
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score
from sklearn.model_selection import GroupKFold

SEED = 20260911
CONFIDENCE = 0.50
MIN_CELLS = 20
PROGRAMS = ["ucell_core_directed", "ucell_sep_directed", "rankmean_core_directed", "rankmean_sep_directed"]


def normalize(matrix):
    matrix = matrix.astype(np.float32)
    totals = np.asarray(matrix.sum(axis=1)).ravel()
    matrix = sparse.diags(10000.0 / totals).dot(matrix).tocsr()
    matrix.data = np.log1p(matrix.data)
    return matrix


def welch_effect(control, psoriasis):
    control = np.asarray(control, dtype=float)
    psoriasis = np.asarray(psoriasis, dtype=float)
    difference = float(psoriasis.mean() - control.mean())
    var_control = control.var(ddof=1)
    var_psoriasis = psoriasis.var(ddof=1)
    variance = var_control / len(control) + var_psoriasis / len(psoriasis)
    se = math.sqrt(variance)
    df = variance ** 2 / ((var_control / len(control)) ** 2 / (len(control) - 1) +
                          (var_psoriasis / len(psoriasis)) ** 2 / (len(psoriasis) - 1))
    critical = stats.t.ppf(0.975, df)
    pooled = math.sqrt(((len(control) - 1) * var_control + (len(psoriasis) - 1) * var_psoriasis) /
                       (len(control) + len(psoriasis) - 2))
    correction = 1 - 3 / (4 * (len(control) + len(psoriasis)) - 9)
    p_value = float(stats.ttest_ind(psoriasis, control, equal_var=False).pvalue)
    return difference, difference - critical * se, difference + critical * se, p_value, difference / pooled * correction


def main():
    freeze = pd.read_csv(ROOT / "metadata/TARGET_FREEZE_STAGE04_F2.tsv", sep="\t")
    if freeze.loc[0, "freeze_id"] != "TARGET_FREEZE_STAGE04_F2_v1.1" or freeze.loc[0, "selected_major_lineage"] != "Fibroblast":
        raise AssertionError("unexpected F2 freeze")

    discovery_obs = pd.read_csv(ROOT / "data/processed/stage04/GSE173706_cell_metadata.tsv.gz", sep="\t")
    discovery_genes = pd.read_csv(ROOT / "data/processed/stage04/gse173706_selected_genes.tsv", sep="\t")
    discovery_counts = sparse.load_npz(ROOT / "data/processed/stage04/gse173706_selected_counts.npz").tocsr()
    replication_obs = pd.read_csv(ROOT / "data/processed/stage04/gse162183_cell_metadata_unannotated.tsv.gz", sep="\t")
    replication_genes = pd.read_csv(ROOT / "data/processed/stage04/gse162183_genes.tsv", sep="\t")
    replication_counts = sparse.load_npz(ROOT / "data/processed/stage04/gse162183_counts_qc.npz").tocsr()

    disc_symbols = discovery_genes["human_gene_symbol"].fillna("").astype(str)
    rep_symbols = replication_genes["human_gene_symbol"].fillna("").astype(str)
    disc_counts = disc_symbols.value_counts()
    rep_counts = rep_symbols.value_counts()
    disc_unique = {symbol: i for i, symbol in enumerate(disc_symbols) if symbol and disc_counts[symbol] == 1}
    rep_unique = {symbol: i for i, symbol in enumerate(rep_symbols) if symbol and rep_counts[symbol] == 1}
    hvg = set(discovery_genes.loc[discovery_genes["hvg_global_raw_dispersion"].astype(str).str.lower().eq("true"), "human_gene_symbol"].dropna().astype(str))
    markers = set(discovery_genes.loc[discovery_genes["canonical_annotation_marker"].astype(str).str.lower().eq("true"), "human_gene_symbol"].dropna().astype(str))
    features = sorted((hvg | markers) & set(disc_unique) & set(rep_unique))
    if len(features) < 2500:
        raise AssertionError("insufficient shared transfer features")
    x_disc = normalize(discovery_counts[:, [disc_unique[x] for x in features]])
    x_rep = normalize(replication_counts[:, [rep_unique[x] for x in features]])
    labelled = discovery_obs["cell_type"].ne("Uncertain").to_numpy()
    y = discovery_obs.loc[labelled, "cell_type"].astype(str).to_numpy()
    groups = discovery_obs.loc[labelled, "donor_id"].astype(str).to_numpy()
    x_labelled = x_disc[labelled]

    cv_rows = []
    predicted_cv = np.empty(len(y), dtype=object)
    for fold, (train, test) in enumerate(GroupKFold(n_splits=5).split(x_labelled, y, groups), start=1):
        model = SGDClassifier(loss="log_loss", alpha=0.0001, class_weight="balanced", max_iter=1000, tol=1e-3, random_state=SEED)
        model.fit(x_labelled[train], y[train])
        prediction = model.predict(x_labelled[test])
        predicted_cv[test] = prediction
        cv_rows.append({"fold": fold, "test_donors": len(set(groups[test])), "test_cells": len(test),
                        "accuracy": accuracy_score(y[test], prediction),
                        "balanced_accuracy": balanced_accuracy_score(y[test], prediction),
                        "macro_f1": f1_score(y[test], prediction, average="macro")})
    cv_rows.append({"fold": "pooled", "test_donors": len(set(groups)), "test_cells": len(y),
                    "accuracy": accuracy_score(y, predicted_cv),
                    "balanced_accuracy": balanced_accuracy_score(y, predicted_cv),
                    "macro_f1": f1_score(y, predicted_cv, average="macro")})

    final_model = SGDClassifier(loss="log_loss", alpha=0.0001, class_weight="balanced", max_iter=1000, tol=1e-3, random_state=SEED)
    final_model.fit(x_labelled, y)
    probability = final_model.predict_proba(x_rep)
    best = probability.argmax(axis=1)
    confidence = probability[np.arange(len(best)), best]
    labels = final_model.classes_[best].astype(object)
    labels[confidence < CONFIDENCE] = "Uncertain"
    replication_obs["cell_type"] = labels
    replication_obs["label_transfer_probability"] = confidence
    replication_obs["label_transfer_status"] = np.where(confidence >= CONFIDENCE, "PASS", "UNCERTAIN")
    replication_obs.to_csv(ROOT / "data/processed/stage04/gse162183_cell_metadata_annotated.tsv.gz", sep="\t", index=False, compression="gzip")
    pd.DataFrame(cv_rows).to_csv(ROOT / "results/stage04/gse162183_label_transfer_cv.tsv", sep="\t", index=False)
    pd.DataFrame({"feature_order": np.arange(len(features)), "human_gene_symbol": features}).to_csv(ROOT / "results/stage04/gse162183_label_transfer_features.tsv", sep="\t", index=False)
    np.savez_compressed(ROOT / "results/stage04/gse162183_label_transfer_model.npz",
                        coef=final_model.coef_, intercept=final_model.intercept_, classes=final_model.classes_)

    donor_scores = replication_obs.groupby(["donor_id", "condition", "cell_type"], observed=True).agg(
        n_cells=("cell_id", "size"), **{program: (program, "mean") for program in PROGRAMS}).reset_index()
    donor_scores["eligible_min_cells"] = donor_scores["n_cells"] >= MIN_CELLS
    donor_scores.to_csv(ROOT / "results/stage04/gse162183_donor_celltype_scores.tsv", sep="\t", index=False)
    effect_rows = []
    for cell_type in sorted(donor_scores["cell_type"].unique()):
        subset = donor_scores.loc[(donor_scores["cell_type"] == cell_type) & donor_scores["eligible_min_cells"]]
        for program in PROGRAMS:
            control = subset.loc[subset["condition"] == "Control", program]
            psoriasis = subset.loc[subset["condition"] == "Psoriasis", program]
            if len(control) >= 2 and len(psoriasis) >= 2:
                difference, low, high, p_value, effect = welch_effect(control, psoriasis)
            else:
                difference = low = high = p_value = effect = np.nan
            effect_rows.append({"cell_type": cell_type, "program": program,
                                "n_control_donors": len(control), "n_psoriasis_donors": len(psoriasis),
                                "mean_psoriasis_minus_control": difference, "ci95_low": low, "ci95_high": high,
                                "welch_p": p_value, "unpaired_hedges_g": effect,
                                "eligible_all_groups_ge2": len(control) >= 2 and len(psoriasis) >= 2})
    effects = pd.DataFrame(effect_rows)
    target = effects.loc[(effects["cell_type"] == "Fibroblast") & (effects["program"] == "ucell_sep_directed")].iloc[0]
    replication_status = "PASS" if target["mean_psoriasis_minus_control"] > 0 and target["welch_p"] < 0.05 else "FAIL"
    effects["f2_target"] = (effects["cell_type"] == "Fibroblast") & (effects["program"] == "ucell_sep_directed")
    effects["replication_status"] = np.where(effects["f2_target"], replication_status, "NOT_PRIMARY_TARGET")
    effects.to_csv(ROOT / "results/stage04/GSE162183_replication.tsv", sep="\t", index=False)

    label_counts = replication_obs["cell_type"].value_counts().rename_axis("cell_type").reset_index(name="cells")
    label_counts.to_csv(ROOT / "results/stage04/gse162183_label_counts.tsv", sep="\t", index=False)
    pooled_cv = cv_rows[-1]
    checks = pd.DataFrame([
        {"check_id": "shared_transfer_features_ge2500", "observed": len(features) >= 2500, "expected": True},
        {"check_id": "grouped_cv_balanced_accuracy_ge0.70", "observed": pooled_cv["balanced_accuracy"] >= 0.70, "expected": True},
        {"check_id": "all_replication_cells_labelled", "observed": replication_obs["cell_type"].notna().sum(), "expected": len(replication_obs)},
        {"check_id": "target_has_3_plus_3_donors", "observed": f"{int(target['n_control_donors'])}+{int(target['n_psoriasis_donors'])}", "expected": "3+3"},
        {"check_id": "replication_terminal_status", "observed": replication_status in {"PASS", "FAIL"}, "expected": True},
    ])
    checks["status"] = np.where(checks["observed"].astype(str) == checks["expected"].astype(str), "PASS", "FAIL")
    checks.to_csv(ROOT / "audits/stage04_replication_f2_checks.tsv", sep="\t", index=False)
    if checks["status"].eq("FAIL").any():
        raise AssertionError("F2 replication audit failed")
    print(label_counts.to_string(index=False))
    print(f"F2 replication {replication_status}: diff={target['mean_psoriasis_minus_control']:.6f}, CI={target['ci95_low']:.6f},{target['ci95_high']:.6f}, p={target['welch_p']:.6g}")


if __name__ == "__main__":
    main()
