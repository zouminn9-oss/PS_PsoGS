#!/usr/bin/env python3
"""Compute label-blind cluster marker evidence for annotation auditing."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))

import numpy as np
import pandas as pd
from scipy import sparse

COUNTS = ROOT / "data/processed/stage04/gse173706_selected_counts.npz"
OBS = ROOT / "data/processed/stage04/GSE173706_cell_metadata.tsv.gz"
GENES = ROOT / "data/processed/stage04/gse173706_selected_genes.tsv"
OUTPUT = ROOT / "results/stage04/cluster_top_markers.tsv"


def main():
    counts = sparse.load_npz(COUNTS).tocsr().astype(np.float32)
    obs = pd.read_csv(OBS, sep="\t")
    genes = pd.read_csv(GENES, sep="\t")
    scale = 10000.0 / np.asarray(counts.sum(axis=1)).ravel()
    matrix = sparse.diags(scale).dot(counts).tocsr()
    matrix.data = np.log1p(matrix.data)
    global_sum = np.asarray(matrix.sum(axis=0)).ravel()
    global_detect = np.asarray((matrix > 0).sum(axis=0)).ravel()
    rows = []
    for cluster in sorted(obs["leiden_08"].astype(int).unique()):
        inside = obs["leiden_08"].astype(int).to_numpy() == cluster
        n_in = int(inside.sum()); n_out = len(obs) - n_in
        in_sum = np.asarray(matrix[inside].sum(axis=0)).ravel()
        in_detect = np.asarray((matrix[inside] > 0).sum(axis=0)).ravel()
        mean_in = in_sum / n_in
        mean_out = (global_sum - in_sum) / n_out
        pct_in = in_detect / n_in
        pct_out = (global_detect - in_detect) / n_out
        score = (mean_in - mean_out) * np.sqrt(np.maximum(pct_in - pct_out, 0))
        order = np.argsort(score)[::-1][:40]
        for rank, j in enumerate(order, start=1):
            rows.append({"cluster": cluster, "rank": rank,
                         "ensembl_gene_id": genes.loc[j, "ensembl_gene_id"],
                         "human_gene_symbol": genes.loc[j, "human_gene_symbol"],
                         "mean_log1p_cp10k_in": mean_in[j], "mean_log1p_cp10k_out": mean_out[j],
                         "detection_fraction_in": pct_in[j], "detection_fraction_out": pct_out[j],
                         "marker_score": score[j]})
    pd.DataFrame(rows).to_csv(OUTPUT, sep="\t", index=False)
    print(f"PASS: {len(rows)} marker rows for {len(set(x['cluster'] for x in rows))} clusters")


if __name__ == "__main__":
    main()
