#!/usr/bin/env python3
"""Prepare locked validation matrices with deterministic feature aggregation."""

from __future__ import annotations

import csv
import gzip
import hashlib
import math
import statistics
from array import array
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOFT = ROOT / "metadata/geo_soft/GSE30999_family.soft.gz"
ANNOT = ROOT / "references/GPL570/GPL570.annot.gz"
SAMPLE_LOCK = ROOT / "metadata/stage03_validation_sample_lock.tsv"
OUT_MATRIX = ROOT / "results/stage03/matrices/gse30999_gcrma_entrez_gene_matrix.tsv.gz"
OUT_COLUMNS = ROOT / "metadata/stage03_gse30999_matrix_columns.tsv"
OUT_QC = ROOT / "results/stage03/qc/gse30999_sample_distribution_qc.tsv"
OUT_AUDIT = ROOT / "audits/stage03_matrix_preparation_checks.tsv"
OUT_INPUTS = ROOT / "metadata/stage03_matrix_input_manifest.tsv"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t",
                                lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def quantile(values: list[float], probability: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = math.floor(position); upper = math.ceil(position)
    if lower == upper:
        return ordered[lower]
    return ordered[lower] * (upper - position) + ordered[upper] * (position - lower)


def main() -> None:
    checks: list[dict[str, object]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": observed, "expected": expected,
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            write_tsv(OUT_AUDIT, checks)
            raise AssertionError(f"{check_id}: observed {observed!r}; expected {expected!r}")

    probe_to_entrez: dict[str, str] = {}
    with gzip.open(ANNOT, "rt", encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            if line.startswith("ID\t"):
                header = line.rstrip("\r\n").split("\t")
                break
        index = {name: idx for idx, name in enumerate(header)}
        annotation_rows = 0
        for line in handle:
            if line.startswith("!platform_table_end"):
                continue
            fields = line.rstrip("\r\n").split("\t")
            annotation_rows += 1
            entrez = {item.strip() for item in fields[index["Gene ID"]].split("///")
                      if item.strip().isdigit()}
            if len(entrez) == 1:
                probe_to_entrez[fields[index["ID"]]] = next(iter(entrez))
    check("GPL570_annotation_rows", annotation_rows, 54675)
    check("GPL570_unique_entrez_probes", len(probe_to_entrez) > 30000, True)

    locks = [row for row in read_tsv(SAMPLE_LOCK) if row["dataset_id"] == "GSE30999"]
    lock_by_gsm = {row["sample_id"]: row for row in locks}
    check("GSE30999_lock_rows", len(locks), 170)

    sample_order: list[str] = []
    sample_titles: dict[str, str] = {}
    data_processing: set[str] = set()
    vectors: dict[str, array] = {}
    qc_rows: list[dict[str, object]] = []
    current_gsm = ""
    current_title = ""
    table_count = 0
    with gzip.open(SOFT, "rt", encoding="utf-8", errors="replace") as handle:
        iterator = iter(handle)
        for line in iterator:
            if line.startswith("^SAMPLE = "):
                current_gsm = line.rstrip("\r\n").split(" = ", 1)[1]
                current_title = ""
            elif line.startswith("!Sample_title = "):
                current_title = line.rstrip("\r\n").split(" = ", 1)[1]
                sample_titles[current_gsm] = current_title
            elif line.startswith("!Sample_data_processing = "):
                data_processing.add(line.rstrip("\r\n").split(" = ", 1)[1])
            elif line.startswith("!sample_table_begin"):
                table_count += 1
                table_header = next(iterator).rstrip("\r\n")
                check(f"GSE30999_table_header::{current_gsm}", table_header, "ID_REF\tVALUE")
                gene_values: dict[str, list[float]] = defaultdict(list)
                all_values: list[float] = []
                row_count = 0
                for data_line in iterator:
                    if data_line.startswith("!sample_table_end"):
                        break
                    probe, value_text = data_line.rstrip("\r\n").split("\t")
                    value = float(value_text)
                    if not math.isfinite(value):
                        raise AssertionError(f"nonfinite value in {current_gsm}")
                    row_count += 1
                    all_values.append(value)
                    entrez = probe_to_entrez.get(probe)
                    if entrez is not None:
                        gene_values[entrez].append(value)
                check(f"GSE30999_table_rows::{current_gsm}", row_count, 54675)
                sample_order.append(current_gsm)
                for gene in vectors:
                    vectors[gene].append(float("nan"))
                sample_index = len(sample_order) - 1
                for gene, values in gene_values.items():
                    if gene not in vectors:
                        vectors[gene] = array("d", [float("nan")] * len(sample_order))
                    vectors[gene][sample_index] = statistics.median(values)
                qc_rows.append({
                    "sample_id": current_gsm, "sample_title": current_title,
                    "n_platform_values": row_count, "n_unique_entrez_genes": len(gene_values),
                    "minimum": min(all_values), "q1": quantile(all_values, 0.25),
                    "median": quantile(all_values, 0.50), "q3": quantile(all_values, 0.75),
                    "maximum": max(all_values), "nonfinite": 0,
                    "normalization": "GCRMA_as_submitted",
                })
    check("GSE30999_sample_tables", table_count, 170)
    check("GSE30999_unique_sample_tables", len(set(sample_order)), 170)
    check("GSE30999_sample_set_matches_lock", set(sample_order), set(lock_by_gsm))
    check("GSE30999_processing", data_processing, {"The data was normalized by GCRMA."})
    check("GSE30999_gene_vectors", len(vectors) > 15000, True)
    check("GSE30999_complete_gene_vectors",
          all(len(values) == 170 and not any(math.isnan(x) for x in values)
              for values in vectors.values()), True)
    check("GSE30999_value_range_log_scale",
          min(row["minimum"] for row in qc_rows) > -5 and
          max(row["maximum"] for row in qc_rows) < 30, True)

    OUT_MATRIX.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(OUT_MATRIX, "wt", encoding="utf-8", newline="") as handle:
        handle.write("entrez_id\t" + "\t".join(sample_order) + "\n")
        for gene in sorted(vectors, key=lambda item: int(item)):
            handle.write(gene + "\t" + "\t".join(format(value, ".10g") for value in vectors[gene]) + "\n")

    column_rows = []
    for index_value, gsm in enumerate(sample_order, 1):
        lock = lock_by_gsm[gsm]
        check(f"GSE30999_title_matches::{gsm}", sample_titles[gsm], lock["sample_title"])
        column_rows.append({
            "column_index": index_value, "sample_id": gsm, "sample_title": sample_titles[gsm],
            "donor_id": lock["donor_id"], "skin_type": lock["skin_type"],
            "analysis_role": lock["analysis_role"], "lock_status": lock["lock_status"],
        })
    write_tsv(OUT_COLUMNS, column_rows)
    write_tsv(OUT_QC, qc_rows)
    check("GSE30999_primary_matrix_columns",
          sum(row["lock_status"] == "PRIMARY_INCLUDE" for row in column_rows), 162)
    check("GSE30999_held_matrix_columns",
          sum(row["lock_status"] == "HOLD_UNRESOLVED_PAIR" for row in column_rows), 8)

    input_paths = [SOFT, ANNOT, SAMPLE_LOCK, ROOT / "config/stage03_validation_gate.yaml"]
    input_rows = [{"artifact_id": path.name, "path": path.relative_to(ROOT).as_posix(),
                   "bytes": path.stat().st_size, "sha256": sha256(path)} for path in input_paths]
    write_tsv(OUT_INPUTS, input_rows)
    write_tsv(OUT_AUDIT, checks)
    print(f"PASS: prepared {len(vectors):,}-gene GSE30999 GCRMA matrix across 170 samples; "
          f"{len(checks)} checks")


if __name__ == "__main__":
    main()
