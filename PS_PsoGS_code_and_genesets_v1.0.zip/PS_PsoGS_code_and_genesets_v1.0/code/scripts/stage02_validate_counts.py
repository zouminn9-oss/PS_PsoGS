#!/usr/bin/env python3
"""Independently validate the frozen GSE212126 featureCounts matrix."""

from __future__ import annotations

import csv
import hashlib
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
COUNT_DIR = ROOT / "results" / "stage02" / "counts"
AUDIT_PATH = ROOT / "audits" / "stage02_counts" / "gse212126_count_integrity_checks.tsv"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main() -> None:
    registry_path = COUNT_DIR / "gse212126_count_column_registry.tsv"
    decision_path = COUNT_DIR / "gse212126_strand_decision.tsv"
    frozen_path = COUNT_DIR / "gse212126_gene_counts_frozen.tsv"
    strand2_path = COUNT_DIR / "gse212126_gene_counts_strand2.tsv"
    status2_path = COUNT_DIR / "gse212126_assignment_status_strand2.tsv"

    registry = read_tsv(registry_path)
    decision = read_tsv(decision_path)
    status2 = read_tsv(status2_path)
    expected_samples = [row["srr"] for row in registry]
    expected_animals = [row["canonical_animal_id"] for row in registry]
    assigned_row = next(row for row in status2 if row["Status"] == "Assigned")
    assigned = {sample: int(assigned_row[sample]) for sample in expected_samples}

    checks: list[tuple[str, str, str]] = []

    def record(check: str, passed: bool, detail: str) -> None:
        checks.append((check, "PASS" if passed else "FAIL", detail))

    record("registry_has_12_unique_libraries", len(registry) == 12 and len(set(expected_samples)) == 12,
           f"rows={len(registry)}; unique_srr={len(set(expected_samples))}")
    record("registry_has_12_unique_animals", len(set(expected_animals)) == 12,
           f"unique_animals={len(set(expected_animals))}")
    group_counts = Counter(row["condition"] for row in registry)
    record("factorial_groups_are_3_mice_each",
           group_counts == Counter({"Control": 3, "CRS": 3, "IMQ": 3, "CRS+IMQ": 3}),
           "; ".join(f"{key}={group_counts[key]}" for key in ("Control", "CRS", "IMQ", "CRS+IMQ")))
    record("strand_decision_has_12_rows", len(decision) == 12, f"rows={len(decision)}")
    record("strand2_selected_for_every_library",
           all(row["selected_strand"] == "2" for row in decision),
           f"selected_values={sorted(set(row['selected_strand'] for row in decision))}")
    record("strand_rule_satisfied_for_every_library",
           all(float(row["strand2_over_unstranded"]) >= 0.80 and
               float(row["strand1_over_unstranded"]) <= 0.20 for row in decision),
           f"strand2_ratio_range={min(float(r['strand2_over_unstranded']) for r in decision):.4f}-"
           f"{max(float(r['strand2_over_unstranded']) for r in decision):.4f}; "
           f"strand1_ratio_range={min(float(r['strand1_over_unstranded']) for r in decision):.4f}-"
           f"{max(float(r['strand1_over_unstranded']) for r in decision):.4f}")
    record("strand_selection_did_not_use_DE",
           all(row["selection_used_differential_expression"] == "FALSE" for row in decision),
           "all rows explicitly FALSE")

    frozen_rows = 0
    totals = {sample: 0 for sample in expected_samples}
    exact_match = True
    integer_nonnegative = True
    unique_gene_ids: set[str] = set()
    with frozen_path.open(encoding="utf-8", newline="") as frozen_handle, strand2_path.open(
        encoding="utf-8", newline=""
    ) as strand2_handle:
        frozen_reader = csv.DictReader(frozen_handle, delimiter="\t")
        strand2_reader = csv.DictReader(strand2_handle, delimiter="\t")
        record("frozen_columns_match_registry", frozen_reader.fieldnames == ["gene_id", *expected_samples],
               f"columns={len(frozen_reader.fieldnames or [])}")
        record("strand2_columns_match_registry",
               (strand2_reader.fieldnames or [])[-12:] == expected_samples,
               f"count_columns={(strand2_reader.fieldnames or [])[-12:]}")
        for frozen_row, strand2_row in zip(frozen_reader, strand2_reader, strict=True):
            frozen_rows += 1
            gene_id = frozen_row["gene_id"]
            if gene_id in unique_gene_ids:
                exact_match = False
            unique_gene_ids.add(gene_id)
            if gene_id != strand2_row["GeneID"]:
                exact_match = False
            for sample in expected_samples:
                value_text = frozen_row[sample]
                if value_text != strand2_row[sample]:
                    exact_match = False
                try:
                    value = int(value_text)
                    if value < 0:
                        integer_nonnegative = False
                    totals[sample] += value
                except ValueError:
                    integer_nonnegative = False

    record("frozen_has_55487_unique_genes", frozen_rows == 55487 and len(unique_gene_ids) == 55487,
           f"rows={frozen_rows}; unique_gene_ids={len(unique_gene_ids)}")
    record("frozen_counts_are_nonnegative_integers", integer_nonnegative,
           "stream-validated every count cell")
    record("frozen_exactly_matches_strand2_counts", exact_match,
           "gene IDs and all 12 count columns compared row-by-row")
    totals_match = all(totals[sample] == assigned[sample] for sample in expected_samples)
    record("count_sums_equal_featureCounts_assigned", totals_match,
           "; ".join(f"{sample}={totals[sample]}" for sample in expected_samples))
    record("frozen_sha256_recorded", True, sha256(frozen_path))
    record("strand_decision_sha256_recorded", True, sha256(decision_path))

    AUDIT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with AUDIT_PATH.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(["check", "status", "detail"])
        writer.writerows(checks)

    failed = [check for check, status, _ in checks if status != "PASS"]
    if failed:
        raise SystemExit("FAIL: " + ", ".join(failed))
    print(f"PASS: {len(checks)} count integrity checks; {frozen_rows} genes x 12 independent mice")


if __name__ == "__main__":
    main()
