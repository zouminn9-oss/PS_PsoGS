#!/usr/bin/env python3
"""Stream GSE173706 counts to verify integers and compute cell/gene QC without dense concatenation."""
from __future__ import annotations
import csv
import gzip
import math
import re
from collections import defaultdict
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
INPUTS = ROOT / "data/raw/single_cell/GSE173706/csv_gz"
MANIFEST = ROOT / "metadata/stage04_singlecell_input_manifest.tsv"
HGNC = ROOT / "metadata/hgnc_complete_set_2026-09-10.tsv"
OUT_CELLS = ROOT / "data/processed/stage04/gse173706_cell_qc.tsv.gz"
OUT_GENES = ROOT / "results/stage04/qc/gse173706_gene_detection.tsv.gz"
OUT_LIBS = ROOT / "results/stage04/qc/gse173706_library_qc_summary.tsv"
OUT_AUDIT = ROOT / "audits/stage04_discovery_count_qc_checks.tsv"

def read_tsv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as h: return list(csv.DictReader(h, delimiter="\t"))

def write_tsv(path, rows, gz=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    opener = gzip.open if gz else open
    with opener(path, "wt", encoding="utf-8", newline="") as h:
        w = csv.DictWriter(h, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n"); w.writeheader(); w.writerows(rows)

def mad(values):
    median = float(np.median(values))
    return median, float(np.median(np.abs(values - median)))

def main():
    checks = []
    def check(name, obs, exp):
        ok = obs == exp; checks.append({"check_id": name, "observed": str(obs), "expected": str(exp), "status": "PASS" if ok else "FAIL"})
        if not ok:
            write_tsv(OUT_AUDIT, checks)
            raise AssertionError(f"{name}: {obs!r} != {exp!r}")

    manifest = [r for r in read_tsv(MANIFEST) if r["dataset_id"] == "GSE173706"]
    sample_meta = {r["sample_id"]: r for r in manifest}
    hgnc = read_tsv(HGNC)
    ensembl_to_symbol = {r["ensembl_gene_id"]: r["symbol"] for r in hgnc if r["ensembl_gene_id"] and r["status"] == "Approved"}
    mito = {r["ensembl_gene_id"] for r in hgnc if r["ensembl_gene_id"] and r["status"] == "Approved" and r["location"].strip().lower() == "mitochondria"}
    check("mitochondrial_ensembl_ids", len(mito) > 10, True)

    files = sorted(INPUTS.glob("*.csv.gz"))
    gene_ids = None
    gene_sum = None; gene_sumsq = None; gene_detected = None
    cell_rows = []; total_nnz = 0; maximum_count = 0
    for file_index, path in enumerate(files):
        gsm = path.name.split("_", 1)[0]
        meta = sample_meta[gsm]
        with gzip.open(path, "rb") as handle:
            header = handle.readline().rstrip(b"\r\n").split(b",")[1:]
            barcodes = [x.decode("ascii") for x in header]
            n_cells = len(barcodes)
            counts = np.zeros(n_cells, dtype=np.int64)
            features = np.zeros(n_cells, dtype=np.int32)
            mito_counts = np.zeros(n_cells, dtype=np.int64)
            current_genes = [] if gene_ids is None else None
            for gene_index, line in enumerate(handle):
                gene_raw, values_raw = line.rstrip(b"\r\n").split(b",", 1)
                gene = gene_raw.decode("ascii")
                values = np.fromstring(values_raw, dtype=np.int64, sep=",")
                if values.size != n_cells:
                    raise AssertionError(f"parsed cell count mismatch {gsm} gene {gene}")
                if np.any(values < 0):
                    raise AssertionError(f"negative count {gsm} gene {gene}")
                maximum_count = max(maximum_count, int(values.max(initial=0)))
                nonzero = values > 0
                counts += values; features += nonzero
                if gene in mito: mito_counts += values
                total_nnz += int(nonzero.sum())
                if gene_ids is None:
                    current_genes.append(gene)
                elif gene != gene_ids[gene_index]:
                    raise AssertionError(f"gene order mismatch {gsm} row {gene_index + 1}")
                if gene_sum is None:
                    continue
                gene_sum[gene_index] += int(values.sum())
                gene_sumsq[gene_index] += float(np.square(values, dtype=np.float64).sum())
                gene_detected[gene_index] += int(nonzero.sum())
            if gene_ids is None:
                gene_ids = current_genes
                n_genes = len(gene_ids)
                gene_sum = np.zeros(n_genes, dtype=np.int64)
                gene_sumsq = np.zeros(n_genes, dtype=np.float64)
                gene_detected = np.zeros(n_genes, dtype=np.int64)
                # The first file was not accumulated above; stream it again once.
                with gzip.open(path, "rb") as replay:
                    replay.readline()
                    for gene_index, line in enumerate(replay):
                        values = np.fromstring(line.rstrip(b"\r\n").split(b",", 1)[1], dtype=np.int64, sep=",")
                        gene_sum[gene_index] += int(values.sum())
                        gene_sumsq[gene_index] += float(np.square(values, dtype=np.float64).sum())
                        gene_detected[gene_index] += int((values > 0).sum())
            check(f"gene_rows::{gsm}", gene_index + 1, len(gene_ids))
            for i, barcode in enumerate(barcodes):
                pct = 100.0 * mito_counts[i] / counts[i] if counts[i] else 0.0
                cell_rows.append({"cell_id": f"{gsm}:{barcode}", "barcode": barcode, "sample_id": gsm,
                    "donor_id": meta["donor_id"], "donor_group": meta["donor_group"], "tissue": meta["tissue"],
                    "n_counts": int(counts[i]), "n_features": int(features[i]), "mito_counts": int(mito_counts[i]),
                    "percent_mito": pct})
        print(f"PROFILE {file_index + 1}/33 {gsm} cells={n_cells}", flush=True)

    check("cell_rows", len(cell_rows), 96088)
    check("gene_rows", len(gene_ids), 33538)
    check("maximum_count_integer", maximum_count >= 1, True)
    check("nonzero_entries", total_nnz > 1000000, True)
    by_sample = defaultdict(list)
    for row in cell_rows: by_sample[row["sample_id"]].append(row)
    lib_rows = []
    for gsm, rows in sorted(by_sample.items()):
        log_counts = np.log10(np.array([r["n_counts"] for r in rows], dtype=float) + 1)
        log_features = np.log10(np.array([r["n_features"] for r in rows], dtype=float) + 1)
        mito_pct = np.array([r["percent_mito"] for r in rows], dtype=float)
        med_c, mad_c = mad(log_counts); med_f, mad_f = mad(log_features); med_m, mad_m = mad(mito_pct)
        low_c = med_c - 3 * mad_c if mad_c > 0 else -math.inf
        high_c = med_c + 3 * mad_c if mad_c > 0 else math.inf
        low_f = med_f - 3 * mad_f if mad_f > 0 else -math.inf
        high_f = med_f + 3 * mad_f if mad_f > 0 else math.inf
        high_m = min(20.0, med_m + 3 * mad_m) if mad_m > 0 else 20.0
        for row, lc, lf in zip(rows, log_counts, log_features):
            hard = row["n_counts"] >= 500 and row["n_features"] >= 200 and row["percent_mito"] <= 20.0
            low_outlier = lc < low_c or lf < low_f or row["percent_mito"] > high_m
            high_flag = lc > high_c or lf > high_f
            row["hard_threshold_pass"] = hard
            row["low_quality_outlier"] = low_outlier
            row["high_count_feature_flag"] = high_flag
            row["qc_pass_pre_doublet"] = hard and not low_outlier
            row["qc_status"] = "PASS_PRE_DOUBLET" if row["qc_pass_pre_doublet"] else "FAIL_QC"
        lib_rows.append({"sample_id": gsm, "donor_id": rows[0]["donor_id"], "tissue": rows[0]["tissue"],
            "input_cells": len(rows), "qc_pass_pre_doublet": sum(r["qc_pass_pre_doublet"] for r in rows),
            "qc_fail": sum(not r["qc_pass_pre_doublet"] for r in rows),
            "high_count_feature_flags": sum(r["high_count_feature_flag"] for r in rows),
            "median_counts": float(np.median([r["n_counts"] for r in rows])),
            "median_features": float(np.median([r["n_features"] for r in rows])),
            "median_percent_mito": float(np.median(mito_pct)),
            "low_logcount_cut": low_c, "high_logcount_flag": high_c,
            "low_logfeature_cut": low_f, "high_logfeature_flag": high_f,
            "mito_outlier_cut_percent": high_m})

    retained = sum(r["qc_pass_pre_doublet"] for r in cell_rows)
    check("retained_pre_doublet_positive", retained > 50000, True)
    total_cells = len(cell_rows)
    gene_rows = []
    for i, gene in enumerate(gene_ids):
        mean = gene_sum[i] / total_cells
        variance = (gene_sumsq[i] - total_cells * mean * mean) / (total_cells - 1)
        gene_rows.append({"ensembl_gene_id": gene, "human_gene_symbol": ensembl_to_symbol.get(gene, ""),
            "total_counts_all_input_cells": int(gene_sum[i]), "detected_input_cells": int(gene_detected[i]),
            "detection_fraction": gene_detected[i] / total_cells, "mean_count": mean,
            "variance_count": max(0.0, variance), "mitochondrial_gene": gene in mito})
    write_tsv(OUT_CELLS, cell_rows, gz=True)
    write_tsv(OUT_GENES, gene_rows, gz=True)
    write_tsv(OUT_LIBS, lib_rows)
    write_tsv(OUT_AUDIT, checks)
    print(f"PASS: integer-count profiling; cells={total_cells} retained_pre_doublet={retained} genes={len(gene_ids)} nnz={total_nnz} checks={len(checks)}")

if __name__ == "__main__": main()
