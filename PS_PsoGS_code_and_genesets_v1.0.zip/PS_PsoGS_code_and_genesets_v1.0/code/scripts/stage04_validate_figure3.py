#!/usr/bin/env python3
"""Cross-check Figure 3A-L source, statistics, rendering, print size, and claims."""
import csv
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))
from PIL import Image
import pandas as pd

rows = []


def check(name, observed, expected):
    status = "PASS" if observed == expected else "FAIL"
    rows.append({"check_id": name, "observed": str(observed), "expected": str(expected), "status": status})


for letter in "abcdefghijkl":
    panel = f"3{letter}"
    paths = {
        "source": ROOT / f"figures/source_data/fig{panel}.tsv",
        "stats": ROOT / f"results/figures/fig{panel}_statistics.tsv",
        "config": ROOT / f"config/figures/fig{panel}.yaml",
        "svg": ROOT / f"figures/panels/fig{panel}.svg",
        "png": ROOT / f"figures/previews/fig{panel}.png",
        "caption": ROOT / f"figures/captions/fig{panel}.md",
    }
    for kind, path in paths.items():
        check(f"{panel}_{kind}_exists", path.is_file(), True)
        check(f"{panel}_{kind}_nonempty", path.stat().st_size > 20 if path.is_file() else False, True)
    source = pd.read_csv(paths["source"], sep="\t")
    stats = pd.read_csv(paths["stats"], sep="\t")
    check(f"{panel}_source_rows_positive", len(source) > 0, True)
    check(f"{panel}_stats_rows_positive", len(stats) > 0, True)
    check(f"{panel}_svg_root", "<svg" in paths["svg"].read_text(encoding="utf-8", errors="ignore")[:1000], True)
    image = Image.open(paths["png"])
    check(f"{panel}_png_width_ge1500", image.width >= 1500, True)
    check(f"{panel}_png_height_ge900", image.height >= 900, True)
    check(f"{panel}_caption_complete", len(paths["caption"].read_text(encoding="utf-8").split()) >= 20, True)

a = pd.read_csv(ROOT / "figures/source_data/fig3a.tsv", sep="\t")
check("fig3a_all_cells", len(a), 75209)
c = pd.read_csv(ROOT / "figures/source_data/fig3c.tsv", sep="\t")
check("fig3c_33_libraries", c["sample_id"].nunique(), 33)
check("fig3c_fraction_sums", all(math.isclose(x, 1.0, abs_tol=1e-10) for x in c.groupby("sample_id")["cell_fraction"].sum()), True)
d = pd.read_csv(ROOT / "figures/source_data/fig3d.tsv", sep="\t")
check("fig3d_shared_embedding_rows", len(d), 75209)
e = pd.read_csv(ROOT / "figures/source_data/fig3e.tsv", sep="\t")
check("fig3e_all_scores_finite", e["ucell_core_directed"].notna().sum(), 75209)
h = pd.read_csv(ROOT / "figures/source_data/fig3h.tsv", sep="\t")
check("fig3h_complete_pairs", h.pivot(index="donor_id", columns="tissue", values="ucell_sep_directed").dropna().shape[0], 8)
i = pd.read_csv(ROOT / "figures/source_data/fig3i.tsv", sep="\t")
check("fig3i_fibroblast_cells", len(i), 9501)
k = pd.read_csv(ROOT / "figures/source_data/fig3k.tsv", sep="\t")
target = k.loc[k["f2_target"].astype(str).str.lower().eq("true")]
check("fig3k_one_f2_target", len(target), 1)
check("fig3k_target_pass", target.iloc[0]["replication_status"], "PASS")
l = pd.read_csv(ROOT / "figures/source_data/fig3l.tsv", sep="\t")
for cohort, subset in l.groupby("cohort"):
    parts = subset.set_index("component")["contribution"]
    check(f"fig3l_exact_sum_{cohort}", math.isclose(parts["composition"] + parts["within_cell"] + parts["interaction"], parts["total"], abs_tol=1e-10), True)

output = ROOT / "audits/stage04_figure3_checks.tsv"
with output.open("w", encoding="utf-8", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
    writer.writeheader(); writer.writerows(rows)
failed = sum(row["status"] == "FAIL" for row in rows)
if failed:
    raise AssertionError(f"Figure 3 QA failed: {failed}/{len(rows)}")
print(f"PASS: Figure 3 QA {len(rows)}/{len(rows)} checks")
