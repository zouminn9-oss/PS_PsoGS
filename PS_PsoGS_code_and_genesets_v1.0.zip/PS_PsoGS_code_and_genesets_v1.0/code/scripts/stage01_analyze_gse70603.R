project_lib <- normalizePath(file.path(getwd(), "r_libs", "stage01"), mustWork = TRUE)
.libPaths(c(project_lib, .libPaths()))
suppressPackageStartupMessages(library(limma))

dir.create(file.path("results", "stage01"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("data", "processed"), recursive = TRUE, showWarnings = FALSE)

expr <- read.delim(gzfile(file.path("data", "processed", "GSE70603_processed_log2_matrix.tsv.gz")),
                   row.names = 1, check.names = FALSE, quote = "", stringsAsFactors = FALSE)
samples <- read.delim(file.path("metadata", "gse70603_analysis_samples.tsv"),
                      check.names = FALSE, quote = "", stringsAsFactors = FALSE)
annotation <- read.delim(file.path("metadata", "gse70603_platform_annotation.tsv"),
                         check.names = FALSE, quote = "\"", comment.char = "", stringsAsFactors = FALSE)

stopifnot(nrow(expr) == 50599L, ncol(expr) == 180L)
stopifnot(setequal(colnames(expr), samples$gsm), !anyDuplicated(samples$gsm))
samples <- samples[match(colnames(expr), samples$gsm), ]
stopifnot(identical(colnames(expr), samples$gsm), all(samples$metadata_match == "PASS"))

annotation <- annotation[match(rownames(expr), annotation$ID), ]
stopifnot(identical(rownames(expr), annotation$ID), !anyDuplicated(annotation$ID))
gene_symbol <- trimws(annotation$GENE_SYMBOL)
keep_gene <- nzchar(gene_symbol)
expr_gene <- avereps(as.matrix(expr[keep_gene, , drop = FALSE]), ID = gene_symbol[keep_gene])

baseline <- samples[samples$timepoint == "pre_minus45", ]
baseline <- baseline[order(baseline$subject_id), ]
subjects <- baseline$subject_id
stopifnot(length(subjects) == 60L, !anyDuplicated(subjects))

ordered_indices <- function(timepoint) {
  subset <- samples[samples$timepoint == timepoint, ]
  index <- match(subjects, subset$subject_id)
  stopifnot(!anyNA(index), identical(subset$history_group[index], baseline$history_group))
  match(subset$gsm[index], colnames(expr))
}

idx_pre <- ordered_indices("pre_minus45")
idx_45 <- ordered_indices("post_plus45")
idx_180 <- ordered_indices("post_plus180")

make_differences <- function(matrix) {
  d45 <- matrix[, idx_45, drop = FALSE] - matrix[, idx_pre, drop = FALSE]
  d180 <- matrix[, idx_180, drop = FALSE] - matrix[, idx_pre, drop = FALSE]
  d180v45 <- matrix[, idx_180, drop = FALSE] - matrix[, idx_45, drop = FALSE]
  colnames(d45) <- colnames(d180) <- colnames(d180v45) <- subjects
  list(d45 = d45, d180 = d180, d180v45 = d180v45)
}

probe_diff <- make_differences(as.matrix(expr))
gene_diff <- make_differences(expr_gene)
saveRDS(gene_diff, file.path("data", "processed", "GSE70603_gene_within_subject_differences.rds"), compress = "xz")

group <- factor(baseline$history_group, levels = c("control_history", "early_adversity"))
sex <- factor(baseline$sex, levels = c("female", "male"))
age <- as.numeric(baseline$age_years)
stopifnot(!anyNA(group), !anyNA(sex), !anyNA(age), table(group)[1] == 30L, table(group)[2] == 30L)

fit_intercept <- function(matrix, contrast_id) {
  design <- matrix(1, nrow = ncol(matrix), ncol = 1,
                   dimnames = list(colnames(matrix), "mean_response"))
  fit <- eBayes(lmFit(matrix, design), trend = TRUE, robust = TRUE)
  tt <- topTable(fit, coef = 1, number = Inf, sort.by = "none", adjust.method = "BH")
  data.frame(feature_id = rownames(matrix), contrast_id = contrast_id,
             effect_log2 = tt$logFC, t = tt$t, p_value = tt$P.Value,
             fdr_bh = tt$adj.P.Val, B = tt$B, n_units = ncol(matrix),
             model = "limma eBayes(trend=TRUE, robust=TRUE), intercept on within-subject differences",
             stringsAsFactors = FALSE)
}

fit_moderation <- function(matrix, contrast_id, adjusted = FALSE) {
  if (!adjusted) {
    design <- model.matrix(~ 0 + group)
    colnames(design) <- levels(group)
    fit <- contrasts.fit(lmFit(matrix, design),
                         makeContrasts(early_adversity - control_history, levels = design))
    model_text <- "limma eBayes; early_adversity minus control_history on within-subject differences"
  } else {
    design <- model.matrix(~ group + scale(age) + sex)
    stopifnot(qr(design)$rank == ncol(design))
    fit <- lmFit(matrix, design)
    model_text <- "limma eBayes; adversity moderation adjusted for age and sex"
  }
  fit <- eBayes(fit, trend = TRUE, robust = TRUE)
  coef_index <- if (adjusted) "groupearly_adversity" else 1
  tt <- topTable(fit, coef = coef_index, number = Inf, sort.by = "none", adjust.method = "BH")
  data.frame(feature_id = rownames(matrix), contrast_id = contrast_id,
             effect_log2 = tt$logFC, t = tt$t, p_value = tt$P.Value,
             fdr_bh = tt$adj.P.Val, B = tt$B, n_units = ncol(matrix),
             model = model_text, stringsAsFactors = FALSE)
}

analyze_feature_matrix <- function(diff, feature_type) {
  results <- rbind(
    fit_intercept(diff$d45, "stress_plus45_vs_pre_all"),
    fit_intercept(diff$d180, "stress_plus180_vs_pre_all"),
    fit_intercept(diff$d180v45, "stress_plus180_vs_plus45_all"),
    fit_moderation(diff$d45, "adversity_moderation_plus45_unadjusted", FALSE),
    fit_moderation(diff$d180, "adversity_moderation_plus180_unadjusted", FALSE),
    fit_moderation(diff$d45, "adversity_moderation_plus45_age_sex_adjusted", TRUE),
    fit_moderation(diff$d180, "adversity_moderation_plus180_age_sex_adjusted", TRUE)
  )
  results$feature_type <- feature_type
  results$statistical_unit <- "person"
  results$effect_definition <- ifelse(grepl("moderation", results$contrast_id),
                                      "difference in within-person response: early adversity minus control history",
                                      "within-person log2 expression difference")
  results
}

probe_results <- analyze_feature_matrix(probe_diff, "probe")
probe_symbol <- setNames(gene_symbol, rownames(expr))
probe_results$gene_symbol <- unname(probe_symbol[probe_results$feature_id])
gene_results <- analyze_feature_matrix(gene_diff, "gene_symbol_deterministic_probe_average")
gene_results$gene_symbol <- gene_results$feature_id

write.table(probe_results, gzfile(file.path("results", "stage01", "GSE70603_probe_statistics.tsv.gz")),
            sep = "\t", row.names = FALSE, quote = FALSE)
write.table(gene_results, gzfile(file.path("results", "stage01", "GSE70603_gene_statistics.tsv.gz")),
            sep = "\t", row.names = FALSE, quote = FALSE)

summary_rows <- do.call(rbind, lapply(split(gene_results, gene_results$contrast_id), function(x) {
  data.frame(contrast_id = x$contrast_id[1], n_people = x$n_units[1], genes_tested = nrow(x),
             fdr_lt_0_05_up = sum(x$fdr_bh < 0.05 & x$effect_log2 > 0),
             fdr_lt_0_05_down = sum(x$fdr_bh < 0.05 & x$effect_log2 < 0),
             minimum_fdr = min(x$fdr_bh), median_effect_log2 = median(x$effect_log2),
             model = x$model[1], stringsAsFactors = FALSE)
}))
rownames(summary_rows) <- NULL
write.table(summary_rows, file.path("results", "stage01", "GSE70603_contrast_summary.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)

early <- gene_results[gene_results$contrast_id == "stress_plus45_vs_pre_all", ]
late <- gene_results[gene_results$contrast_id == "stress_plus180_vs_pre_all", ]
stopifnot(identical(early$feature_id, late$feature_id))
sig_early <- early$fdr_bh < 0.05
sig_late <- late$fdr_bh < 0.05
retain <- sig_early | sig_late
classification <- ifelse(sig_early & sig_late & sign(early$effect_log2) == sign(late$effect_log2), "persistent_same_direction",
                  ifelse(sig_early & sig_late, "biphasic_opposite_direction",
                  ifelse(sig_early, "plus45_only", "plus180_only")))
candidates <- data.frame(
  gene_symbol = early$feature_id[retain],
  response_class = classification[retain],
  effect_plus45_log2 = early$effect_log2[retain], fdr_plus45 = early$fdr_bh[retain],
  effect_plus180_log2 = late$effect_log2[retain], fdr_plus180 = late$fdr_bh[retain],
  direction_plus45 = ifelse(early$effect_log2[retain] > 0, "UP", "DOWN"),
  direction_plus180 = ifelse(late$effect_log2[retain] > 0, "UP", "DOWN"),
  evidence_label = "time_locked_human_laboratory_stress_response_no_unstressed_time_control",
  eligibility = "PS_REFERENCE_EVIDENCE_ONLY",
  stringsAsFactors = FALSE
)
write.table(candidates, file.path("genesets", "GSE70603_time_locked_stress_v1.0.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)

session <- capture.output(sessionInfo())
writeLines(session, file.path("audits", "GSE70603_sessionInfo.txt"))
cat(sprintf("PASS: %d gene symbols; %d time-locked response candidates\n", nrow(expr_gene), nrow(candidates)))
