options(stringsAsFactors = FALSE)

registry <- read.delim(file.path("metadata", "gse212126_library_animal_registry.tsv"),
                       check.names = FALSE, stringsAsFactors = FALSE)
stopifnot(nrow(registry) == 12L,
          length(unique(registry$canonical_animal_id)) == 12L,
          all(registry$libraries_per_animal == 1L),
          all(registry$animals_per_library == 1L),
          all(registry$pooling_status == "NO_POOLING_USER_CONFIRMED"))

registry$CRS <- as.integer(registry$condition %in% c("CRS", "CRS+IMQ"))
registry$IMQ <- as.integer(registry$condition %in% c("IMQ", "CRS+IMQ"))
registry <- registry[order(registry$CRS, registry$IMQ, registry$replicate_label), ]

design <- model.matrix(~ CRS + IMQ + CRS:IMQ, data = registry)
colnames(design) <- c("Intercept", "CRS", "IMQ", "CRS_by_IMQ")
stopifnot(qr(design)$rank == 4L)
stopifnot(all(table(registry$condition) == 3L))

design_out <- data.frame(
  canonical_animal_id = registry$canonical_animal_id,
  gsm = registry$gsm,
  srr = registry$srr,
  condition = registry$condition,
  replicate_label = registry$replicate_label,
  design,
  statistical_unit = "independent_mouse",
  pooling_status = registry$pooling_status,
  stringsAsFactors = FALSE,
  check.names = FALSE
)

contrast <- data.frame(
  coefficient = colnames(design),
  S0 = c(0, 1, 0, 0),
  SD = c(0, 1, 0, 1),
  I = c(0, 0, 0, 1),
  stringsAsFactors = FALSE
)

result_registry_path <- file.path("results", "stage02", "factorial_edger",
                                  "gse212126_estimand_result_registry.tsv")
result_status <- "NOT_ESTIMATED_AT_DESIGN_FREEZE"
if (file.exists(result_registry_path)) {
  result_registry <- read.delim(result_registry_path, check.names = FALSE,
                                stringsAsFactors = FALSE)
  stopifnot(identical(result_registry$estimand, c("S0", "SD", "I")),
            all(result_registry$tested_genes == 18484L),
            all(!result_registry$threshold_changed_after_results),
            all(!result_registry$validation_expression_accessed))
  result_status <- "ESTIMATED_MOUSE_FACTORIAL;VALIDATION_NOT_ACCESSED"
}

estimands <- data.frame(
  estimand = c("S0", "SD", "I"),
  biological_definition = c("CRS - Control", "CRS+IMQ - IMQ", "SD - S0"),
  model_scale_definition = c("beta_CRS", "beta_CRS + beta_CRS_by_IMQ", "beta_CRS_by_IMQ"),
  multiple_testing_family = c("S0_all_tested_genes", "SD_all_tested_genes", "I_all_tested_genes"),
  correction = "Benjamini-Hochberg",
  current_result_status = result_status,
  stringsAsFactors = FALSE
)

dir.create(file.path("results", "stage02"), recursive = TRUE, showWarnings = FALSE)
write.table(design_out, file.path("results", "stage02", "gse212126_design_matrix.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(contrast, file.path("results", "stage02", "gse212126_contrast_matrix.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(estimands, file.path("results", "stage02", "gse212126_estimand_registry.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

cat("PASS: frozen full-rank 12-mouse design and S0/SD/I contrast matrices; status synchronized without validation expression\n")
