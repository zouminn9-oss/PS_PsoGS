#!/usr/bin/env python3
"""Validate source-data consistency and exported dimensions for the QC figure."""

from __future__ import annotations

import csv
import struct
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        signature = handle.read(24)
    if signature[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError("invalid PNG signature")
    return struct.unpack(">II", signature[16:24])


def main() -> None:
    panel_a = read_tsv(ROOT / "figures" / "source_data" / "stage01_gse70603_qc_panel_a.tsv")
    panel_b = read_tsv(ROOT / "figures" / "source_data" / "stage01_gse70603_qc_panel_b.tsv")
    panel_c = read_tsv(ROOT / "figures" / "source_data" / "stage01_gse70603_qc_panel_c.tsv")
    checks = []

    def check(check_id, observed, expected, note=""):
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if observed == expected else "FAIL", "note": note})

    check("panel_a_rows", len(panel_a), 7)
    check("panel_a_genes_tested", {int(r["genes_tested"]) for r in panel_a}, {32080})
    check("panel_a_moderation_zero",
          sum(int(r["significant_up"]) + int(r["significant_down"]) == 0
              for r in panel_a if r["contrast_id"].startswith("adversity_")), 4)
    check("panel_b_rows", len(panel_b), 4)
    check("panel_b_total", sum(int(r["candidate_count"]) for r in panel_b), 4426)
    check("panel_c_rows", len(panel_c), 3)
    check("panel_c_total", sum(int(r["symbol_count"]) for r in panel_c), 4426)
    check("panel_c_pass", next(int(r["symbol_count"]) for r in panel_c
                               if r["mapping_status"] == "PASS"), 3871)

    png = ROOT / "figures" / "qc" / "stage01_gse70603_qc.png"
    svg = ROOT / "figures" / "qc" / "stage01_gse70603_qc.svg"
    check("png_dimensions", png_dimensions(png), (1980, 864))
    root = ET.parse(svg).getroot()
    check("svg_root", root.tag.endswith("svg"), True)
    check("svg_nontrivial_bytes", svg.stat().st_size > 10000, True)
    check("caption_exists", (ROOT / "figures" / "captions" / "stage01_gse70603_qc.md").exists(), True)
    check("config_exists", (ROOT / "config" / "stage01_gse70603_qc_figure.yaml").exists(), True)

    output = ROOT / "audits" / "stage01_gse70603_qc_figure_checks.tsv"
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(checks)
    failures = [row for row in checks if row["status"] == "FAIL"]
    if failures:
        raise AssertionError(f"{len(failures)} figure checks failed; see {output}")
    print(f"PASS: {len(checks)} GSE70603 QC figure checks")


if __name__ == "__main__":
    main()
