#!/usr/bin/env python3
"""Read-only probe for release-100 BioMart databases on Ensembl's public server."""

from __future__ import annotations

import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs" / "stage02_orthology"))

import pymysql  # noqa: E402


def main() -> None:
    con = pymysql.connect(
        host="martdb.ensembl.org",
        port=5316,
        user="anonymous",
        password="",
        charset="utf8mb4",
        connect_timeout=20,
        read_timeout=60,
        cursorclass=pymysql.cursors.DictCursor,
    )
    try:
        with con.cursor() as cur:
            cur.execute("SELECT VERSION() AS server_version")
            version = cur.fetchone()
            cur.execute("SHOW DATABASES LIKE %s", ("%100%",))
            databases = cur.fetchall()
            print(json.dumps({"server": version, "release_100_databases": databases}, indent=2))
    finally:
        con.close()


if __name__ == "__main__":
    main()
