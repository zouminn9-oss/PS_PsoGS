options(stringsAsFactors = FALSE)

stats <- read.delim(file.path("results", "stage03", "scores", "paired_score_statistics.tsv"),
                    check.names = FALSE)
stopifnot(nrow(stats) == 2L,
          identical(sort(stats$dataset_id), c("GSE121212", "GSE30999")),
          all(stats$n_pairs > 2L), all(stats$sd_delta > 0))

n <- stats$n_pairs
d <- stats$mean_delta / stats$sd_delta
J <- 1 - 3 / (4 * (n - 1) - 1)
g <- J * d
variance <- J^2 * (1 / n + d^2 / (2 * (n - 1)))
se <- sqrt(variance)
zcrit <- qnorm(0.975)

cohort <- data.frame(
  record_type = "COHORT",
  dataset_id = stats$dataset_id,
  label = c(GSE30999 = "GSE30999 | GPL570 array",
            GSE121212 = "GSE121212 | RNA-seq")[stats$dataset_id],
  n_pairs = n,
  mean_delta = stats$mean_delta,
  sd_delta = stats$sd_delta,
  cohens_dz = d,
  hedges_J = J,
  effect = g,
  variance = variance,
  standard_error = se,
  ci_low = g - zcrit * se,
  ci_high = g + zcrit * se,
  weight_fixed = NA_real_,
  z_value = g / se,
  p_value = 2 * pnorm(-abs(g / se)),
  estimator = "Hedges g of paired differences"
)

w <- 1 / variance
fixed <- sum(w * g) / sum(w)
fixed_se <- sqrt(1 / sum(w))
Q <- sum(w * (g - fixed)^2)
df <- length(g) - 1
Q_p <- pchisq(Q, df = df, lower.tail = FALSE)
C_value <- sum(w) - sum(w^2) / sum(w)
tau2 <- max(0, (Q - df) / C_value)
I2 <- if (Q > 0) max(0, (Q - df) / Q) * 100 else 0
wr <- 1 / (variance + tau2)
random <- sum(wr * g) / sum(wr)
random_se <- sqrt(1 / sum(wr))
cohort$weight_fixed <- w / sum(w)

summaries <- data.frame(
  record_type = "SUMMARY",
  dataset_id = c("FIXED", "RANDOM_DL"),
  label = c("Fixed effect", "Random effect (DL sensitivity)"),
  n_pairs = sum(n), mean_delta = NA_real_, sd_delta = NA_real_, cohens_dz = NA_real_,
  hedges_J = NA_real_, effect = c(fixed, random), variance = c(fixed_se^2, random_se^2),
  standard_error = c(fixed_se, random_se),
  ci_low = c(fixed, random) - zcrit * c(fixed_se, random_se),
  ci_high = c(fixed, random) + zcrit * c(fixed_se, random_se),
  weight_fixed = NA_real_, z_value = c(fixed, random) / c(fixed_se, random_se),
  p_value = 2 * pnorm(-abs(c(fixed, random) / c(fixed_se, random_se))),
  estimator = c("inverse-variance fixed effect", "DerSimonian-Laird random effect")
)
out <- rbind(cohort, summaries)

heterogeneity <- data.frame(
  k_cohorts = length(g), Q = Q, Q_df = df, Q_p_value = Q_p,
  I2_percent = I2, tau2_DL = tau2,
  stable_heterogeneity_claim_allowed = "NO_K_LT_3",
  interpretation = "Two cohorts only; heterogeneity estimates are unstable"
)

write.table(out, file.path("results", "stage03", "scores", "score_meta.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE, na = "")
write.table(heterogeneity,
            file.path("results", "stage03", "scores", "score_meta_heterogeneity.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
cat("PASS: computed two-cohort frozen standardized score meta-analysis\n")
