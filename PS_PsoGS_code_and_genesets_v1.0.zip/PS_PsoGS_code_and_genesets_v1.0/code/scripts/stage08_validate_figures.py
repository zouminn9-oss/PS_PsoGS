from pathlib import Path
import csv,sys
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import pandas as pd
from PIL import Image
checks=[]
def ck(n,p,d): checks.append((n,bool(p),str(d)))
for p in [f"8{x.lower()}" for x in "ABCDEF"]:
 files={"source":ROOT/f"figures/source_data/fig{p}.tsv","stats":ROOT/f"results/figures/fig{p}_statistics.tsv","config":ROOT/f"config/figures/fig{p}.yaml","svg":ROOT/f"figures/panels/fig{p}.svg","png":ROOT/f"figures/previews/fig{p}.png","caption":ROOT/f"figures/captions/fig{p}.md"}
 for k,f in files.items(): ck(f"{p}_{k}_exists",f.exists() and f.stat().st_size>0,f)
 ck(f"{p}_source_nonempty",len(pd.read_csv(files["source"],sep="\t"))>0,files["source"])
 ck(f"{p}_stats_nonempty",len(pd.read_csv(files["stats"],sep="\t"))>0,files["stats"])
 with Image.open(files["png"]) as im: ck(f"{p}_print_pixels",im.width>=900 and im.height>=600,f"{im.width}x{im.height}")
 ck(f"{p}_caption_complete",len(files["caption"].read_text(encoding="utf-8").split())>=35,"word-like tokens")
registry=pd.read_csv(ROOT/"results/stage08/query_registry.tsv",sep="\t")
ck("all_queries_frozen",registry.frozen_before_connectivity.eq("YES").all(),registry.frozen_before_connectivity.tolist())
ck("q3_lm_blocked",registry.loc[registry.query_id=="Q3_CTRA","landmark_gate_status"].iloc[0].startswith("BLOCKED"),registry.loc[registry.query_id=="Q3_CTRA","landmark_gate_status"].iloc[0])
drug=pd.read_csv(ROOT/"results/stage08/l1000_drug_scores.tsv",sep="\t")
ck("two_lm_queries_only",set(drug.query_id)=={"Q1_SEP","Q2_ORDINARY_LESION"},sorted(drug.query_id.unique()))
ck("primary_minimum_context_enforced",drug.loc[drug.eligible_min_3_cell_lines,"n_cell_lines"].min()>=3,drug.loc[drug.eligible_min_3_cell_lines,"n_cell_lines"].min())
q3=pd.read_csv(ROOT/"results/stage08/q3_sigcom_gate.tsv",sep="\t").iloc[0]
ck("q3_separate_family",q3.not_mixed_with_LM_cosine=="YES",q3.not_mixed_with_LM_cosine)
sens=pd.read_csv(ROOT/"results/stage08/l1000_sensitivity.tsv",sep="\t")
ck("sensitivity_24_variants",len(sens)==24,len(sens))
gate=pd.read_csv(ROOT/"results/stage08/stage08_module_gate.tsv",sep="\t")
ck("final_hierarchy_blocked",gate.loc[gate.module=="final_dual_benefit_hierarchy","status"].iloc[0].startswith("BLOCKED"),gate.loc[gate.module=="final_dual_benefit_hierarchy","status"].iloc[0])
with (ROOT/"panel_manifest.tsv").open(encoding="utf-8",newline="") as f: man={r["panel_id"]:r for r in csv.DictReader(f,delimiter="\t")}
for p in [f"8{x}" for x in "ABCDEF"]: ck(f"manifest_{p}_ready",man[p]["status"]=="PASS" and man[p]["figure_ready"]=="YES",man[p]["status"])
for p in [f"8{x}" for x in "GHIJKL"]: ck(f"manifest_{p}_blocked",man[p]["status"].startswith("BLOCKED") and man[p]["figure_ready"]=="NO",man[p]["status"])
out=pd.DataFrame(checks,columns=["check","pass","detail"]); out.to_csv(ROOT/"audits/stage08_figure_checks.tsv",sep="\t",index=False)
if not out["pass"].all(): raise AssertionError(out.loc[~out["pass"]].to_string(index=False))
print(f"PASS: Stage 08 Figure QA {len(out)}/{len(out)} checks")
