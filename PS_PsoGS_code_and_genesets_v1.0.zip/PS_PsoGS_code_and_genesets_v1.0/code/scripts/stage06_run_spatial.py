from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))
import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import optimize, stats
from PIL import Image
import scanpy as sc
import yaml

CFG = yaml.safe_load((ROOT / "config/stage06_spatial.yaml").read_text(encoding="utf-8"))
BASE = ROOT / "data/raw/stage06/sections"; OUT = ROOT / "results/stage06"; OUT.mkdir(parents=True, exist_ok=True)

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest().upper()

def collapse_symbols(X, symbols):
    symbols=np.asarray([str(x).upper() for x in symbols],dtype=str)
    uniq, inv=np.unique(symbols,return_inverse=True)
    C=sp.csr_matrix((np.ones(len(symbols)),(np.arange(len(symbols)),inv)),shape=(len(symbols),len(uniq)))
    return (X.tocsr()@C).tocsr(),uniq

def rank_scores(expr, gene_symbols, up, down):
    # Dense per-section ranks are tractable (<1,500 x <=33,538) and retain zero ties.
    dense=expr.toarray()
    ranks=np.apply_along_axis(stats.rankdata,1,dense)/dense.shape[1]
    col={g:i for i,g in enumerate(gene_symbols)}
    ui=[col[g] for g in up if g in col]; di=[col[g] for g in down if g in col]
    return ranks[:,ui].mean(1)-ranks[:,di].mean(1),len(ui),len(di),ranks

core=pd.read_csv(ROOT/'genesets/PS_PsoGS_Core_v1.0.tsv',sep='\t')
sep=pd.read_csv(ROOT/'genesets/SEP_v1.0.tsv',sep='\t')
core_up=set(core.loc[core.H_logFC>0,'human_gene_symbol'].str.upper());core_dn=set(core.loc[core.H_logFC<0,'human_gene_symbol'].str.upper())
sep_up=set(sep.loc[sep.sep_direction=='UP','human_gene_symbol'].str.upper());sep_dn=set(sep.loc[sep.sep_direction=='DOWN','human_gene_symbol'].str.upper())
gmt={}
with (ROOT/'data/raw/stage05/reactome-current/ReactomePathways.gmt').open(encoding='utf-8') as f:
    for line in f:
        p=line.rstrip().split('\t');
        if len(p)>=3:gmt[p[1]]=(p[0],[x.upper() for x in p[2:]])
gsh=set(gmt['R-HSA-174403'][1])

# Discovery reference centroid and label-blind specificity markers.
ref_idx=pd.read_csv(ROOT/'results/stage05/donor_celltype_pseudobulk_index.tsv',sep='\t')
ref_gen=pd.read_csv(ROOT/'results/stage05/donor_celltype_pseudobulk_genes.tsv',sep='\t')
ref_mat=sp.load_npz(ROOT/'results/stage05/donor_celltype_pseudobulk_log1p_cp10k.npz').tocsr()
eligible=ref_idx.eligible_min_cells.to_numpy(bool)
celltypes=sorted(ref_idx.loc[eligible,'cell_type'].unique())
ref_cent=[]
for ct in celltypes:
    rr=np.where(eligible & (ref_idx.cell_type.to_numpy()==ct))[0]
    ref_cent.append(np.asarray(ref_mat[rr].mean(0)).ravel())
ref_cent=np.vstack(ref_cent); ref_symbols=ref_gen.gene_symbol.astype(str).str.upper().to_numpy();
markers={}
for i,ct in enumerate(celltypes):
    other=np.max(np.delete(ref_cent,i,axis=0),axis=0)
    spec=ref_cent[i]-other; order=np.argsort(spec)[::-1]
    markers[ct]=[ref_symbols[j] for j in order if spec[j]>0][:int(CFG['reference_mapping']['top_markers_per_cell_type'])]
pd.DataFrame([(ct,g,k+1) for ct,gs in markers.items() for k,g in enumerate(gs)],columns=['cell_type','gene_symbol','specificity_rank']).to_csv(OUT/'mapping_marker_registry.tsv',sep='\t',index=False)

# Independent reference centroids for sensitivity, using transferred labels only.
rmeta=pd.read_csv(ROOT/'data/processed/stage04/gse162183_cell_metadata_annotated.tsv.gz',sep='\t')
rX=sp.load_npz(ROOT/'data/processed/stage04/gse162183_counts_qc.npz').tocsr()
rgenes=pd.read_csv(ROOT/'data/processed/stage04/gse162183_genes.tsv',sep='\t')
rX,rsym=collapse_symbols(rX,rgenes.human_gene_symbol.fillna(''))
name_map={'T_cell':'T','Smooth_muscle':'Smooth_muscle'}
rmeta['cell_type_aligned']=rmeta.cell_type.replace(name_map)
common_ct=sorted(set(celltypes)&set(rmeta.cell_type_aligned.unique()))
rcent=[]
for ct in common_ct:
    rr=np.where(rmeta.cell_type_aligned.to_numpy()==ct)[0]
    sums=np.asarray(rX[rr].sum(0)).ravel(); rcent.append(np.log1p(sums/sums.sum()*1e4))
rcent=np.vstack(rcent)
rmarkers={}
for i,ct in enumerate(common_ct):
    other=np.max(np.delete(rcent,i,axis=0),axis=0);spec=rcent[i]-other;order=np.argsort(spec)[::-1]
    rmarkers[ct]=[rsym[j] for j in order if spec[j]>0][:int(CFG['reference_mapping']['top_markers_per_cell_type'])]

qc_rows=[];spot_frames=[];map_frames=[];sens_rows=[];file_rows=[]
for section,meta_cfg in CFG['sections'].items():
    d=BASE/section
    for f in sorted(d.rglob('*')):
        if f.is_file():file_rows.append({'section':section,'file':str(f.relative_to(ROOT)).replace('\\','/'),'bytes':f.stat().st_size,'sha256':sha(f)})
    ad=sc.read_10x_h5(d/'filtered_feature_bc_matrix.h5')
    raw=sc.read_10x_h5(d/'raw_feature_bc_matrix.h5')
    X,symbols=collapse_symbols(ad.X,ad.var_names)
    pos=pd.read_csv(d/'spatial/tissue_positions_list.csv',header=None,names=['barcode','in_tissue','array_row','array_col','pxl_row_fullres','pxl_col_fullres']).set_index('barcode')
    pos=pos.loc[ad.obs_names]
    sf=json.loads((d/'spatial/scalefactors_json.json').read_text())
    with Image.open(d/'spatial/tissue_hires_image.png') as im: iw,ih=im.size
    totals=np.asarray(X.sum(1)).ravel();features=np.diff(X.indptr)
    mt=np.array([g.startswith('MT-') for g in symbols]);mtc=np.asarray(X[:,mt].sum(1)).ravel();mito=np.divide(mtc,totals,out=np.zeros_like(mtc,dtype=float),where=totals>0)*100
    q=(totals>=CFG['spot_qc']['minimum_counts'])&(features>=CFG['spot_qc']['minimum_features'])&(mito<=CFG['spot_qc']['maximum_mito_percent'])&(pos.in_tissue.to_numpy()==1)
    scale=np.divide(1e4,totals,out=np.zeros_like(totals,dtype=float),where=totals>0);expr=X.multiply(scale[:,None]).tocsr();expr.data=np.log1p(expr.data)
    core_score,ncu,ncd,ranks=rank_scores(expr,symbols,core_up,core_dn)
    col={g:i for i,g in enumerate(symbols)}; su=[col[g] for g in sep_up if g in col];sd=[col[g] for g in sep_dn if g in col]
    sep_score=ranks[:,su].mean(1)-ranks[:,sd].mean(1)
    gg=[col[g] for g in gsh if g in col];gsh_score=ranks[:,gg].mean(1)
    jag=np.asarray(expr[:,col['JAG2']].toarray()).ravel() if 'JAG2' in col else np.full(len(ad),np.nan)
    notch=np.asarray(expr[:,col['NOTCH2']].toarray()).ravel() if 'NOTCH2' in col else np.full(len(ad),np.nan)
    spots=pd.DataFrame({'section':section,'gsm':meta_cfg['gsm'],'disease':meta_cfg['disease'],'chemistry':meta_cfg['chemistry'],'barcode':ad.obs_names,'in_tissue':pos.in_tissue.to_numpy(),'x_hires':pos.pxl_col_fullres.to_numpy()*sf['tissue_hires_scalef'],'y_hires':pos.pxl_row_fullres.to_numpy()*sf['tissue_hires_scalef'],'n_counts':totals,'n_features':features,'mito_percent':mito,'qc_pass':q,'core_directed':core_score,'sep_directed':sep_score,'glutathione_rna':gsh_score,'JAG2_log1p_cp10k':jag,'NOTCH2_log1p_cp10k':notch})
    spot_frames.append(spots)
    # Primary discovery-reference NNLS on union of markers measurable in section.
    use=sorted(set(sum(markers.values(),[]))&set(symbols)&set(ref_symbols)); scols=[col[g] for g in use]; rcol={g:i for i,g in enumerate(ref_symbols)}
    A=ref_cent[:,[rcol[g] for g in use]].T
    B=expr[:,scols].toarray(); coef=np.zeros((len(ad),len(celltypes)));resid=np.zeros(len(ad))
    for ii,b in enumerate(B):coef[ii],resid[ii]=optimize.nnls(A,b)
    denom=coef.sum(1);coef=np.divide(coef,denom[:,None],out=np.zeros_like(coef),where=denom[:,None]>0)
    m=spots[['section','barcode','disease','chemistry','qc_pass']].copy()
    for i,ct in enumerate(celltypes):m[ct]=coef[:,i]
    strom=m.get('Fibroblast',0)+m.get('Endothelial',0)+m.get('Smooth_muscle',0)
    immune=m.get('T',0)+m.get('Myeloid',0)+m.get('Mast',0)
    ker=m.get('Keratinocyte',0)
    arr=np.vstack([ker,strom,immune]).T; names=np.array(['keratinocyte-rich','stromal-rich','immune-rich'])
    m['expression_compartment']=np.where(arr.max(1)>=.40,names[arr.argmax(1)],'mixed/uncertain')
    m['nnls_residual']=resid
    map_frames.append(m)
    # Sensitivity reference: compare keratinocyte/fibroblast proportions on a shared marker union.
    use2=sorted(set(sum(rmarkers.values(),[]))&set(symbols)&set(rsym)); r2col={g:i for i,g in enumerate(rsym)};A2=rcent[:,[r2col[g] for g in use2]].T;B2=expr[:,[col[g] for g in use2]].toarray();coef2=np.zeros((len(ad),len(common_ct)))
    for ii,b in enumerate(B2):coef2[ii],_=optimize.nnls(A2,b)
    de=coef2.sum(1);coef2=np.divide(coef2,de[:,None],out=np.zeros_like(coef2),where=de[:,None]>0)
    for ct in ['Keratinocyte','Fibroblast']:
        if ct in celltypes and ct in common_ct:
            a=coef[:,celltypes.index(ct)];b=coef2[:,common_ct.index(ct)];ok=q&np.isfinite(a)&np.isfinite(b)
            rho,p=stats.spearmanr(a[ok],b[ok])
            sens_rows.append({'section':section,'cell_type':ct,'n_qc_spots':int(ok.sum()),'spearman_rho':rho,'spearman_p':p,'primary_median':np.median(a[ok]),'sensitivity_median':np.median(b[ok])})
    qc_rows.append({'section':section,'gsm':meta_cfg['gsm'],'disease':meta_cfg['disease'],'chemistry':meta_cfg['chemistry'],'filtered_spots':len(ad),'raw_barcodes':len(raw),'genes':X.shape[1],'raw_genes':raw.n_vars,'nnz':X.nnz,'qc_spots':int(q.sum()),'qc_fraction':q.mean(),'median_counts':np.median(totals),'median_features':np.median(features),'median_mito_percent':np.median(mito),'positions_rows':len(pos),'hires_width_px':iw,'hires_height_px':ih,'hires_scalef':sf['tissue_hires_scalef'],'spot_diameter_fullres_px':sf['spot_diameter_fullres'],'core_up_genes':ncu,'core_down_genes':ncd,'sep_up_genes':len(su),'sep_down_genes':len(sd),'glutathione_genes':len(gg)})

qc=pd.DataFrame(qc_rows);spots=pd.concat(spot_frames,ignore_index=True);mapping=pd.concat(map_frames,ignore_index=True);sens=pd.DataFrame(sens_rows)
qc.to_csv(OUT/'section_qc.tsv',sep='\t',index=False);spots.to_csv(OUT/'spot_scores.tsv.gz',sep='\t',index=False,compression='gzip');mapping.to_csv(OUT/'cell_mapping.tsv.gz',sep='\t',index=False,compression='gzip');sens.to_csv(OUT/'reference_sensitivity.tsv',sep='\t',index=False);pd.DataFrame(file_rows).to_csv(OUT/'stage06_input_file_manifest.tsv',sep='\t',index=False)
merged=spots.merge(mapping[['section','barcode','expression_compartment']],on=['section','barcode'])
summary=merged[merged.qc_pass].groupby(['section','disease','chemistry']).agg(n_spots=('barcode','size'),median_core=('core_directed','median'),median_sep=('sep_directed','median'),median_glutathione=('glutathione_rna','median'),median_JAG2=('JAG2_log1p_cp10k','median'),median_NOTCH2=('NOTCH2_log1p_cp10k','median')).reset_index()
comp=merged[merged.qc_pass].groupby(['section','expression_compartment']).size().rename('n').reset_index();comp['fraction']=comp.n/comp.groupby('section').n.transform('sum')
summary.to_csv(OUT/'section_effects.tsv',sep='\t',index=False);comp.to_csv(OUT/'compartments.tsv',sep='\t',index=False)
blocks=pd.DataFrame({'module':CFG['blocked_modules'],'status':['BLOCKED_BY_PRIMARY_PAPER_QUALITY_LIMITATION']*4+['BLOCKED_NO_SPATIAL_METABOLOMICS']})
blocks.to_csv(OUT/'spatial_blocked_modules.tsv',sep='\t',index=False)
checks=[('six_sections',len(qc)==6,len(qc)),('five_frozen_one_ffpe',(qc.chemistry=='frozen').sum()==5 and (qc.chemistry=='FFPE').sum()==1,qc.chemistry.value_counts().to_dict()),('positions_match_filtered',bool((qc.positions_rows==qc.filtered_spots).all()),'all'),('all_have_qc_spots',bool((qc.qc_spots>0).all()),qc.qc_spots.min()),('core_coverage',bool((qc.core_up_genes>=20).all()&(qc.core_down_genes>=20).all()),f"{qc.core_up_genes.min()}/{qc.core_down_genes.min()}"),('sep_coverage',bool((qc.sep_up_genes>=20).all()&(qc.sep_down_genes>=20).all()),f"{qc.sep_up_genes.min()}/{qc.sep_down_genes.min()}"),('all_images_nonempty',all(x['bytes']>0 for x in file_rows),len(file_rows)),('mapping_rows_equal_spots',len(mapping)==len(spots),f"{len(mapping)}/{len(spots)}"),('blocked_modules_retained',len(blocks)==5,len(blocks))]
audit=pd.DataFrame(checks,columns=['check','pass','detail']);audit.to_csv(ROOT/'audits/stage06_spatial_checks.tsv',sep='\t',index=False)
if not audit['pass'].all():raise AssertionError(audit.loc[~audit['pass']].to_string(index=False))
print(qc.to_string(index=False));print(f"PASS: {len(audit)} Stage 06 spatial checks; {len(spots)} filtered spots")
