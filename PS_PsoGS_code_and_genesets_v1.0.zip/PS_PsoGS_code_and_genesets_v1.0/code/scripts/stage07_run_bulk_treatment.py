from pathlib import Path
from collections import defaultdict
import csv, gzip, hashlib, json, math, sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))
import numpy as np
import pandas as pd
from scipy.stats import rankdata, t, wilcoxon
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

RAW = ROOT / "data/raw/stage07"
OUT = ROOT / "results/stage07"
AUDIT = ROOT / "audits"
OUT.mkdir(parents=True, exist_ok=True)

def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""): h.update(block)
    return h.hexdigest().upper()

def bh(p):
    p = np.asarray(p, float); n = len(p); order = np.argsort(p); q = np.empty(n); last = 1.0
    for rank in range(n, 0, -1):
        i = order[rank-1]; last = min(last, p[i] * n / rank); q[i] = last
    return q

def parse_annotation(path):
    probe_to_entrez = {}
    with gzip.open(path, "rt", encoding="utf-8", errors="replace", newline="") as f:
        reader = csv.reader((line for line in f if not line.startswith(("#", "!", "^"))), delimiter="\t")
        header = next(reader); ix = {x:i for i,x in enumerate(header)}
        for row in reader:
            if len(row) <= max(ix["ID"], ix["Gene ID"]): continue
            ids = {x.strip() for x in row[ix["Gene ID"]].split("///") if x.strip().isdigit()}
            if len(ids) == 1: probe_to_entrez[row[ix["ID"]]] = next(iter(ids))
    return probe_to_entrez

def parse_matrix(path, probe_to_entrez):
    samples = None; by_gene = defaultdict(list); in_table = False
    with gzip.open(path, "rt", encoding="utf-8", errors="replace", newline="") as f:
        for line in f:
            if line.startswith("!series_matrix_table_begin"): in_table = True; continue
            if not in_table: continue
            if line.startswith("!series_matrix_table_end"): break
            row = next(csv.reader([line], delimiter="\t"))
            if samples is None:
                assert row[0] == "ID_REF"; samples = row[1:]; continue
            gene = probe_to_entrez.get(row[0])
            if gene is not None: by_gene[gene].append(np.asarray(row[1:], dtype=np.float32))
    genes = sorted(by_gene, key=lambda x: int(x))
    matrix = np.vstack([np.median(np.vstack(by_gene[g]), axis=0) for g in genes]).astype(np.float32)
    probes_per_gene = np.asarray([len(by_gene[g]) for g in genes])
    return samples, genes, matrix, probes_per_gene

def load_signature(path): return pd.read_csv(path, sep="\t", dtype={"selected_human_entrez_id":str})

def score(matrix, genes, sig, direction):
    ranks = rankdata(matrix, method="average", axis=0) / (matrix.shape[0] + 1.0)
    index = {g:i for i,g in enumerate(genes)}
    if direction == "sep_direction":
        up = [index[g] for g in sig.loc[sig[direction] == "UP", "selected_human_entrez_id"] if g in index]
        down = [index[g] for g in sig.loc[sig[direction] == "DOWN", "selected_human_entrez_id"] if g in index]
    else:
        up = [index[g] for g in sig.loc[sig.H_logFC > 0, "selected_human_entrez_id"] if g in index]
        down = [index[g] for g in sig.loc[sig.H_logFC < 0, "selected_human_entrez_id"] if g in index]
    return ranks[up].mean(axis=0) - ranks[down].mean(axis=0), len(up), len(down)

checks=[]
def ck(name, passed, detail):
    checks.append({"check":name,"pass":bool(passed),"detail":str(detail)})
    if not passed: raise AssertionError(f"{name}: {detail}")

matrix_path = RAW / "GSE117468_series_matrix.txt.gz"; annot_path = RAW / "GPL570.annot.gz"
probe_map = parse_annotation(annot_path)
samples, genes, matrix, probes_per_gene = parse_matrix(matrix_path, probe_map)
ck("matrix_samples", len(samples)==565, len(samples)); ck("unique_samples", len(set(samples))==565, len(set(samples)))
ck("gene_count_gt_20000", len(genes)>20000, len(genes)); ck("eligible_probes_gt_30000", len(probe_map)>30000, len(probe_map))

meta = pd.read_csv(ROOT / "metadata/gse117468_patient_visit_tissue_map.tsv", sep="\t", dtype={"patient_id":str})
ck("metadata_samples", len(meta)==565, len(meta)); ck("sample_sets_equal", set(meta.sample_id)==set(samples), len(set(meta.sample_id)&set(samples)))
meta = meta.set_index("sample_id").loc[samples].reset_index()

sep = load_signature(ROOT / "genesets/SEP_v1.0.tsv")
core = load_signature(ROOT / "genesets/PS_PsoGS_Core_v1.0.tsv")
sep_score, sep_up, sep_down = score(matrix, genes, sep, "sep_direction")
core_score, core_up, core_down = score(matrix, genes, core, "H_direction")
ck("sep_coverage_up", sep_up >= 1200, sep_up); ck("sep_coverage_down", sep_down >= 1200, sep_down)
ck("core_coverage_up", core_up >= 2200, core_up); ck("core_coverage_down", core_down >= 2200, core_down)

scores = meta.copy()
scores["sep_score"] = sep_score; scores["core_score"] = core_score
scores["score_definition"] = "mean_fractional_rank_UP_minus_DOWN"
scores.to_csv(OUT / "gse117468_sample_scores.tsv", sep="\t", index=False)

# Persist the deterministic gene summary in compressed long-header matrix form.
expr = pd.DataFrame(matrix, index=genes, columns=samples); expr.index.name = "entrez_id"
expr.to_csv(OUT / "gse117468_gene_median_gcrma.tsv.gz", sep="\t", compression="gzip")
pd.DataFrame({"entrez_id":genes,"eligible_probe_count":probes_per_gene}).to_csv(OUT / "gse117468_gene_probe_counts.tsv",sep="\t",index=False)

effects=[]; score_names=["sep_score","core_score"]
for sc in score_names:
  for (arm,tissue), group in scores.groupby(["treatment","tissue"]):
    wide=group.pivot_table(index="patient_id",columns="visit",values=sc,aggfunc="first")
    for visit in ["W4","W12"]:
      if {"BL",visit}.issubset(wide.columns):
        d=(wide[visit]-wide["BL"]).dropna(); n=len(d)
        if n>=5:
          se=d.std(ddof=1)/math.sqrt(n); crit=t.ppf(.975,n-1)
          try: p=float(wilcoxon(d,alternative="two-sided").pvalue)
          except ValueError: p=1.0
          effects.append(dict(program=sc.replace("_score",""),treatment=arm,tissue=tissue,contrast=f"{visit}_minus_BL",n_pairs=n,mean_difference=d.mean(),ci_low=d.mean()-crit*se,ci_high=d.mean()+crit*se,median_difference=d.median(),wilcoxon_p=p))
  # LS-NL normalization interaction among complete four-sample patients.
  x=scores.pivot_table(index=["patient_id","treatment"],columns=["visit","tissue"],values=sc,aggfunc="first")
  need=[("BL","lesional skin"),("BL","non-lesional skin"),("W12","lesional skin"),("W12","non-lesional skin")]
  if all(c in x.columns for c in need):
    for arm,g in x.groupby(level="treatment"):
      d=((g[("W12","lesional skin")]-g[("W12","non-lesional skin")])-(g[("BL","lesional skin")]-g[("BL","non-lesional skin")])).dropna(); n=len(d)
      if n>=5:
        se=d.std(ddof=1)/math.sqrt(n); crit=t.ppf(.975,n-1)
        try: p=float(wilcoxon(d,alternative="two-sided").pvalue)
        except ValueError: p=1.0
        effects.append(dict(program=sc.replace("_score",""),treatment=arm,tissue="LS_minus_NL",contrast="W12_minus_BL_interaction",n_pairs=n,mean_difference=d.mean(),ci_low=d.mean()-crit*se,ci_high=d.mean()+crit*se,median_difference=d.median(),wilcoxon_p=p))
effects=pd.DataFrame(effects); effects["fdr_bh"]=bh(effects.wilcoxon_p.values)
effects.to_csv(OUT / "gse117468_longitudinal_effects.tsv",sep="\t",index=False)

# Restricted, fully internal comparison. Missing M1 means this is not canonical M2.
registry=pd.read_csv(ROOT / "metadata/gse117468_patient_registry.tsv",sep="\t",dtype={"patient_id":str})
eligible=registry[(registry.baseline_ls_prediction_metadata_eligible=="YES") &
                  (registry.metadata_role=="BRODALUMAB_BASELINE_PREDICTION_METADATA_ELIGIBLE")].copy()
base=scores[(scores.visit=="BL")&(scores.tissue=="lesional skin")][["patient_id","sep_score","core_score"]]
pred=eligible.merge(base,on="patient_id",how="inner")
ck("prediction_n",len(pred)==74,len(pred)); ck("prediction_events",int(pred.pasi75.eq("YES").sum())==62,int(pred.pasi75.eq("YES").sum()))
pred["y"]=(pred.pasi75=="YES").astype(int)
numeric=["age","bmi","weight","bl_pasi"]; categorical=["race"]
for c in numeric: pred[c]=pd.to_numeric(pred[c],errors="coerce")
models={"M0_CLINICAL":numeric+categorical,"M0_PLUS_SEP_SENSITIVITY_NOT_CANONICAL_M2":numeric+categorical+["sep_score"]}
outer=RepeatedStratifiedKFold(n_splits=5,n_repeats=20,random_state=20260911)
pred_rows=[]; repeat_metrics=[]; tuning=[]
for model_name,features in models.items():
  num=[c for c in features if c != "race"]; cat=[c for c in features if c == "race"]
  prep=ColumnTransformer([("num",Pipeline([("impute",SimpleImputer(strategy="median")),("scale",StandardScaler())]),num),("cat",Pipeline([("impute",SimpleImputer(strategy="most_frequent")),("onehot",OneHotEncoder(handle_unknown="ignore"))]),cat)])
  pipe=Pipeline([("prep",prep),("clf",LogisticRegression(max_iter=2000,class_weight="balanced",solver="liblinear"))])
  fold=0
  for train,test in outer.split(pred[features],pred.y):
    rep=fold//5; split=fold%5; fold+=1
    inner=StratifiedKFold(n_splits=4,shuffle=True,random_state=20260911+fold)
    fit=GridSearchCV(pipe,{"clf__C":[.01,.1,1,10]},scoring="average_precision",cv=inner,n_jobs=1)
    fit.fit(pred.iloc[train][features],pred.iloc[train].y)
    probability=fit.predict_proba(pred.iloc[test][features])[:,1]
    tuning.append({"model":model_name,"repeat":rep,"fold":split,"best_C":fit.best_params_["clf__C"]})
    for i,pr in zip(test,probability): pred_rows.append({"model":model_name,"repeat":rep,"fold":split,"patient_id":pred.iloc[i].patient_id,"outcome":int(pred.iloc[i].y),"probability":pr})
predictions=pd.DataFrame(pred_rows)
for (model,rep),g in predictions.groupby(["model","repeat"]):
  repeat_metrics.append({"model":model,"repeat":rep,"auroc":roc_auc_score(g.outcome,g.probability),"auprc":average_precision_score(g.outcome,g.probability),"brier":brier_score_loss(g.outcome,g.probability)})
metrics=pd.DataFrame(repeat_metrics)
summary=metrics.groupby("model").agg(auroc_median=("auroc","median"),auroc_q025=("auroc",lambda x:x.quantile(.025)),auroc_q975=("auroc",lambda x:x.quantile(.975)),auprc_median=("auprc","median"),auprc_q025=("auprc",lambda x:x.quantile(.025)),auprc_q975=("auprc",lambda x:x.quantile(.975)),brier_median=("brier","median"),brier_q025=("brier",lambda x:x.quantile(.025)),brier_q975=("brier",lambda x:x.quantile(.975))).reset_index()
wide=metrics.pivot(index="repeat",columns="model",values=["auroc","auprc","brier"])
delta=[]
for metric in ["auroc","auprc","brier"]:
  d=wide[metric]["M0_PLUS_SEP_SENSITIVITY_NOT_CANONICAL_M2"]-wide[metric]["M0_CLINICAL"]
  delta.append({"metric":metric,"delta_median":d.median(),"delta_q025":d.quantile(.025),"delta_q975":d.quantile(.975),"n_repeats":len(d)})
summary.to_csv(OUT/"prediction_model_summary.tsv",sep="\t",index=False)
pd.DataFrame(delta).to_csv(OUT/"prediction_model_deltas.tsv",sep="\t",index=False)
metrics.to_csv(OUT/"prediction_repeat_metrics.tsv",sep="\t",index=False)
predictions.to_csv(OUT/"prediction_outer_predictions.tsv.gz",sep="\t",index=False,compression="gzip")
pd.DataFrame(tuning).to_csv(OUT/"prediction_inner_tuning.tsv",sep="\t",index=False)

avg=predictions.groupby(["model","patient_id","outcome"],as_index=False).probability.mean()
cal=[]
for model,g in avg.groupby("model"):
  g=g.copy(); g["bin"]=pd.qcut(g.probability,q=8,labels=False,duplicates="drop")
  for b,z in g.groupby("bin"): cal.append({"model":model,"bin":int(b),"n":len(z),"mean_predicted":z.probability.mean(),"observed_fraction":z.outcome.mean()})
pd.DataFrame(cal).to_csv(OUT/"prediction_calibration.tsv",sep="\t",index=False)

blocked=pd.DataFrame([
 {"module":"canonical_M1","status":"BLOCKED_MISSING_FROZEN_COMPARATOR_SIGNATURES","reason":"No result-blind frozen conventional psoriasis inflammatory program exists."},
 {"module":"canonical_M2_comparison","status":"BLOCKED_MISSING_CANONICAL_M1","reason":"M2=M1+SEP cannot be constructed without M1; M0+SEP is reported only as sensitivity."},
 {"module":"gene_panel_stability","status":"BLOCKED_ONLY_12_NONEVENTS_AND_NO_PRESPECIFIED_SELECTION","reason":"Gene selection would be unstable and was not pre-specified."},
 {"module":"external_prediction_validation","status":"BLOCKED_NO_EXTERNAL_RESPONSE_COHORT","reason":"All predictive estimates are internal repeated nested CV."},
 {"module":"multiview_fusion","status":"BLOCKED_NO_MATCHED_MULTIVIEW_PATIENT_MATRIX","reason":"No matched patient multi-view input."},
])
blocked.to_csv(OUT/"stage07_blocked_modules.tsv",sep="\t",index=False)

files=[matrix_path,annot_path,ROOT/"metadata/gse117468_patient_visit_tissue_map.tsv",ROOT/"metadata/gse117468_patient_registry.tsv",ROOT/"genesets/SEP_v1.0.tsv",ROOT/"genesets/PS_PsoGS_Core_v1.0.tsv"]
pd.DataFrame([{"path":str(p.relative_to(ROOT)).replace('\\','/'),"bytes":p.stat().st_size,"sha256":sha256(p)} for p in files]).to_csv(OUT/"stage07_input_manifest.tsv",sep="\t",index=False)
pd.DataFrame(checks).to_csv(AUDIT/"stage07_bulk_checks.tsv",sep="\t",index=False)
print(f"PASS: Stage 07 bulk treatment {len(checks)}/{len(checks)} checks; {len(genes)} genes; {len(effects)} longitudinal contrasts")
print(summary.to_string(index=False))
print(pd.DataFrame(delta).to_string(index=False))
