#!/usr/bin/env python3
"""Audit GSE270712 condition labels and experimental-unit eligibility.

This script deliberately does not read expression matrices.  It reconciles the
official GEO SOFT metadata with the primary-paper JATS XML and leaves ambiguous
conditions unresolved rather than guessing from file-name abbreviations.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import re
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATE = "2026-09-10"
SOFT_PATH = ROOT / "metadata" / "geo_soft" / "GSE270712_family.soft.gz"
PAPER_XML_PATH = ROOT / "metadata" / "gse270712_pmc12183641.xml"
GEO_URL = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270712"
PAPER_URL = "https://pmc.ncbi.nlm.nih.gov/articles/PMC12183641/"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_tsv(path: Path, rows: list[dict[str, str]]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write empty audit: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n"
        )
        writer.writeheader()
        writer.writerows(rows)


def read_soft_samples(path: Path) -> tuple[str, list[dict[str, object]]]:
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
        text = handle.read()

    series_design = ""
    for line in text.splitlines():
        if line.startswith("!Series_overall_design = "):
            series_design = line.split(" = ", 1)[1]
            break

    samples: list[dict[str, object]] = []
    for block in re.split(r"(?=\^SAMPLE = )", text):
        if not block.startswith("^SAMPLE = "):
            continue
        record: dict[str, object] = {"supplementary_files": [], "relations": []}
        for line in block.splitlines():
            if " = " not in line:
                continue
            key, value = line.split(" = ", 1)
            if key == "^SAMPLE":
                record["gsm"] = value
            elif key == "!Sample_title":
                record["title"] = value
            elif key == "!Sample_characteristics_ch1" and value.lower().startswith("treatment:"):
                record["treatment"] = value.split(":", 1)[1].strip()
            elif key.startswith("!Sample_supplementary_file_"):
                record["supplementary_files"].append(value)
            elif key == "!Sample_relation":
                record["relations"].append(value)
        samples.append(record)
    return series_design, samples


def components(label: str) -> str:
    value = label.lower().replace("staphylococcus aureus", "sa")
    found: list[str] = []
    if "control" in value:
        found.append("CONTROL")
    if "sa" in value and "control" not in value:
        found.append("SA")
    if "stress" in value:
        found.append("STRESS")
    if "sb" in value:
        found.append("SB")
    return "+".join(found)


def file_prefix(files: list[str]) -> str:
    if not files:
        return ""
    name = Path(files[0]).name
    match = re.match(r"GSM\d+_([^_]+)_", name)
    return match.group(1) if match else ""


def relation_accession(relations: list[str], kind: str) -> str:
    for relation in relations:
        if relation.startswith(f"{kind}:"):
            return relation.rsplit("/", 1)[-1].replace("?term=", "")
    return ""


def paper_sections(path: Path) -> list[tuple[str, str]]:
    root = ET.parse(path).getroot()
    sections: list[tuple[str, str]] = []
    for sec in root.iter():
        if sec.tag.split("}")[-1] != "sec":
            continue
        title = ""
        for child in sec:
            if child.tag.split("}")[-1] == "title":
                title = " ".join("".join(child.itertext()).split())
                break
        body = " ".join("".join(sec.itertext()).split())
        sections.append((title, body))
    return sections


def find_section(sections: list[tuple[str, str]], phrase: str) -> tuple[str, str]:
    phrase_norm = " ".join(phrase.split()).lower()
    for title, body in sections:
        if phrase_norm in body.lower():
            return title, body
    raise AssertionError(f"Primary-paper evidence phrase not found: {phrase}")


def main() -> None:
    series_design, samples = read_soft_samples(SOFT_PATH)
    if len(samples) != 6:
        raise AssertionError(f"Expected 6 GEO samples, found {len(samples)}")

    frozen = {
        "GSM8350485": ("Control", "DESCRIPTIVE_LABEL_CONFIRMED"),
        "GSM8350486": ("Stress", "DESCRIPTIVE_LABEL_CONFIRMED"),
        "GSM8350487": ("SA", "DESCRIPTIVE_LABEL_CONFIRMED"),
        "GSM8350488": ("SA+Stress", "DESCRIPTIVE_LABEL_CONFIRMED"),
        "GSM8350489": ("", "HOLD_CONFLICTING_GEO_FIELDS"),
        "GSM8350490": ("", "HOLD_CONFLICTING_GEO_FIELDS"),
    }

    audit_rows: list[dict[str, str]] = []
    for sample in samples:
        gsm = str(sample["gsm"])
        title = str(sample.get("title", ""))
        treatment = str(sample.get("treatment", ""))
        files = list(sample.get("supplementary_files", []))
        relations = list(sample.get("relations", []))
        canonical, status = frozen[gsm]
        title_components = components(title)
        treatment_components = components(treatment)
        audit_rows.append(
            {
                "dataset_id": "GSE270712",
                "sample_accession": gsm,
                "geo_title_verbatim": title,
                "geo_treatment_verbatim": treatment,
                "title_components": title_components,
                "treatment_components": treatment_components,
                "supplementary_file_prefix": file_prefix(files),
                "canonical_condition": canonical,
                "label_status": status,
                "field_concordance": "PASS" if title_components == treatment_components else "FAIL",
                "statistical_unit": "pooled_library",
                "animals_per_pool": "3",
                "library_replicates_per_condition": "1",
                "confirmatory_eligibility": "DESCRIPTIVE_ONLY",
                "expression_matrix_accessed": "NO",
                "biosample": relation_accession(relations, "BioSample"),
                "sra_experiment": relation_accession(relations, "SRA"),
                "source_url": GEO_URL,
                "source_file": SOFT_PATH.relative_to(ROOT).as_posix(),
                "source_sha256": sha256(SOFT_PATH),
                "accessed_local_date": DATE,
                "adjudication_note": (
                    "Title and treatment fields agree; retained only for descriptive use because the condition has one pooled library."
                    if status == "DESCRIPTIVE_LABEL_CONFIRMED"
                    else "Title and treatment fields disagree; file-prefix semantics are unverified and were not used to guess a condition."
                ),
            }
        )

    sections = paper_sections(PAPER_XML_PATH)
    pooled_title, pooled_body = find_section(
        sections, "Pooled dorsal skin tissues from SA- or mock-infected mice"
    )
    # ASCII drug identifier avoids locale-dependent rendering of the Greek beta
    # character while still locating the in-vivo inhibitor passage.
    inhibitor_title, inhibitor_body = find_section(sections, "SB431542")
    if "n = 3 animals per condition" not in pooled_body:
        raise AssertionError("The expected n=3 animals-per-condition statement is absent")

    evidence_rows = [
        {
            "evidence_id": "GSE270712_GEO_DESIGN",
            "source_type": "official_repository",
            "source_locator": "GEO Series overall design",
            "evidence_summary": series_design,
            "supports": "Six-condition scRNA-seq design includes stress, SA infection and SB-431542 context.",
            "limits": "Series-level design does not reconcile conflicting sample fields.",
            "source_url": GEO_URL,
            "source_file": SOFT_PATH.relative_to(ROOT).as_posix(),
            "source_sha256": sha256(SOFT_PATH),
            "accessed_local_date": DATE,
        },
        {
            "evidence_id": "GSE270712_PAPER_POOLING",
            "source_type": "primary_article",
            "source_locator": f"Materials and Methods / {pooled_title or 'single-cell RNA-seq'}",
            "evidence_summary": "The paper states that dorsal skin from three animals per condition was pooled for scRNA-seq.",
            "supports": "Animals per pooled library = 3.",
            "limits": "Pooling supplies cells but not three independent library replicates.",
            "source_url": PAPER_URL,
            "source_file": PAPER_XML_PATH.relative_to(ROOT).as_posix(),
            "source_sha256": sha256(PAPER_XML_PATH),
            "accessed_local_date": DATE,
        },
        {
            "evidence_id": "GSE270712_PAPER_SB_CONTEXT",
            "source_type": "primary_article",
            "source_locator": inhibitor_title or "Results / TGF-beta inhibition",
            "evidence_summary": "The paper reports an in-vivo TGF-beta receptor-inhibitor experiment during stress and SA infection.",
            "supports": "SB-related biological context exists in the primary paper.",
            "limits": "The searchable article text does not map each conflicting GSM to a unique condition.",
            "source_url": PAPER_URL,
            "source_file": PAPER_XML_PATH.relative_to(ROOT).as_posix(),
            "source_sha256": sha256(PAPER_XML_PATH),
            "accessed_local_date": DATE,
        },
    ]

    write_tsv(ROOT / "audits" / "gse270712_label_audit.tsv", audit_rows)
    write_tsv(ROOT / "audits" / "gse270712_paper_evidence.tsv", evidence_rows)
    print("PASS: wrote 6 label rows and 3 primary-source evidence rows")


if __name__ == "__main__":
    main()
