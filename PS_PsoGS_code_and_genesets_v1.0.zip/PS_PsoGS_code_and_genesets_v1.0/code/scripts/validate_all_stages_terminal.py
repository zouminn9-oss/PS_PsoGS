from pathlib import Path
import csv,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import pandas as pd

checks=[]
def ck(name,passed,detail): checks.append({"check":name,"pass":bool(passed),"detail":str(detail)})

panels=pd.read_csv(ROOT/"panel_manifest.tsv",sep="\t",dtype=str).fillna("")
ready=panels[panels.figure_ready=="YES"]; nonready=panels[panels.figure_ready!="YES"]
ck("master_prompt_present",(ROOT/"PS_PsoGS_Codex_Project_Master_Prompt.md").stat().st_size>0,"present")
ck("eight_main_figures",panels.figure_id.nunique()==8,panels.figure_id.nunique())
ck("ninety_planned_panels",len(panels)==90,len(panels))
ck("sixty_six_rendered_panels",len(ready)==66,len(ready))
ck("twenty_four_terminal_nonrendered",len(nonready)==24,len(nonready))
ck("all_ready_status_pass",ready.status.eq("PASS").all(),ready.status.value_counts().to_dict())
ck("all_ready_qa_pass",ready.qa_status.eq("PASS_RENDER_DATA_PRINT").all(),ready.qa_status.value_counts().to_dict())
ck("all_nonready_formally_blocked",nonready.status.str.startswith("BLOCKED").all(),nonready.status.value_counts().to_dict())

artifact_cols=["analysis_script","plot_script","source_data","statistics_file","config_file","vector_output","preview_output"]
missing=[]
for _,r in ready.iterrows():
 for col in artifact_cols:
  p=ROOT/r[col]
  if not p.is_file() or p.stat().st_size==0: missing.append(f"{r.panel_id}:{col}:{r[col]}")
 cap=ROOT/"figures/captions"/f"fig{r.panel_id.lower()}.md"
 if not cap.is_file() or cap.stat().st_size==0: missing.append(f"{r.panel_id}:caption")
ck("ready_artifacts_complete",not missing,missing[:10])

reports=["STAGE00_SUMMARY_ZH.md","STAGE01_SUMMARY_ZH.md","STAGE02_F1_SUMMARY_ZH.md","STAGE03_BULK_VALIDATION_ZH.md","STAGE04_SINGLE_CELL_F2_ZH.md","STAGE05_MECHANISMS_ZH.md","STAGE06_SPATIAL_ZH.md","STAGE07_TREATMENT_PREDICTION_ZH.md","STAGE08_DRUG_REPURPOSING_ZH.md","ALL_STAGES_COMPLETION_ZH.md"]
ck("stage_reports_complete",all((ROOT/"reports"/x).is_file() for x in reports),[x for x in reports if not (ROOT/"reports"/x).is_file()])
ck("freeze_F1_present",(ROOT/"metadata/signature_f1_manifest.tsv").is_file(),"F1")
ck("freeze_F2_present",(ROOT/"metadata/TARGET_FREEZE_STAGE04_F2.tsv").is_file(),"F2")
ck("freeze_F3_present",(ROOT/"metadata/F3_STAGE08_QUERY_FREEZE.tsv").is_file(),"F3")

qc=pd.read_csv(ROOT/"results/stage07/gse228421/library_qc.tsv",sep="\t")
cells=pd.read_csv(ROOT/"data/processed/stage07/gse228421/all_cell_metadata.tsv.gz",sep="\t",usecols=["cell_id","patient_id"])
ck("gse228421_twenty_libraries",len(qc)==20,len(qc)); ck("gse228421_five_patients",qc.patient_id.nunique()==5,qc.patient_id.nunique()); ck("gse228421_223828_cells",len(cells)==223828,len(cells))

g117=pd.read_csv(ROOT/"results/stage07/prediction_outer_predictions.tsv.gz",sep="\t")
ck("gse117468_prediction_74_patients",g117.patient_id.nunique()==74,g117.patient_id.nunique()); ck("gse117468_prediction_internal_20_repeats",g117.repeat.nunique()==20,g117.repeat.nunique())
qreg=pd.read_csv(ROOT/"results/stage08/query_registry.tsv",sep="\t")
ck("stage08_queries_frozen_before_connectivity",qreg.frozen_before_connectivity.eq("YES").all(),qreg.frozen_before_connectivity.tolist())
gate=pd.read_csv(ROOT/"results/stage08/stage08_module_gate.tsv",sep="\t")
ck("stage08_final_hierarchy_blocked",gate.loc[gate.module=="final_dual_benefit_hierarchy","status"].iloc[0].startswith("BLOCKED"),gate.loc[gate.module=="final_dual_benefit_hierarchy","status"].iloc[0])

for path,col in [
 ("audits/stage00_integrity_checks.tsv","status"),
 ("audits/stage04_figure3_checks.tsv","status"),
 ("audits/stage05_figure45_checks.tsv","pass"),
 ("audits/stage06_figure6_checks.tsv","pass"),
 ("audits/stage07_bulk_figure_checks.tsv","pass"),
 ("audits/stage07_singlecell_figure_checks.tsv","pass"),
 ("audits/stage08_figure_checks.tsv","pass"),
]:
 x=pd.read_csv(ROOT/path,sep="\t")
 ok=x[col].eq("PASS").all() if col=="status" else x[col].astype(str).str.lower().eq("true").all()
 ck(f"audit_{Path(path).stem}_all_pass",ok,len(x))

out=pd.DataFrame(checks); (ROOT/"audits").mkdir(exist_ok=True); out.to_csv(ROOT/"audits/all_stages_terminal_checks.tsv",sep="\t",index=False)
summary=pd.DataFrame([
 {"metric":"planned_panels","value":90},
 {"metric":"rendered_figure_ready_panels","value":66},
 {"metric":"terminal_blocked_panels","value":24},
 {"metric":"gse228421_processed_libraries","value":20},
 {"metric":"gse228421_retained_cells","value":223828},
 {"metric":"stage08_shared_eligible_perturbagens","value":3435},
])
(ROOT/"results").mkdir(exist_ok=True); summary.to_csv(ROOT/"results/project_terminal_summary.tsv",sep="\t",index=False)
if not out["pass"].all(): raise AssertionError(out.loc[~out["pass"]].to_string(index=False))
print(f"PASS: all-stages terminal audit {len(out)}/{len(out)} checks")
