project_lib <- file.path(getwd(), "r_libs", "stage01")
dir.create(project_lib, recursive = TRUE, showWarnings = FALSE)
.libPaths(c(project_lib, .libPaths()))

options(repos = c(CRAN = "https://cloud.r-project.org"))
if (!dir.exists(file.path(project_lib, "statmod"))) {
  install.packages("statmod", lib = project_lib, quiet = TRUE)
}
if (!dir.exists(file.path(project_lib, "limma"))) {
  if (!requireNamespace("BiocManager", quietly = TRUE)) {
    install.packages("BiocManager", lib = project_lib, quiet = TRUE)
  }
  BiocManager::install("limma", lib = project_lib, ask = FALSE, update = FALSE, quiet = TRUE, force = TRUE)
}

stopifnot(requireNamespace("limma", quietly = TRUE))
versions <- data.frame(
  package = c("R", "statmod", "limma"),
  version = c(as.character(getRversion()), as.character(packageVersion("statmod")), as.character(packageVersion("limma"))),
  library = c(R.home("library"), find.package("statmod"), find.package("limma")),
  stringsAsFactors = FALSE
)
write.table(versions, file.path("audits", "stage01_R_packages.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
print(versions)
