#!/usr/bin/env python3
"""Resume one HTTP download without silently overwriting a partial file."""
from __future__ import annotations
import argparse
import urllib.request
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("url")
parser.add_argument("output")
args = parser.parse_args()
path = Path(args.output)
path.parent.mkdir(parents=True, exist_ok=True)
current = path.stat().st_size if path.exists() else 0
headers = {"Range": f"bytes={current}-"} if current else {}
request = urllib.request.Request(args.url, headers=headers)
with urllib.request.urlopen(request, timeout=120) as response:
    if current and response.status != 206:
        raise RuntimeError(f"server did not honor resume: status={response.status}, current={current}")
    expected = response.headers.get("Content-Range") or response.headers.get("Content-Length", "unknown")
    print(f"START status={response.status} current={current} response={expected}", flush=True)
    next_report = current + 10 * 1024 * 1024
    with path.open("ab") as handle:
        while True:
            block = response.read(1024 * 1024)
            if not block:
                break
            handle.write(block)
            current += len(block)
            if current >= next_report:
                print(f"PROGRESS bytes={current}", flush=True)
                next_report += 10 * 1024 * 1024
print(f"COMPLETE bytes={current}", flush=True)
