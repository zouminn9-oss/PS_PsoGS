#!/usr/bin/env python3
"""Add omitted discovery-effect inputs to F1 manifest without rebuilding signatures."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "metadata/signature_f1_manifest.tsv"
AUDIT = ROOT / "audits/stage02_orthology/f1_manifest_completion_checks.tsv"
STATS = ROOT / "results/stage02/signatures/signature_statistics.tsv"
NEW_INPUTS = [
    ("source_mouse_S0_effects", ROOT / "results/stage02/factorial_edger/gse212126_S0_all_genes.tsv", 18484),
    ("source_mouse_SD_effects", ROOT / "results/stage02/factorial_edger/gse212126_SD_all_genes.tsv", 18484),
    ("source_mouse_I_effects", ROOT / "results/stage02/factorial_edger/gse212126_I_all_genes.tsv", 18484),
    ("source_human_H_effects", ROOT / "results/stage02/gse13355/gse13355_H_paired_all_genes.tsv", 20826),
]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t",
                                lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def data_rows(path: Path) -> int:
    with path.open("rb") as handle:
        return max(sum(1 for _ in handle) - 1, 0)


def main() -> None:
    rows = read_tsv(MANIFEST)
    checks: list[dict[str, object]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        status = "PASS" if observed == expected else "FAIL"
        checks.append({"check_id": check_id, "observed": observed, "expected": expected,
                       "status": status, "note": note})
        if status == "FAIL":
            write_tsv(AUDIT, checks)
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    check("existing_manifest_rows_before_completion", len(rows), 16)
    check("existing_artifact_ids_unique", len({row["artifact_id"] for row in rows}), len(rows))
    timestamps = {row["frozen_at_utc"] for row in rows}
    versions = {row["signature_version"] for row in rows}
    check("single_original_f1_timestamp", len(timestamps), 1)
    check("single_signature_version", versions, {"v1.0"})
    for row in rows:
        path = ROOT / row["path"]
        check(f"existing_file_present::{row['artifact_id']}", path.is_file(), True)
        check(f"existing_bytes::{row['artifact_id']}", path.stat().st_size, int(row["bytes"]))
        check(f"existing_sha256::{row['artifact_id']}", sha256(path), row["sha256"])

    stats = {row["metric"]: row["value"] for row in read_tsv(STATS)}
    check("validation_expression_files_read", stats["validation_expression_files_read"], "0")
    frozen_at = next(iter(timestamps))
    new_rows: list[dict[str, object]] = []
    for artifact_id, path, expected_records in NEW_INPUTS:
        check(f"new_input_present::{artifact_id}", path.is_file(), True)
        check(f"new_input_records::{artifact_id}", data_rows(path), expected_records)
        new_rows.append({
            "artifact_id": artifact_id,
            "path": path.relative_to(ROOT).as_posix(),
            "records_or_sets": expected_records,
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
            "frozen_at_utc": frozen_at,
            "signature_version": "v1.0",
        })

    completed = new_rows + rows
    check("completed_manifest_rows", len(completed), 20)
    check("completed_artifact_ids_unique", len({row["artifact_id"] for row in completed}), 20)
    write_tsv(MANIFEST, completed)
    write_tsv(AUDIT, checks)
    print("PASS: completed F1 manifest with four discovery-effect inputs; signatures not rebuilt")


if __name__ == "__main__":
    main()
