#!/usr/bin/env python3
"""Parallel, resumable HTTP range downloader for large immutable public files."""
from __future__ import annotations
import argparse
import concurrent.futures
import hashlib
import os
import time
import urllib.request
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("url")
parser.add_argument("output")
parser.add_argument("total_bytes", type=int)
parser.add_argument("--workers", type=int, default=8)
parser.add_argument("--chunk-mb", type=int, default=32)
args = parser.parse_args()

output = Path(args.output)
output.parent.mkdir(parents=True, exist_ok=True)
parts = output.parent / f".{output.stem}.parts"
parts.mkdir(parents=True, exist_ok=True)
chunk = args.chunk_mb * 1024 * 1024
ranges = [(i, i * chunk, min(args.total_bytes - 1, (i + 1) * chunk - 1))
          for i in range((args.total_bytes + chunk - 1) // chunk)]

def fetch(item):
    index, start, end = item
    part = parts / f"part{index:03d}"
    expected = end - start + 1
    current = part.stat().st_size if part.exists() else 0
    if current > expected:
        raise RuntimeError(f"oversized part {index}: {current}>{expected}")
    while current < expected:
        request_start = start + current
        request = urllib.request.Request(args.url, headers={"Range": f"bytes={request_start}-{end}"})
        last_error = None
        for attempt in range(1, 6):
            try:
                with urllib.request.urlopen(request, timeout=180) as response:
                    if response.status != 206:
                        raise RuntimeError(f"range not honored for part {index}: {response.status}")
                    content_range = response.headers.get("Content-Range", "")
                    if not content_range.startswith(f"bytes {request_start}-"):
                        raise RuntimeError(f"unexpected Content-Range {content_range}")
                    with part.open("ab") as handle:
                        while current < expected:
                            block = response.read(min(1024 * 1024, expected - current))
                            if not block:
                                break
                            handle.write(block)
                            current += len(block)
                last_error = None
                break
            except Exception as error:
                last_error = error
                time.sleep(attempt * 2)
        if last_error is not None:
            raise last_error
    print(f"PART {index + 1}/{len(ranges)} complete bytes={current}", flush=True)
    return index, current

with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
    completed = list(executor.map(fetch, ranges))
if sum(size for _, size in completed) != args.total_bytes:
    raise RuntimeError("part byte sum does not equal expected total")

assembling = output.with_suffix(output.suffix + ".assembling")
with assembling.open("wb") as destination:
    for index, start, end in ranges:
        part = parts / f"part{index:03d}"
        with part.open("rb") as source:
            while True:
                block = source.read(4 * 1024 * 1024)
                if not block:
                    break
                destination.write(block)
if assembling.stat().st_size != args.total_bytes:
    raise RuntimeError(f"assembled size mismatch {assembling.stat().st_size}")
os.replace(assembling, output)
digest = hashlib.sha256()
with output.open("rb") as handle:
    for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
        digest.update(block)
print(f"COMPLETE bytes={output.stat().st_size} sha256={digest.hexdigest()}", flush=True)
