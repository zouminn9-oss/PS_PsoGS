#!/usr/bin/env python3
"""Build the discovery atlas and perform frozen donor-level F2 selection."""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))

import anndata as ad
import harmonypy as hm
import numpy as np
import pandas as pd
import scanpy as sc
from scipy import sparse, stats
from sklearn.decomposition import TruncatedSVD

SEED = 20260911
N_PCS = 50
MIN_CELLS = 20
MIN_PAIRS = 6
COUNTS = ROOT / "data/processed/stage04/gse173706_selected_counts.npz"
OBS = ROOT / "data/processed/stage04/gse173706_cell_metadata.tsv.gz"
GENES = ROOT / "data/processed/stage04/gse173706_selected_genes.tsv"
OUT = ROOT / "data/processed/stage04"
RES = ROOT / "results/stage04"
AUDIT = ROOT / "audits/stage04_atlas_f2_checks.tsv"

MARKERS = {
    "Keratinocyte": ["KRT14", "KRT5", "KRT1", "KRT10", "DMKN", "SFN"],
    "Fibroblast": ["DCN", "LUM", "COL1A1", "COL1A2", "COL3A1", "PDGFRA"],
    "Endothelial": ["PECAM1", "VWF", "CDH5", "CLDN5", "EMCN", "KDR"],
    "T_cell": ["CD3D", "CD3E", "TRAC", "IL7R", "CD8A", "CD247"],
    "Myeloid": ["LYZ", "TYROBP", "FCER1G", "CTSS", "HLA-DRA", "CD74"],
    "Mast": ["TPSAB1", "TPSB2", "CPA3", "MS4A2", "KIT", "CTSG"],
    "Melanocyte": ["DCT", "TYRP1", "PMEL", "MLANA", "TYR", "SOX10"],
    "Eccrine": ["DCD", "PIP", "MUCL1", "KRT19", "KRT8", "KRT18"],
    "Smooth_muscle": ["ACTA2", "TAGLN", "MYL9", "CNN1", "MYH11", "RGS5"],
    "Nerve_glial": ["MPZ", "PLP1", "S100B", "SOX10", "SLC1A3", "NGFR"],
    "B_cell": ["CD79A", "MS4A1", "CD37", "CD74", "CD22", "CD19"],
}
PROGRAMS = [
    "ucell_core_up", "ucell_core_down", "ucell_core_directed",
    "ucell_sep_up", "ucell_sep_down", "ucell_sep_directed",
    "rankmean_core_up", "rankmean_core_down", "rankmean_core_directed",
    "rankmean_sep_up", "rankmean_sep_down", "rankmean_sep_directed",
]


def write_tsv(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(path, sep="\t", index=False)


def bh(values: list[float]) -> np.ndarray:
    x = np.asarray(values, dtype=float)
    output = np.full(len(x), np.nan)
    valid = np.isfinite(x)
    p = x[valid]
    order = np.argsort(p)
    ranked = p[order] * len(p) / np.arange(1, len(p) + 1)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]
    restored = np.empty(len(p))
    restored[order] = np.minimum(ranked, 1.0)
    output[valid] = restored
    return output


def paired_effects(data: pd.DataFrame, programs: list[str]) -> pd.DataFrame:
    rows = []
    for cell_type in sorted(data["cell_type"].unique()):
        eligible_cells = data.loc[(data["cell_type"] == cell_type) & data["eligible_min_cells"]]
        for program in programs:
            pivot = eligible_cells.pivot(index="donor_id", columns="tissue", values=program)
            pairs = (pivot["PP"] - pivot["PN"]).dropna() if {"PN", "PP"}.issubset(pivot.columns) else pd.Series(dtype=float)
            n = len(pairs)
            mean = float(pairs.mean()) if n else np.nan
            sd = float(pairs.std(ddof=1)) if n > 1 else np.nan
            se = sd / math.sqrt(n) if n > 1 else np.nan
            critical = stats.t.ppf(0.975, n - 1) if n > 1 else np.nan
            t_p = float(stats.ttest_1samp(pairs, 0).pvalue) if n > 1 and sd > 0 else np.nan
            try:
                wilcoxon_p = float(stats.wilcoxon(pairs, zero_method="wilcox").pvalue) if n else np.nan
            except ValueError:
                wilcoxon_p = np.nan
            dz = mean / sd if n > 1 and sd > 0 else np.nan
            correction = 1 - 3 / (4 * n - 5) if n > 2 else np.nan
            rows.append({
                "cell_type": cell_type, "program": program, "n_complete_pairs": n,
                "mean_pp_minus_pn": mean,
                "ci95_low": mean - critical * se if n > 1 else np.nan,
                "ci95_high": mean + critical * se if n > 1 else np.nan,
                "sd_difference": sd,
                "paired_hedges_gz": dz * correction if n > 2 and np.isfinite(dz) else np.nan,
                "paired_t_p": t_p, "paired_wilcoxon_p": wilcoxon_p,
                "eligibility_min_pairs": n >= MIN_PAIRS,
            })
    result = pd.DataFrame(rows)
    result["paired_t_fdr_bh"] = np.nan
    for program in programs:
        idx = result.index[(result["program"] == program) & result["eligibility_min_pairs"]]
        result.loc[idx, "paired_t_fdr_bh"] = bh(result.loc[idx, "paired_t_p"].tolist())
    return result


def main() -> None:
    np.random.seed(SEED)
    RES.mkdir(parents=True, exist_ok=True)
    counts = sparse.load_npz(COUNTS).tocsr()
    obs = pd.read_csv(OBS, sep="\t")
    genes = pd.read_csv(GENES, sep="\t")
    if counts.shape != (len(obs), len(genes)):
        raise AssertionError("count/metadata/gene dimensions disagree")

    normalized = counts.astype(np.float32)
    totals = np.asarray(normalized.sum(axis=1)).ravel()
    normalized = sparse.diags(10000.0 / totals).dot(normalized).tocsr()
    normalized.data = np.log1p(normalized.data)
    hvg = genes["hvg_global_raw_dispersion"].astype(str).str.lower().eq("true").to_numpy()
    svd = TruncatedSVD(n_components=N_PCS, random_state=SEED)
    pca = svd.fit_transform(normalized[:, hvg]).astype(np.float32)
    print(f"PCA complete: variance={svd.explained_variance_ratio_.sum():.4f}", flush=True)
    harmony = hm.run_harmony(pca, obs, "sample_id", random_state=SEED, max_iter_harmony=20, verbose=True)
    pca_harmony = np.asarray(harmony.Z_corr).T.astype(np.float32)
    atlas = ad.AnnData(X=sparse.csr_matrix((len(obs), 1), dtype=np.float32), obs=obs[["cell_id", "sample_id", "donor_id", "tissue"]].copy())
    atlas.obs_names = obs["cell_id"].astype(str).to_numpy()
    atlas.obsm["X_pca_harmony"] = pca_harmony
    sc.pp.neighbors(atlas, n_neighbors=15, use_rep="X_pca_harmony", random_state=SEED)
    sc.tl.umap(atlas, min_dist=0.30, random_state=SEED)
    sc.tl.leiden(atlas, resolution=0.80, random_state=SEED, flavor="igraph", n_iterations=2, directed=False, key_added="leiden_08")
    obs["leiden_08"] = atlas.obs["leiden_08"].astype(str).to_numpy()
    obs["umap_1"] = atlas.obsm["X_umap"][:, 0]
    obs["umap_2"] = atlas.obsm["X_umap"][:, 1]

    symbol_to_columns: dict[str, list[int]] = {}
    for i, symbol in enumerate(genes["human_gene_symbol"].fillna("").astype(str)):
        if symbol:
            symbol_to_columns.setdefault(symbol, []).append(i)
    clusters = sorted(obs["leiden_08"].unique(), key=int)
    marker_rows = []
    for cluster in clusters:
        idx = np.flatnonzero(obs["leiden_08"].to_numpy() == cluster)
        for cell_type, marker_list in MARKERS.items():
            for marker_gene in marker_list:
                columns = symbol_to_columns.get(marker_gene, [])
                if columns:
                    values = np.asarray(normalized[idx][:, columns].sum(axis=1)).ravel()
                    mean_value = float(values.mean())
                    detected = float((values > 0).mean())
                else:
                    mean_value = np.nan
                    detected = np.nan
                marker_rows.append({
                    "cluster": cluster, "candidate_cell_type": cell_type, "marker": marker_gene,
                    "mean_log1p_cp10k": mean_value, "detection_fraction": detected,
                    "cluster_cells": len(idx), "marker_present": bool(columns),
                })
    marker = pd.DataFrame(marker_rows)
    marker["z_mean"] = marker.groupby("marker")["mean_log1p_cp10k"].transform(
        lambda x: (x - x.mean()) / x.std(ddof=0) if x.std(ddof=0) > 0 else 0)
    marker["z_detection"] = marker.groupby("marker")["detection_fraction"].transform(
        lambda x: (x - x.mean()) / x.std(ddof=0) if x.std(ddof=0) > 0 else 0)
    marker["marker_evidence"] = marker["z_mean"] + 0.5 * marker["z_detection"]
    annotation_rows = []
    for cluster in clusters:
        candidate_scores = []
        for cell_type in MARKERS:
            subset = marker.loc[(marker["cluster"] == cluster) & (marker["candidate_cell_type"] == cell_type)]
            support = int(((subset["detection_fraction"] >= 0.10) & subset["marker_present"]).sum())
            candidate_scores.append((cell_type, float(subset["marker_evidence"].mean()), support))
        candidate_scores.sort(key=lambda item: (-item[1], item[0]))
        best, second = candidate_scores[0], candidate_scores[1]
        margin = best[1] - second[1]
        label = best[0] if best[2] >= 2 and margin >= 0.15 else "Uncertain"
        idx = obs["leiden_08"] == cluster
        annotation_rows.append({
            "cluster": cluster, "cell_type": label, "best_candidate": best[0],
            "best_evidence_score": best[1], "second_candidate": second[0],
            "second_evidence_score": second[1], "best_second_margin": margin,
            "supporting_markers_ge10pct": best[2], "cells": int(idx.sum()),
            "donors": int(obs.loc[idx, "donor_id"].nunique()),
            "max_single_donor_fraction": float(obs.loc[idx, "donor_id"].value_counts(normalize=True).max()),
            "annotation_status": "PASS" if label != "Uncertain" else "UNCERTAIN",
        })
    annotation = pd.DataFrame(annotation_rows)
    obs["cell_type"] = obs["leiden_08"].map(dict(zip(annotation["cluster"], annotation["cell_type"])))

    obs.to_csv(OUT / "GSE173706_cell_metadata.tsv.gz", sep="\t", index=False, compression="gzip")
    write_tsv(RES / "annotation_markers.tsv", marker)
    write_tsv(RES / "cluster_annotations.tsv", annotation)
    np.savez_compressed(OUT / "gse173706_atlas_representations.npz", X_pca=pca, X_pca_harmony=pca_harmony, X_umap=atlas.obsm["X_umap"])
    sparse.save_npz(OUT / "gse173706_connectivities.npz", atlas.obsp["connectivities"], compressed=True)

    score_columns = [column for column in PROGRAMS if column in obs.columns]
    aggregations = {column: (column, "mean") for column in score_columns}
    donor_scores = obs.groupby(["donor_id", "sample_id", "tissue", "cell_type"], observed=True).agg(
        n_cells=("cell_id", "size"), **aggregations).reset_index()
    donor_scores["eligible_min_cells"] = donor_scores["n_cells"] >= MIN_CELLS
    write_tsv(RES / "donor_celltype_scores.tsv", donor_scores)
    effects = paired_effects(donor_scores, score_columns)
    write_tsv(RES / "paired_donor_scores.tsv", effects)

    composition = obs.groupby(["donor_id", "sample_id", "tissue", "cell_type"], observed=True).size().rename("n_cells").reset_index()
    composition["library_total_cells"] = composition.groupby("sample_id")["n_cells"].transform("sum")
    composition["cell_fraction"] = composition["n_cells"] / composition["library_total_cells"]
    write_tsv(RES / "composition_qc.tsv", composition)
    abundance_input = composition.rename(columns={"cell_fraction": "abundance_fraction"}).copy()
    abundance_input["eligible_min_cells"] = True
    abundance_effects = paired_effects(abundance_input, ["abundance_fraction"])
    write_tsv(RES / "differential_abundance.tsv", abundance_effects)

    sep = effects.loc[(effects["program"] == "ucell_sep_directed") & effects["eligibility_min_pairs"]].copy()
    sep["f2_eligible"] = (sep["mean_pp_minus_pn"] > 0) & (sep["paired_t_fdr_bh"] < 0.05) & (sep["cell_type"] != "Uncertain")
    eligible = sep.loc[sep["f2_eligible"]].copy()
    if len(eligible):
        eligible["abs_effect"] = eligible["paired_hedges_gz"].abs()
        eligible = eligible.sort_values(["abs_effect", "n_complete_pairs", "cell_type"], ascending=[False, False, True])
        selected = eligible.iloc[0]
        f2_status = "PASS"
        selected_type = selected["cell_type"]
        reason = "highest absolute paired Hedges gz among pre-specified eligible discovery major lineages"
    else:
        f2_status = "FAIL"
        selected_type = "NONE"
        reason = "no major lineage met the frozen discovery eligibility rule"
    freeze = pd.DataFrame([{
        "freeze_id": "TARGET_FREEZE_STAGE04_F2_v1.0", "status": f2_status,
        "selected_major_lineage": selected_type, "selection_reason": reason,
        "discovery_dataset": "GSE173706", "replication_dataset_unopened_for_effects": "GSE162183",
        "selection_program": "SEP_v1.0 directed UCell", "frozen_at_utc": "2026-09-11T21:25:00Z",
    }])
    write_tsv(ROOT / "metadata/TARGET_FREEZE_STAGE04_F2.tsv", freeze)

    checks = [
        ("atlas_cells", len(obs), 75209),
        ("umap_finite", bool(np.isfinite(obs[["umap_1", "umap_2"]].to_numpy()).all()), True),
        ("clusters_at_least_10", len(clusters) >= 10, True),
        ("all_clusters_have_multiple_donors", bool((annotation["donors"] >= 2).all()), True),
        ("known_labels_present", obs.loc[obs["cell_type"] != "Uncertain", "cell_type"].nunique() >= 6, True),
        ("paired_donor_max_11", int(effects["n_complete_pairs"].max()), 11),
        ("f2_terminal_status", f2_status in {"PASS", "FAIL"}, True),
    ]
    audit = pd.DataFrame([{
        "check_id": name, "observed": observed, "expected": expected,
        "status": "PASS" if observed == expected else "FAIL",
    } for name, observed, expected in checks])
    write_tsv(AUDIT, audit)
    summary = {
        "cells": len(obs), "clusters": len(clusters),
        "major_labels": sorted(obs["cell_type"].unique()),
        "uncertain_cells": int((obs["cell_type"] == "Uncertain").sum()),
        "f2_status": f2_status, "f2_selected_major_lineage": selected_type,
        "pca_variance_ratio": float(svd.explained_variance_ratio_.sum()),
    }
    with (RES / "stage04_discovery_atlas_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2)
    if (audit["status"] == "FAIL").any():
        raise AssertionError("Stage 04 atlas/F2 gate failed; see audit")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
