#!/usr/bin/env python3
"""Hash and validate the completed frozen Rsubread index."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INDEX_ROOT = ROOT / "references" / "genomes" / "GRCm38_gencode_M25" / "rsubread_index"
BASE = "GRCm38_GENCODE_M25"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(16 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    files = sorted(path for path in INDEX_ROOT.glob(f"{BASE}.*") if path.suffix != ".log")
    if len(files) < 4:
        raise AssertionError(f"expected at least four Rsubread index components, found {len(files)}")
    if any(path.stat().st_size <= 0 for path in files):
        raise AssertionError("one or more Rsubread index components are empty")
    rows = [
        {
            "file": path.relative_to(ROOT).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
            "rsubread_version": "2.20.0",
            "reference_release": "GENCODE_M25_GRCm38.p6",
            "status": "PASS",
        }
        for path in files
    ]
    out = ROOT / "audits" / "gse212126_rsubread_index_files.tsv"
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    print(f"PASS: hashed {len(rows)} non-empty Rsubread index components")


if __name__ == "__main__":
    main()
