param(
    [Parameter(Mandatory = $true)][string]$Run,
    [int]$Threads = 8
)

$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$ToolkitBin = Join-Path $ProjectRoot "tools\sratoolkit\sratoolkit.3.4.1-win64\bin"
$OfflineConfig = Join-Path $ProjectRoot "config\sra_toolkit_offline\user-settings.mkfg"
$AuditPath = Join-Path $ProjectRoot "audits\gse212126_sra_audit.tsv"
$SraFile = Join-Path $ProjectRoot "data\raw\gse212126_sra\$Run\$Run.sra"
$FastqRoot = Join-Path $ProjectRoot "data\interim\gse212126_fastq\full_$Run"
$TempRoot = Join-Path $ProjectRoot "data\interim\gse212126_fastq\temp_full_$Run"
$LogRoot = Join-Path $ProjectRoot "logs\stage02"
$LogFile = Join-Path $LogRoot "${Run}_full_conversion.log"
$Gzip = "C:\Program Files\Git\usr\bin\gzip.exe"
$MinimumFreeBytes = 250000000000L

if ($Run -notmatch '^SRR[0-9]+$') { throw "invalid run accession: $Run" }
$Meta = @(Import-Csv -LiteralPath $AuditPath -Delimiter "`t" | Where-Object { $_.srr -eq $Run })
if ($Meta.Count -ne 1) { throw "expected one SRA metadata row for $Run" }
foreach ($Path in @($OfflineConfig, $SraFile, $Gzip)) {
    if (-not (Test-Path -LiteralPath $Path)) { throw "required input missing: $Path" }
}
if ((Get-PSDrive -Name D).Free -lt $MinimumFreeBytes) { throw "free disk is below frozen 250-GB minimum" }
New-Item -ItemType Directory -Force -Path $FastqRoot, $TempRoot, $LogRoot | Out-Null
$Read1 = Join-Path $FastqRoot "${Run}_1.fastq"
$Read2 = Join-Path $FastqRoot "${Run}_2.fastq"
$Read1Gz = "$Read1.gz"
$Read2Gz = "$Read2.gz"
if ((Test-Path -LiteralPath $Read1) -or (Test-Path -LiteralPath $Read2) -or
    (Test-Path -LiteralPath $Read1Gz) -or (Test-Path -LiteralPath $Read2Gz)) {
    throw "refusing to overwrite prior full FASTQ output for $Run"
}

$ObservedMd5 = (Get-FileHash -LiteralPath $SraFile -Algorithm MD5).Hash.ToLower()
if ($ObservedMd5 -ne $Meta[0].normalized_sra_md5) { throw "official SRA MD5 mismatch for $Run" }
$env:NCBI_SETTINGS = $OfflineConfig
$Validate = Join-Path $ToolkitBin "vdb-validate.exe"
$Fasterq = Join-Path $ToolkitBin "fasterq-dump.exe"
"START`t$(Get-Date -Format o)`t$Run`tthreads=$Threads`toffline=true" | Out-File -LiteralPath $LogFile -Encoding utf8
& $Validate $SraFile 2>&1 | Tee-Object -FilePath $LogFile -Append
if ($LASTEXITCODE -ne 0) { throw "vdb-validate failed for $Run" }
& $Fasterq $SraFile --split-files --skip-technical --threads $Threads --temp $TempRoot --outdir $FastqRoot --size-check on --progress 2>&1 | Tee-Object -FilePath $LogFile -Append
if ($LASTEXITCODE -ne 0) { throw "full fasterq-dump failed for $Run" }
if (-not (Test-Path -LiteralPath $Read1) -or -not (Test-Path -LiteralPath $Read2)) {
    throw "paired full FASTQ files were not created"
}

& python (Join-Path $ProjectRoot "scripts\stage02_validate_fastq_full.py") $Run 2>&1 | Tee-Object -FilePath $LogFile -Append
if ($LASTEXITCODE -ne 0) { throw "full FASTQ audit failed for $Run" }
& $Gzip -f $Read1
if ($LASTEXITCODE -ne 0) { throw "gzip failed for mate 1" }
& $Gzip -f $Read2
if ($LASTEXITCODE -ne 0) { throw "gzip failed for mate 2" }
foreach ($Path in @($Read1Gz, $Read2Gz)) {
    & $Gzip -t $Path
    if ($LASTEXITCODE -ne 0) { throw "gzip integrity test failed: $Path" }
}
$CompressedAudit = foreach ($Path in @($Read1Gz, $Read2Gz)) {
    $Item = Get-Item -LiteralPath $Path
    [pscustomobject]@{
        srr = $Run
        file = $Item.FullName.Substring($ProjectRoot.Length + 1).Replace('\','/')
        bytes = $Item.Length
        sha256 = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLower()
        gzip_test_status = "PASS"
        source_full_fastq_audit = "audits/stage02_fastq/${Run}_full_fastq.tsv"
    }
}
$CompressedAudit | Export-Csv -LiteralPath (Join-Path $ProjectRoot "audits\stage02_fastq\${Run}_compressed_fastq.tsv") -Delimiter "`t" -NoTypeInformation -Encoding utf8
"COMPLETE`t$(Get-Date -Format o)`t$Run`tfull_fastq_audit_and_gzip_pass" | Tee-Object -FilePath $LogFile -Append
