$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$downloadDir = Join-Path $projectRoot 'data\raw\GSE13355'
$finalPath = Join-Path $downloadDir 'GSE13355_RAW.tar'
$prefixPath = Join-Path $downloadDir 'GSE13355_RAW.part000'
$assemblingPath = Join-Path $downloadDir 'GSE13355_RAW.tar.assembling'
$sourceUrl = 'https://ftp.ncbi.nlm.nih.gov/geo/series/GSE13nnn/GSE13355/suppl/GSE13355_RAW.tar'
$expectedBytes = [int64]955514880
$parallelRanges = 8

if (Test-Path -LiteralPath $finalPath) {
    $currentBytes = (Get-Item -LiteralPath $finalPath).Length
    if ($currentBytes -eq $expectedBytes) {
        Write-Output "PASS: complete archive already present ($currentBytes bytes)"
        exit 0
    }
    if ($currentBytes -le 0 -or $currentBytes -ge $expectedBytes) {
        throw "Unexpected partial archive size: $currentBytes"
    }
    if (Test-Path -LiteralPath $prefixPath) {
        throw "Both partial final archive and part000 exist; refusing ambiguous overwrite"
    }
    Move-Item -LiteralPath $finalPath -Destination $prefixPath
}

if (-not (Test-Path -LiteralPath $prefixPath)) {
    throw 'Missing verified sequential prefix part000'
}
$prefixBytes = (Get-Item -LiteralPath $prefixPath).Length
if ($prefixBytes -le 0 -or $prefixBytes -ge $expectedBytes) {
    throw "Unexpected prefix size: $prefixBytes"
}

$remaining = $expectedBytes - $prefixBytes
$chunkBytes = [int64][Math]::Ceiling($remaining / $parallelRanges)
$jobs = @()
$parts = @($prefixPath)
for ($index = 1; $index -le $parallelRanges; $index++) {
    $start = $prefixBytes + (($index - 1) * $chunkBytes)
    if ($start -ge $expectedBytes) { break }
    $end = [Math]::Min($expectedBytes - 1, $start + $chunkBytes - 1)
    $partPath = Join-Path $downloadDir ('GSE13355_RAW.part{0:D3}' -f $index)
    $expectedPartBytes = $end - $start + 1
    $parts += $partPath
    if ((Test-Path -LiteralPath $partPath) -and
        ((Get-Item -LiteralPath $partPath).Length -eq $expectedPartBytes)) {
        Write-Output "SKIP complete part $index ($start-$end)"
        continue
    }
    $stdout = Join-Path $downloadDir ('GSE13355_RAW.part{0:D3}.stdout.log' -f $index)
    $stderr = Join-Path $downloadDir ('GSE13355_RAW.part{0:D3}.stderr.log' -f $index)
    $arguments = @('-L', '--fail', '--retry', '10', '--retry-delay', '5',
                   '--range', "$start-$end", '-o', $partPath, $sourceUrl)
    $process = Start-Process -FilePath 'curl.exe' -ArgumentList $arguments -WindowStyle Hidden `
        -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru
    $jobs += [pscustomobject]@{ Index = $index; Start = $start; End = $end;
        Expected = $expectedPartBytes; Path = $partPath; Process = $process }
    Write-Output "START part $index ($start-$end)"
}

foreach ($job in $jobs) {
    $job.Process.WaitForExit()
    $observed = (Get-Item -LiteralPath $job.Path).Length
    if ($observed -ne $job.Expected) {
        throw "Part $($job.Index) length mismatch: $observed vs $($job.Expected); exit code $($job.Process.ExitCode)"
    }
    $exitCode = $job.Process.ExitCode
    if ($null -ne $exitCode -and $exitCode -ne 0) {
        throw "curl failed for part $($job.Index) with exit code $exitCode"
    }
    Write-Output "PASS part $($job.Index): $observed bytes"
}

if (Test-Path -LiteralPath $assemblingPath) {
    Remove-Item -LiteralPath $assemblingPath
}
$output = [System.IO.File]::Open($assemblingPath, [System.IO.FileMode]::CreateNew,
                                [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
try {
    foreach ($part in $parts) {
        $input = [System.IO.File]::OpenRead($part)
        try { $input.CopyTo($output) } finally { $input.Dispose() }
    }
} finally {
    $output.Dispose()
}

$assembledBytes = (Get-Item -LiteralPath $assemblingPath).Length
if ($assembledBytes -ne $expectedBytes) {
    throw "Assembled length mismatch: $assembledBytes vs $expectedBytes"
}
Move-Item -LiteralPath $assemblingPath -Destination $finalPath
$sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $finalPath).Hash.ToLowerInvariant()
Write-Output "PASS archive: $assembledBytes bytes; sha256=$sha256"
