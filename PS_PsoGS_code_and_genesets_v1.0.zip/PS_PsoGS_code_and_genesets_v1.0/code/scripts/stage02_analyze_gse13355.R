options(stringsAsFactors = FALSE)
.libPaths(c(file.path("r_libs", "stage02_human"), .Library))
dir.create("logs", recursive = TRUE, showWarnings = FALSE)
log_connection <- file(file.path("logs", "stage02_gse13355_analysis.log"), open = "wt")
sink(log_connection, type = "output", split = TRUE)
sink(log_connection, type = "message")
on.exit({
  sink(type = "message")
  sink(type = "output")
  close(log_connection)
}, add = TRUE)
suppressPackageStartupMessages({
  library(affy)
  library(limma)
  library(AnnotationDbi)
  library(hgu133plus2.db)
  library(org.Hs.eg.db)
})
set.seed(13355)

out_dir <- file.path("results", "stage02", "gse13355")
audit_dir <- file.path("audits", "stage02_gse13355")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(audit_dir, recursive = TRUE, showWarnings = FALSE)

pairs <- read.delim(file.path("metadata", "gse13355_pp_pn_pair_registry.tsv"),
                    check.names = FALSE)
samples <- read.delim(file.path("metadata", "sample_manifest.tsv"), check.names = FALSE)
samples <- samples[samples$dataset_id == "GSE13355", ]
cel_files <- sort(list.files(file.path("data", "raw", "GSE13355", "CEL"),
                             pattern = "^GSM[0-9]+\\.CEL\\.gz$", full.names = TRUE))
gsm <- sub("\\.CEL\\.gz$", "", basename(cel_files))
stopifnot(nrow(pairs) == 58L, nrow(samples) == 180L, length(cel_files) == 180L,
          !anyDuplicated(gsm), setequal(gsm, samples$sample_id),
          all(pairs$primary_contrast == "PP-PN"),
          all(pairs$statistical_unit == "paired_patient"))

sample_meta <- samples[match(gsm, samples$sample_id),
                       c("sample_id", "donor_or_animal_id", "condition", "sample_title")]
stopifnot(!anyNA(sample_meta$sample_id), identical(sample_meta$sample_id, gsm))

message("Reading 180 audited compressed CEL files")
raw <- ReadAffy(filenames = cel_files)
sampleNames(raw) <- gsm
stopifnot(ncol(exprs(raw)) == 180L, annotation(raw) == "hgu133plus2")

message("Calculating outcome-independent raw intensity QC")
pm_values <- pm(raw)
raw_log2_pm_median <- raw_log2_pm_iqr <- numeric(ncol(pm_values))
for (index in seq_len(ncol(pm_values))) {
  values <- log2(pm_values[, index])
  raw_log2_pm_median[index] <- median(values)
  raw_log2_pm_iqr[index] <- IQR(values)
}
rm(pm_values); invisible(gc())

message("Running frozen all-180-array RMA")
normalized <- rma(raw, verbose = FALSE)
probe_expression <- exprs(normalized)
stopifnot(nrow(probe_expression) == 54675L, ncol(probe_expression) == 180L,
          identical(colnames(probe_expression), gsm), all(is.finite(probe_expression)))
saveRDS(probe_expression, file.path(out_dir, "gse13355_rma_probe_expression.rds"),
        compress = "xz")

message("Calculating normalized RLE and PCA diagnostics")
probe_centers <- apply(probe_expression, 1L, median)
rle <- sweep(probe_expression, 1L, probe_centers, "-")
rle_median <- apply(rle, 2L, median)
rle_iqr <- apply(rle, 2L, IQR)
rm(rle, probe_centers); invisible(gc())
probe_iqr <- apply(probe_expression, 1L, IQR)
top_variable <- order(probe_iqr, decreasing = TRUE)[seq_len(5000L)]
pca <- prcomp(t(probe_expression[top_variable, , drop = FALSE]), center = TRUE, scale. = FALSE)
pca_variance <- pca$sdev^2 / sum(pca$sdev^2)
pca_distance5 <- sqrt(rowSums(scale(pca$x[, seq_len(5L), drop = FALSE])^2))

robust_z <- function(values) {
  denominator <- mad(values, center = median(values), constant = 1.4826)
  if (!is.finite(denominator) || denominator == 0) return(rep(0, length(values)))
  (values - median(values)) / denominator
}
diagnostic_matrix <- cbind(
  raw_log2_pm_median_z = robust_z(raw_log2_pm_median),
  raw_log2_pm_iqr_z = robust_z(raw_log2_pm_iqr),
  rle_median_z = robust_z(rle_median), rle_iqr_z = robust_z(rle_iqr),
  pca_distance5_z = robust_z(pca_distance5))
soft_qc_flag <- apply(abs(diagnostic_matrix) > 4, 1L, any)
qc <- data.frame(
  gsm = gsm, patient_id = sample_meta$donor_or_animal_id,
  condition = sample_meta$condition, sample_title = sample_meta$sample_title,
  raw_log2_pm_median = raw_log2_pm_median, raw_log2_pm_iqr = raw_log2_pm_iqr,
  rle_median = rle_median, rle_iqr = rle_iqr,
  PC1 = pca$x[, 1L], PC2 = pca$x[, 2L], PC3 = pca$x[, 3L],
  pca_distance5 = pca_distance5, diagnostic_matrix,
  soft_qc_flag = soft_qc_flag,
  primary_exclusion = FALSE,
  exclusion_rule = "unreadable_or_corrupt_CEL_only",
  stringsAsFactors = FALSE)
write.table(qc, file.path(out_dir, "gse13355_array_qc.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
write.table(data.frame(PC = seq_along(pca_variance), variance_explained = pca_variance),
            file.path(out_dir, "gse13355_PCA_variance.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)

message("Applying frozen unique-Entrez probe mapping")
probe_ids <- rownames(probe_expression)
annotation_rows <- AnnotationDbi::select(hgu133plus2.db, keys = probe_ids,
                                         columns = c("ENTREZID", "SYMBOL"),
                                         keytype = "PROBEID")
annotation_rows <- unique(annotation_rows)
annotation_split <- split(annotation_rows, annotation_rows$PROBEID)
probe_entrez <- probe_symbol <- rep(NA_character_, length(probe_ids))
mapping_status <- rep("FAIL_NO_UNIQUE_ENTREZ", length(probe_ids))
names(probe_entrez) <- names(probe_symbol) <- names(mapping_status) <- probe_ids
mapping_ledger <- vector("list", length(probe_ids))
for (index in seq_along(probe_ids)) {
  probe <- probe_ids[index]
  rows <- annotation_split[[probe]]
  entrez <- if (is.null(rows)) character() else unique(rows$ENTREZID[!is.na(rows$ENTREZID) & rows$ENTREZID != ""])
  symbols <- if (is.null(rows)) character() else unique(rows$SYMBOL[!is.na(rows$SYMBOL) & rows$SYMBOL != ""])
  if (length(entrez) == 1L) {
    probe_entrez[index] <- entrez
    probe_symbol[index] <- if (length(symbols) == 1L) symbols else NA_character_
    mapping_status[index] <- "PASS_UNIQUE_ENTREZ"
  } else if (length(entrez) > 1L) {
    mapping_status[index] <- "HOLD_MULTI_ENTREZ"
  }
  mapping_ledger[[index]] <- data.frame(
    probe_id = probe, entrez_ids = paste(sort(entrez), collapse = ";"),
    symbols = paste(sort(symbols), collapse = ";"), entrez_count = length(entrez),
    symbol_count = length(symbols), mapping_status = mapping_status[index],
    stringsAsFactors = FALSE)
}
mapping_ledger <- do.call(rbind, mapping_ledger)
write.table(mapping_ledger, file.path(out_dir, "gse13355_probe_mapping_ledger.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

keep_probe <- mapping_status == "PASS_UNIQUE_ENTREZ"
summed <- rowsum(probe_expression[keep_probe, , drop = FALSE],
                 group = probe_entrez[keep_probe], reorder = TRUE)
probe_count <- table(probe_entrez[keep_probe])
gene_expression <- summed / as.numeric(probe_count[rownames(summed)])
rm(summed); invisible(gc())
unique_symbol <- function(values) {
  values <- unique(values[!is.na(values) & values != ""])
  if (length(values) == 1L) values else NA_character_
}
gene_symbol <- AnnotationDbi::mapIds(org.Hs.eg.db, keys = rownames(gene_expression),
                                     column = "SYMBOL", keytype = "ENTREZID",
                                     multiVals = unique_symbol)
symbol_present <- !is.na(gene_symbol) & gene_symbol != ""
duplicated_symbols <- names(which(table(gene_symbol[symbol_present]) > 1L))
gene_keep <- symbol_present & !(gene_symbol %in% duplicated_symbols)
gene_expression <- gene_expression[gene_keep, , drop = FALSE]
gene_symbol <- gene_symbol[rownames(gene_expression)]
stopifnot(!anyDuplicated(rownames(gene_expression)), !anyDuplicated(gene_symbol),
          all(is.finite(gene_expression)))
saveRDS(gene_expression, file.path(out_dir, "gse13355_rma_gene_expression.rds"),
        compress = "xz")
gene_table <- data.frame(entrez_id = rownames(gene_expression), gene_symbol = unname(gene_symbol),
                         gene_expression, check.names = FALSE)
connection <- gzfile(file.path(out_dir, "gse13355_rma_gene_expression.tsv.gz"), "wt")
write.table(gene_table, connection, sep = "\t", quote = FALSE, row.names = FALSE)
close(connection)

message("Fitting frozen paired PP-PN patient-fixed-effect model")
paired_gsm <- as.vector(rbind(pairs$pn_gsm, pairs$pp_gsm))
paired_patient <- factor(rep(pairs$patient_id, each = 2L))
paired_condition <- factor(rep(c("PN", "PP"), nrow(pairs)), levels = c("PN", "PP"))
stopifnot(length(paired_gsm) == 116L, !anyDuplicated(paired_gsm),
          all(paired_gsm %in% colnames(gene_expression)))
paired_expression <- gene_expression[, paired_gsm, drop = FALSE]
design <- model.matrix(~ paired_patient + paired_condition)
stopifnot(qr(design)$rank == ncol(design), nrow(design) == 116L,
          ncol(design) == 59L)
fit <- lmFit(paired_expression, design)
fit <- eBayes(fit, trend = TRUE, robust = TRUE)
coefficient <- which(colnames(design) == "paired_conditionPP")
stopifnot(length(coefficient) == 1L)
result <- topTable(fit, coef = coefficient, number = Inf, sort.by = "none",
                   adjust.method = "BH")
stopifnot(identical(rownames(result), rownames(gene_expression)))
result_out <- data.frame(
  entrez_id = rownames(result), gene_symbol = unname(gene_symbol[rownames(result)]),
  estimand = "H_PP_minus_PN", logFC = result$logFC, AveExpr = result$AveExpr,
  t = result$t, PValue = result$P.Value, FDR = result$adj.P.Val, B = result$B,
  significant_FDR_0_05 = result$adj.P.Val < 0.05,
  direction = ifelse(result$logFC > 0, "UP", ifelse(result$logFC < 0, "DOWN", "ZERO")),
  statistical_unit = "paired_patient", n_pairs = 58L,
  stringsAsFactors = FALSE)
write.table(result_out, file.path(out_dir, "gse13355_H_paired_all_genes.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

design_out <- data.frame(
  sample_order = seq_along(paired_gsm), gsm = paired_gsm,
  patient_id = as.character(paired_patient), condition = as.character(paired_condition),
  design_rank = qr(design)$rank, design_columns = ncol(design),
  included_primary = TRUE, stringsAsFactors = FALSE)
write.table(design_out, file.path(out_dir, "gse13355_paired_design.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

statistics <- data.frame(
  metric = c("raw_arrays", "NN_arrays_qc_only", "paired_patients", "paired_arrays",
             "GPL570_probe_sets", "unique_entrez_mapped_probes", "modeled_unique_genes",
             "design_rank", "design_columns", "residual_df", "soft_qc_flags_report_only",
             "primary_sample_exclusions", "H_FDR_lt_0.05", "H_up_FDR_lt_0.05",
             "H_down_FDR_lt_0.05", "validation_expression_accessed"),
  value = c(180, 64, 58, 116, nrow(probe_expression), sum(keep_probe), nrow(gene_expression),
            qr(design)$rank, ncol(design), fit$df.residual[1], sum(soft_qc_flag), 0,
            sum(result_out$significant_FDR_0_05),
            sum(result_out$significant_FDR_0_05 & result_out$direction == "UP"),
            sum(result_out$significant_FDR_0_05 & result_out$direction == "DOWN"), 0),
  status = c(rep("PASS", 15), "PASS_LOCKED"), stringsAsFactors = FALSE)
write.table(statistics, file.path(out_dir, "gse13355_analysis_statistics.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
writeLines(capture.output(sessionInfo()), file.path(out_dir, "gse13355_sessionInfo.txt"))
cat(sprintf("PASS: GSE13355 all-array RMA and paired H model; %d unique genes; %d FDR<0.05\n",
            nrow(result_out), sum(result_out$significant_FDR_0_05)))
