options(stringsAsFactors = FALSE)
.libPaths(c(file.path("r_libs", "stage02_human"), .Library))
packages <- c("affy", "affyio", "BiocGenerics", "Biobase", "preprocessCore",
              "hgu133plus2cdf", "limma", "AnnotationDbi", "org.Hs.eg.db",
              "hgu133plus2.db", "statmod")
stopifnot(all(vapply(packages, requireNamespace, logical(1L), quietly = TRUE)))
manifest <- data.frame(
  component = c("R", packages),
  version = c(paste(R.version$major, R.version$minor, sep = "."),
              vapply(packages, function(package) as.character(packageVersion(package)), character(1L))),
  library_path = c(R.home(), vapply(packages, find.package, character(1L))),
  role = c("analysis runtime", "CEL reading and RMA", "CEL binary IO",
           "Bioconductor generics", "expression container", "RMA normalization core",
           "GPL570 CDF", "paired linear model and empirical Bayes",
           "probe annotation interface", "current human Entrez-symbol mapping",
           "GPL570 probe annotation", "robust empirical Bayes support"),
  freeze_date = "2026-09-11", stringsAsFactors = FALSE)
dir.create("metadata", recursive = TRUE, showWarnings = FALSE)
write.table(manifest, file.path("metadata", "stage02_gse13355_software_manifest.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: recorded %d GSE13355 software components\n", nrow(manifest)))
