#!/usr/bin/env python3
"""Independent integrity checks for the frozen GSE212126 edgeR outputs."""

from __future__ import annotations

import csv
import math
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESULT_DIR = ROOT / "results" / "stage02" / "factorial_edger"
COUNT_DIR = ROOT / "results" / "stage02" / "counts"
AUDIT_PATH = ROOT / "audits" / "stage02_counts" / "gse212126_edger_integrity_checks.tsv"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def bh_adjust_stable(p_values: list[float]) -> list[float]:
    """BH adjustment without relying on result-table ordering."""
    n = len(p_values)
    ascending = sorted(range(n), key=p_values.__getitem__)
    adjusted = [0.0] * n
    running = 1.0
    for rank_zero_based in range(n - 1, -1, -1):
        index = ascending[rank_zero_based]
        rank = rank_zero_based + 1
        running = min(running, p_values[index] * n / rank)
        adjusted[index] = min(1.0, running)
    return adjusted


def main() -> None:
    checks: list[tuple[str, str, str]] = []

    def record(check: str, passed: bool, detail: str) -> None:
        checks.append((check, "PASS" if passed else "FAIL", detail))

    columns = read_tsv(COUNT_DIR / "gse212126_count_column_registry.tsv")
    counts = read_tsv(COUNT_DIR / "gse212126_gene_counts_frozen.tsv")
    design = read_tsv(ROOT / "results" / "stage02" / "gse212126_design_matrix.tsv")
    contrasts = read_tsv(ROOT / "results" / "stage02" / "gse212126_contrast_matrix.tsv")
    registry = read_tsv(RESULT_DIR / "gse212126_estimand_result_registry.tsv")
    filter_audit = read_tsv(RESULT_DIR / "gse212126_filterByExpr_audit.tsv")
    library_qc = read_tsv(RESULT_DIR / "gse212126_library_QC.tsv")
    pca = read_tsv(RESULT_DIR / "gse212126_PCA_coordinates.tsv")

    samples = [row["srr"] for row in columns]
    raw_design_order = [row["srr"] for row in design]
    reordered_design = sorted(design, key=lambda row: samples.index(row["srr"]))
    record("design_sample_set_matches_counts",
           len(raw_design_order) == 12 and set(raw_design_order) == set(samples),
           "raw design is grouped Control/IMQ/CRS/CRS+IMQ; model reorders by SRR")
    record("design_reorders_exactly_to_count_columns",
           [row["srr"] for row in reordered_design] == samples,
           f"reordered_samples={len(reordered_design)}")
    expected_design = {
        "Control": (0, 0, 0),
        "CRS": (1, 0, 0),
        "IMQ": (0, 1, 0),
        "CRS+IMQ": (1, 1, 1),
    }
    design_ok = all(
        tuple(int(row[key]) for key in ("CRS", "IMQ", "CRS_by_IMQ"))
        == expected_design[next(col["condition"] for col in columns if col["srr"] == row["srr"])]
        and int(row["Intercept"]) == 1
        for row in design
    )
    record("design_encodes_frozen_2x2_factorial", design_ok,
           "Control=000; CRS=100; IMQ=010; CRS+IMQ=111")
    contrast_map = {
        row["coefficient"]: tuple(int(row[key]) for key in ("S0", "SD", "I"))
        for row in contrasts
    }
    expected_contrasts = {
        "Intercept": (0, 0, 0), "CRS": (1, 1, 0),
        "IMQ": (0, 0, 0), "CRS_by_IMQ": (0, 1, 1),
    }
    record("contrasts_match_predefined_estimands", contrast_map == expected_contrasts,
           "S0=CRS; SD=CRS+CRS:IMQ; I=CRS:IMQ")

    pass_count = sum(row["passed_filterByExpr"] == "TRUE" for row in filter_audit)
    record("filter_audit_covers_all_frozen_genes", len(filter_audit) == len(counts) == 55487,
           f"audit_rows={len(filter_audit)}; count_rows={len(counts)}")
    record("frozen_filter_retains_18484_genes", pass_count == 18484,
           f"passed={pass_count}; failed={len(filter_audit) - pass_count}")
    record("filter_did_not_use_validation_data",
           all(row["filter_used_validation_data"] == "FALSE" for row in filter_audit),
           "all genes explicitly FALSE")

    count_totals = {sample: sum(int(row[sample]) for row in counts) for sample in samples}
    qc_by_sample = {row["srr"]: row for row in library_qc}
    record("library_QC_has_all_12_mice_once",
           len(library_qc) == 12 and set(qc_by_sample) == set(samples),
           f"rows={len(library_qc)}; unique_srr={len(qc_by_sample)}")
    record("library_QC_raw_sizes_match_frozen_counts",
           all(int(qc_by_sample[sample]["raw_library_size"]) == count_totals[sample] for sample in samples),
           f"raw_size_range={min(count_totals.values())}-{max(count_totals.values())}")
    record("statistical_unit_is_independent_mouse",
           all(row["statistical_unit"] == "independent_mouse" for row in library_qc),
           "12/12 rows")
    norm_factors = [float(row["TMM_norm_factor"]) for row in library_qc]
    record("TMM_factors_are_finite_positive", all(math.isfinite(x) and x > 0 for x in norm_factors),
           f"range={min(norm_factors):.4f}-{max(norm_factors):.4f}")

    result_tables: dict[str, list[dict[str, str]]] = {}
    for estimand in ("S0", "SD", "I"):
        table = read_tsv(RESULT_DIR / f"gse212126_{estimand}_all_genes.tsv")
        result_tables[estimand] = table
        gene_ids = [row["gene_id"] for row in table]
        p_values = [float(row["PValue"]) for row in table]
        fdr_values = [float(row["FDR"]) for row in table]
        recalculated = bh_adjust_stable(p_values)
        max_fdr_delta = max(abs(a - b) for a, b in zip(fdr_values, recalculated))
        numeric_ok = all(
            math.isfinite(float(row[key]))
            for row in table for key in ("logFC", "logCPM", "F", "PValue", "FDR")
        )
        ranges_ok = all(0 <= p <= 1 and 0 <= q <= 1 for p, q in zip(p_values, fdr_values))
        flags_ok = all(
            (row["significant_FDR_0_05"] == "TRUE") == (float(row["FDR"]) < 0.05)
            and row["direction"] == ("UP" if float(row["logFC"]) > 0 else
                                      "DOWN" if float(row["logFC"]) < 0 else "ZERO")
            for row in table
        )
        record(f"{estimand}_has_18484_unique_tested_genes",
               len(table) == 18484 and len(set(gene_ids)) == 18484,
               f"rows={len(table)}; unique={len(set(gene_ids))}")
        record(f"{estimand}_statistics_are_finite_and_bounded", numeric_ok and ranges_ok,
               "finite logFC/logCPM/F/P/FDR; P and FDR in [0,1]")
        record(f"{estimand}_BH_FDR_recalculates", max_fdr_delta < 1e-12,
               f"maximum_absolute_delta={max_fdr_delta:.3e}")
        record(f"{estimand}_flags_match_frozen_thresholds", flags_ok,
               "FDR<0.05 and logFC direction recomputed row-by-row")

    common_order = all(
        [row["gene_id"] for row in result_tables[key]]
        == [row["gene_id"] for row in result_tables["S0"]]
        for key in ("SD", "I")
    )
    record("estimand_gene_order_is_identical", common_order, "S0, SD and I compared")
    max_identity_delta = max(
        abs(float(sd["logFC"]) - float(s0["logFC"]) - float(interaction["logFC"]))
        for s0, sd, interaction in zip(
            result_tables["S0"], result_tables["SD"], result_tables["I"], strict=True
        )
    )
    record("factorial_logFC_identity_SD_equals_S0_plus_I", max_identity_delta < 1e-10,
           f"maximum_absolute_delta={max_identity_delta:.3e}")

    result_registry = {row["estimand"]: row for row in registry}
    registry_ok = True
    for estimand, table in result_tables.items():
        row = result_registry[estimand]
        registry_ok &= int(row["tested_genes"]) == len(table)
        registry_ok &= int(row["FDR_lt_0_05"]) == sum(float(x["FDR"]) < 0.05 for x in table)
        registry_ok &= int(row["FDR_lt_0_05_up"]) == sum(
            float(x["FDR"]) < 0.05 and float(x["logFC"]) > 0 for x in table
        )
        registry_ok &= int(row["FDR_lt_0_05_down"]) == sum(
            float(x["FDR"]) < 0.05 and float(x["logFC"]) < 0 for x in table
        )
        registry_ok &= row["threshold_changed_after_results"] == "FALSE"
        registry_ok &= row["validation_expression_accessed"] == "FALSE"
    record("estimand_registry_recalculates_exactly", registry_ok,
           "tested/significant/up/down counts and leakage flags checked")

    pca_samples = [row["srr"] for row in pca]
    pca_ok = pca_samples == samples and all(
        math.isfinite(float(row[key])) for row in pca for key in ("PC1", "PC2")
    )
    pca_group_counts = Counter(row["condition"] for row in pca)
    record("PCA_has_12_finite_mouse_coordinates", pca_ok and set(pca_group_counts.values()) == {3},
           f"rows={len(pca)}; groups={dict(pca_group_counts)}")

    AUDIT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with AUDIT_PATH.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(["check", "status", "detail"])
        writer.writerows(checks)

    failed = [check for check, status, _ in checks if status != "PASS"]
    if failed:
        raise SystemExit("FAIL: " + ", ".join(failed))
    print(f"PASS: {len(checks)} independent edgeR integrity checks")


if __name__ == "__main__":
    main()
