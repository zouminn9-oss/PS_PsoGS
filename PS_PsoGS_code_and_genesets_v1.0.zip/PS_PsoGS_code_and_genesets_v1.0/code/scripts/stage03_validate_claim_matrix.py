#!/usr/bin/env python3
"""Evidence and claim-ceiling audit for the Stage 03 claim matrix."""
from __future__ import annotations
import csv
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "audits/stage03_claim_matrix_checks.tsv"

def read(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as h: return list(csv.DictReader(h, delimiter="\t"))

def main():
    checks = []
    def check(name, obs, exp):
        ok = obs == exp; checks.append({"check_id": name, "observed": str(obs), "expected": str(exp), "status": "PASS" if ok else "FAIL"})
        if not ok: raise AssertionError(f"{name}: {obs!r} != {exp!r}")
    claims = read(ROOT / "results/stage03/claim_matrix.tsv")
    summary = read(ROOT / "results/stage03/claim_matrix_summary.tsv")
    check("claim_rows", len(claims), 11)
    check("claim_ids", [r["claim_id"] for r in claims], [f"C{i}" for i in range(1, 12)])
    check("synthesis_counts", Counter(r["synthesis_status"] for r in claims),
          Counter({"PASS": 3, "PASS_WITH_LIMITATION": 4, "FAIL": 1, "BLOCKED": 2, "NOT_TESTED": 1}))
    smap = {r["claim_id"]: r for r in claims}
    check("exclusivity_fails", (smap["C5"]["GSE121212_status"], smap["C5"]["synthesis_status"]), ("FAIL", "FAIL"))
    check("comparator_blocked", (smap["C10"]["GSE30999_status"], smap["C10"]["GSE121212_status"], smap["C10"]["synthesis_status"]), ("BLOCKED", "BLOCKED", "BLOCKED"))
    check("causality_not_tested", set((smap["C11"]["GSE30999_status"], smap["C11"]["GSE121212_status"], smap["C11"]["synthesis_status"])), {"NOT_TESTED"})
    check("ad_single_cohort_ceiling", (smap["C4"]["GSE30999_status"], smap["C4"]["GSE121212_status"], smap["C4"]["synthesis_status"]),
          ("NOT_APPLICABLE", "PASS", "PASS_WITH_LIMITATION"))
    check("random_pass", smap["C6"]["synthesis_status"], "PASS")
    check("influence_pass", smap["C9"]["synthesis_status"], "PASS")
    check("summary_rows", len(summary), 6)
    check("no_blank_boundaries", all(r["allowed_claim"] and r["prohibited_overreach"] for r in claims), True)
    check("no_causal_allowed_claim", all("caus" not in r["allowed_claim"].lower() for r in claims), True)
    with OUT.open("w", encoding="utf-8", newline="") as h:
        w = csv.DictWriter(h, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n"); w.writeheader(); w.writerows(checks)
    print(f"PASS: {len(checks)} Stage 03 claim-ceiling checks")

if __name__ == "__main__": main()
