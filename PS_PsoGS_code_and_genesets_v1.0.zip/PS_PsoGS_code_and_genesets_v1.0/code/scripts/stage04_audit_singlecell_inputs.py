#!/usr/bin/env python3
"""Audit Stage 04 single-cell matrix structure before expression analysis."""
from __future__ import annotations
import csv
import gzip
import hashlib
import re
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DISCOVERY_DIR = ROOT / "data/raw/single_cell/GSE173706/csv_gz"
REPLICATION = ROOT / "data/raw/single_cell/GSE162183/GSE162183_Raw_gene_counts_matrix.tab.gz"
DONORS = ROOT / "metadata/gse173706_donor_registry.tsv"
OUT_MANIFEST = ROOT / "metadata/stage04_singlecell_input_manifest.tsv"
OUT_REP_DONORS = ROOT / "metadata/gse162183_donor_registry.tsv"
OUT_AUDIT = ROOT / "audits/stage04_singlecell_input_gate_checks.tsv"

def read_tsv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as h: return list(csv.DictReader(h, delimiter="\t"))

def write_tsv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as h:
        w = csv.DictWriter(h, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n"); w.writeheader(); w.writerows(rows)

def sha256(path):
    d = hashlib.sha256()
    with path.open("rb") as h:
        for block in iter(lambda: h.read(4 * 1024 * 1024), b""): d.update(block)
    return d.hexdigest()

def main():
    checks = []
    def check(name, obs, exp, note=""):
        ok = obs == exp
        checks.append({"check_id": name, "observed": str(obs), "expected": str(exp), "status": "PASS" if ok else "FAIL", "note": note})
        if not ok:
            write_tsv(OUT_AUDIT, checks)
            raise AssertionError(f"{name}: {obs!r} != {exp!r}")

    donor_rows = read_tsv(DONORS)
    sample_to_donor = {}
    donor_group = {}
    for row in donor_rows:
        donor_group[row["canonical_donor_id"]] = row["donor_group"]
        for gsm in row["sample_accessions"].split("|"):
            sample_to_donor[gsm] = row["canonical_donor_id"]
    files = sorted(DISCOVERY_DIR.glob("*.csv.gz"))
    check("discovery_files", len(files), 33)
    check("discovery_registry_samples", len(sample_to_donor), 33)
    manifest = []
    gene_hashes = set()
    total_cells = 0
    seen_prefixed_cells = set()
    pattern = re.compile(r"^(GSM\d+)_(NS|PN|PP)-(.+)\.csv\.gz$")
    for path in files:
        match = pattern.match(path.name)
        check(f"filename::{path.name}", match is not None, True)
        gsm, tissue, file_donor = match.groups()
        canonical = sample_to_donor[gsm]
        check(f"donor::{gsm}", file_donor, canonical)
        expected_tissue = "NS" if donor_group[canonical] == "healthy" else tissue
        check(f"tissue_group::{gsm}", tissue == expected_tissue if donor_group[canonical] == "healthy" else tissue in {"PN", "PP"}, True)
        gene_digest = hashlib.sha256(); gene_rows = 0
        with gzip.open(path, "rt", encoding="utf-8", errors="strict", newline="") as handle:
            header = handle.readline().rstrip("\r\n").split(",")
            cell_ids = header[1:]
            check(f"cells_nonempty::{gsm}", len(cell_ids) > 100, True)
            check(f"cell_unique::{gsm}", len(cell_ids), len(set(cell_ids)))
            prefixed = [f"{gsm}:{cell}" for cell in cell_ids]
            check(f"global_cell_unique::{gsm}", len(seen_prefixed_cells.intersection(prefixed)), 0)
            seen_prefixed_cells.update(prefixed)
            n_columns = len(header)
            for line in handle:
                check_value = line.count(",") + 1
                if check_value != n_columns:
                    raise AssertionError(f"column count {path.name} row {gene_rows + 2}: {check_value}!={n_columns}")
                gene = line.split(",", 1)[0]
                gene_digest.update(gene.encode("ascii")); gene_digest.update(b"\n")
                gene_rows += 1
        check(f"gene_rows::{gsm}", gene_rows > 20000, True)
        gene_hash = gene_digest.hexdigest(); gene_hashes.add(gene_hash)
        total_cells += len(cell_ids)
        manifest.append({"dataset_id": "GSE173706", "file": path.relative_to(ROOT).as_posix(),
            "sample_id": gsm, "donor_id": canonical, "donor_group": donor_group[canonical],
            "tissue": tissue, "cells": len(cell_ids), "gene_rows": gene_rows,
            "gene_id_type": "Ensembl_gene_id", "compressed_bytes": path.stat().st_size,
            "sha256": sha256(path), "gene_order_sha256": gene_hash, "analysis_role": "DISCOVERY"})
    check("discovery_gene_order_consistent", len(gene_hashes), 1)
    check("discovery_total_cells_positive", total_cells > 50000, True)
    check("discovery_global_cell_ids", len(seen_prefixed_cells), total_cells)

    with gzip.open(REPLICATION, "rt", encoding="utf-8", errors="strict", newline="") as handle:
        header = handle.readline().rstrip("\r\n").split("\t")
        rep_cells = header[1:]
        donors = [cell.split("_10x_", 1)[0] for cell in rep_cells]
        check("replication_cells", len(rep_cells), 24234)
        check("replication_cell_unique", len(rep_cells), len(set(rep_cells)))
        check("replication_donors", set(donors), {"Ctrl1", "Ctrl2", "Ctrl3", "Psor1", "Psor2", "Psor3"})
        gene_digest = hashlib.sha256(); rep_gene_rows = 0
        for line in handle:
            if line.count("\t") + 1 != len(header):
                raise AssertionError(f"replication column count at row {rep_gene_rows + 2}")
            gene = line.split("\t", 1)[0]
            gene_digest.update(gene.encode("utf-8")); gene_digest.update(b"\n")
            rep_gene_rows += 1
    check("replication_gene_rows", rep_gene_rows, 19968)
    counts = Counter(donors)
    rep_registry = []
    for donor in sorted(counts):
        rep_registry.append({"dataset_id": "GSE162183", "canonical_donor_id": donor,
            "donor_group": "healthy" if donor.startswith("Ctrl") else "psoriasis",
            "tissue": "NS" if donor.startswith("Ctrl") else "PP",
            "cell_count": counts[donor], "paired_status": "UNPAIRED",
            "analysis_role": "INDEPENDENT_F2_REPLICATION_ONLY"})
    check("replication_registry_rows", len(rep_registry), 6)
    manifest.append({"dataset_id": "GSE162183", "file": REPLICATION.relative_to(ROOT).as_posix(),
        "sample_id": "MERGED_SIX_DONORS", "donor_id": "Ctrl1|Ctrl2|Ctrl3|Psor1|Psor2|Psor3",
        "donor_group": "healthy|psoriasis", "tissue": "NS|PP", "cells": len(rep_cells),
        "gene_rows": rep_gene_rows, "gene_id_type": "HGNC_like_symbol_as_submitted",
        "compressed_bytes": REPLICATION.stat().st_size, "sha256": sha256(REPLICATION),
        "gene_order_sha256": gene_digest.hexdigest(), "analysis_role": "REPLICATION"})
    write_tsv(OUT_MANIFEST, manifest)
    write_tsv(OUT_REP_DONORS, rep_registry)
    check("manifest_rows", len(manifest), 34)
    write_tsv(OUT_AUDIT, checks)
    print(f"PASS: Stage 04 input gate; discovery cells={total_cells}, replication cells={len(rep_cells)}, checks={len(checks)}")

if __name__ == "__main__": main()
