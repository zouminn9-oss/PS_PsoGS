from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parents[1]; path=ROOT/"panel_manifest.tsv"
with path.open(encoding="utf-8",newline="") as f: rows=list(csv.DictReader(f,delimiter="\t"))
fields=list(rows[0]); ready={f"7{x}" for x in "BCDEFG"}
for row in rows:
 if row["panel_id"] in ready:
  low=row["panel_id"].lower(); row.update({"analysis_script":"scripts/figures/figure7_singlecell_analysis.py","plot_script":"scripts/figures/figure7_singlecell_plot.py","source_data":f"figures/source_data/fig{low}.tsv","statistics_file":f"results/figures/fig{low}_statistics.tsv","config_file":f"config/figures/fig{low}.yaml","vector_output":f"figures/panels/fig{low}.svg","preview_output":f"figures/previews/fig{low}.png","status":"PASS","qa_status":"PASS_RENDER_DATA_PRINT","figure_ready":"YES"})
with path.open("w",encoding="utf-8",newline="") as f:
 w=csv.DictWriter(f,fieldnames=fields,delimiter="\t",lineterminator="\n"); w.writeheader(); w.writerows(rows)
print("PASS: registered GSE228421 Figure 7 panels B-G")
