$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$downloadDir = Join-Path $projectRoot 'references\ensembl_release100_compara'
$parallelRanges = 8

function Get-RangedFile {
    param(
        [Parameter(Mandatory = $true)][string]$FileName,
        [Parameter(Mandatory = $true)][string]$SourceUrl,
        [Parameter(Mandatory = $true)][int64]$ExpectedBytes
    )

    $finalPath = Join-Path $downloadDir $FileName
    $prefixPath = "$finalPath.part000"
    $assemblingPath = "$finalPath.assembling"

    if (Test-Path -LiteralPath $finalPath) {
        $currentBytes = (Get-Item -LiteralPath $finalPath).Length
        if ($currentBytes -eq $ExpectedBytes) {
            $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $finalPath).Hash.ToLowerInvariant()
            Write-Output "SKIP complete ${FileName}: $currentBytes bytes; sha256=$hash"
            return
        }
        if ($currentBytes -le 0 -or $currentBytes -ge $ExpectedBytes) {
            throw "Unexpected partial size for ${FileName}: $currentBytes"
        }
        if (Test-Path -LiteralPath $prefixPath) {
            throw "Both incomplete final file and part000 exist for $FileName"
        }
        Move-Item -LiteralPath $finalPath -Destination $prefixPath
        Write-Output "PRESERVE sequential prefix for ${FileName}: $currentBytes bytes"
    }

    $parts = @()
    $prefixBytes = [int64]0
    if (Test-Path -LiteralPath $prefixPath) {
        $prefixBytes = (Get-Item -LiteralPath $prefixPath).Length
        if ($prefixBytes -le 0 -or $prefixBytes -ge $ExpectedBytes) {
            throw "Unexpected prefix size for ${FileName}: $prefixBytes"
        }
        $parts += $prefixPath
    }

    $remaining = $ExpectedBytes - $prefixBytes
    $chunkBytes = [int64][Math]::Ceiling($remaining / $parallelRanges)
    $jobs = @()
    for ($index = 1; $index -le $parallelRanges; $index++) {
        $start = $prefixBytes + (($index - 1) * $chunkBytes)
        if ($start -ge $ExpectedBytes) { break }
        $end = [Math]::Min($ExpectedBytes - 1, $start + $chunkBytes - 1)
        $partPath = "$finalPath.part$('{0:D3}' -f $index)"
        $expectedPartBytes = $end - $start + 1
        $parts += $partPath
        if ((Test-Path -LiteralPath $partPath) -and
            ((Get-Item -LiteralPath $partPath).Length -eq $expectedPartBytes)) {
            Write-Output "SKIP complete part $index for $FileName"
            continue
        }
        $stdout = "$partPath.stdout.log"
        $stderr = "$partPath.stderr.log"
        $arguments = @('-L', '--fail', '--retry', '10', '--retry-delay', '3',
                       '--range', "$start-$end", '-o', $partPath, $SourceUrl)
        $process = Start-Process -FilePath 'curl.exe' -ArgumentList $arguments `
            -WindowStyle Hidden -RedirectStandardOutput $stdout `
            -RedirectStandardError $stderr -PassThru
        $jobs += [pscustomobject]@{ Index = $index; Expected = $expectedPartBytes;
            Path = $partPath; Process = $process }
        Write-Output "START $FileName part $index ($start-$end)"
    }

    foreach ($job in $jobs) {
        $job.Process.WaitForExit()
        if (-not (Test-Path -LiteralPath $job.Path)) {
            throw "Missing downloaded part $($job.Index) for $FileName"
        }
        $observed = (Get-Item -LiteralPath $job.Path).Length
        if ($observed -ne $job.Expected) {
            throw "Part $($job.Index) length mismatch for ${FileName}: $observed vs $($job.Expected)"
        }
        if ($job.Process.ExitCode -ne 0) {
            throw "curl failed for $FileName part $($job.Index): $($job.Process.ExitCode)"
        }
        Write-Output "PASS $FileName part $($job.Index): $observed bytes"
    }

    if (Test-Path -LiteralPath $assemblingPath) {
        Remove-Item -LiteralPath $assemblingPath
    }
    $output = [System.IO.File]::Open($assemblingPath, [System.IO.FileMode]::CreateNew,
                                    [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
    try {
        foreach ($part in $parts) {
            $input = [System.IO.File]::OpenRead($part)
            try { $input.CopyTo($output) } finally { $input.Dispose() }
        }
    } finally {
        $output.Dispose()
    }

    $assembledBytes = (Get-Item -LiteralPath $assemblingPath).Length
    if ($assembledBytes -ne $ExpectedBytes) {
        throw "Assembled length mismatch for ${FileName}: $assembledBytes vs $ExpectedBytes"
    }
    Move-Item -LiteralPath $assemblingPath -Destination $finalPath
    $sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $finalPath).Hash.ToLowerInvariant()
    Write-Output "PASS ${FileName}: $assembledBytes bytes; sha256=$sha256"
}

Get-RangedFile `
    -FileName 'Compara.100.mouse.protein_default.homologies.tsv.gz' `
    -SourceUrl 'https://ftp.ensembl.org/pub/release-100/tsv/ensembl-compara/homologies/mus_musculus/Compara.100.protein_default.homologies.tsv.gz' `
    -ExpectedBytes 140988833

Get-RangedFile `
    -FileName 'Compara.100.mouse.ncrna_default.homologies.tsv.gz' `
    -SourceUrl 'https://ftp.ensembl.org/pub/release-100/tsv/ensembl-compara/homologies/mus_musculus/Compara.100.ncrna_default.homologies.tsv.gz' `
    -ExpectedBytes 20209380

Get-RangedFile `
    -FileName 'Compara.100.human.protein_default.homologies.tsv.gz' `
    -SourceUrl 'https://ftp.ensembl.org/pub/release-100/tsv/ensembl-compara/homologies/homo_sapiens/Compara.100.protein_default.homologies.tsv.gz' `
    -ExpectedBytes 147349199

Get-RangedFile `
    -FileName 'Compara.100.human.ncrna_default.homologies.tsv.gz' `
    -SourceUrl 'https://ftp.ensembl.org/pub/release-100/tsv/ensembl-compara/homologies/homo_sapiens/Compara.100.ncrna_default.homologies.tsv.gz' `
    -ExpectedBytes 36834898
