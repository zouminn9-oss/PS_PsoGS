#!/usr/bin/env python3
"""Audit the frozen GENCODE M25 GTF and build a gene-level annotation registry."""

from __future__ import annotations

import csv
import gzip
import re
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
GTF = ROOT / "references" / "genomes" / "GRCm38_gencode_M25" / "gencode.vM25.primary_assembly.annotation.gtf.gz"
ATTRIBUTE = re.compile(r'(\S+) "([^"]*)";')


def main() -> None:
    feature_counts: Counter[str] = Counter()
    seqname_counts: Counter[str] = Counter()
    genes: list[dict[str, object]] = []
    malformed = 0
    with gzip.open(GTF, "rt", encoding="utf-8") as handle:
        for line in handle:
            if line.startswith("#"):
                continue
            fields = line.rstrip("\n").split("\t")
            if len(fields) != 9:
                malformed += 1
                continue
            seqname, source, feature, start, end, score, strand, frame, attributes = fields
            feature_counts[feature] += 1
            seqname_counts[seqname] += 1
            if feature != "gene":
                continue
            attr = dict(ATTRIBUTE.findall(attributes))
            gene_id = attr.get("gene_id", "")
            genes.append(
                {
                    "gene_id": gene_id,
                    "base_gene_id": gene_id.split(".", 1)[0],
                    "gene_name": attr.get("gene_name", ""),
                    "gene_type": attr.get("gene_type", attr.get("gene_biotype", "")),
                    "seqname": seqname,
                    "start": int(start),
                    "end": int(end),
                    "strand": strand,
                    "source": source,
                }
            )

    if malformed:
        raise AssertionError(f"malformed non-comment GTF rows: {malformed}")
    if not genes or feature_counts["exon"] == 0:
        raise AssertionError("GTF contains no gene or exon features")
    if any(not row["gene_id"] for row in genes):
        raise AssertionError("at least one gene feature lacks gene_id")
    gene_ids = [str(row["gene_id"]) for row in genes]
    base_ids = [str(row["base_gene_id"]) for row in genes]
    if len(gene_ids) != len(set(gene_ids)):
        raise AssertionError("gene_id is not unique across gene features")
    if len(base_ids) != len(set(base_ids)):
        raise AssertionError("base_gene_id is not unique after version removal")

    gene_out = ROOT / "metadata" / "gencode_m25_mouse_gene_registry.tsv"
    with gene_out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(genes[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(genes)

    metrics = [
        ("gtf_noncomment_rows", sum(feature_counts.values()), "PASS", "sum of parsed feature rows"),
        ("gtf_malformed_rows", malformed, "PASS", "must equal zero"),
        ("gene_features", feature_counts["gene"], "PASS", "unique gene_id required"),
        ("transcript_features", feature_counts["transcript"], "PASS", "descriptive"),
        ("exon_features", feature_counts["exon"], "PASS", "featureCounts input feature"),
        ("unique_seqnames", len(seqname_counts), "PASS", "primary assembly contigs represented"),
        ("unique_gene_ids", len(set(gene_ids)), "PASS", "equals gene feature count"),
        ("unique_base_gene_ids", len(set(base_ids)), "PASS", "equals gene feature count"),
        ("genes_with_gene_name", sum(bool(row["gene_name"]) for row in genes), "PASS", "empty names retained, never guessed"),
        ("genes_with_gene_type", sum(bool(row["gene_type"]) for row in genes), "PASS", "GENCODE biotype field"),
    ]
    summary_out = ROOT / "audits" / "gencode_m25_gtf_summary.tsv"
    with summary_out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(("metric", "value", "status", "note"))
        writer.writerows(metrics)
    print(f"PASS: audited {sum(feature_counts.values())} GTF rows and registered {len(genes)} unique genes")


if __name__ == "__main__":
    main()
