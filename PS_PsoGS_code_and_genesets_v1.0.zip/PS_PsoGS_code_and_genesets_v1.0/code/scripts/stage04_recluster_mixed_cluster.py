#!/usr/bin/env python3
"""Label-blind rescue subclustering for global cluster 8, which mixed rare lineages."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))

import anndata as ad
import numpy as np
import pandas as pd
import scanpy as sc
from scipy import sparse

SEED = 20260911
TARGET_CLUSTER = "8"
MARKERS = {
    "Fibroblast": ["DCN", "LUM", "COL1A1", "COL1A2", "COL3A1", "PDGFRA"],
    "Mast": ["TPSAB1", "TPSB2", "CPA3", "MS4A2", "KIT", "CTSG", "CMA1", "HPGDS"],
    "Nerve_glial": ["MPZ", "PLP1", "S100B", "SOX10", "SLC1A3", "NGFR", "CDH19"],
    "Eccrine": ["DCD", "PIP", "MUCL1", "AQP5", "KRT19", "KRT7"],
}


def main():
    obs = pd.read_csv(ROOT / "data/processed/stage04/GSE173706_cell_metadata.tsv.gz", sep="\t")
    genes = pd.read_csv(ROOT / "data/processed/stage04/gse173706_selected_genes.tsv", sep="\t")
    counts = sparse.load_npz(ROOT / "data/processed/stage04/gse173706_selected_counts.npz").tocsr().astype(np.float32)
    representations = np.load(ROOT / "data/processed/stage04/gse173706_atlas_representations.npz")
    selected = obs["leiden_08"].astype(str).eq(TARGET_CLUSTER).to_numpy()
    index = np.flatnonzero(selected)
    atlas = ad.AnnData(X=sparse.csr_matrix((len(index), 1), dtype=np.float32), obs=obs.loc[selected, ["cell_id", "sample_id", "donor_id", "tissue"]].copy())
    atlas.obs_names = obs.loc[selected, "cell_id"].astype(str).to_numpy()
    atlas.obsm["X_pca_harmony"] = representations["X_pca_harmony"][selected]
    sc.pp.neighbors(atlas, n_neighbors=15, use_rep="X_pca_harmony", random_state=SEED)
    sc.tl.leiden(atlas, resolution=1.0, random_state=SEED, flavor="igraph", n_iterations=2, directed=False, key_added="rescue_leiden_10")

    matrix = counts[index]
    scale = 10000.0 / np.asarray(matrix.sum(axis=1)).ravel()
    matrix = sparse.diags(scale).dot(matrix).tocsr()
    matrix.data = np.log1p(matrix.data)
    symbol_cols = {}
    for j, symbol in enumerate(genes["human_gene_symbol"].fillna("").astype(str)):
        if symbol:
            symbol_cols.setdefault(symbol, []).append(j)
    labels = atlas.obs["rescue_leiden_10"].astype(str).to_numpy()
    rows = []
    annotations = []
    for cluster in sorted(set(labels), key=int):
        inside = labels == cluster
        candidates = []
        for cell_type, marker_list in MARKERS.items():
            support = 0
            evidence = 0.0
            for marker in marker_list:
                columns = symbol_cols.get(marker, [])
                values = np.asarray(matrix[inside][:, columns].sum(axis=1)).ravel() if columns else np.array([])
                mean = float(values.mean()) if values.size else np.nan
                fraction = float((values > 0).mean()) if values.size else np.nan
                support += int(np.isfinite(fraction) and fraction >= 0.20)
                evidence += (mean if np.isfinite(mean) else 0) * (fraction if np.isfinite(fraction) else 0)
                rows.append({"rescue_cluster": cluster, "candidate_cell_type": cell_type, "marker": marker,
                             "mean_log1p_cp10k": mean, "detection_fraction": fraction})
            candidates.append((cell_type, evidence / len(marker_list), support))
        candidates.sort(key=lambda x: (-x[1], x[0]))
        best, second = candidates[:2]
        label = best[0] if best[2] >= 2 and best[1] >= 1.5 * max(second[1], 1e-9) else "Uncertain_mixed"
        donor_fraction = obs.loc[index[inside], "donor_id"].value_counts(normalize=True).max()
        annotations.append({"rescue_cluster": cluster, "cell_type": label, "best_candidate": best[0],
                            "best_evidence": best[1], "second_candidate": second[0], "second_evidence": second[1],
                            "supporting_markers_ge20pct": best[2], "cells": int(inside.sum()),
                            "donors": int(obs.loc[index[inside], "donor_id"].nunique()),
                            "max_single_donor_fraction": float(donor_fraction)})
    mapping = pd.DataFrame({"cell_id": obs.loc[selected, "cell_id"].to_numpy(), "rescue_leiden_10": labels})
    mapping.to_csv(ROOT / "results/stage04/cluster8_rescue_cell_labels.tsv.gz", sep="\t", index=False, compression="gzip")
    pd.DataFrame(rows).to_csv(ROOT / "results/stage04/cluster8_rescue_marker_evidence.tsv", sep="\t", index=False)
    pd.DataFrame(annotations).to_csv(ROOT / "results/stage04/cluster8_rescue_annotations.tsv", sep="\t", index=False)
    print(pd.DataFrame(annotations).to_string(index=False))


if __name__ == "__main__":
    main()
