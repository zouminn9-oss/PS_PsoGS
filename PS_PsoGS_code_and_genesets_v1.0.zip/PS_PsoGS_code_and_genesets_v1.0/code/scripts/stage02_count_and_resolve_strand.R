options(stringsAsFactors = FALSE)

.libPaths(c(normalizePath(file.path("r_libs", "stage02")),
            normalizePath(file.path("r_libs", "stage01")), .libPaths()))
stopifnot(requireNamespace("Rsubread", quietly = TRUE))
stopifnot(as.character(packageVersion("Rsubread")) == "2.20.0")

registry <- read.delim(file.path("metadata", "gse212126_library_animal_registry.tsv"),
                       check.names = FALSE, stringsAsFactors = FALSE)
stopifnot(nrow(registry) == 12L, length(unique(registry$srr)) == 12L,
          length(unique(registry$canonical_animal_id)) == 12L)
bams <- file.path("data", "interim", "gse212126_bam", paste0(registry$srr, ".bam"))
if (!all(file.exists(bams))) {
  stop("all 12 BAMs are required; missing: ", paste(registry$srr[!file.exists(bams)], collapse = ","))
}

gtf <- file.path("references", "genomes", "GRCm38_gencode_M25",
                 "gencode.vM25.primary_assembly.annotation.gtf")
stopifnot(file.exists(gtf))
out_root <- file.path("results", "stage02", "counts")
dir.create(out_root, recursive = TRUE, showWarnings = FALSE)

run_feature_counts <- function(strand) {
  Rsubread::featureCounts(
    files = bams,
    annot.ext = gtf,
    isGTFAnnotationFile = TRUE,
    GTF.featureType = "exon",
    GTF.attrType = "gene_id",
    useMetaFeatures = TRUE,
    allowMultiOverlap = FALSE,
    countMultiMappingReads = FALSE,
    primaryOnly = TRUE,
    strandSpecific = strand,
    isPairedEnd = TRUE,
    countReadPairs = TRUE,
    requireBothEndsMapped = TRUE,
    countChimericFragments = FALSE,
    nthreads = 8,
    tmpDir = file.path("data", "interim"),
    verbose = TRUE
  )
}

counts_by_strand <- vector("list", 3L)
stats_by_strand <- vector("list", 3L)
names(counts_by_strand) <- names(stats_by_strand) <- c("0", "1", "2")
for (strand in 0:2) {
  fc <- run_feature_counts(strand)
  stopifnot(ncol(fc$counts) == 12L, nrow(fc$counts) > 0L,
            all(is.finite(fc$counts)), all(fc$counts >= 0),
            all(fc$counts == round(fc$counts)))
  colnames(fc$counts) <- registry$srr
  count_table <- cbind(fc$annotation, as.data.frame(fc$counts, check.names = FALSE))
  write.table(count_table,
              file.path(out_root, paste0("gse212126_gene_counts_strand", strand, ".tsv")),
              sep = "\t", quote = FALSE, row.names = FALSE)

  stat <- fc$stat
  colnames(stat)[-1L] <- registry$srr
  write.table(stat,
              file.path(out_root, paste0("gse212126_assignment_status_strand", strand, ".tsv")),
              sep = "\t", quote = FALSE, row.names = FALSE)
  counts_by_strand[[as.character(strand)]] <- fc$counts
  stats_by_strand[[as.character(strand)]] <- stat
}

assigned <- sapply(stats_by_strand, function(x) {
  row <- which(x$Status == "Assigned")
  stopifnot(length(row) == 1L)
  as.numeric(x[row, -1L, drop = TRUE])
})
colnames(assigned) <- c("assigned_strand0", "assigned_strand1", "assigned_strand2")
stopifnot(all(assigned[, "assigned_strand0"] > 0))
ratio1 <- assigned[, "assigned_strand1"] / assigned[, "assigned_strand0"]
ratio2 <- assigned[, "assigned_strand2"] / assigned[, "assigned_strand0"]
if (all(ratio1 >= 0.80 & ratio2 <= 0.20)) {
  selected <- 1L
  reason <- "strand1 retained >=80% and strand2 <=20% in every library"
} else if (all(ratio2 >= 0.80 & ratio1 <= 0.20)) {
  selected <- 2L
  reason <- "strand2 retained >=80% and strand1 <=20% in every library"
} else {
  selected <- 0L
  reason <- "strict every-library strandedness rule not met; use unstranded"
}

decision <- data.frame(
  srr = registry$srr,
  canonical_animal_id = registry$canonical_animal_id,
  condition = registry$condition,
  assigned,
  strand1_over_unstranded = ratio1,
  strand2_over_unstranded = ratio2,
  selected_strand = selected,
  decision_reason = reason,
  selection_used_differential_expression = FALSE,
  stringsAsFactors = FALSE,
  check.names = FALSE
)
write.table(decision, file.path(out_root, "gse212126_strand_decision.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

chosen <- counts_by_strand[[as.character(selected)]]
canonical <- data.frame(gene_id = rownames(chosen), chosen, check.names = FALSE)
colnames(canonical)[-1L] <- registry$srr
write.table(canonical, file.path(out_root, "gse212126_gene_counts_frozen.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(registry[, c("srr", "gsm", "canonical_animal_id", "condition", "replicate_label")],
            file.path(out_root, "gse212126_count_column_registry.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: counted 12 independent-mouse libraries; frozen strandSpecific=%d\n", selected))
