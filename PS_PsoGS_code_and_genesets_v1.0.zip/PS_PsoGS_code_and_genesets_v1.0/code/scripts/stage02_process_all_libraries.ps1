param(
    [string]$WaitForActiveRun = "SRR21221229",
    [int]$WaitTimeoutHours = 6
)

$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
Set-Location -LiteralPath $ProjectRoot

$AuditPath = Join-Path $ProjectRoot "audits\gse212126_sra_audit.tsv"
$LedgerPath = Join-Path $ProjectRoot "audits\gse212126_run_processing_state.tsv"
$DownloadStatePath = Join-Path $ProjectRoot "audits\gse212126_sra_download_state.tsv"
$EventPath = Join-Path $ProjectRoot "audits\stage02_processing_events.tsv"
$LogPath = Join-Path $ProjectRoot "logs\stage02\stage02_process_all_libraries.log"
$DownloadScript = Join-Path $ProjectRoot "scripts\stage02_download_all_sra.ps1"
$ConvertScript = Join-Path $ProjectRoot "scripts\stage02_convert_full_run.ps1"
$RefreshScript = Join-Path $ProjectRoot "scripts\stage02_refresh_run_processing_state.py"
$ManifestScript = Join-Path $ProjectRoot "scripts\stage02_refresh_manifest_state.py"
$Finalizer = Join-Path $ProjectRoot "scripts\stage02_finalize_alignment_audit.py"
$AlignScript = Join-Path $ProjectRoot "scripts\stage02_align_run.R"
$Rscript = "C:\Program Files\R\R-4.4.1\bin\Rscript.exe"
$MinimumFreeBytes = 250000000000L

foreach ($Required in @(
    $AuditPath, $LedgerPath, $DownloadStatePath, $EventPath, $DownloadScript,
    $ConvertScript, $RefreshScript, $ManifestScript, $Finalizer, $AlignScript, $Rscript
)) {
    if (-not (Test-Path -LiteralPath $Required)) { throw "required input missing: $Required" }
}

function Write-OrchestratorLog {
    param([string]$Message)
    $Line = "$(Get-Date -Format o)`t$Message"
    $Line | Out-File -LiteralPath $LogPath -Encoding utf8 -Append
    Write-Host $Line
}

function Invoke-Checked {
    param(
        [Parameter(Mandatory = $true)][string]$Label,
        [Parameter(Mandatory = $true)][scriptblock]$Action
    )
    Write-OrchestratorLog "START`t$Label"
    & $Action 2>&1 | Tee-Object -FilePath $LogPath -Append | ForEach-Object { Write-Host $_ }
    if ($LASTEXITCODE -ne 0) { throw "$Label failed with exit code $LASTEXITCODE" }
    Write-OrchestratorLog "PASS`t$Label"
}

function Refresh-Ledger {
    Invoke-Checked -Label "refresh processing ledger" -Action { & python $RefreshScript }
    return @(Import-Csv -LiteralPath $LedgerPath -Delimiter "`t")
}

function Get-DownloadPass {
    param([string]$Run)
    $Rows = @(Import-Csv -LiteralPath $DownloadStatePath -Delimiter "`t" |
        Where-Object { $_.srr -eq $Run })
    return ($Rows.Count -eq 1 -and $Rows[0].integrity_status -eq "PASS" -and
        $Rows[0].vdb_validate_status -eq "PASS")
}

function Add-CompletionEvent {
    param([string]$Run)
    $Now = Get-Date -Format o
    $Line = "$Now`tStage02 serial orchestrator`tcomplete $Run library reconstruction`tPASS`tSRA MD5/VDB, paired FASTQ audit/gzip hashes, subjunc arithmetic and BAM SHA-256 all passed`tretain audited artifacts and proceed to the next independent mouse`tno across-animal inference until all 12 libraries pass"
    $Line | Out-File -LiteralPath $EventPath -Encoding utf8 -Append
}

$Runs = @(Import-Csv -LiteralPath $AuditPath -Delimiter "`t" | Sort-Object srr)
if ($Runs.Count -ne 12) { throw "expected 12 audited runs, found $($Runs.Count)" }
if ((Get-PSDrive -Name D).Free -lt $MinimumFreeBytes) {
    throw "free D: space is below the frozen 250-GB minimum"
}

Write-OrchestratorLog "RUNNING`tserial reconstruction of all 12 independent-mouse libraries"

if ($WaitForActiveRun) {
    if (@($Runs | Where-Object { $_.srr -eq $WaitForActiveRun }).Count -ne 1) {
        throw "active run is not in the frozen 12-run registry: $WaitForActiveRun"
    }
    $WaitStart = Get-Date
    $ExpectedMinimumBytes = [long](@($Runs | Where-Object { $_.srr -eq $WaitForActiveRun })[0].compressed_size_bytes)
    $LastBytes = -1L
    $StallChecks = 0
    $NoCurlChecks = 0
    while (-not (Get-DownloadPass -Run $WaitForActiveRun)) {
        $SraFile = Join-Path $ProjectRoot "data\raw\gse212126_sra\$WaitForActiveRun\$WaitForActiveRun.sra"
        $Bytes = if (Test-Path -LiteralPath $SraFile) { (Get-Item -LiteralPath $SraFile).Length } else { 0L }
        if ($Bytes -eq $LastBytes) { $StallChecks++ } else { $StallChecks = 0 }
        $LastBytes = $Bytes
        $CurlAlive = @(Get-Process -Name curl -ErrorAction SilentlyContinue).Count -gt 0
        if ($CurlAlive) { $NoCurlChecks = 0 } else { $NoCurlChecks++ }
        Write-OrchestratorLog "WAIT_ACTIVE_DOWNLOAD`t$WaitForActiveRun`tbytes=$Bytes`tcurl_alive=$CurlAlive`tstall_checks=$StallChecks`tno_curl_checks=$NoCurlChecks"
        if (-not $CurlAlive -and $Bytes -lt $ExpectedMinimumBytes) {
            throw "active download ended before the expected object size for $WaitForActiveRun"
        }
        if (-not $CurlAlive -and $NoCurlChecks -gt 40) {
            throw "official MD5/VDB finalization did not complete within the 20-minute grace period for $WaitForActiveRun"
        }
        if (((Get-Date) - $WaitStart).TotalHours -ge $WaitTimeoutHours) {
            throw "active download wait exceeded $WaitTimeoutHours hours for $WaitForActiveRun"
        }
        Start-Sleep -Seconds 30
    }
    Write-OrchestratorLog "PASS`tactive download completed official integrity gates for $WaitForActiveRun"
}

for ($Index = 0; $Index -lt $Runs.Count; $Index++) {
    $Run = $Runs[$Index].srr
    $Ledger = Refresh-Ledger
    $State = @($Ledger | Where-Object { $_.srr -eq $Run })
    if ($State.Count -ne 1) { throw "expected one ledger row for $Run" }

    if ($State[0].sra_md5_vdb -ne "PASS") {
        $OneBasedIndex = $Index + 1
        Invoke-Checked -Label "download and validate $Run" -Action {
            & $DownloadScript -StartAt $OneBasedIndex -StopAfter $OneBasedIndex
        }
        $Ledger = Refresh-Ledger
        $State = @($Ledger | Where-Object { $_.srr -eq $Run })
        if ($State[0].sra_md5_vdb -ne "PASS") { throw "SRA gate did not pass for $Run" }
    } else {
        Write-OrchestratorLog "SKIP_PASS`tdownload and validate $Run"
    }

    if ($State[0].full_fastq -ne "PASS") {
        Invoke-Checked -Label "convert, audit and compress $Run FASTQ" -Action {
            & $ConvertScript -Run $Run -Threads 8
        }
        $Ledger = Refresh-Ledger
        $State = @($Ledger | Where-Object { $_.srr -eq $Run })
        if ($State[0].full_fastq -ne "PASS") { throw "FASTQ gate did not pass for $Run" }
    } else {
        Write-OrchestratorLog "SKIP_PASS`tconvert, audit and compress $Run FASTQ"
    }

    if ($State[0].alignment_bam -ne "PASS") {
        $Bam = Join-Path $ProjectRoot "data\interim\gse212126_bam\$Run.bam"
        if (-not (Test-Path -LiteralPath $Bam)) {
            Invoke-Checked -Label "subjunc alignment $Run" -Action { & $Rscript $AlignScript $Run }
        } else {
            Write-OrchestratorLog "RECOVER_NO_REALIGN`t$Run BAM exists; run strict finalizer without overwriting alignment"
        }
        Invoke-Checked -Label "finalize alignment audit $Run" -Action { & python $Finalizer $Run }
        $Ledger = Refresh-Ledger
        $State = @($Ledger | Where-Object { $_.srr -eq $Run })
        if ($State[0].alignment_bam -ne "PASS") { throw "BAM gate did not pass for $Run" }
        Add-CompletionEvent -Run $Run
    } else {
        Write-OrchestratorLog "SKIP_PASS`talignment and BAM audit $Run"
    }

    Invoke-Checked -Label "refresh project state after $Run" -Action { & python $ManifestScript }
    $FreeBytes = (Get-PSDrive -Name D).Free
    Write-OrchestratorLog "CHECKPOINT`t$Run complete`tfree_D_bytes=$FreeBytes"
    if ($FreeBytes -lt $MinimumFreeBytes) { throw "free D: space fell below frozen minimum after $Run" }
}

$FinalLedger = Refresh-Ledger
$Passed = @($FinalLedger | Where-Object { $_.alignment_bam -eq "PASS" }).Count
if ($Passed -ne 12) { throw "expected 12 BAM PASS rows, found $Passed" }
Invoke-Checked -Label "final project state refresh" -Action { & python $ManifestScript }
Invoke-Checked -Label "full regression suite" -Action { & python -m unittest discover -s tests -v }
Write-OrchestratorLog "PASS`tall 12 independent-mouse libraries completed audited reconstruction"
Write-Output "PASS: all 12 independent-mouse libraries completed SRA, FASTQ and BAM gates"
