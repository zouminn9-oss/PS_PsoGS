from pathlib import Path
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))
import pandas as pd
from PIL import Image

ready = ["4a", "4h", "5a", "5b", "5d", "5f", "5g", "5i", "5j", "5l"]
checks = []
def ck(name, passed, detail): checks.append((name, bool(passed), str(detail)))
for p in ready:
    files = {
        "source": ROOT / f"figures/source_data/fig{p}.tsv",
        "stats": ROOT / f"results/figures/fig{p}_statistics.tsv",
        "config": ROOT / f"config/figures/fig{p}.yaml",
        "svg": ROOT / f"figures/panels/fig{p}.svg",
        "png": ROOT / f"figures/previews/fig{p}.png",
        "caption": ROOT / f"figures/captions/fig{p}.md",
    }
    for kind, f in files.items(): ck(f"{p}_{kind}_exists", f.exists() and f.stat().st_size > 0, f)
    ck(f"{p}_source_nonempty", len(pd.read_csv(files["source"], sep="\t")) > 0, files["source"])
    ck(f"{p}_stats_nonempty", len(pd.read_csv(files["stats"], sep="\t")) > 0, files["stats"])
    with Image.open(files["png"]) as im: ck(f"{p}_print_pixels", im.width >= 900 and im.height >= 600, f"{im.width}x{im.height}")
    ck(f"{p}_caption_complete", len(files["caption"].read_text(encoding="utf-8").split()) >= 35, "word-like tokens")

tf = pd.read_csv(ROOT / "results/stage05/fibroblast_dorothea_paired_effects.tsv", sep="\t")
ck("tf_zero_bh_significant", ((tf.fdr_bh < .05) & tf.eligible).sum() == 0, ((tf.fdr_bh < .05) & tf.eligible).sum())
lr = pd.read_csv(ROOT / "results/figures/fig5b_statistics.tsv", sep="\t")
ck("lr_discovery_bh_pass", float(lr.loc[lr.cohort == "GSE173706", "fdr_bh"].iloc[0]) < .05, "discovery")
ck("lr_replication_rule_pass", str(lr.loc[lr.cohort == "GSE162183", "minimum_p_rule_replication"].iloc[0]).lower() == "true", "replication")
met = pd.read_csv(ROOT / "results/stage05/fibroblast_reactome_metabolism_paired_effects.tsv", sep="\t")
ck("metabolism_eight_primary", len(met[met.variant == "primary"]) == 8, len(met[met.variant == "primary"]))
ck("metabolism_one_primary_bh", (met[met.variant == "primary"].fdr_bh < .05).sum() == 1, (met[met.variant == "primary"].fdr_bh < .05).sum())
rep = pd.read_csv(ROOT / "results/stage05/gse162183_glutathione_replication_statistics.tsv", sep="\t").iloc[0]
ck("glutathione_replication_fails", not bool(rep.minimum_p_rule_replication), rep.welch_p)
couple = pd.read_csv(ROOT / "results/figures/fig5j_statistics.tsv", sep="\t").iloc[0]
ck("coupling_uses_seven_pairs", int(couple.n_donors) == 7, couple.n_donors)
ck("coupling_not_significant", float(couple.spearman_p) >= .05, couple.spearman_p)
with (ROOT / "panel_manifest.tsv").open(encoding="utf-8", newline="") as f: man = {r["panel_id"]: r for r in csv.DictReader(f, delimiter="\t")}
for p in [x.upper() for x in ready]:
    ck(f"manifest_{p}_ready", man[p]["status"] == "PASS" and man[p]["figure_ready"] == "YES" and man[p]["qa_status"] == "PASS_RENDER_DATA_PRINT", man[p]["status"])
blocked = ["4B","4C","4D","4E","4F","4G","4I","4J","5C","5E","5H","5K"]
for p in blocked: ck(f"manifest_{p}_blocked", man[p]["status"].startswith("BLOCKED") and man[p]["figure_ready"] == "NO", man[p]["status"])
out = pd.DataFrame(checks, columns=["check", "pass", "detail"])
out.to_csv(ROOT / "audits/stage05_figure45_checks.tsv", sep="\t", index=False)
if not out["pass"].all(): raise AssertionError(out.loc[~out["pass"]].to_string(index=False))
print(f"PASS: Figure 4/5 QA {len(out)}/{len(out)} checks")
