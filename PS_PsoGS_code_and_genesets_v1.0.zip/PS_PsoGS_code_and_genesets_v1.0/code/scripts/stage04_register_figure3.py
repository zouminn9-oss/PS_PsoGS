#!/usr/bin/env python3
"""Register completed Figure 3 panels without rebuilding earlier manifests."""
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PATH = ROOT / "panel_manifest.tsv"
with PATH.open(encoding="utf-8-sig", newline="") as handle:
    rows = list(csv.DictReader(handle, delimiter="\t"))

inputs = {
    "3A": "data/processed/stage04/GSE173706_cell_metadata.tsv.gz",
    "3B": "results/stage04/annotation_markers.tsv;results/stage04/final_annotation_ledger.tsv",
    "3C": "results/stage04/composition_qc.tsv",
    "3D": "data/processed/stage04/GSE173706_cell_metadata.tsv.gz",
    "3E": "data/processed/stage04/GSE173706_cell_metadata.tsv.gz;results/stage04/paired_donor_scores.tsv",
    "3F": "results/stage04/donor_celltype_scores.tsv;results/stage04/paired_donor_scores.tsv",
    "3G": "results/stage04/paired_donor_scores.tsv",
    "3H": "results/stage04/donor_celltype_scores.tsv;metadata/TARGET_FREEZE_STAGE04_F2.tsv",
    "3I": "data/processed/stage04/subatlas_metadata.tsv.gz;metadata/TARGET_FREEZE_STAGE04_F2_SUBTYPE.tsv",
    "3J": "results/stage04/differential_abundance.tsv",
    "3K": "results/stage04/GSE162183_replication.tsv",
    "3L": "results/stage04/composition_decomposition.tsv",
}
for row in rows:
    if row["figure_id"] == "Figure 3":
        row["input_table"] = inputs[row["panel_id"]]
        row["analysis_script"] = "scripts/figures/figure3_analysis.py"
        row["plot_script"] = "scripts/figures/figure3_plot.py"
        row["status"] = "PASS"
        row["qa_status"] = "PASS_RENDER_DATA_PRINT"
        row["figure_ready"] = "YES"

with PATH.open("w", encoding="utf-8", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
    writer.writeheader(); writer.writerows(rows)
print("PASS: registered Figure 3A-L")
