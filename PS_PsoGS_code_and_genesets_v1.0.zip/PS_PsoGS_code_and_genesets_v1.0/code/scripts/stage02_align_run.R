options(stringsAsFactors = FALSE)

.libPaths(c(normalizePath(file.path("r_libs", "stage02")),
            normalizePath(file.path("r_libs", "stage01")), .libPaths()))
stopifnot(requireNamespace("Rsubread", quietly = TRUE))
stopifnot(as.character(packageVersion("Rsubread")) == "2.20.0")

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L || !grepl("^SRR[0-9]+$", args[[1L]])) {
  stop("usage: Rscript scripts/stage02_align_run.R SRR########")
}
run <- args[[1L]]
registry <- read.delim(file.path("metadata", "gse212126_library_animal_registry.tsv"),
                       check.names = FALSE, stringsAsFactors = FALSE)
stopifnot(sum(registry$srr == run) == 1L)

fastq_root <- file.path("data", "interim", "gse212126_fastq", paste0("full_", run))
read1 <- file.path(fastq_root, paste0(run, "_1.fastq.gz"))
read2 <- file.path(fastq_root, paste0(run, "_2.fastq.gz"))
stopifnot(file.exists(read1), file.exists(read2))

reference_root <- file.path("references", "genomes", "GRCm38_gencode_M25")
index_base <- file.path(reference_root, "rsubread_index", "GRCm38_GENCODE_M25")
gtf <- file.path(reference_root, "gencode.vM25.primary_assembly.annotation.gtf")
stopifnot(length(Sys.glob(paste0(index_base, ".*"))) > 0L, file.exists(gtf))

bam_root <- file.path("data", "interim", "gse212126_bam")
audit_root <- file.path("audits", "stage02_alignment")
dir.create(bam_root, recursive = TRUE, showWarnings = FALSE)
dir.create(audit_root, recursive = TRUE, showWarnings = FALSE)
bam <- file.path(bam_root, paste0(run, ".bam"))
if (file.exists(bam)) stop("refusing to overwrite existing BAM: ", bam)

alignment <- Rsubread::subjunc(
  index = index_base,
  readfile1 = read1,
  readfile2 = read2,
  input_format = "gzFASTQ",
  output_format = "BAM",
  output_file = bam,
  phredOffset = 33,
  unique = FALSE,
  nBestLocations = 1,
  minFragLength = 50,
  maxFragLength = 600,
  PE_orientation = "fr",
  nthreads = 8,
  sortReadsByCoordinates = TRUE,
  useAnnotation = TRUE,
  annot.ext = gtf,
  isGTF = TRUE,
  GTF.featureType = "exon",
  GTF.attrType = "gene_id"
)
stopifnot(file.exists(bam), file.info(bam)$size > 0)

if (is.data.frame(alignment) || is.matrix(alignment)) {
  alignment_df <- as.data.frame(alignment, check.names = FALSE)
  metric_names <- rownames(alignment_df)
  if (!is.null(metric_names) && !identical(metric_names, as.character(seq_len(nrow(alignment_df))))) {
    alignment_df <- data.frame(metric = metric_names, alignment_df,
                               check.names = FALSE, row.names = NULL)
  }
  write.table(alignment_df, file.path(audit_root, paste0(run, "_subjunc.tsv")),
              sep = "\t", quote = FALSE, row.names = FALSE)
} else {
  capture.output(str(alignment), file = file.path(audit_root, paste0(run, "_subjunc_structure.txt")))
}
cat(sprintf("PASS: aligned %s without overwriting any prior BAM\n", run))
cat(sprintf("NEXT: run python scripts/stage02_finalize_alignment_audit.py %s\n", run))
