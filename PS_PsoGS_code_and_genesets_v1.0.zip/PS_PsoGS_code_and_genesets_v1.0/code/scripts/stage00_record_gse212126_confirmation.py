#!/usr/bin/env python3
"""Record the project-owner confirmation of GSE212126 animal independence/no pooling."""

from __future__ import annotations

import csv
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATE = "2026-09-10"
SOURCE = "USER_PROVIDED_PROJECT_CONFIRMATION_IN_CODEX_TASK"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def canonical_condition(row: dict[str, str]) -> tuple[str, str]:
    title = row["title"]
    if "CRS+IMQ" in title:
        return "CRS+IMQ", "CRS_IMQ"
    if "Imiquimod" in title:
        return "IMQ", "IMQ"
    if "Chronic restrain stress" in title:
        return "CRS", "CRS"
    return "Control", "CTRL"


def main() -> None:
    sra = read_tsv(ROOT / "audits" / "gse212126_sra_audit.tsv")
    if len(sra) != 12:
        raise AssertionError(f"Expected 12 SRA rows, found {len(sra)}")

    rows: list[dict[str, object]] = []
    for row in sra:
        match = re.search(r"rep(\d+)$", row["title"])
        if not match:
            raise AssertionError(f"Missing replicate label: {row['title']}")
        replicate = int(match.group(1))
        condition, code = canonical_condition(row)
        rows.append({
            "dataset_id": "GSE212126",
            "gsm": row["gsm"],
            "srx": row["srx"],
            "srs": row["srs"],
            "biosample": row["biosample"],
            "srr": row["srr"],
            "condition": condition,
            "replicate_label": f"rep{replicate}",
            "canonical_animal_id": f"GSE212126_{code}_M{replicate}",
            "animal_id_type": "PROJECT_ASSIGNED_ANONYMOUS_ID",
            "libraries_per_animal": 1,
            "animals_per_library": 1,
            "pooling_status": "NO_POOLING_USER_CONFIRMED",
            "independence_status": "PASS_USER_CONFIRMED_ONE_LIBRARY_PER_INDEPENDENT_MOUSE",
            "confirmation_source": SOURCE,
            "confirmation_date": DATE,
            "public_source_animal_id": "NOT_EXPLICIT",
            "limitation": "Original animal identifiers and a source document are not archived locally; confirmation is user-provided.",
        })

    write_tsv(ROOT / "metadata" / "gse212126_library_animal_registry.tsv", rows)
    confirmation = [{
        "dataset_id": "GSE212126",
        "confirmation_date": DATE,
        "confirmation_source": SOURCE,
        "confirmed_statement": "Each of the 12 RNA-seq libraries corresponds to one independent mouse and no library is pooled.",
        "n_libraries": 12,
        "n_independent_animals": 12,
        "libraries_per_animal": 1,
        "animals_per_library": 1,
        "pooling_status": "NO_POOLING",
        "animal_gate_status": "PASS_USER_CONFIRMED",
        "public_source_document_archived": "NO",
        "remaining_stage02_blocker": "RAW_INTEGER_COUNTS_NOT_YET_RECONSTRUCTED",
    }]
    write_tsv(ROOT / "audits" / "gse212126_user_confirmation.tsv", confirmation)
    print("PASS: recorded 12 independent unpooled GSE212126 mice from user confirmation")


if __name__ == "__main__":
    main()
