#!/usr/bin/env python3
"""Validate the frozen GSE117468 public-metadata audit."""

from __future__ import annotations

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    sample_map = read_tsv(ROOT / "metadata" / "gse117468_patient_visit_tissue_map.tsv")
    patients = read_tsv(ROOT / "metadata" / "gse117468_patient_registry.tsv")
    cohorts = {row["cohort"]: row for row in read_tsv(ROOT / "audits" / "gse117468_cohort_summary.tsv")}
    sources = {row["source"]: row for row in read_tsv(ROOT / "audits" / "gse117468_source_reconciliation.tsv")}
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    check("public_array_rows", len(sample_map), 565)
    check("unique_gsm", len({row["sample_id"] for row in sample_map}), 565)
    check("public_patient_ids", len(patients), 133)
    check("unique_patient_ids", len({row["patient_id"] for row in patients}), 133)
    check("no_expression_access", sum(row["expression_values_accessed"] == "NO" for row in sample_map), 565)
    check("complete_patient_id", sum(bool(row["patient_id"]) for row in sample_map), 565)
    check("complete_treatment", sum(bool(row["treatment"]) for row in sample_map), 565)
    check("complete_visit", sum(bool(row["visit"]) for row in sample_map), 565)
    check("complete_tissue", sum(bool(row["tissue"]) for row in sample_map), 565)
    check("complete_pasi", sum(bool(row["pasi"]) for row in sample_map), 565)
    check("complete_age", sum(bool(row["age"]) for row in sample_map), 565)
    check("complete_bmi", sum(bool(row["bmi"]) for row in sample_map), 565)
    check("complete_weight", sum(bool(row["weight"]) for row in sample_map), 565)
    check("complete_race", sum(bool(row["race"]) for row in sample_map), 565)
    check("sex_absent", sum(bool(row["sex"]) for row in sample_map), 0)
    check("treatment_consistent_by_patient", sum(row["treatment_consistent"] == "YES" for row in patients), 133)
    check("pasi_consistent_within_visit", sum(row["pasi_consistent_within_visit"] == "YES" for row in patients), 133)
    check("static_fields_consistent", sum(row["static_clinical_fields_consistent"] == "YES" for row in patients), 133)
    check("duplicate_visit_tissue_cells", sum(row["duplicate_patient_visit_tissue_cell"] == "YES" for row in patients), 0)

    expected = {
        "Brodalumab 140 mg Q2W": (46, 207, 45, 33, 42, 40, 40, 42, 42, 34, 25, 34, 25),
        "Brodalumab 210 mg Q2W": (42, 167, 38, 22, 31, 31, 29, 33, 32, 29, 26, 28, 25),
        "Placebo": (29, 117, 25, 10, 24, 25, 22, 27, 24, 2, 1, 2, 1),
        "Ustekinumab": (16, 74, 16, 13, 15, 14, 14, 15, 15, 14, 6, 14, 6),
        "Brodalumab combined": (88, 374, 83, 55, 73, 71, 69, 75, 74, 63, 51, 62, 50),
        "All public records": (133, 565, 124, 78, 112, 110, 105, 117, 113, 79, 58, 78, 57),
    }
    fields = ["n_patients", "n_public_arrays", "baseline_ls_nl_pairs", "ls_bl_w4_pairs",
              "ls_bl_w12_pairs", "nl_bl_w12_pairs", "complete_bl_w12_ls_nl",
              "outcome_evaluable_bl_w12", "baseline_ls_prediction_metadata_eligible",
              "pasi75_yes_among_outcome_evaluable", "pasi90_yes_among_outcome_evaluable",
              "pasi75_yes_among_prediction_eligible", "pasi90_yes_among_prediction_eligible"]
    for cohort, values in expected.items():
        check(f"cohort_present_{cohort}", cohort in cohorts, True)
        for field, value in zip(fields, values):
            check(f"{cohort}_{field}", cohorts[cohort][field], value)

    outcome = [row for row in patients if row["treatment"].startswith("Brodalumab") and row["outcome_evaluable_bl_w12"] == "YES"]
    prediction = [row for row in patients if row["treatment"].startswith("Brodalumab") and row["baseline_ls_prediction_metadata_eligible"] == "YES"]
    outcome_only = [row for row in outcome if row["baseline_ls_prediction_metadata_eligible"] == "NO"]
    check("brodalumab_outcome_evaluable", len(outcome), 75)
    check("brodalumab_pasi75_responders", sum(row["pasi75"] == "YES" for row in outcome), 63)
    check("brodalumab_pasi75_nonresponders", sum(row["pasi75"] == "NO" for row in outcome), 12)
    check("brodalumab_baseline_prediction_metadata_eligible", len(prediction), 74)
    check("brodalumab_prediction_pasi75_responders", sum(row["pasi75"] == "YES" for row in prediction), 62)
    check("brodalumab_prediction_pasi75_nonresponders", sum(row["pasi75"] == "NO" for row in prediction), 12)
    check("brodalumab_prediction_pasi90_responders", sum(row["pasi90"] == "YES" for row in prediction), 50)
    check("brodalumab_prediction_pasi90_nonresponders", sum(row["pasi90"] == "NO" for row in prediction), 24)
    check("outcome_only_missing_bl_ls", len(outcome_only), 1)
    check("outcome_only_patient", outcome_only[0]["patient_id"], "10266014010")

    check("source_rows", len(sources), 3)
    check("series_people", sources["GEO_SERIES_OVERALL_DESIGN"]["reported_people_or_ids"], 116)
    check("series_biopsies", sources["GEO_SERIES_OVERALL_DESIGN"]["reported_biopsies_or_arrays"], 844)
    check("public_people", sources["PUBLIC_GEO_SAMPLE_RECORDS"]["reported_people_or_ids"], 133)
    check("public_arrays", sources["PUBLIC_GEO_SAMPLE_RECORDS"]["reported_biopsies_or_arrays"], 565)
    check("public_ustekinumab_people", sources["PUBLIC_GEO_SAMPLE_RECORDS"]["ustekinumab_people"], 16)
    check("pubmed_response_subgroup", sources["PUBMED_PMID_31883845_ABSTRACT"]["outcome_subgroup"],
          "63 PASI75 responders plus 12 nonresponders (75 total)")

    write_tsv(ROOT / "audits" / "gse117468_integrity_checks.tsv", checks)
    print(f"PASS: {len(checks)} GSE117468 metadata integrity checks")


if __name__ == "__main__":
    main()
