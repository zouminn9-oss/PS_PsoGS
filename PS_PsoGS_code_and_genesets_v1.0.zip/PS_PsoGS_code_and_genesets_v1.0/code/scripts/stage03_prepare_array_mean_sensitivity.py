#!/usr/bin/env python3
"""Build a non-overwriting GSE30999 all-eligible-probe mean sensitivity matrix."""

from __future__ import annotations

import csv
import gzip
import math
from array import array
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOFT = ROOT / "metadata/geo_soft/GSE30999_family.soft.gz"
ANNOT = ROOT / "references/GPL570/GPL570.annot.gz"
OUT = ROOT / "results/stage03/sensitivity/gse30999_gcrma_entrez_gene_mean_matrix.tsv.gz"
AUDIT = ROOT / "audits/stage03_array_mean_preparation_checks.tsv"


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)


def main() -> None:
    checks = []

    def check(name: str, condition: bool, detail: object) -> None:
        checks.append({"check_id": name, "status": "PASS" if condition else "FAIL", "detail": detail})
        if not condition:
            write_tsv(AUDIT, checks)
            raise AssertionError(f"{name}: {detail}")

    probe_to_entrez = {}
    with gzip.open(ANNOT, "rt", encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            if line.startswith("ID\t"):
                header = line.rstrip("\r\n").split("\t"); break
        index = {name: i for i, name in enumerate(header)}
        rows = 0
        for line in handle:
            if line.startswith("!"):
                continue
            fields = line.rstrip("\r\n").split("\t"); rows += 1
            ids = {x.strip() for x in fields[index["Gene ID"]].split("///") if x.strip().isdigit()}
            if len(ids) == 1:
                probe_to_entrez[fields[index["ID"]]] = next(iter(ids))
    check("annotation_rows", rows == 54675, rows)
    check("eligible_probe_count", len(probe_to_entrez) > 30000, len(probe_to_entrez))

    sample_order = []
    vectors: dict[str, array] = {}
    current = ""
    with gzip.open(SOFT, "rt", encoding="utf-8", errors="replace") as handle:
        iterator = iter(handle)
        for line in iterator:
            if line.startswith("^SAMPLE = "):
                current = line.rstrip("\r\n").split(" = ", 1)[1]
            elif line.startswith("!sample_table_begin"):
                table_header = next(iterator).rstrip("\r\n")
                check(f"header::{current}", table_header == "ID_REF\tVALUE", table_header)
                sums = defaultdict(float); counts = defaultdict(int); table_rows = 0
                for data_line in iterator:
                    if data_line.startswith("!sample_table_end"):
                        break
                    probe, value_text = data_line.rstrip("\r\n").split("\t")
                    value = float(value_text); table_rows += 1
                    if not math.isfinite(value):
                        raise AssertionError(f"nonfinite {current}")
                    gene = probe_to_entrez.get(probe)
                    if gene is not None:
                        sums[gene] += value; counts[gene] += 1
                check(f"rows::{current}", table_rows == 54675, table_rows)
                sample_order.append(current)
                for gene in vectors:
                    vectors[gene].append(float("nan"))
                idx = len(sample_order) - 1
                for gene, total in sums.items():
                    if gene not in vectors:
                        vectors[gene] = array("d", [float("nan")] * len(sample_order))
                    vectors[gene][idx] = total / counts[gene]

    check("sample_count", len(sample_order) == 170, len(sample_order))
    check("unique_samples", len(set(sample_order)) == 170, len(set(sample_order)))
    check("gene_count", len(vectors) == 20848, len(vectors))
    check("complete_vectors", all(len(v) == 170 and all(math.isfinite(x) for x in v) for v in vectors.values()), len(vectors))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with gzip.open(OUT, "wt", encoding="utf-8", newline="") as handle:
        handle.write("entrez_id\t" + "\t".join(sample_order) + "\n")
        for gene in sorted(vectors, key=int):
            handle.write(gene + "\t" + "\t".join(format(x, ".10g") for x in vectors[gene]) + "\n")
    check("output_nonempty", OUT.stat().st_size > 1_000_000, OUT.stat().st_size)
    write_tsv(AUDIT, checks)
    print(f"PASS: GSE30999 all-probe mean sensitivity matrix, {len(checks)} checks")


if __name__ == "__main__":
    main()
