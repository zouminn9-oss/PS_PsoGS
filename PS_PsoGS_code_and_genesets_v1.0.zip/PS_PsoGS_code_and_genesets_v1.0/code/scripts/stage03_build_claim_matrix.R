options(stringsAsFactors = FALSE)
out_dir <- file.path("results", "stage03")
score <- read.delim(file.path(out_dir, "scores", "paired_score_statistics.tsv"), check.names = FALSE)
meta <- read.delim(file.path(out_dir, "scores", "score_meta.tsv"), check.names = FALSE)
specificity <- read.delim(file.path(out_dir, "specificity", "gse121212_pso_ad_direct_comparisons.tsv"), check.names = FALSE)
groups <- read.delim(file.path(out_dir, "specificity", "gse121212_pso_ad_group_statistics.tsv"), check.names = FALSE)
random <- read.delim(file.path(out_dir, "random_null", "random_signature_null_summary.tsv"), check.names = FALSE)
sensitivity <- read.delim(file.path(out_dir, "sensitivity", "stage03_sensitivity.tsv"), check.names = FALSE)
influence <- read.delim(file.path(out_dir, "influence", "stage03_influence_summary.tsv"), check.names = FALSE)
gene_summary <- read.delim(file.path(out_dir, "gene_replication_summary.tsv"), check.names = FALSE)
comparator_gate <- read.delim(file.path("metadata", "stage03_comparator_program_gate.tsv"), check.names = FALSE)

stopifnot(all(score$mean_delta > 0), all(score$t_p_value < 1e-10),
          abs(random$empirical_p_greater[1] - 1/2001) < 1e-15,
          abs(random$empirical_p_greater[2] - 1/2001) < 1e-15,
          all(influence$max_relative_loo_change < 0.005),
          all(sensitivity$ci_low[sensitivity$status == "ESTIMATED"] > 0),
          all(comparator_gate$gate_status == "BLOCKED"),
          groups$mean_delta[groups$group_id == "AD_ORDINARY"] > 0,
          specificity$ci_low[specificity$contrast_id == "PSO_MINUS_AD_ORDINARY"] > 0)

claim <- function(id, short, question, a_status, a_evidence, r_status, r_evidence,
                  synthesis_status, synthesis, allowed, prohibited) {
  data.frame(claim_id = id, short_label = short, claim_question = question,
    GSE30999_status = a_status, GSE30999_evidence = a_evidence,
    GSE121212_status = r_status, GSE121212_evidence = r_evidence,
    synthesis_status = synthesis_status, synthesis = synthesis,
    allowed_claim = allowed, prohibited_overreach = prohibited, stringsAsFactors = FALSE)
}

rows <- list(
  claim("C1", "Paired SEP shift", "Is the frozen SEP score higher in psoriasis lesions?",
        "PASS", "79/81 positive; mean 0.0741", "PASS", "27/27 positive; mean 0.0888", "PASS",
        "Positive paired shifts in both independent validation cohorts", "Lesion-associated SEP score rises in both cohorts", "Stress exposure or causality"),
  claim("C2", "Gene directions", "Do individual frozen members reproduce expected directions?",
        "PASS_WITH_LIMITATION", "2361/2679 concordant; 116 strict reverse", "PASS_WITH_LIMITATION", "2333/2572 concordant; 105 strict reverse", "PASS_WITH_LIMITATION",
        "Broad direction replication with preserved discordance", "Most tested members align directionally", "Universal gene-level replication"),
  claim("C3", "Cross-platform effect", "Are standardized paired effects consistent across platforms?",
        "PASS", "Hedges g 3.00", "PASS", "Hedges g 2.97", "PASS_WITH_LIMITATION",
        "Fixed summary g 3.00; heterogeneity unstable at k=2", "Large positive standardized effects on both platforms", "Proven homogeneity"),
  claim("C4", "PSO > ordinary AD", "Is the paired shift larger in PSO than ordinary AD?",
        "NOT_APPLICABLE", "No AD arm", "PASS", "Direct difference 0.0337; CI 0.0171 to 0.0503", "PASS_WITH_LIMITATION",
        "Supported in one RNA-seq cohort only", "PSO shows a larger shift than ordinary AD in GSE121212", "Cross-cohort disease specificity"),
  claim("C5", "PSO-exclusive", "Is the SEP lesion shift exclusive to psoriasis?",
        "NOT_APPLICABLE", "No AD arm", "FAIL", "ordinary AD mean 0.0551; 21/21 positive", "FAIL",
        "Positive ordinary-AD shifts refute exclusivity", "SEP is not psoriasis-exclusive", "Diagnostic specificity"),
  claim("C6", "Matched-random null", "Does SEP exceed size/expression-matched random signatures?",
        "PASS", "0/2000 exceed; P=1/2001", "PASS", "0/2000 exceed; P=1/2001", "PASS",
        "Exceeds coarse measurement-matched random sets", "Performance exceeds matched random signatures", "All confounding excluded"),
  claim("C7", "Subset/mapping robust", "Are effects stable to frozen subsets and array aggregation?",
        "PASS", "ratios 0.941 to 1.011", "PASS", "ratios 0.972 to 1.000", "PASS_WITH_LIMITATION",
        "Stable for estimable variants; array mean was post-primary deterministic", "Score is measurement-robust across reported variants", "Fully pre-registered multiverse"),
  claim("C8", "Clinical adjustment", "Do patient-level clinical covariates explain the effect?",
        "BLOCKED", "clinical fields unavailable", "BLOCKED", "clinical fields unavailable", "BLOCKED",
        "No covariate-adjusted model can be fitted", "Clinical adjustment is unresolved", "Unmeasured confounding removed"),
  claim("C9", "Single-gene influence", "Is the cohort mean dominated by one member?",
        "PASS", "max LOO change 0.492%", "PASS", "max LOO change 0.403%", "PASS",
        "No single measurable gene dominates the mean score", "Single-gene dominance is not observed", "Coordinated pathway confounding excluded"),
  claim("C10", "Beyond inflammation", "Is SEP independent of inflammation/IFN/proliferation programs?",
        "BLOCKED", "no pre-effect comparator package", "BLOCKED", "no pre-effect comparator package", "BLOCKED",
        "Biological comparator model not run", "Incremental information remains unresolved", "Inflammation-independent stress specificity"),
  claim("C11", "Stress causality", "Does validation show psychological stress causes psoriasis lesions?",
        "NOT_TESTED", "no stress exposure/intervention", "NOT_TESTED", "no stress exposure/intervention", "NOT_TESTED",
        "Stage 03 design cannot test exposure or causality", "None", "Psychological-stress exposure or causal mechanism")
)
matrix <- do.call(rbind, rows)
write.table(matrix, file.path(out_dir, "claim_matrix.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(data.frame(status = c("PASS", "PASS_WITH_LIMITATION", "FAIL", "BLOCKED", "NOT_TESTED", "NOT_APPLICABLE"),
                       n_synthesis_claims = as.integer(table(factor(matrix$synthesis_status,
                         levels = c("PASS", "PASS_WITH_LIMITATION", "FAIL", "BLOCKED", "NOT_TESTED", "NOT_APPLICABLE")))),
                       interpretation = c("supported within design", "supported with explicit ceiling", "claim contradicted", "required input absent", "design does not test claim", "cohort lacks relevant arm")),
            file.path(out_dir, "claim_matrix_summary.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: adjudicated %d Stage 03 claims without F1 feedback\n", nrow(matrix)))
