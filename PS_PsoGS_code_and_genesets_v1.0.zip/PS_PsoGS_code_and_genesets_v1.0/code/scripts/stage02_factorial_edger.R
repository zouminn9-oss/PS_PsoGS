options(stringsAsFactors = FALSE)

.libPaths(c(normalizePath(file.path("r_libs", "stage02")),
            normalizePath(file.path("r_libs", "stage01")), .libPaths()))
stopifnot(requireNamespace("edgeR", quietly = TRUE),
          requireNamespace("limma", quietly = TRUE),
          as.character(packageVersion("edgeR")) == "4.4.2",
          as.character(packageVersion("limma")) == "3.62.2")

count_path <- file.path("results", "stage02", "counts", "gse212126_gene_counts_frozen.tsv")
column_path <- file.path("results", "stage02", "counts", "gse212126_count_column_registry.tsv")
design_path <- file.path("results", "stage02", "gse212126_design_matrix.tsv")
contrast_path <- file.path("results", "stage02", "gse212126_contrast_matrix.tsv")
gene_registry_path <- file.path("metadata", "gencode_m25_mouse_gene_registry.tsv")
stopifnot(file.exists(count_path), file.exists(column_path),
          file.exists(design_path), file.exists(contrast_path), file.exists(gene_registry_path))

count_table <- read.delim(count_path, check.names = FALSE, stringsAsFactors = FALSE)
columns <- read.delim(column_path, check.names = FALSE, stringsAsFactors = FALSE)
design_table <- read.delim(design_path, check.names = FALSE, stringsAsFactors = FALSE)
contrast_table <- read.delim(contrast_path, check.names = FALSE, stringsAsFactors = FALSE)
gene_registry <- read.delim(gene_registry_path, check.names = FALSE, stringsAsFactors = FALSE)
stopifnot(nrow(columns) == 12L, length(unique(columns$srr)) == 12L,
          identical(colnames(count_table)[-1L], columns$srr),
          setequal(columns$srr, design_table$srr),
          all(c("Intercept", "CRS", "IMQ", "CRS_by_IMQ") %in% colnames(design_table)))

counts <- as.matrix(count_table[, columns$srr, drop = FALSE])
storage.mode(counts) <- "double"
rownames(counts) <- count_table$gene_id
stopifnot(!anyDuplicated(rownames(counts)), all(is.finite(counts)),
          all(counts >= 0), all(counts == round(counts)))
gene_registry <- gene_registry[match(rownames(counts), gene_registry$gene_id), , drop = FALSE]
stopifnot(!anyNA(gene_registry$gene_id), identical(gene_registry$gene_id, rownames(counts)))

design_table <- design_table[match(columns$srr, design_table$srr), , drop = FALSE]
design <- as.matrix(design_table[, c("Intercept", "CRS", "IMQ", "CRS_by_IMQ")])
storage.mode(design) <- "double"
rownames(design) <- design_table$srr
stopifnot(qr(design)$rank == 4L, identical(rownames(design), colnames(counts)))

contrast <- as.matrix(contrast_table[, c("S0", "SD", "I")])
storage.mode(contrast) <- "double"
rownames(contrast) <- contrast_table$coefficient
stopifnot(identical(rownames(contrast), colnames(design)),
          identical(as.numeric(contrast[, "S0"]), c(0, 1, 0, 0)),
          identical(as.numeric(contrast[, "SD"]), c(0, 1, 0, 1)),
          identical(as.numeric(contrast[, "I"]), c(0, 0, 0, 1)))

group <- factor(columns$condition, levels = c("Control", "CRS", "IMQ", "CRS+IMQ"))
y <- edgeR::DGEList(counts = counts, samples = data.frame(columns, group = group))
keep <- edgeR::filterByExpr(y, design = design)
if (sum(keep) < 1000L) stop("fewer than 1000 genes passed the frozen abundance filter")
y <- y[keep, , keep.lib.sizes = FALSE]
y <- edgeR::calcNormFactors(y, method = "TMM")
y <- edgeR::estimateDisp(y, design = design, robust = TRUE)
fit <- edgeR::glmQLFit(y, design = design, robust = TRUE)

out_root <- file.path("results", "stage02", "factorial_edger")
dir.create(out_root, recursive = TRUE, showWarnings = FALSE)
filter_audit <- data.frame(
  gene_id = rownames(counts),
  gene_name = gene_registry$gene_name,
  gene_type = gene_registry$gene_type,
  total_count = rowSums(counts),
  passed_filterByExpr = keep,
  filter_design = "~ CRS + IMQ + CRS:IMQ",
  filter_used_validation_data = FALSE,
  stringsAsFactors = FALSE
)
write.table(filter_audit, file.path(out_root, "gse212126_filterByExpr_audit.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

result_registry <- list()
for (estimand in colnames(contrast)) {
  test <- edgeR::glmQLFTest(fit, contrast = contrast[, estimand])
  table <- edgeR::topTags(test, n = Inf, sort.by = "none")$table
  table$gene_id <- rownames(table)
  annotation_index <- match(table$gene_id, gene_registry$gene_id)
  stopifnot(!anyNA(annotation_index))
  table$gene_name <- gene_registry$gene_name[annotation_index]
  table$gene_type <- gene_registry$gene_type[annotation_index]
  table$estimand <- estimand
  table$significant_FDR_0_05 <- table$FDR < 0.05
  table$direction <- ifelse(table$logFC > 0, "UP", ifelse(table$logFC < 0, "DOWN", "ZERO"))
  table <- table[, c("gene_id", "gene_name", "gene_type", "estimand", "logFC", "logCPM", "F", "PValue", "FDR",
                     "significant_FDR_0_05", "direction")]
  write.table(table, file.path(out_root, paste0("gse212126_", estimand, "_all_genes.tsv")),
              sep = "\t", quote = FALSE, row.names = FALSE)
  result_registry[[estimand]] <- data.frame(
    estimand = estimand,
    tested_genes = nrow(table),
    FDR_lt_0_05 = sum(table$FDR < 0.05),
    FDR_lt_0_05_up = sum(table$FDR < 0.05 & table$logFC > 0),
    FDR_lt_0_05_down = sum(table$FDR < 0.05 & table$logFC < 0),
    threshold_changed_after_results = FALSE,
    validation_expression_accessed = FALSE,
    stringsAsFactors = FALSE
  )
}
write.table(do.call(rbind, result_registry),
            file.path(out_root, "gse212126_estimand_result_registry.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

logcpm <- edgeR::cpm(y, log = TRUE, prior.count = 2)
logcpm_index <- match(rownames(logcpm), gene_registry$gene_id)
stopifnot(!anyNA(logcpm_index))
write.table(data.frame(gene_id = rownames(logcpm),
                       gene_name = gene_registry$gene_name[logcpm_index],
                       gene_type = gene_registry$gene_type[logcpm_index],
                       logcpm, check.names = FALSE),
            file.path(out_root, "gse212126_TMM_logCPM.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
pca <- prcomp(t(logcpm), center = TRUE, scale. = FALSE)
pca_table <- data.frame(
  srr = rownames(pca$x),
  canonical_animal_id = columns$canonical_animal_id[match(rownames(pca$x), columns$srr)],
  condition = columns$condition[match(rownames(pca$x), columns$srr)],
  PC1 = pca$x[, 1L],
  PC2 = pca$x[, 2L],
  stringsAsFactors = FALSE
)
write.table(pca_table, file.path(out_root, "gse212126_PCA_coordinates.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(data.frame(PC = seq_along(pca$sdev),
                       variance_explained = pca$sdev^2 / sum(pca$sdev^2)),
            file.path(out_root, "gse212126_PCA_variance.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

library_qc <- data.frame(
  srr = colnames(y),
  canonical_animal_id = columns$canonical_animal_id,
  condition = columns$condition,
  raw_library_size = colSums(counts),
  filtered_library_size = y$samples$lib.size,
  TMM_norm_factor = y$samples$norm.factors,
  effective_library_size = y$samples$lib.size * y$samples$norm.factors,
  statistical_unit = "independent_mouse",
  stringsAsFactors = FALSE
)
write.table(library_qc, file.path(out_root, "gse212126_library_QC.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
saveRDS(list(y = y, design = design, contrasts = contrast, fit = fit),
        file.path(out_root, "gse212126_edgeR_QL_fit.rds"))
capture.output(sessionInfo(), file = file.path(out_root, "gse212126_sessionInfo.txt"))
cat("PASS: fitted frozen 12-mouse edgeR QL model and exported all predefined estimands\n")
