options(stringsAsFactors = FALSE)
.libPaths(c(normalizePath(file.path("r_libs", "stage02")),
            normalizePath(file.path("r_libs", "stage01")), .libPaths()))
stopifnot(requireNamespace("edgeR", quietly = TRUE))
out_dir <- file.path("results", "stage03", "influence")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create("logs", showWarnings = FALSE)
log_con <- file(file.path("logs", "stage03_score_influence.log"), open = "wt")
sink(log_con, type = "output", split = TRUE); sink(log_con, type = "message")
on.exit({sink(type = "message"); sink(type = "output"); close(log_con)}, add = TRUE)

sep <- read.delim(file.path("genesets", "SEP_v1.0.tsv"), check.names = FALSE)
lock <- read.delim(file.path("metadata", "stage03_validation_sample_lock.tsv"), check.names = FALSE)
pairs <- read.delim(file.path("metadata", "gse30999_metadata_pair_registry.tsv"), check.names = FALSE)
pairs <- pairs[pairs$metadata_pair_status == "COMPLETE_EXACT_ID_PAIR", ]
primary <- read.delim(file.path("results", "stage03", "scores", "paired_score_statistics.tsv"), check.names = FALSE)
stopifnot(nrow(sep) == 2716L)

array_df <- read.delim(gzfile(file.path("results", "stage03", "matrices", "gse30999_gcrma_entrez_gene_matrix.tsv.gz")), check.names = FALSE)
array_ids <- as.character(array_df[[1]])
array_mat <- as.matrix(array_df[-1]); storage.mode(array_mat) <- "double"; rownames(array_mat) <- array_ids
array_samples <- c(pairs$nl_gsm, pairs$ls_gsm)
array_ranks <- apply(array_mat[, array_samples, drop = FALSE], 2, rank, ties.method = "average") / (nrow(array_mat) + 1)
array_gene_delta <- array_ranks[, pairs$ls_gsm, drop = FALSE] - array_ranks[, pairs$nl_gsm, drop = FALSE]
colnames(array_gene_delta) <- pairs$public_subject_id

count_df <- read.delim(gzfile(file.path("data", "raw", "validation", "GSE121212", "GSE121212_readcount.txt.gz")), check.names = FALSE)
count_ids <- as.character(count_df[[1]])
count_mat <- as.matrix(count_df[-1]); storage.mode(count_mat) <- "integer"
count_mat <- rowsum(count_mat, group = count_ids, reorder = FALSE)
y <- edgeR::DGEList(counts = count_mat); y <- edgeR::calcNormFactors(y, method = "TMM")
rna_mat <- edgeR::cpm(y, log = TRUE, prior.count = 2)
rna_lock <- lock[lock$dataset_id == "GSE121212" & lock$lock_status == "PRIMARY_INCLUDE", ]
rna_ranks <- apply(rna_mat[, rna_lock$sample_title, drop = FALSE], 2, rank, ties.method = "average") / (nrow(rna_mat) + 1)
rna_pairs <- split(rna_lock, rna_lock$donor_id)
rna_gene_delta <- do.call(cbind, lapply(rna_pairs, function(z) {
  rna_ranks[, z$sample_title[z$skin_type == "lesional"]] - rna_ranks[, z$sample_title[z$skin_type == "non-lesional"]]
}))
colnames(rna_gene_delta) <- names(rna_pairs)

influence_one <- function(dataset_id, gene_delta, feature_ids, id_field) {
  ids <- as.character(sep[[id_field]])
  measurable <- ids %in% feature_ids
  up_idx <- which(sep$sep_direction == "UP" & measurable)
  down_idx <- which(sep$sep_direction == "DOWN" & measurable)
  up_mat <- gene_delta[match(ids[up_idx], feature_ids), , drop = FALSE]
  down_mat <- gene_delta[match(ids[down_idx], feature_ids), , drop = FALSE]
  mean_up_patient <- colMeans(up_mat); mean_down_patient <- colMeans(down_mat)
  primary_patient <- mean_up_patient - mean_down_patient
  observed_primary <- primary$mean_delta[primary$dataset_id == dataset_id]
  stopifnot(abs(mean(primary_patient) - observed_primary) < 1e-12)
  result <- data.frame(dataset_id = dataset_id, human_gene_symbol = sep$human_gene_symbol,
    human_entrez_id = sep$selected_human_entrez_id, sep_direction = sep$sep_direction,
    platform_feature_id = ids, measurement_status = ifelse(measurable, "MEASURABLE", "NOT_MAPPABLE"),
    n_direction_measurable = ifelse(sep$sep_direction == "UP", length(up_idx), length(down_idx)),
    primary_mean_effect = observed_primary, loo_mean_effect = NA_real_, change_from_primary = NA_real_,
    absolute_change = NA_real_, relative_absolute_change = NA_real_,
    max_absolute_patient_change = NA_real_, stringsAsFactors = FALSE)
  for (idx in up_idx) {
    gd <- gene_delta[match(ids[idx], feature_ids), ]
    patient_change <- (mean_up_patient - gd) / (length(up_idx) - 1L)
    result$change_from_primary[idx] <- mean(patient_change)
    result$loo_mean_effect[idx] <- observed_primary + result$change_from_primary[idx]
    result$absolute_change[idx] <- abs(result$change_from_primary[idx])
    result$relative_absolute_change[idx] <- result$absolute_change[idx] / abs(observed_primary)
    result$max_absolute_patient_change[idx] <- max(abs(patient_change))
  }
  for (idx in down_idx) {
    gd <- gene_delta[match(ids[idx], feature_ids), ]
    patient_change <- (gd - mean_down_patient) / (length(down_idx) - 1L)
    result$change_from_primary[idx] <- mean(patient_change)
    result$loo_mean_effect[idx] <- observed_primary + result$change_from_primary[idx]
    result$absolute_change[idx] <- abs(result$change_from_primary[idx])
    result$relative_absolute_change[idx] <- result$absolute_change[idx] / abs(observed_primary)
    result$max_absolute_patient_change[idx] <- max(abs(patient_change))
  }
  result$influence_rank <- NA_integer_
  ranked <- order(result$absolute_change, decreasing = TRUE, na.last = NA)
  result$influence_rank[ranked] <- seq_along(ranked)
  coverage <- do.call(rbind, lapply(c("UP", "DOWN"), function(direction) {
    z <- result[result$sep_direction == direction, ]
    data.frame(dataset_id = dataset_id, sep_direction = direction, frozen_members = nrow(z),
      measurable_members = sum(z$measurement_status == "MEASURABLE"),
      missing_members = sum(z$measurement_status != "MEASURABLE"),
      coverage_fraction = mean(z$measurement_status == "MEASURABLE"),
      minimum_required = 0.70,
      samples_below_threshold = 0L, stringsAsFactors = FALSE)
  }))
  list(result = result, coverage = coverage, patient_primary = primary_patient)
}

array <- influence_one("GSE30999", array_gene_delta, array_ids, "selected_human_entrez_id")
rna <- influence_one("GSE121212", rna_gene_delta, rownames(rna_gene_delta), "human_gene_symbol")
influence <- rbind(array$result, rna$result)
coverage <- rbind(array$coverage, rna$coverage)
summary <- do.call(rbind, lapply(split(influence, influence$dataset_id), function(z) {
  m <- z[z$measurement_status == "MEASURABLE", ]
  top <- m[which.max(m$absolute_change), ]
  data.frame(dataset_id = z$dataset_id[1], frozen_members = nrow(z), measurable_members = nrow(m),
    coverage_fraction = nrow(m) / nrow(z), primary_mean_effect = unique(z$primary_mean_effect),
    max_absolute_loo_change = max(m$absolute_change),
    max_relative_loo_change = max(m$relative_absolute_change),
    most_influential_gene = top$human_gene_symbol,
    most_influential_direction = top$sep_direction,
    most_influential_loo_effect = top$loo_mean_effect,
    max_patient_level_change = max(m$max_absolute_patient_change),
    stringsAsFactors = FALSE)
}))
write.table(influence, file.path(out_dir, "stage03_gene_leave_one_out.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(coverage, file.path(out_dir, "stage03_score_coverage.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(summary, file.path(out_dir, "stage03_influence_summary.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: %d complete frozen-member rows; max relative LOO %.6g and %.6g\n",
            nrow(influence), summary$max_relative_loo_change[summary$dataset_id == "GSE30999"],
            summary$max_relative_loo_change[summary$dataset_id == "GSE121212"]))
