from pathlib import Path
import csv

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "panel_manifest.tsv"
with path.open(encoding="utf-8", newline="") as f:
    rows = list(csv.DictReader(f, delimiter="\t"))
fields = list(rows[0])
ready = {"6A", "6B", "6C", "6D", "6E", "6F", "6G", "6K", "6L"}
blocked = {
    "6H": "BLOCKED_BY_PRIMARY_PAPER_QUALITY_LIMITATION",
    "6I": "BLOCKED_BY_PRIMARY_PAPER_QUALITY_LIMITATION",
    "6J": "BLOCKED_BY_PRIMARY_PAPER_QUALITY_LIMITATION",
}
for row in rows:
    pid = row["panel_id"]
    if pid in ready:
        low = pid.lower()
        row.update({
            "analysis_script": "scripts/figures/figure6_analysis.py",
            "plot_script": "scripts/figures/figure6_plot.py",
            "source_data": f"figures/source_data/fig{low}.tsv",
            "statistics_file": f"results/figures/fig{low}_statistics.tsv",
            "config_file": f"config/figures/fig{low}.yaml",
            "vector_output": f"figures/panels/fig{low}.svg",
            "preview_output": f"figures/previews/fig{low}.png",
            "status": "PASS", "qa_status": "PASS_RENDER_DATA_PRINT", "figure_ready": "YES",
        })
    elif pid in blocked:
        row.update({"status": blocked[pid], "qa_status": "NOT_RENDERED_INPUT_BLOCK", "figure_ready": "NO"})
with path.open("w", encoding="utf-8", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=fields, delimiter="\t", lineterminator="\n")
    writer.writeheader(); writer.writerows(rows)
print("PASS: registered Stage 06 terminal Figure 6 states")
