#!/usr/bin/env python3
"""Read-only structural inspection of the two GSE212126 XLSX files.

The bundled spreadsheet importer did not complete on these gene-scale sheets, so
this fallback uses only the documented OOXML ZIP/XML structure. It does not edit
or re-save the source workbooks.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
OUT = ROOT / "audits" / "gse212126_workbook_audit.tsv"
DETAIL = ROOT / "audits" / "gse212126_workbook_preview.json"
NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"


def col_index(ref: str) -> int:
    letters = re.match(r"[A-Z]+", ref).group(0)
    value = 0
    for letter in letters:
        value = value * 26 + ord(letter) - 64
    return value


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def shared_strings(book: zipfile.ZipFile) -> list[str]:
    if "xl/sharedStrings.xml" not in book.namelist():
        return []
    root = ET.fromstring(book.read("xl/sharedStrings.xml"))
    values = []
    for item in root.findall(f"{NS}si"):
        values.append("".join(node.text or "" for node in item.iter(f"{NS}t")))
    return values


def inspect(path: Path) -> tuple[dict[str, str], dict, list[str]]:
    with zipfile.ZipFile(path) as book:
        strings = shared_strings(book)
        sheet_xml = book.read("xl/worksheets/sheet1.xml")
        root = ET.fromstring(sheet_xml)
        dimension_node = root.find(f"{NS}dimension")
        dimension = dimension_node.attrib.get("ref", "") if dimension_node is not None else ""
        rows = root.findall(f".//{NS}sheetData/{NS}row")
        previews = []
        formula_cells = 0
        numeric_cells = 0
        text_cells = 0
        max_col = 0
        gene_ids: list[str] = []
        matrix_cells = 0
        matrix_missing = 0
        matrix_negative = 0
        for row in rows:
            values: dict[int, object] = {}
            for cell in row.findall(f"{NS}c"):
                idx = col_index(cell.attrib["r"])
                max_col = max(max_col, idx)
                if cell.find(f"{NS}f") is not None:
                    formula_cells += 1
                value_node = cell.find(f"{NS}v")
                value: object = "" if value_node is None else value_node.text or ""
                if cell.attrib.get("t") == "s" and value != "":
                    value = strings[int(value)]
                    text_cells += 1
                elif cell.attrib.get("t") in {"inlineStr", "str"}:
                    text_cells += 1
                elif value != "":
                    numeric_cells += 1
                values[idx] = value
            row_number = int(row.attrib.get("r", "0"))
            if row_number > 1:
                gene_ids.append(str(values.get(1, "")))
                for idx in range(10, 16):
                    matrix_cells += 1
                    item = values.get(idx, "")
                    if item == "":
                        matrix_missing += 1
                    else:
                        try:
                            if float(item) < 0:
                                matrix_negative += 1
                        except ValueError:
                            matrix_missing += 1
            if len(previews) < 8:
                previews.append([values.get(i, "") for i in range(1, max(max_col, 1) + 1)])
        header = [str(x) for x in previews[0]] if previews else []
        sample_like = [
            item for item in header
            if re.search(r"(?:ctrl|crs|imq|rep|sample|fpkm)", item, flags=re.I)
        ]
        audit = {
            "file": str(path.relative_to(ROOT)),
            "bytes": str(path.stat().st_size),
            "sha256": sha256(path),
            "sheet_count": "1",
            "sheet_dimension": dimension,
            "row_count_xml": str(len(rows)),
            "max_column_index": str(max_col),
            "formula_cell_count": str(formula_cells),
            "numeric_cell_count": str(numeric_cells),
            "text_cell_count": str(text_cells),
            "header": " | ".join(header),
            "sample_like_headers": " | ".join(sample_like),
            "gene_id_count": str(len(gene_ids)),
            "unique_gene_id_count": str(len(set(gene_ids))),
            "duplicate_gene_id_count": str(len(gene_ids) - len(set(gene_ids))),
            "fpkm_matrix_cell_count": str(matrix_cells),
            "fpkm_missing_or_nonnumeric_count": str(matrix_missing),
            "fpkm_negative_count": str(matrix_negative),
            "formal_interaction_input_status": "FAIL_FPKM_NOT_RAW_COUNTS",
            "inspection_method": "read-only OOXML ZIP/XML fallback",
        }
        detail = {"file": audit["file"], "dimension": dimension, "preview_rows": previews}
        return audit, detail, gene_ids


def main() -> None:
    files = sorted(RAW.glob("GSE212126*.xlsx"))
    audits, details, gene_lists = zip(*(inspect(path) for path in files))
    cross_file = {
        "same_gene_id_order": gene_lists[0] == gene_lists[1],
        "same_gene_id_set": set(gene_lists[0]) == set(gene_lists[1]),
        "shared_gene_ids": len(set(gene_lists[0]).intersection(gene_lists[1])),
        "interpretation": "The two files can be joined for descriptive FPKM QC, but FPKM must not be treated as raw counts for the confirmatory interaction model.",
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(audits[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(audits)
    DETAIL.write_text(json.dumps({"workbooks": details, "cross_file": cross_file}, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
