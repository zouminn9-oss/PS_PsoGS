from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parents[1]; path=ROOT/"panel_manifest.tsv"
with path.open(encoding="utf-8",newline="") as f: rows=list(csv.DictReader(f,delimiter="\t"))
fields=list(rows[0]); ready={"7H","7I","7J"}; blocked={"7K":"BLOCKED_ONLY_12_NONEVENTS_AND_NO_PRESPECIFIED_SELECTION","7L":"BLOCKED_NO_MATCHED_MULTIVIEW_PATIENT_MATRIX"}
for row in rows:
  pid=row["panel_id"]
  if pid in ready:
    low=pid.lower(); row.update({"analysis_script":"scripts/figures/figure7_bulk_analysis.py","plot_script":"scripts/figures/figure7_bulk_plot.py","source_data":f"figures/source_data/fig{low}.tsv","statistics_file":f"results/figures/fig{low}_statistics.tsv","config_file":f"config/figures/fig{low}.yaml","vector_output":f"figures/panels/fig{low}.svg","preview_output":f"figures/previews/fig{low}.png","status":"PASS","qa_status":"PASS_RENDER_DATA_PRINT","figure_ready":"YES"})
  elif pid in blocked: row.update({"status":blocked[pid],"qa_status":"NOT_RENDERED_INPUT_BLOCK","figure_ready":"NO"})
with path.open("w",encoding="utf-8",newline="") as f:
  w=csv.DictWriter(f,fieldnames=fields,delimiter="\t",lineterminator="\n"); w.writeheader(); w.writerows(rows)
print("PASS: registered Stage 07 bulk panels and terminal blocks")
