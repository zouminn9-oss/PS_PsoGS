#!/usr/bin/env python3
"""Build complete frozen-SEP gene-level validation states without outcome selection."""

from __future__ import annotations

import csv
import gzip
import math
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/stage03/gene_replication.tsv"
SUMMARY = ROOT / "results/stage03/gene_replication_summary.tsv"


def read_tsv(path: Path, compressed: bool = False) -> list[dict[str, str]]:
    opener = gzip.open if compressed else open
    mode = "rt" if compressed else "r"
    with opener(path, mode, encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)


def classify(logfc: float, fdr: float, expected_sign: int) -> tuple[str, bool, bool]:
    signed = logfc * expected_sign
    concordant = signed > 0
    strict = concordant and fdr < 0.05
    if signed == 0:
        return "ZERO_EFFECT", False, False
    direction = "CONCORDANT" if concordant else "DISCORDANT"
    significance = "FDR_LT_0.05" if fdr < 0.05 else "FDR_GE_0.05"
    return f"{direction}_{significance}", concordant, strict


def main() -> None:
    signature = read_tsv(ROOT / "genesets/SEP_v1.0.tsv")
    array_rows = read_tsv(ROOT / "results/stage03/effects/gse30999_paired_all_genes.tsv")
    rna_rows = read_tsv(ROOT / "results/stage03/effects/gse121212_pso_paired_all_tested_genes.tsv")
    coverage = read_tsv(ROOT / "metadata/stage03_platform_coverage.tsv")
    with gzip.open(ROOT / "data/raw/validation/GSE121212/GSE121212_readcount.txt.gz",
                   "rt", encoding="utf-8-sig", newline="") as handle:
        raw_features = {line.split("\t", 1)[0] for line in handle if line.strip()}
    raw_features.discard("Gene")

    if len(signature) != 2716 or len({r["human_gene_symbol"] for r in signature}) != 2716:
        raise AssertionError("SEP must contain 2716 unique human symbols")
    if Counter(r["sep_direction"] for r in signature) != Counter({"UP": 1399, "DOWN": 1317}):
        raise AssertionError("unexpected frozen SEP direction counts")
    array = {r["entrez_id"]: r for r in array_rows}
    rna = {r["human_gene_symbol"]: r for r in rna_rows}
    if len(array) != 20848 or len(rna) != 24382:
        raise AssertionError("validation effect tables changed")

    output: list[dict[str, object]] = []
    for frozen_order, gene in enumerate(signature, start=1):
        symbol = gene["human_gene_symbol"]
        entrez = gene["selected_human_entrez_id"]
        direction = gene["sep_direction"]
        expected_sign = 1 if direction == "UP" else -1
        array_effect = array.get(entrez)
        rna_effect = rna.get(symbol)
        rna_mappable = symbol in raw_features

        if array_effect is None:
            array_state, array_concordant, array_strict = "NOT_PLATFORM_MAPPABLE", False, False
            array_logfc = array_p = array_fdr = array_stat = ""
        else:
            array_logfc = float(array_effect["logFC"])
            array_p = float(array_effect["PValue"])
            array_fdr = float(array_effect["FDR"])
            array_stat = float(array_effect["t"])
            array_state, array_concordant, array_strict = classify(
                array_logfc, array_fdr, expected_sign)

        if not rna_mappable:
            rna_state, rna_concordant, rna_strict = "NOT_PLATFORM_MAPPABLE", False, False
            rna_logfc = rna_p = rna_fdr = rna_stat = ""
        elif rna_effect is None:
            rna_state, rna_concordant, rna_strict = "FILTERED_LOW_EXPRESSION", False, False
            rna_logfc = rna_p = rna_fdr = rna_stat = ""
        else:
            rna_logfc = float(rna_effect["logFC"])
            rna_p = float(rna_effect["PValue"])
            rna_fdr = float(rna_effect["FDR"])
            rna_stat = math.copysign(math.sqrt(float(rna_effect["F"])), rna_logfc)
            rna_state, rna_concordant, rna_strict = classify(rna_logfc, rna_fdr, expected_sign)

        array_tested = array_effect is not None
        rna_tested = rna_effect is not None
        if array_tested and rna_tested:
            if array_concordant and rna_concordant:
                cross_state = "BOTH_DIRECTION_CONCORDANT"
            elif not array_concordant and not rna_concordant:
                cross_state = "BOTH_DIRECTION_DISCORDANT"
            else:
                cross_state = "MIXED_DIRECTION"
        elif array_tested:
            cross_state = "ARRAY_ONLY_TESTED_CONCORDANT" if array_concordant else "ARRAY_ONLY_TESTED_DISCORDANT"
        elif rna_tested:
            cross_state = "RNASEQ_ONLY_TESTED_CONCORDANT" if rna_concordant else "RNASEQ_ONLY_TESTED_DISCORDANT"
        else:
            cross_state = "NOT_TESTED_EITHER"

        output.append({
            "frozen_order": frozen_order,
            "human_gene_symbol": symbol,
            "selected_human_entrez_id": entrez,
            "sep_direction": direction,
            "expected_sign": expected_sign,
            "discovery_SD_logFC": gene["SD_logFC"],
            "discovery_SD_FDR": gene["SD_FDR"],
            "discovery_H_logFC": gene["H_logFC"],
            "discovery_H_FDR": gene["H_FDR"],
            "array_platform_mappable": "YES" if array_tested else "NO",
            "array_tested": "YES" if array_tested else "NO",
            "array_logFC": array_logfc,
            "array_test_statistic": array_stat,
            "array_PValue": array_p,
            "array_FDR": array_fdr,
            "array_state": array_state,
            "array_direction_concordant": "YES" if array_concordant else "NO",
            "array_strict_replication": "YES" if array_strict else "NO",
            "rnaseq_platform_mappable": "YES" if rna_mappable else "NO",
            "rnaseq_tested": "YES" if rna_tested else "NO",
            "rnaseq_logFC": rna_logfc,
            "rnaseq_signed_sqrt_F": rna_stat,
            "rnaseq_PValue": rna_p,
            "rnaseq_FDR": rna_fdr,
            "rnaseq_state": rna_state,
            "rnaseq_direction_concordant": "YES" if rna_concordant else "NO",
            "rnaseq_strict_replication": "YES" if rna_strict else "NO",
            "both_tested": "YES" if array_tested and rna_tested else "NO",
            "both_direction_concordant": "YES" if array_tested and rna_tested and array_concordant and rna_concordant else "NO",
            "both_strict_replication": "YES" if array_strict and rna_strict else "NO",
            "cross_cohort_state": cross_state,
        })

    expected_coverage = {(r["dataset_id"], r["signature_id"]): int(r["measurable_members"])
                         for r in coverage}
    if sum(r["array_platform_mappable"] == "YES" for r in output) != expected_coverage[("GSE30999", "SEP")]:
        raise AssertionError("array SEP coverage mismatch")
    if sum(r["rnaseq_platform_mappable"] == "YES" for r in output) != expected_coverage[("GSE121212", "SEP")]:
        raise AssertionError("RNA-seq SEP coverage mismatch")

    summary: list[dict[str, object]] = []
    for dataset, prefix in (("GSE30999", "array"), ("GSE121212", "rnaseq")):
        for stratum in ("ALL", "UP", "DOWN"):
            rows = output if stratum == "ALL" else [r for r in output if r["sep_direction"] == stratum]
            tested = [r for r in rows if r[f"{prefix}_tested"] == "YES"]
            mappable = [r for r in rows if r[f"{prefix}_platform_mappable"] == "YES"]
            concordant = sum(r[f"{prefix}_direction_concordant"] == "YES" for r in tested)
            strict = sum(r[f"{prefix}_strict_replication"] == "YES" for r in tested)
            discordant_fdr = sum(r[f"{prefix}_state"] == "DISCORDANT_FDR_LT_0.05" for r in tested)
            summary.append({
                "summary_type": "COHORT_DIRECTION",
                "dataset_id": dataset,
                "direction_stratum": stratum,
                "frozen_members": len(rows),
                "platform_mappable": len(mappable),
                "tested_members": len(tested),
                "filtered_low_expression": sum(r[f"{prefix}_state"] == "FILTERED_LOW_EXPRESSION" for r in rows),
                "not_platform_mappable": sum(r[f"{prefix}_state"] == "NOT_PLATFORM_MAPPABLE" for r in rows),
                "direction_concordant": concordant,
                "direction_discordant": len(tested) - concordant,
                "strict_replication": strict,
                "discordant_FDR_lt_0.05": discordant_fdr,
                "direction_concordance_rate_tested": concordant / len(tested),
                "strict_replication_rate_tested": strict / len(tested),
                "strict_replication_rate_frozen": strict / len(rows),
            })

    for stratum in ("ALL", "UP", "DOWN"):
        rows = output if stratum == "ALL" else [r for r in output if r["sep_direction"] == stratum]
        both = [r for r in rows if r["both_tested"] == "YES"]
        summary.append({
            "summary_type": "CROSS_COHORT",
            "dataset_id": "BOTH",
            "direction_stratum": stratum,
            "frozen_members": len(rows),
            "platform_mappable": "",
            "tested_members": len(both),
            "filtered_low_expression": "",
            "not_platform_mappable": "",
            "direction_concordant": sum(r["both_direction_concordant"] == "YES" for r in both),
            "direction_discordant": sum(r["cross_cohort_state"] == "BOTH_DIRECTION_DISCORDANT" for r in both),
            "strict_replication": sum(r["both_strict_replication"] == "YES" for r in both),
            "discordant_FDR_lt_0.05": sum(
                r["array_state"] == "DISCORDANT_FDR_LT_0.05" or r["rnaseq_state"] == "DISCORDANT_FDR_LT_0.05"
                for r in both),
            "direction_concordance_rate_tested": sum(r["both_direction_concordant"] == "YES" for r in both) / len(both),
            "strict_replication_rate_tested": sum(r["both_strict_replication"] == "YES" for r in both) / len(both),
            "strict_replication_rate_frozen": sum(r["both_strict_replication"] == "YES" for r in rows) / len(rows),
        })

    write_tsv(OUT, output)
    write_tsv(SUMMARY, summary)
    print(f"PASS: wrote {len(output)} frozen SEP gene states and {len(summary)} summary rows")


if __name__ == "__main__":
    main()
