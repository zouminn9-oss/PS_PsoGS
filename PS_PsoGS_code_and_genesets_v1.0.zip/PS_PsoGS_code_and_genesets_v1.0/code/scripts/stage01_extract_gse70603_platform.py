#!/usr/bin/env python3
"""Extract GPL17077 platform annotation and audit GSE70603 probe coverage."""

from __future__ import annotations

import csv
import gzip
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOFT = ROOT / "metadata" / "geo_soft" / "GSE70603_family.soft.gz"
MATRIX = ROOT / "data" / "processed" / "GSE70603_processed_log2_matrix.tsv.gz"
OUTPUT = ROOT / "metadata" / "gse70603_platform_annotation.tsv"
AUDIT = ROOT / "audits" / "gse70603_platform_audit.tsv"


def write_tsv(path, rows, fields=None):
    fields = fields or list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n", extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def main():
    rows, header, in_table = [], [], False
    with gzip.open(SOFT, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            line = raw.rstrip("\r\n")
            if line == "!platform_table_begin":
                in_table, header = True, []
            elif line == "!platform_table_end" and in_table:
                break
            elif in_table and not header:
                header = line.split("\t")
            elif in_table and line:
                parts = line.split("\t")
                rows.append(dict(zip(header, parts)))
    assert rows and header
    id_field = "ID" if "ID" in header else "ID_REF"
    symbol_field = next((field for field in ("GENE_SYMBOL", "Gene Symbol", "GENE", "gene_assignment") if field in header), "")
    ids = [row[id_field].strip('"') for row in rows]
    with gzip.open(MATRIX, "rt", encoding="utf-8") as handle:
        next(handle)
        matrix_ids = [line.split("\t", 1)[0] for line in handle]
    annotation_ids = set(ids)
    matrix_set = set(matrix_ids)
    mapped_symbol = 0
    if symbol_field:
        mapped_symbol = sum(bool(row.get(symbol_field, "").strip().strip('"')) for row in rows if row[id_field].strip('"') in matrix_set)
    write_tsv(OUTPUT, rows, header)
    audit = [
        {"check":"platform_rows","observed":len(rows),"expected":"nonzero","status":"PASS"},
        {"check":"platform_header","observed":" | ".join(header),"expected":"recorded","status":"PASS"},
        {"check":"platform_id_field","observed":id_field,"expected":"ID","status":"PASS" if id_field=="ID" else "PARTIAL"},
        {"check":"symbol_field","observed":symbol_field,"expected":"available","status":"PASS" if symbol_field else "FAIL"},
        {"check":"duplicate_platform_ids","observed":len(ids)-len(annotation_ids),"expected":0,"status":"PASS" if len(ids)==len(annotation_ids) else "FAIL"},
        {"check":"matrix_probe_count","observed":len(matrix_ids),"expected":50599,"status":"PASS" if len(matrix_ids)==50599 else "FAIL"},
        {"check":"matrix_probes_in_platform","observed":len(matrix_set & annotation_ids),"expected":len(matrix_set),"status":"PASS" if matrix_set <= annotation_ids else "FAIL"},
        {"check":"matrix_probes_with_nonempty_symbol","observed":mapped_symbol,"expected":"report coverage; do not drop silently","status":"PASS"},
    ]
    write_tsv(AUDIT, audit)
    assert len(ids) == len(annotation_ids) and matrix_set <= annotation_ids and symbol_field
    print(f"PASS: platform={len(rows)} rows; matrix coverage={len(matrix_set & annotation_ids)}/{len(matrix_set)}; symbol field={symbol_field}; nonempty symbols={mapped_symbol}")


if __name__ == "__main__":
    main()
