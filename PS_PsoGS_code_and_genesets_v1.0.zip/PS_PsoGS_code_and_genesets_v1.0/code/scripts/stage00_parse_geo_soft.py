#!/usr/bin/env python3
"""Parse cached GEO SOFT metadata into auditable Stage 00 TSVs.

This script never downloads data and never infers that a labelled replicate is an
independent donor/animal. Dataset-specific biological-unit adjudication remains a
manual audit step in metadata/sample_manifest.tsv.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import re
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOFT_DIR = ROOT / "metadata" / "geo_soft"


def open_text(path: Path):
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return path.open("rt", encoding="utf-8", errors="replace")


def add_field(record: dict[str, list[str]], key: str, value: str) -> None:
    record.setdefault(key, []).append(value.strip())


def parse_soft(path: Path) -> tuple[dict[str, list[str]], list[dict[str, list[str]]]]:
    series: dict[str, list[str]] = {}
    samples: list[dict[str, list[str]]] = []
    current: dict[str, list[str]] | None = None
    section = ""
    with open_text(path) as handle:
        for raw in handle:
            line = raw.rstrip("\r\n")
            if line.startswith("^SERIES = "):
                section = "series"
                current = series
                continue
            if line.startswith("^SAMPLE = "):
                section = "sample"
                current = {"Sample_geo_accession": [line.split("=", 1)[1].strip()]}
                samples.append(current)
                continue
            if line.startswith("^"):
                section = "other"
                current = None
                continue
            if current is None or not line.startswith("!") or " = " not in line:
                continue
            key, value = line[1:].split(" = ", 1)
            if section == "series" and key.startswith("Series_"):
                add_field(current, key, value)
            elif section == "sample" and key.startswith("Sample_"):
                add_field(current, key, value)
    return series, samples


def first(record: dict[str, list[str]], key: str) -> str:
    values = record.get(key, [])
    return values[0] if values else ""


def joined(record: dict[str, list[str]], key: str, sep: str = " | ") -> str:
    return sep.join(record.get(key, []))


def characteristics(record: dict[str, list[str]]) -> dict[str, str]:
    out: dict[str, list[str]] = defaultdict(list)
    for key, values in record.items():
        if not key.startswith("Sample_characteristics"):
            continue
        for value in values:
            if ": " in value:
                name, item = value.split(": ", 1)
            elif ":" in value:
                name, item = value.split(":", 1)
            else:
                name, item = "unparsed", value
            clean = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
            out[clean].append(item.strip())
    return {key: " | ".join(values) for key, values in out.items()}


def pick(mapping: dict[str, str], names: list[str]) -> str:
    for name in names:
        if mapping.get(name):
            return mapping[name]
    return ""


def relation_value(record: dict[str, list[str]], label: str) -> str:
    prefix = label.lower() + ":"
    for value in record.get("Sample_relation", []):
        if value.lower().startswith(prefix):
            return value.split(":", 1)[1].strip()
    return ""


def derive_fields(dataset: str, title: str, chars: dict[str, str]) -> dict[str, str]:
    donor = pick(
        chars,
        [
            "donor_id", "donor", "patient_id", "patientid", "patient", "subject_id",
            "subject", "individual", "individual_id", "mouse_id", "animal_id",
        ],
    )
    condition = pick(
        chars,
        [
            "disease_status", "disease_state", "disease", "patient_s_condition",
            "subject_status", "condition", "treatment", "group", "sample_type",
            "skin_type", "diagnosis", "phenotype",
        ],
    )
    tissue = pick(chars, ["tissue", "tissue_type", "organ", "source_name"])
    timepoint = pick(chars, ["time_point", "timepoint", "time", "visit", "day", "treatment_duration"])
    batch = pick(chars, ["batch", "batch_id", "sequencing_batch", "chip"])
    inferred = []

    if dataset == "GSE212126":
        condition = chars.get("treatment", condition) or title
        m = re.search(r"rep\s*(\d+)", title, flags=re.I)
        condition_slug = re.sub(r"[^a-z0-9]+", "_", condition.lower()).strip("_")
        donor = f"animal_{condition_slug}_labelled_rep_{m.group(1)}" if m else donor
        timepoint = "day 29"
        inferred.append("animal identity inferred only from replicate label; independence requires paper/SRA confirmation")
    elif dataset == "GSE70603":
        m = re.search(r"_(\d+)$", title)
        donor = f"subject_{m.group(1)}" if m else donor
        tm = re.search(r"_(TBS45|TAS45|TAS180)_", title, flags=re.I)
        timepoint = tm.group(1).upper() if tm else timepoint
        condition = ("control_history" if title.upper().startswith("A_") else
                     "early_adversity" if title.upper().startswith("B_") else condition)
        inferred.append("subject/time parsed from title; A/B group confirmed by verbatim GEO source_name as control/early adversity")
    elif dataset == "GSE30999":
        parts = title.split("_")
        if len(parts) >= 3:
            donor = parts[-2]
            condition = parts[-1]
        inferred.append("donor and skin type parsed from documented <site>_<subject>_<skin type> title")
    elif dataset == "GSE13355":
        m = re.match(r"Individual_(\d+)_(NN|PN|PP)_sample", title, flags=re.I)
        if m:
            donor = m.group(1)
            condition = m.group(2).upper()
        inferred.append("NN/PN/PP semantics follow GEO series design; pairing must be verified from exact IDs")
    elif dataset == "GSE121212":
        m = re.match(r"(AD|PSO)_(\d+)_(lesional|non-lesional|chronic_lesion)", title, flags=re.I)
        if m:
            donor = f"{m.group(1).upper()}_{m.group(2)}"
            condition = f"{m.group(1).upper()}_{m.group(3).lower()}"
        else:
            m = re.match(r"(?:HC|CTRL)_(\d+)", title, flags=re.I)
            if m:
                donor = f"CTRL_{m.group(1)}"
                condition = "CTRL"
        inferred.append("donor/disease/skin type parsed from GEO sample title")
    elif dataset == "GSE162183":
        m = re.search(r"(control|psoriasis)\s*(\d+)", title, flags=re.I)
        if m:
            donor = f"{m.group(1).lower()}_{m.group(2)}"
            condition = m.group(1).lower()
        inferred.append("one library per labelled skin sample; donor identity beyond label not supplied")
    elif dataset == "GSE225475":
        m = re.search(r"(Healthy control|Psoriasis) skin (\d+)", title, flags=re.I)
        if m:
            condition = "healthy" if m.group(1).lower().startswith("healthy") else "psoriasis"
            donor = f"{condition}_skin_{m.group(2)}"
        inferred.append("library unit parsed from title; exact donor identity and overlap require paper/supplement audit")
    elif dataset == "GSE228421":
        m = re.match(r"P(\d+)-V(\d+)\s+(Lesional|Non Lesional)", title, flags=re.I)
        if m:
            donor = f"P{m.group(1)}"
            timepoint = {"1": "day 0", "2": "day 3", "3": "day 14"}.get(m.group(2), f"V{m.group(2)}")
            condition = m.group(3).lower().replace(" ", "-")
        inferred.append("longitudinal donor/visit fields are retained from GEO characteristics when present")
    elif dataset == "GSE26487":
        m = re.search(r"rep\s*(\d+)", title, flags=re.I)
        if m:
            donor = f"culture_batch_{m.group(1)}"
            batch = f"culture_batch_{m.group(1)}"
        inferred.append("two independent cell batches, not two human donors; destructive time-course cultures are not repeated measures")
    elif dataset == "GSE270712":
        donor = "single_library_" + re.sub(r"[^a-z0-9]+", "_", title.lower()).strip("_")
        inferred.append("one library per displayed condition; no library-level biological replication in GEO")
    elif dataset == "GSE270713":
        m = re.search(r"(?:triplicate\s+sample|sample)\s*(\d+)", title, flags=re.I)
        condition_slug = re.sub(r"[^a-z0-9]+", "_", condition.lower()).strip("_")
        donor = f"{condition_slug}_labelled_rep_{m.group(1)}" if m else donor
        inferred.append("triplicate label does not by itself establish independent donor/animal identity")
    elif dataset == "GSE117468":
        inferred.append("patient, tissue, visit, treatment and available clinical fields read from GEO family sample records; series-level cohort narrative remains discrepant")

    return {
        "donor_or_animal_id": donor,
        "condition": condition,
        "tissue": tissue,
        "timepoint_or_visit": timepoint,
        "batch": batch,
        "derivation_note": "; ".join(inferred),
    }


def choose_source(dataset: str) -> Path | None:
    family = SOFT_DIR / f"{dataset}_family.soft.gz"
    if family.exists() and family.stat().st_size > 0:
        try:
            with gzip.open(family, "rb") as handle:
                handle.read(1)
            return family
        except OSError:
            pass
    samples = SOFT_DIR / f"{dataset}_samples_brief.soft"
    if samples.exists() and samples.stat().st_size > 0:
        return samples
    series = SOFT_DIR / f"{dataset}_series_brief.soft"
    if series.exists() and series.stat().st_size > 0:
        return series
    return None


def audit_labels(dataset: str) -> tuple[str, str]:
    pairing = {
        "GSE70603": "PAIRED_3_TIMEPOINTS_BY_SUBJECT_LABEL",
        "GSE13355": "CASE_PP_PN_PAIRED;CONTROL_UNPAIRED",
        "GSE30999": "PARTIAL_LS_NL_PAIRING;81_UNAMBIGUOUS_PAIRS",
        "GSE121212": "MOSTLY_PAIRED_DISEASE_SKIN;ONE_PSO_MATE_MISSING",
        "GSE228421": "LONGITUDINAL_4_SAMPLES_PER_PATIENT_LABEL",
        "GSE117468": "PARTIAL_LONGITUDINAL_AND_TISSUE_PAIRING",
        "GSE26487": "TIME_MATCHED_CULTURE_BATCHES;NOT_DONOR_PAIRED",
    }.get(dataset, "NOT_APPLICABLE_OR_TO_AUDIT")
    unit = {
        "GSE70603": "GEO_SUBJECT_ID_PRESENT",
        "GSE13355": "GEO_INDIVIDUAL_ID_PRESENT",
        "GSE30999": "GEO_SUBJECT_ID_PRESENT_WITH_ID_DISCREPANCY",
        "GSE121212": "GEO_PATIENT_LABEL_PRESENT",
        "GSE173706": "GEO_SUBJECT_ID_PRESENT",
        "GSE228421": "GEO_PATIENT_LABEL_PRESENT",
        "GSE117468": "GEO_PATIENTID_PRESENT",
        "GSE212126": "REPLICATE_LABEL_ONLY;ANIMAL_INDEPENDENCE_UNVERIFIED",
        "GSE270712": "ONE_LIBRARY_PER_CONDITION;NO_LIBRARY_LEVEL_REPLICATION",
        "GSE270713": "TRIPLICATE_LABEL_ONLY;INDEPENDENCE_UNVERIFIED",
        "GSE26487": "TWO_INDEPENDENT_CELL_BATCHES;NO_DONOR_IDS",
        "GSE162183": "ONE_LIBRARY_PER_LABELLED_SKIN;DONOR_DETAIL_LIMITED",
        "GSE225475": "ONE_LIBRARY_PER_LABELLED_SKIN;DONOR_OVERLAP_UNRESOLVED",
    }.get(dataset, "TO_AUDIT")
    return pairing, unit


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    datasets = sorted({p.name.split("_")[0] for p in SOFT_DIR.glob("GSE*_series_brief.soft")})
    profiles: list[dict[str, str]] = []
    sample_rows: list[dict[str, str]] = []
    cache_rows: list[dict[str, str]] = []

    for dataset in datasets:
        series_path = SOFT_DIR / f"{dataset}_series_brief.soft"
        series, _ = parse_soft(series_path)
        source = choose_source(dataset)
        _, samples = parse_soft(source) if source else ({}, [])
        declared_ids = series.get("Series_sample_id", [])
        supplements = series.get("Series_supplementary_file", [])
        profiles.append(
            {
                "dataset_id": dataset,
                "title": first(series, "Series_title"),
                "status": first(series, "Series_status"),
                "experiment_type": joined(series, "Series_type", "; "),
                "platform_ids": joined(series, "Series_platform_id", ";"),
                "n_series_sample_ids": str(len(declared_ids)),
                "n_sample_records_cached": str(len(samples)),
                "pubmed_ids": joined(series, "Series_pubmed_id", ";"),
                "overall_design": joined(series, "Series_overall_design"),
                "supplementary_files": " | ".join(supplements),
                "bioproject": joined(series, "Series_relation"),
                "source_url": f"https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={dataset}",
                "accessed_local_date": "2026-09-10",
                "sample_metadata_source": str(source.relative_to(ROOT)) if source else "",
            }
        )

        if samples:
            for sample in samples:
                chars = characteristics(sample)
                title = first(sample, "Sample_title")
                derived = derive_fields(dataset, title, chars)
                pairing_status, independent_unit_status = audit_labels(dataset)
                sample_rows.append(
                    {
                        "dataset_id": dataset,
                        "sample_id": first(sample, "Sample_geo_accession"),
                        "sample_title": title,
                        "organism": first(sample, "Sample_organism_ch1"),
                        "source_name": first(sample, "Sample_source_name_ch1"),
                        **derived,
                        "disease_state": pick(chars, ["disease_status", "disease_state", "disease", "patient_s_condition", "subject_status", "diagnosis"]),
                        "skin_type": pick(chars, ["skin_type", "biopsy_type", "tissue_type"]),
                        "treatment": pick(chars, ["treatment", "compound", "drug"]),
                        "pasi": pick(chars, ["pasi", "pasi_score", "baseline_pasi"]),
                        "age": pick(chars, ["age", "age_years"]),
                        "sex": pick(chars, ["sex", "gender"]),
                        "race_or_ethnicity": pick(chars, ["race", "ethnicity"]),
                        "genotype": pick(chars, ["genotype"]),
                        "platform_id": first(sample, "Sample_platform_id"),
                        "library_strategy": first(sample, "Sample_library_strategy"),
                        "biosample": relation_value(sample, "BioSample"),
                        "sra_relation": relation_value(sample, "SRA"),
                        "characteristics": " | ".join(f"{k}={v}" for k, v in sorted(chars.items())),
                        "clinical_fields_available": ";".join(
                            k for k in sorted(chars) if any(token in k for token in ("pasi", "severity", "response", "age", "sex", "gender"))
                        ),
                        "pairing_status": pairing_status,
                        "independent_unit_status": independent_unit_status,
                        "inclusion_status": "PENDING",
                        "exclusion_reason": "",
                        "source_url": f"https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={first(sample, 'Sample_geo_accession')}",
                    }
                )
        else:
            for sample_id in declared_ids:
                derived = derive_fields(dataset, "", {})
                pairing_status, independent_unit_status = audit_labels(dataset)
                sample_rows.append(
                    {
                        "dataset_id": dataset,
                        "sample_id": sample_id,
                        "sample_title": "",
                        "organism": "",
                        "source_name": "",
                        **derived,
                        "disease_state": "",
                        "skin_type": "",
                        "treatment": "",
                        "pasi": "",
                        "age": "",
                        "sex": "",
                        "race_or_ethnicity": "",
                        "genotype": "",
                        "platform_id": joined(series, "Series_platform_id", ";"),
                        "library_strategy": "",
                        "biosample": "",
                        "sra_relation": "",
                        "characteristics": "",
                        "clinical_fields_available": "",
                        "pairing_status": pairing_status,
                        "independent_unit_status": independent_unit_status,
                        "inclusion_status": "PENDING",
                        "exclusion_reason": "",
                        "source_url": f"https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={sample_id}",
                    }
                )

    for path in sorted(SOFT_DIR.glob("*")):
        if path.is_file():
            cache_rows.append(
                {
                    "path": str(path.relative_to(ROOT)),
                    "bytes": str(path.stat().st_size),
                    "sha256": sha256(path),
                    "status": "EMPTY_FAILED_DOWNLOAD" if path.stat().st_size == 0 else "CACHED",
                }
            )

    outputs = [
        (ROOT / "metadata" / "geo_series_profile.tsv", profiles),
        (ROOT / "metadata" / "sample_manifest.tsv", sample_rows),
        (ROOT / "metadata" / "geo_cache_checksums.tsv", cache_rows),
    ]
    for path, rows in outputs:
        path.parent.mkdir(parents=True, exist_ok=True)
        if not rows:
            continue
        with path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
            writer.writeheader()
            writer.writerows(rows)


if __name__ == "__main__":
    main()
