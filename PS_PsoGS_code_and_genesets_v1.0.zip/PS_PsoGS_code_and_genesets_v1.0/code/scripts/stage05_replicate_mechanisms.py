from __future__ import annotations

import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))

import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

OUT = ROOT / "results/stage05"
meta = pd.read_csv(ROOT / "data/processed/stage04/gse162183_cell_metadata_annotated.tsv.gz", sep="\t")
genes = pd.read_csv(ROOT / "data/processed/stage04/gse162183_genes.tsv", sep="\t")
X = sp.load_npz(ROOT / "data/processed/stage04/gse162183_counts_qc.npz").tocsr()
assert X.shape == (len(meta), len(genes))

symbols = genes.human_gene_symbol.fillna("").astype(str).str.upper().to_numpy(dtype=str)
unique_symbols, inv_gene = np.unique(symbols, return_inverse=True)
C = sp.csr_matrix((np.ones(len(symbols)), (np.arange(len(symbols)), inv_gene)), shape=(len(symbols), len(unique_symbols)))
keys = meta[["donor_id", "condition", "cell_type"]].astype(str).agg("|".join, axis=1)
levels, inv_cell = np.unique(keys, return_inverse=True)
G = sp.csr_matrix((np.ones(len(inv_cell)), (inv_cell, np.arange(len(inv_cell)))), shape=(len(levels), len(inv_cell)))
raw = (G @ X @ C).tocsr()
idx = pd.DataFrame([x.split("|", 2) for x in levels], columns=["donor_id", "condition", "cell_type"])
idx["n_cells"] = np.bincount(inv_cell)
idx["total_counts"] = np.asarray(raw.sum(axis=1)).ravel()
scale = np.divide(1e4, idx.total_counts.to_numpy(float), out=np.zeros(len(idx)), where=idx.total_counts.to_numpy() > 0)
expr = raw.multiply(scale[:, None]).tocsr(); expr.data = np.log1p(expr.data)
col = {g: i for i, g in enumerate(unique_symbols)}

def group_value(donor, condition, cell_type, geneset, mode="min"):
    q = idx.index[(idx.donor_id == donor) & (idx.condition == condition) & (idx.cell_type == cell_type) & (idx.n_cells >= 25)]
    if len(q) != 1 or not all(g in col for g in geneset):
        return np.nan
    vals = expr[q[0], [col[g] for g in geneset]].toarray().ravel()
    return float(vals.min() if mode == "min" else vals.mean())

lr_rows = []
for donor, condition in idx[["donor_id", "condition"]].drop_duplicates().itertuples(index=False):
    ligand = group_value(donor, condition, "Endothelial", ["JAG2"])
    receptor = group_value(donor, condition, "Fibroblast", ["NOTCH2"])
    score = math.sqrt(max(ligand, 0) * max(receptor, 0)) if np.isfinite(ligand) and np.isfinite(receptor) else np.nan
    lr_rows.append({"donor_id": donor, "condition": condition, "sender": "Endothelial", "receiver": "Fibroblast", "ligand": "JAG2", "receptor": "NOTCH2", "ligand_log1p_cp10k": ligand, "receptor_log1p_cp10k": receptor, "compatibility_score": score})
lr = pd.DataFrame(lr_rows).dropna(subset=["compatibility_score"])
lr.to_csv(OUT / "gse162183_jag2_notch2_replication_scores.tsv", sep="\t", index=False)
c = lr[lr.condition == "Control"].compatibility_score.to_numpy(); p = lr[lr.condition == "Psoriasis"].compatibility_score.to_numpy()
t = stats.ttest_ind(p, c, equal_var=False)
diff = float(p.mean() - c.mean())
se = math.sqrt(p.var(ddof=1) / len(p) + c.var(ddof=1) / len(c))
df = (p.var(ddof=1) / len(p) + c.var(ddof=1) / len(c)) ** 2 / ((p.var(ddof=1) / len(p)) ** 2 / (len(p) - 1) + (c.var(ddof=1) / len(c)) ** 2 / (len(c) - 1))
ci = stats.t.interval(0.95, df, loc=diff, scale=se)
lr_stat = pd.DataFrame([{"candidate": "Endothelial_JAG2_to_Fibroblast_NOTCH2", "n_control": len(c), "n_psoriasis": len(p), "mean_psoriasis_minus_control": diff, "ci95_low": ci[0], "ci95_high": ci[1], "welch_p": t.pvalue, "direction_replication": diff > 0, "minimum_p_rule_replication": bool(diff > 0 and t.pvalue < 0.05)}])
lr_stat.to_csv(OUT / "gse162183_jag2_notch2_replication_statistics.tsv", sep="\t", index=False)

# Frozen Reactome glutathione program. Score by within-pseudobulk percentile as in discovery.
gmt = {}
with (ROOT / "data/raw/stage05/reactome-current/ReactomePathways.gmt").open(encoding="utf-8") as f:
    for line in f:
        z = line.rstrip().split("\t")
        if len(z) >= 3:
            gmt[z[1]] = (z[0], [x.upper() for x in z[2:]])
pathway_id = "R-HSA-174403"
available = [g for g in gmt[pathway_id][1] if g in col]
fib_rows = idx.index[(idx.cell_type == "Fibroblast") & (idx.n_cells >= 25)].to_numpy()
fib_expr = expr[fib_rows].toarray()
ranks = np.apply_along_axis(stats.rankdata, 1, fib_expr) / fib_expr.shape[1]
scores = ranks[:, [col[g] for g in available]].mean(axis=1)
met = idx.loc[fib_rows, ["donor_id", "condition", "n_cells", "total_counts"]].copy()
met["pathway_id"] = pathway_id; met["pathway"] = gmt[pathway_id][0]; met["n_genes"] = len(available); met["score"] = scores
met.to_csv(OUT / "gse162183_glutathione_replication_scores.tsv", sep="\t", index=False)
c2 = met[met.condition == "Control"].score.to_numpy(); p2 = met[met.condition == "Psoriasis"].score.to_numpy()
t2 = stats.ttest_ind(p2, c2, equal_var=False); diff2 = float(p2.mean() - c2.mean())
se2 = math.sqrt(p2.var(ddof=1) / len(p2) + c2.var(ddof=1) / len(c2))
df2 = (p2.var(ddof=1) / len(p2) + c2.var(ddof=1) / len(c2)) ** 2 / ((p2.var(ddof=1) / len(p2)) ** 2 / (len(p2) - 1) + (c2.var(ddof=1) / len(c2)) ** 2 / (len(c2) - 1))
ci2 = stats.t.interval(0.95, df2, loc=diff2, scale=se2)
met_stat = pd.DataFrame([{"candidate": "Reactome_R-HSA-174403_Glutathione_synthesis_and_recycling", "n_control": len(c2), "n_psoriasis": len(p2), "n_genes": len(available), "mean_psoriasis_minus_control": diff2, "ci95_low": ci2[0], "ci95_high": ci2[1], "welch_p": t2.pvalue, "direction_replication": diff2 > 0, "minimum_p_rule_replication": bool(diff2 > 0 and t2.pvalue < 0.05)}])
met_stat.to_csv(OUT / "gse162183_glutathione_replication_statistics.tsv", sep="\t", index=False)

checks = pd.DataFrame([
    ("freeze_precedes_replication_script", (ROOT / "metadata/TARGET_FREEZE_STAGE05_MECHANISMS.tsv").exists(), "two candidates frozen"),
    ("lr_has_3_plus_3", len(c) == 3 and len(p) == 3, f"{len(c)}+{len(p)}"),
    ("metabolism_has_3_plus_3", len(c2) == 3 and len(p2) == 3, f"{len(c2)}+{len(p2)}"),
    ("glutathione_members_present", len(available) >= 5, f"n={len(available)}"),
], columns=["check", "pass", "detail"])
checks.to_csv(ROOT / "audits/stage05_replication_checks.tsv", sep="\t", index=False)
if not checks["pass"].all():
    raise AssertionError(checks.loc[~checks["pass"]].to_string(index=False))
print(json.dumps({"JAG2_NOTCH2": lr_stat.iloc[0].to_dict(), "glutathione": met_stat.iloc[0].to_dict()}, indent=2, default=float))
print("PASS: Stage 05 frozen candidate replication checks")
