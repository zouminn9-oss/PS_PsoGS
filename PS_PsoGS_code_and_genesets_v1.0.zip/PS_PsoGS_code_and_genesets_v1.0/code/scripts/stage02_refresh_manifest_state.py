#!/usr/bin/env python3
"""Refresh only the audited GSE212126 state fields in the dataset manifest."""

from __future__ import annotations

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PATH = ROOT / "metadata" / "dataset_manifest.tsv"


def replace_line(path: Path, prefix: str, replacement: str) -> None:
    lines = path.read_text(encoding="utf-8").splitlines()
    hits = [index for index, line in enumerate(lines) if line.startswith(prefix)]
    if len(hits) != 1:
        raise AssertionError(f"expected one line starting with {prefix!r} in {path}")
    lines = [replacement if line.startswith(prefix) else line for line in lines]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    download_state = ROOT / "audits" / "gse212126_sra_download_state.tsv"
    with download_state.open(encoding="utf-8-sig", newline="") as handle:
        download_rows = list(csv.DictReader(handle, delimiter="\t"))
    sra_pass_count = sum(
        row.get("integrity_status") == "PASS" and row.get("vdb_validate_status") == "PASS"
        for row in download_rows
    )
    ledger_path = ROOT / "audits" / "gse212126_run_processing_state.tsv"
    with ledger_path.open(encoding="utf-8-sig", newline="") as handle:
        ledger_rows = list(csv.DictReader(handle, delimiter="\t"))
    if len(ledger_rows) != 12:
        raise AssertionError("expected 12 processing-ledger rows")
    fastq_pass_count = sum(row.get("full_fastq") == "PASS" for row in ledger_rows)
    bam_pass_count = sum(row.get("alignment_bam") == "PASS" for row in ledger_rows)
    remaining_count = 12 - bam_pass_count
    if remaining_count != 0 or sra_pass_count != 12 or fastq_pass_count != 12:
        raise AssertionError("final Stage 02 refresh requires all 12 SRA/FASTQ/BAM audits to pass")
    for audit_name, expected_rows in (
        ("gse212126_count_integrity_checks.tsv", 15),
        ("gse212126_edger_integrity_checks.tsv", 27),
    ):
        audit_path = ROOT / "audits" / "stage02_counts" / audit_name
        with audit_path.open(encoding="utf-8-sig", newline="") as handle:
            audit_rows = list(csv.DictReader(handle, delimiter="\t"))
        if len(audit_rows) != expected_rows or any(item["status"] != "PASS" for item in audit_rows):
            raise AssertionError(f"{audit_name} is not fully PASS")
    with PATH.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    matches = [row for row in rows if row["dataset_id"] == "GSE212126"]
    if len(matches) != 1:
        raise AssertionError("expected exactly one GSE212126 dataset-manifest row")
    row = matches[0]
    row["raw_data"] = (
        "12 paired-end NovaSeq 6000 SRA runs; 23,679,415,090 compressed bytes; "
        f"{sra_pass_count}/12 normalized SRA objects passed official MD5 and VDB validation; "
        f"{fastq_pass_count}/12 full FASTQ and {bam_pass_count}/12 BAM audits passed; "
        "55,487-gene integer matrix frozen at strandSpecific=2; edgeR S0/SD/I exported"
    )
    row["confirmatory_eligibility"] = (
        "PASS for mouse factorial inference and frozen F1 discovery input"
    )
    row["stage00_status"] = "PASS_WITH_USER_CONFIRMED_ANIMAL_PROVENANCE"
    with PATH.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    report = ROOT / "reports" / "STAGE02_PREPARATION_METHODS_RESULTS_EN.md"
    report_text = report.read_text(encoding="utf-8").replace("mappinglua statistic", "mapping statistic")
    report.write_text(report_text, encoding="utf-8")
    replace_line(
        ROOT / "STATUS.md",
        "| 02 析因与签名 |",
        "| 02 析因与签名 | PASS | 鼠侧12库counts与S0/SD/I、GSE13355 180 CEL与58对患者H模型、Ensembl Compara release-100可靠1:1映射及F1均已冻结；Core=4,976、Interaction=4,085、SEP=2,716；20项F1文件清单及Figure 1E–1J通过成图/校验门禁 | Core含2,260个SD–H方向冲突并明确保留；Interaction的3,521个reversal为冻结符号分类，不自动表示加重或因果。PS-Reference与Core重叠1,273仅作注释；GSM337287软QC标记仍保留 |",
    )
    replace_line(
        ROOT / "README.md",
        "- Stage 02：",
        "- Stage 02：`PASS`。鼠侧12/12文库与S0/SD/I、GSE13355的180/180 CEL与58对患者H、Ensembl Compara release-100 reciprocal 1:1 orthology均已冻结。F1得到Core 4,976、Interaction 4,085、SEP 2,716；20项文件清单的实时SHA-256在Figure 1J独立复核中全部一致，验证表达读取数为0。",
    )
    next_path = ROOT / "NEXT_STEPS.md"
    replace_line(
        next_path,
        "1. `COMPLETED`：",
        "1. `COMPLETED`：Stage 02 已完成鼠侧S0/SD/I、GSE13355患者内H、Ensembl Compara release-100 reciprocal 1:1 orthology与F1冻结。Core=4,976、Interaction=4,085、SEP=2,716；20项文件清单已独立重算SHA-256，验证表达读取数为0。",
    )
    replace_line(
        next_path,
        "13. ",
        "13. `COMPLETED`：Rsubread索引用时44.3分钟构建完成；7个非空组件共14,994,601,711 bytes，逐文件SHA-256已登记。",
    )
    replace_line(
        next_path,
        "14. ",
        "14. `COMPLETED`：`SRR21221234` 的20,857,369个 paired fragments 已完成全量 FASTQ 审计和比对；99.3% fragments mapped，BAM SHA-256 已登记。featureCounts 单样本试运行通过，但不用于冻结链特异性。",
    )
    replace_line(
        next_path,
        "15. ",
        "15. `COMPLETED`：`SRR21221228` 的22,600,497个 paired fragments 已完成全量 FASTQ 审计和比对；99.4% fragments mapped，BAM SHA-256 已登记。R调用Python后处理失败但比对未重跑，独立审计随后通过。",
    )
    replace_line(
        next_path,
        "16. ",
        "16. `COMPLETED`：12库统一完成strand 0/1/2计数，按预注册规则冻结strandSpecific=2；edgeR主模型保留18,484基因并输出S0/SD/I，未访问验证表达。",
    )
    replace_line(
        next_path,
        "36. cell2location",
        "36. cell2location、scTour、scFEA、MOGONET等重依赖继续不安装，直到相应阶段的真实输入门禁通过。",
    )
    print("PASS: refreshed completed GSE212126 mouse-factorial state fields")


if __name__ == "__main__":
    main()
