from pathlib import Path
import csv
import gzip
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))
import pandas as pd
from PIL import Image

ready = ["6a", "6b", "6c", "6d", "6e", "6f", "6g", "6k", "6l"]
checks = []
def ck(name, passed, detail): checks.append((name, bool(passed), str(detail)))

for panel in ready:
    files = {
        "source": ROOT / f"figures/source_data/fig{panel}.tsv",
        "stats": ROOT / f"results/figures/fig{panel}_statistics.tsv",
        "config": ROOT / f"config/figures/fig{panel}.yaml",
        "svg": ROOT / f"figures/panels/fig{panel}.svg",
        "png": ROOT / f"figures/previews/fig{panel}.png",
        "caption": ROOT / f"figures/captions/fig{panel}.md",
    }
    for kind, file in files.items(): ck(f"{panel}_{kind}_exists", file.exists() and file.stat().st_size > 0, file)
    ck(f"{panel}_source_nonempty", len(pd.read_csv(files["source"], sep="\t")) > 0, files["source"])
    ck(f"{panel}_stats_nonempty", len(pd.read_csv(files["stats"], sep="\t")) > 0, files["stats"])
    with Image.open(files["png"]) as im: ck(f"{panel}_print_pixels", im.width >= 900 and im.height >= 600, f"{im.width}x{im.height}")
    ck(f"{panel}_caption_complete", len(files["caption"].read_text(encoding="utf-8").split()) >= 35, "word-like tokens")

qc = pd.read_csv(ROOT / "results/stage06/section_qc.tsv", sep="\t")
ck("six_sections", len(qc) == 6, len(qc))
ck("filtered_spot_total", int(qc.filtered_spots.sum()) == 7570, int(qc.filtered_spots.sum()))
ck("one_ffpe_section", (qc.chemistry == "FFPE").sum() == 1, int((qc.chemistry == "FFPE").sum()))
ck("ffpe_is_pp4", qc.loc[qc.chemistry == "FFPE", "section"].tolist() == ["PP4"], qc.loc[qc.chemistry == "FFPE", "section"].tolist())

blocked = pd.read_csv(ROOT / "results/stage06/spatial_blocked_modules.tsv", sep="\t")
for module in ["local_proximity", "ligand_receptor_colocalization", "constrained_spatial_permutation", "border_distance"]:
    state = blocked.loc[blocked.module == module, "status"].iloc[0]
    ck(f"{module}_quality_blocked", state == "BLOCKED_BY_PRIMARY_PAPER_QUALITY_LIMITATION", state)
state = blocked.loc[blocked.module == "spatial_metabolomics", "status"].iloc[0]
ck("spatial_metabolomics_blocked", state == "BLOCKED_NO_SPATIAL_METABOLOMICS", state)

with (ROOT / "panel_manifest.tsv").open(encoding="utf-8", newline="") as f:
    manifest = {r["panel_id"]: r for r in csv.DictReader(f, delimiter="\t")}
for panel in [x.upper() for x in ready]:
    row = manifest[panel]
    ck(f"manifest_{panel}_ready", row["status"] == "PASS" and row["figure_ready"] == "YES" and row["qa_status"] == "PASS_RENDER_DATA_PRINT", row["status"])
for panel in ["6H", "6I", "6J"]:
    row = manifest[panel]
    ck(f"manifest_{panel}_blocked", row["status"] == "BLOCKED_BY_PRIMARY_PAPER_QUALITY_LIMITATION" and row["figure_ready"] == "NO", row["status"])

out = pd.DataFrame(checks, columns=["check", "pass", "detail"])
out.to_csv(ROOT / "audits/stage06_figure6_checks.tsv", sep="\t", index=False)
if not out["pass"].all(): raise AssertionError(out.loc[~out["pass"]].to_string(index=False))
print(f"PASS: Figure 6 QA {len(out)}/{len(out)} checks")
