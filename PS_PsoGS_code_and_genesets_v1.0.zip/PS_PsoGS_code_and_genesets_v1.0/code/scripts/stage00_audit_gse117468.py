#!/usr/bin/env python3
"""Freeze the public-metadata design audit for GSE117468.

The audit deliberately reads no expression values. It reconciles the cached
official GEO sample records with the PubMed record for PMID 31883845 and
derives patient-level eligibility using metadata-only rules.
"""

from __future__ import annotations

import csv
import hashlib
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATE = "2026-09-10"
DATASET = "GSE117468"
SAMPLE_MANIFEST = ROOT / "metadata" / "sample_manifest.tsv"
GEO_FAMILY = ROOT / "metadata" / "geo_soft" / "GSE117468_family.soft.gz"
GEO_SERIES = ROOT / "metadata" / "geo_soft" / "GSE117468_series_brief.soft"
PUBMED_XML = ROOT / "metadata" / "gse117468_pubmed_31883845.xml"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write empty audit: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def characteristics(row: dict[str, str]) -> dict[str, str]:
    return {
        key.strip().lower(): value.strip()
        for item in row["characteristics"].split(" | ")
        if "=" in item
        for key, value in [item.split("=", 1)]
    }


def numeric(value: str) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def yn(value: bool) -> str:
    return "YES" if value else "NO"


def fmt(value: float | None) -> str:
    if value is None:
        return ""
    return f"{value:g}"


def main() -> None:
    required = [SAMPLE_MANIFEST, GEO_FAMILY, GEO_SERIES, PUBMED_XML]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing required audit source(s): " + "; ".join(missing))

    rows = [row for row in read_tsv(SAMPLE_MANIFEST) if row["dataset_id"] == DATASET]
    if len(rows) != 565:
        raise AssertionError(f"Expected 565 public sample rows, found {len(rows)}")

    paper_text = " ".join(text.strip() for text in ET.parse(PUBMED_XML).getroot().itertext() if text.strip()).replace("\xa0", " ")
    for required_text in ["n = 116", "140 mg (n = 46)", "210 mg (n = 41)", "placebo (n = 29)",
                          "week 12 (n = 63)", "nonresponders (n = 12)"]:
        if required_text not in paper_text:
            raise AssertionError(f"PubMed source does not contain expected text: {required_text}")

    patients: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        patients[row["donor_or_animal_id"]].append(row)

    patient_registry: list[dict[str, object]] = []
    sample_map: list[dict[str, object]] = []
    for patient_id, patient_rows in sorted(patients.items()):
        treatments = {row["treatment"] for row in patient_rows}
        treatment_consistent = len(treatments) == 1
        treatment = next(iter(treatments)) if treatment_consistent else "CONFLICT"

        cell = {(row["timepoint_or_visit"], row["tissue"]): row for row in patient_rows}
        duplicate_cells = len(cell) != len(patient_rows)
        visit_pasi: dict[str, set[float]] = defaultdict(set)
        for row in patient_rows:
            value = numeric(row["pasi"])
            if value is not None:
                visit_pasi[row["timepoint_or_visit"]].add(value)
        pasi_consistent = all(len(values) == 1 for values in visit_pasi.values())
        bl_pasi = next(iter(visit_pasi["BL"])) if len(visit_pasi.get("BL", set())) == 1 else None
        w4_pasi = next(iter(visit_pasi["W4"])) if len(visit_pasi.get("W4", set())) == 1 else None
        w12_pasi = next(iter(visit_pasi["W12"])) if len(visit_pasi.get("W12", set())) == 1 else None

        def has(visit: str, tissue: str) -> bool:
            return (visit, tissue) in cell

        has_bl_ls = has("BL", "lesional skin")
        has_bl_nl = has("BL", "non-lesional skin")
        has_w4_ls = has("W4", "lesional skin")
        has_w4_nl = has("W4", "non-lesional skin")
        has_w12_ls = has("W12", "lesional skin")
        has_w12_nl = has("W12", "non-lesional skin")
        outcome_evaluable = pasi_consistent and bl_pasi is not None and w12_pasi is not None and bl_pasi > 0
        baseline_prediction_metadata_eligible = outcome_evaluable and has_bl_ls
        improvement = (bl_pasi - w12_pasi) / bl_pasi if outcome_evaluable else None

        static_values: dict[str, set[str]] = defaultdict(set)
        for row in patient_rows:
            values = characteristics(row)
            for field in ["age", "bmi", "weight", "race"]:
                if values.get(field, ""):
                    static_values[field].add(values[field])
        static_consistent = all(len(static_values[field]) <= 1 for field in ["age", "bmi", "weight", "race"])

        if treatment.startswith("Brodalumab") and baseline_prediction_metadata_eligible:
            role = "BRODALUMAB_BASELINE_PREDICTION_METADATA_ELIGIBLE"
        elif treatment.startswith("Brodalumab") and outcome_evaluable:
            role = "BRODALUMAB_OUTCOME_EVALUABLE_MISSING_PUBLIC_BL_LS"
        elif treatment.startswith("Brodalumab"):
            role = "BRODALUMAB_INCOMPLETE_BL_W12_OUTCOME"
        else:
            role = "COMPARATOR_ARM"

        registry_row: dict[str, object] = {
            "dataset_id": DATASET,
            "patient_id": patient_id,
            "treatment": treatment,
            "n_public_arrays": len(patient_rows),
            "has_bl_ls": yn(has_bl_ls),
            "has_bl_nl": yn(has_bl_nl),
            "has_w4_ls": yn(has_w4_ls),
            "has_w4_nl": yn(has_w4_nl),
            "has_w12_ls": yn(has_w12_ls),
            "has_w12_nl": yn(has_w12_nl),
            "baseline_ls_nl_pair": yn(has_bl_ls and has_bl_nl),
            "ls_bl_w4_pair": yn(has_bl_ls and has_w4_ls),
            "ls_bl_w12_pair": yn(has_bl_ls and has_w12_ls),
            "nl_bl_w12_pair": yn(has_bl_nl and has_w12_nl),
            "complete_bl_w12_ls_nl": yn(has_bl_ls and has_bl_nl and has_w12_ls and has_w12_nl),
            "bl_pasi": fmt(bl_pasi),
            "w4_pasi": fmt(w4_pasi),
            "w12_pasi": fmt(w12_pasi),
            "pasi_consistent_within_visit": yn(pasi_consistent),
            "outcome_evaluable_bl_w12": yn(outcome_evaluable),
            "baseline_ls_prediction_metadata_eligible": yn(baseline_prediction_metadata_eligible),
            "pasi_fraction_improvement": fmt(improvement),
            "pasi75": yn(improvement is not None and improvement >= 0.75) if outcome_evaluable else "",
            "pasi90": yn(improvement is not None and improvement >= 0.90) if outcome_evaluable else "",
            "age": next(iter(static_values["age"])) if len(static_values["age"]) == 1 else "",
            "bmi": next(iter(static_values["bmi"])) if len(static_values["bmi"]) == 1 else "",
            "weight": next(iter(static_values["weight"])) if len(static_values["weight"]) == 1 else "",
            "race": next(iter(static_values["race"])) if len(static_values["race"]) == 1 else "",
            "sex": "",
            "treatment_consistent": yn(treatment_consistent),
            "static_clinical_fields_consistent": yn(static_consistent),
            "duplicate_patient_visit_tissue_cell": yn(duplicate_cells),
            "metadata_role": role,
            "expression_values_accessed": "NO",
            "source_accessed_local_date": DATE,
        }
        patient_registry.append(registry_row)

        for row in sorted(patient_rows, key=lambda item: item["sample_id"]):
            values = characteristics(row)
            sample_map.append({
                "dataset_id": DATASET,
                "sample_id": row["sample_id"],
                "patient_id": patient_id,
                "treatment": row["treatment"],
                "visit": row["timepoint_or_visit"],
                "tissue": row["tissue"],
                "pasi": row["pasi"],
                "age": row["age"],
                "bmi": values.get("bmi", ""),
                "weight": values.get("weight", ""),
                "race": row["race_or_ethnicity"],
                "sex": row["sex"],
                "outcome_evaluable_bl_w12": registry_row["outcome_evaluable_bl_w12"],
                "baseline_ls_prediction_metadata_eligible": registry_row["baseline_ls_prediction_metadata_eligible"],
                "patient_metadata_role": role,
                "expression_values_accessed": "NO",
                "source_url": row["source_url"],
            })

    def summarize(label: str, selected: list[dict[str, object]]) -> dict[str, object]:
        return {
            "cohort": label,
            "n_patients": len(selected),
            "n_public_arrays": sum(int(row["n_public_arrays"]) for row in selected),
            "baseline_ls_nl_pairs": sum(row["baseline_ls_nl_pair"] == "YES" for row in selected),
            "ls_bl_w4_pairs": sum(row["ls_bl_w4_pair"] == "YES" for row in selected),
            "ls_bl_w12_pairs": sum(row["ls_bl_w12_pair"] == "YES" for row in selected),
            "nl_bl_w12_pairs": sum(row["nl_bl_w12_pair"] == "YES" for row in selected),
            "complete_bl_w12_ls_nl": sum(row["complete_bl_w12_ls_nl"] == "YES" for row in selected),
            "outcome_evaluable_bl_w12": sum(row["outcome_evaluable_bl_w12"] == "YES" for row in selected),
            "baseline_ls_prediction_metadata_eligible": sum(row["baseline_ls_prediction_metadata_eligible"] == "YES" for row in selected),
            "pasi75_yes_among_outcome_evaluable": sum(row["outcome_evaluable_bl_w12"] == "YES" and row["pasi75"] == "YES" for row in selected),
            "pasi90_yes_among_outcome_evaluable": sum(row["outcome_evaluable_bl_w12"] == "YES" and row["pasi90"] == "YES" for row in selected),
            "pasi75_yes_among_prediction_eligible": sum(row["baseline_ls_prediction_metadata_eligible"] == "YES" and row["pasi75"] == "YES" for row in selected),
            "pasi90_yes_among_prediction_eligible": sum(row["baseline_ls_prediction_metadata_eligible"] == "YES" and row["pasi90"] == "YES" for row in selected),
            "analysis_scope": "metadata-only feasibility; no expression values accessed",
        }

    arms = ["Brodalumab 140 mg Q2W", "Brodalumab 210 mg Q2W", "Placebo", "Ustekinumab"]
    summary = [summarize(arm, [row for row in patient_registry if row["treatment"] == arm]) for arm in arms]
    summary.append(summarize("Brodalumab combined", [row for row in patient_registry if str(row["treatment"]).startswith("Brodalumab")]))
    summary.append(summarize("All public records", patient_registry))

    reconciliation: list[dict[str, object]] = [
        {
            "source": "GEO_SERIES_OVERALL_DESIGN",
            "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE117468",
            "reported_people_or_ids": 116,
            "reported_biopsies_or_arrays": 844,
            "brodalumab_140_people": 46,
            "brodalumab_210_people": 41,
            "placebo_people": 29,
            "ustekinumab_people": "NOT_ENUMERATED",
            "outcome_subgroup": "NOT_ENUMERATED",
            "audit_interpretation": "Narrative denominator; cannot be substituted for the deposited-array denominator.",
            "source_sha256": sha256(GEO_SERIES),
            "accessed_local_date": DATE,
        },
        {
            "source": "PUBLIC_GEO_SAMPLE_RECORDS",
            "source_url": "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE117468",
            "reported_people_or_ids": 133,
            "reported_biopsies_or_arrays": 565,
            "brodalumab_140_people": 46,
            "brodalumab_210_people": 42,
            "placebo_people": 29,
            "ustekinumab_people": 16,
            "outcome_subgroup": "75 brodalumab patients have internally consistent BL/W12 PASI; 74 also have a public BL lesional array",
            "audit_interpretation": "Canonical denominator for analyses reproducible from the current public deposit.",
            "source_sha256": sha256(GEO_FAMILY),
            "accessed_local_date": DATE,
        },
        {
            "source": "PUBMED_PMID_31883845_ABSTRACT",
            "source_url": "https://pubmed.ncbi.nlm.nih.gov/31883845/",
            "reported_people_or_ids": 116,
            "reported_biopsies_or_arrays": "NOT_STATED_IN_ABSTRACT",
            "brodalumab_140_people": 46,
            "brodalumab_210_people": 41,
            "placebo_people": 29,
            "ustekinumab_people": "MENTIONED_WITHOUT_N",
            "outcome_subgroup": "63 PASI75 responders plus 12 nonresponders (75 total)",
            "audit_interpretation": "Matches the 75 metadata outcome-evaluable public brodalumab patients, but not the 74-patient public baseline-lesional prediction set.",
            "source_sha256": sha256(PUBMED_XML),
            "accessed_local_date": DATE,
        },
    ]

    write_tsv(ROOT / "metadata" / "gse117468_patient_visit_tissue_map.tsv", sample_map)
    write_tsv(ROOT / "metadata" / "gse117468_patient_registry.tsv", patient_registry)
    write_tsv(ROOT / "audits" / "gse117468_cohort_summary.tsv", summary)
    write_tsv(ROOT / "audits" / "gse117468_source_reconciliation.tsv", reconciliation)
    print(f"PASS: {len(sample_map)} arrays, {len(patient_registry)} patients, {len(summary)} cohort rows")


if __name__ == "__main__":
    main()
