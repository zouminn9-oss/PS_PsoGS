#!/usr/bin/env python3
"""Map GSE70603 time-locked response candidates to a frozen HGNC snapshot.

Every source symbol is retained.  Ambiguous/unmapped symbols are not silently
dropped, and collisions where multiple source symbols map to one current HGNC
symbol are explicitly flagged for later deterministic collapse.
"""

from __future__ import annotations

import csv
import hashlib
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "genesets" / "GSE70603_time_locked_stress_v1.0.tsv"
HGNC = ROOT / "metadata" / "hgnc_complete_set_2026-09-10.tsv"
OUTPUT = ROOT / "genesets" / "GSE70603_time_locked_stress_v1.1_hgnc_2026-09-10.tsv"
AUDIT = ROOT / "audits" / "gse70603_hgnc_mapping_audit.tsv"
SUMMARY = ROOT / "audits" / "gse70603_hgnc_mapping_summary.tsv"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def tokens(value: str) -> set[str]:
    return {part.strip() for part in (value or "").split("|") if part.strip()}


def main() -> None:
    candidates = read_tsv(SOURCE)
    hgnc = read_tsv(HGNC)
    approved = [row for row in hgnc if row["status"] == "Approved"]
    by_symbol = {row["symbol"]: row for row in approved}
    by_prev: dict[str, list[dict[str, str]]] = defaultdict(list)
    by_alias: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in approved:
        for value in tokens(row["prev_symbol"]):
            by_prev[value].append(row)
        for value in tokens(row["alias_symbol"]):
            by_alias[value].append(row)

    snapshot_hash = hashlib.sha256(HGNC.read_bytes()).hexdigest()
    prelim: list[dict[str, str]] = []
    audit: list[dict[str, str]] = []
    for item in candidates:
        raw = item["gene_symbol"]
        if raw in by_symbol:
            matches, route = [by_symbol[raw]], "APPROVED_SYMBOL_EXACT"
        elif len(by_prev[raw]) == 1:
            matches, route = by_prev[raw], "UNIQUE_PREVIOUS_SYMBOL"
        elif len(by_alias[raw]) == 1:
            matches, route = by_alias[raw], "UNIQUE_ALIAS_SYMBOL"
        else:
            matches = by_prev[raw] or by_alias[raw]
            route = "AMBIGUOUS_PREVIOUS_OR_ALIAS" if len(matches) > 1 else "UNMAPPED"
        current = matches[0] if len(matches) == 1 else {}
        mapped = {
            "raw_symbol": raw,
            "current_hgnc_symbol": current.get("symbol", ""),
            "hgnc_id": current.get("hgnc_id", ""),
            "approved_name": current.get("name", ""),
            "locus_group": current.get("locus_group", ""),
            "locus_type": current.get("locus_type", ""),
            "ensembl_gene_id": current.get("ensembl_gene_id", ""),
            "entrez_id": current.get("entrez_id", ""),
            "mapping_route": route,
            "mapping_status": "PASS" if len(matches) == 1 else "HOLD",
            "hgnc_collision_size": "",
            **{key: value for key, value in item.items() if key != "gene_symbol"},
            "hgnc_snapshot_date": "2026-09-10",
            "hgnc_snapshot_sha256": snapshot_hash,
        }
        prelim.append(mapped)
        audit.append({
            "raw_symbol": raw,
            "match_count": str(len(matches)),
            "mapping_route": route,
            "matched_symbols": "|".join(row["symbol"] for row in matches),
            "status": mapped["mapping_status"],
        })

    current_counts = Counter(row["current_hgnc_symbol"] for row in prelim if row["current_hgnc_symbol"])
    for row in prelim:
        if row["current_hgnc_symbol"]:
            row["hgnc_collision_size"] = str(current_counts[row["current_hgnc_symbol"]])
            if current_counts[row["current_hgnc_symbol"]] > 1:
                row["mapping_status"] = "HOLD_COLLISION"
    audit_status = {row["raw_symbol"]: row for row in audit}
    for row in prelim:
        if row["mapping_status"] == "HOLD_COLLISION":
            audit_status[row["raw_symbol"]]["status"] = "HOLD_COLLISION"

    write_tsv(OUTPUT, prelim)
    write_tsv(AUDIT, audit)
    route_counts = Counter(row["mapping_route"] for row in prelim)
    status_counts = Counter(row["mapping_status"] for row in prelim)
    summary_rows = [
        {"metric": "input_candidate_symbols", "value": str(len(prelim)), "note": "source symbols retained"},
        {"metric": "unique_current_hgnc_symbols", "value": str(len(current_counts)), "note": "before collision hold"},
        *({"metric": f"mapping_route::{key}", "value": str(value), "note": ""}
          for key, value in sorted(route_counts.items())),
        *({"metric": f"mapping_status::{key}", "value": str(value), "note": ""}
          for key, value in sorted(status_counts.items())),
    ]
    write_tsv(SUMMARY, summary_rows)
    print(f"HGNC audit: {len(prelim)} inputs; {len(current_counts)} unique current symbols; "
          f"routes={dict(route_counts)}; status={dict(status_counts)}")


if __name__ == "__main__":
    main()
