#!/usr/bin/env python3
"""Reconcile GSE30999 paper-level design with public GEO sample identifiers."""

from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "metadata" / "sample_manifest.tsv"
PAIR_OUT = ROOT / "metadata" / "gse30999_metadata_pair_registry.tsv"
SUMMARY_OUT = ROOT / "audits" / "gse30999_design_reconciliation.tsv"


def read_tsv(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main():
    rows = [row for row in read_tsv(INPUT) if row["dataset_id"] == "GSE30999"]
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["donor_or_animal_id"]].append(row)
    registry = []
    for subject, group in sorted(grouped.items()):
        nl = [row for row in group if row["sample_title"].endswith("_NL")]
        ls = [row for row in group if row["sample_title"].endswith("_LS")]
        complete = len(nl) == 1 and len(ls) == 1
        registry.append({
            "public_subject_id": subject,
            "nl_gsm": nl[0]["sample_id"] if len(nl) == 1 else "",
            "ls_gsm": ls[0]["sample_id"] if len(ls) == 1 else "",
            "n_public_records": len(group),
            "metadata_pair_status": "COMPLETE_EXACT_ID_PAIR" if complete else "SINGLETON_UNRESOLVED",
            "primary_validation_eligibility": "ELIGIBLE_AFTER_F1" if complete else "HOLD",
            "reason": "exact public subject ID and both biopsy types" if complete else "paper reports 85 pairs but public ID counterpart is unresolved",
            "expression_data_accessed_for_pairing": "NO",
        })
    summaries = [
        {"evidence_layer":"primary paper cohort","metric":"skin-biopsy participants","value":"89","status":"PASS","interpretation":"Methods and Results explicitly state 89 patients entered the biopsy substudy","source":"PMC3472561 paragraphs 8 and 23"},
        {"evidence_layer":"primary paper analysis","metric":"reported matched PP-PN pairs","value":"85","status":"PASS","interpretation":"Abstract/introduction report 85 paired lesional and non-lesional samples","source":"PMC3472561 paragraphs 2 and 7"},
        {"evidence_layer":"primary paper QC","metric":"low-QC samples excluded","value":"3","status":"PASS","interpretation":"Paper says three samples were excluded; it does not publish the GEO subject mapping in the main XML","source":"PMC3472561 paragraph 25"},
        {"evidence_layer":"public GEO records","metric":"sample records","value":str(len(rows)),"status":"PASS","interpretation":"85 LS and 85 NL records","source":"GSE30999 family SOFT"},
        {"evidence_layer":"public GEO identifiers","metric":"distinct subject IDs","value":str(len(grouped)),"status":"PASS","interpretation":"Matches the 89-person biopsy-substudy size","source":"sample title and subject characteristic"},
        {"evidence_layer":"public GEO identifiers","metric":"complete exact-ID pairs","value":str(sum(row["metadata_pair_status"] == "COMPLETE_EXACT_ID_PAIR" for row in registry)),"status":"PARTIAL","interpretation":"Four of the paper-reported 85 pairs cannot be reconstructed from exact public IDs","source":"metadata/gse30999_metadata_pair_registry.tsv"},
        {"evidence_layer":"public GEO identifiers","metric":"singleton records","value":str(sum(row["metadata_pair_status"] == "SINGLETON_UNRESOLVED" for row in registry)),"status":"PARTIAL","interpretation":"Four LS-only and four NL-only public IDs; no safe cross-ID matching rule","source":"metadata/gse30999_metadata_pair_registry.tsv"},
    ]
    assert len(rows) == 170 and len(grouped) == 89
    assert sum(row["metadata_pair_status"] == "COMPLETE_EXACT_ID_PAIR" for row in registry) == 81
    assert sum(row["metadata_pair_status"] == "SINGLETON_UNRESOLVED" for row in registry) == 8
    write_tsv(PAIR_OUT, registry)
    write_tsv(SUMMARY_OUT, summaries)
    print("PASS: 170 records, 89 public IDs, 81 exact pairs, 8 unresolved singletons; expression not accessed")


if __name__ == "__main__":
    main()
