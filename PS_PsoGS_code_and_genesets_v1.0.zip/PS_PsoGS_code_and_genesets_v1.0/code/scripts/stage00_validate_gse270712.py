#!/usr/bin/env python3
"""Validate the conservative GSE270712 label adjudication."""

from __future__ import annotations

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    rows = read_tsv(ROOT / "audits" / "gse270712_label_audit.tsv")
    evidence = read_tsv(ROOT / "audits" / "gse270712_paper_evidence.tsv")
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append(
            {
                "check_id": check_id,
                "observed": str(observed),
                "expected": str(expected),
                "status": "PASS" if passed else "FAIL",
                "note": note,
            }
        )
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    held = [r for r in rows if r["label_status"] == "HOLD_CONFLICTING_GEO_FIELDS"]
    confirmed = [r for r in rows if r["label_status"] == "DESCRIPTIVE_LABEL_CONFIRMED"]
    check("sample_rows", len(rows), 6)
    check("unique_gsm", len({r["sample_accession"] for r in rows}), 6)
    check("confirmed_descriptive_labels", len(confirmed), 4)
    check("held_conflicting_labels", len(held), 2)
    check("held_accessions", ",".join(sorted(r["sample_accession"] for r in held)), "GSM8350489,GSM8350490")
    check("held_canonical_blank", sum(not r["canonical_condition"] for r in held), 2)
    check("confirmed_fields_concordant", sum(r["field_concordance"] == "PASS" for r in confirmed), 4)
    check("held_fields_conflicting", sum(r["field_concordance"] == "FAIL" for r in held), 2)
    check("all_pooled_libraries", sum(r["statistical_unit"] == "pooled_library" for r in rows), 6)
    check("all_three_animals_per_pool", sum(r["animals_per_pool"] == "3" for r in rows), 6)
    check("all_one_library_per_condition", sum(r["library_replicates_per_condition"] == "1" for r in rows), 6)
    check("all_descriptive_only", sum(r["confirmatory_eligibility"] == "DESCRIPTIVE_ONLY" for r in rows), 6)
    check("expression_not_accessed", sum(r["expression_matrix_accessed"] == "NO" for r in rows), 6)
    check("primary_source_evidence_rows", len(evidence), 3)
    check("pooling_evidence_present", sum(r["evidence_id"] == "GSE270712_PAPER_POOLING" for r in evidence), 1)

    write_tsv(ROOT / "audits" / "gse270712_integrity_checks.tsv", checks)
    print(f"PASS: {len(checks)} GSE270712 integrity checks")


if __name__ == "__main__":
    main()
