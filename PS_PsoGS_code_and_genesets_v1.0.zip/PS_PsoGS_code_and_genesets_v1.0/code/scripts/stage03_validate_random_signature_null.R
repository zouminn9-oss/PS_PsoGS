options(stringsAsFactors = FALSE)
.libPaths(c(normalizePath(file.path("r_libs", "stage02")),
            normalizePath(file.path("r_libs", "stage01")), .libPaths()))
stopifnot(requireNamespace("edgeR", quietly = TRUE))

checks <- list()
add_check <- function(id, ok, detail) {
  checks[[length(checks) + 1L]] <<- data.frame(check_id = id,
    status = if (isTRUE(ok)) "PASS" else "FAIL", detail = as.character(detail))
}
eq <- function(x, y, tol = 1e-12) isTRUE(all.equal(as.numeric(x), as.numeric(y), tolerance = tol))
bin <- function(x, bins) as.integer(ceiling(rank(x, ties.method = "first") * bins / length(x)))

sep <- read.delim(file.path("genesets", "SEP_v1.0.tsv"), check.names = FALSE)
null <- read.delim(file.path("results", "stage03", "random_null", "random_signature_null.tsv"), check.names = FALSE)
summary <- read.delim(file.path("results", "stage03", "random_null", "random_signature_null_summary.tsv"), check.names = FALSE)
strata_ref <- read.delim(file.path("results", "stage03", "random_null", "random_signature_match_strata.tsv"), check.names = FALSE)
membership <- readRDS(file.path("results", "stage03", "random_null", "random_signature_membership.rds"))
observed <- read.delim(file.path("results", "stage03", "scores", "paired_score_statistics.tsv"), check.names = FALSE)

add_check("null_rows", nrow(null) == 4000L, nrow(null))
add_check("two_cohorts", identical(sort(unique(null$dataset_id)), c("GSE121212", "GSE30999")), paste(unique(null$dataset_id), collapse = ","))
add_check("permutation_sequence", all(vapply(split(null$permutation_id, null$dataset_id), identical, logical(1), 1:2000)), "1:2000 each")
add_check("fixed_seed", all(null$seed == 20260911L) && membership$seed == 20260911L, unique(null$seed))
add_check("membership_B", membership$B == 2000L && length(membership$GSE30999) == 2000L && length(membership$GSE121212) == 2000L, membership$B)
add_check("finite_null_effects", all(is.finite(null$random_effect)), sum(!is.finite(null$random_effect)))

array_df <- read.delim(gzfile(file.path("results", "stage03", "matrices", "gse30999_gcrma_entrez_gene_matrix.tsv.gz")), check.names = FALSE)
array_ids <- as.character(array_df[[1]])
array_mat <- as.matrix(array_df[-1]); storage.mode(array_mat) <- "double"; rownames(array_mat) <- array_ids
array_strata <- setNames(paste0("E", bin(rowMeans(array_mat), 10L)), array_ids)
array_sep_up <- intersect(as.character(sep$selected_human_entrez_id[sep$sep_direction == "UP"]), array_ids)
array_sep_down <- intersect(as.character(sep$selected_human_entrez_id[sep$sep_direction == "DOWN"]), array_ids)

count_df <- read.delim(gzfile(file.path("data", "raw", "validation", "GSE121212", "GSE121212_readcount.txt.gz")), check.names = FALSE)
count_ids <- as.character(count_df[[1]])
count_mat <- as.matrix(count_df[-1]); storage.mode(count_mat) <- "integer"
count_mat <- rowsum(count_mat, group = count_ids, reorder = FALSE)
y <- edgeR::DGEList(counts = count_mat); y <- edgeR::calcNormFactors(y, method = "TMM")
logcpm <- edgeR::cpm(y, log = TRUE, prior.count = 2)
rna_ids <- rownames(count_mat)
rna_strata <- setNames(paste0("E", bin(rowMeans(logcpm), 10L), "_D", bin(rowMeans(count_mat > 0), 5L)), rna_ids)
rna_sep_up <- intersect(sep$human_gene_symbol[sep$sep_direction == "UP"], rna_ids)
rna_sep_down <- intersect(sep$human_gene_symbol[sep$sep_direction == "DOWN"], rna_ids)

validate_draws <- function(dataset_id, draws, strata, sep_up, sep_down) {
  expected_up <- table(strata[sep_up]); expected_down <- table(strata[sep_down])
  expected_up <- expected_up[order(names(expected_up))]
  expected_down <- expected_down[order(names(expected_down))]
  valid <- vapply(draws, function(draw) {
    up_tab <- table(factor(strata[draw$up], levels = union(names(expected_up), names(expected_down))))
    down_tab <- table(factor(strata[draw$down], levels = union(names(expected_up), names(expected_down))))
    ref_up <- expected_up[match(names(up_tab), names(expected_up))]; ref_up[is.na(ref_up)] <- 0L
    ref_down <- expected_down[match(names(down_tab), names(expected_down))]; ref_down[is.na(ref_down)] <- 0L
    length(draw$up) == length(sep_up) && length(draw$down) == length(sep_down) &&
      !anyDuplicated(draw$up) && !anyDuplicated(draw$down) &&
      length(intersect(draw$up, draw$down)) == 0L &&
      length(intersect(c(draw$up, draw$down), c(sep_up, sep_down))) == 0L &&
      identical(as.integer(up_tab), as.integer(ref_up)) &&
      identical(as.integer(down_tab), as.integer(ref_down))
  }, logical(1))
  add_check(paste0(dataset_id, "_all_2000_memberships_match"), all(valid), sum(valid))
}
validate_draws("GSE30999", membership$GSE30999, array_strata, array_sep_up, array_sep_down)
validate_draws("GSE121212", membership$GSE121212, rna_strata, rna_sep_up, rna_sep_down)

for (dataset in c("GSE30999", "GSE121212")) {
  n <- null[null$dataset_id == dataset, ]
  s <- summary[summary$dataset_id == dataset, ]
  o <- observed$mean_delta[observed$dataset_id == dataset]
  add_check(paste0(dataset, "_observed_identity"), eq(s$observed_effect, o), s$observed_effect)
  add_check(paste0(dataset, "_null_mean"), eq(s$null_mean, mean(n$random_effect)), s$null_mean)
  add_check(paste0(dataset, "_null_sd"), eq(s$null_sd, sd(n$random_effect)), s$null_sd)
  p <- (1 + sum(n$random_effect >= o)) / 2001
  add_check(paste0(dataset, "_empirical_p"), eq(s$empirical_p_greater, p), s$empirical_p_greater)
  add_check(paste0(dataset, "_minimum_empirical_p"), eq(p, 1 / 2001), p)
}
add_check("strata_have_sufficient_pools", all(strata_ref$pool_n >= strata_ref$target_total), min(strata_ref$pool_n - strata_ref$target_total))
add_check("config_exists", file.exists(file.path("config", "stage03_random_signature_null.yaml")), "present")

audit <- do.call(rbind, checks)
write.table(audit, file.path("audits", "stage03_random_signature_null_checks.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
failed <- audit$check_id[audit$status != "PASS"]
if (length(failed)) stop("Random-null audit failed: ", paste(failed, collapse = ", "))
cat(sprintf("PASS: %d matched-random null checks including all 4,000 memberships\n", nrow(audit)))
