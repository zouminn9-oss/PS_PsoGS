from pathlib import Path
import gzip
ROOT=Path(__file__).resolve().parents[1]
rows=[]
for path in sorted((ROOT/"data/raw/stage07/GSE228421").glob("*matrix.mtx.gz")):
    with gzip.open(path,"rt") as f:
        header=f.readline().strip()
        line=f.readline().strip()
        while line.startswith("%"):
            line=f.readline().strip()
    genes,barcodes,nnz=map(int,line.split())
    rows.append((path.name,genes,barcodes,nnz))
for row in rows: print("\t".join(map(str,row)))
