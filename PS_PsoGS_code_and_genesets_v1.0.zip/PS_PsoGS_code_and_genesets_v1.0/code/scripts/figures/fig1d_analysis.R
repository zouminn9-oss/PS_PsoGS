options(stringsAsFactors = FALSE)

dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)

ledger <- read.delim(file.path("metadata", "gene_evidence_ledger.tsv"),
                     check.names = FALSE, stringsAsFactors = FALSE)
ontology <- read.delim(file.path("genesets", "endocrine_go_exact_2026-09-10.tsv"),
                       check.names = FALSE, stringsAsFactors = FALSE)

ctra <- unique(ledger$normalized_symbol[
  ledger$evidence_source == "CTRA_KOHRT2016_v1.0" &
  ledger$core_eligibility == "ANNOTATION_ONLY" & ledger$normalized_symbol != ""])
gse70603 <- unique(ledger$normalized_symbol[
  ledger$evidence_source == "GSE70603_TIME_LOCKED_v1.1" &
  ledger$core_eligibility == "ANNOTATION_ONLY" & ledger$normalized_symbol != ""])
quickgo <- unique(ontology$source_symbol[
  ontology$species == "Homo sapiens" &
  ontology$hgnc_exact_status == "PASS_EXACT_APPROVED_SYMBOL" & ontology$source_symbol != ""])

stopifnot(length(ctra) == 53L, length(gse70603) == 3871L, length(quickgo) == 46L)
all_genes <- sort(unique(c(ctra, gse70603, quickgo)))
source_data <- data.frame(
  gene_symbol = all_genes,
  CTRA_fixed = as.integer(all_genes %in% ctra),
  GSE70603_time_locked = as.integer(all_genes %in% gse70603),
  QuickGO_exact_human = as.integer(all_genes %in% quickgo),
  stringsAsFactors = FALSE
)
source_data$membership_pattern <- paste0(source_data$CTRA_fixed,
                                         source_data$GSE70603_time_locked,
                                         source_data$QuickGO_exact_human)
source_data$number_of_layers <- source_data$CTRA_fixed + source_data$GSE70603_time_locked +
  source_data$QuickGO_exact_human
source_data$core_eligibility <- "NO_AUTOMATIC_CORE_ELIGIBILITY"
source_data$directional_union_score_generated <- "NO"
source_data$analysis_scope <- "human exact-approved symbols; descriptive overlap only"
write.table(source_data, file.path("figures", "source_data", "fig1d.tsv"), sep = "\t",
            row.names = FALSE, quote = FALSE, na = "")

pattern_label <- function(pattern) {
  labels <- c("CTRA fixed", "GSE70603 time-locked", "QuickGO exact human")
  paste(labels[strsplit(pattern, "", fixed = TRUE)[[1]] == "1"], collapse = " + ")
}
pattern_counts <- sort(table(source_data$membership_pattern), decreasing = TRUE)
intersection_stats <- data.frame(
  statistic_type = "EXCLUSIVE_INTERSECTION",
  group = names(pattern_counts),
  display_label = vapply(names(pattern_counts), pattern_label, character(1)),
  count = as.integer(pattern_counts),
  denominator = nrow(source_data),
  percent = 100 * as.integer(pattern_counts) / nrow(source_data),
  statistical_test = "none_descriptive_overlap",
  note = "Exclusive membership among three frozen evidence layers.",
  stringsAsFactors = FALSE
)
set_stats <- data.frame(
  statistic_type = "SET_SIZE",
  group = c("100", "010", "001"),
  display_label = c("CTRA fixed", "GSE70603 time-locked", "QuickGO exact human"),
  count = c(length(ctra), length(gse70603), length(quickgo)),
  denominator = nrow(source_data),
  percent = 100 * c(length(ctra), length(gse70603), length(quickgo)) / nrow(source_data),
  statistical_test = "none_descriptive_overlap",
  note = "Non-exclusive set size; evidence classes retain separate meanings.",
  stringsAsFactors = FALSE
)
total_stats <- data.frame(
  statistic_type = "UNION_SIZE", group = "union", display_label = "Unique exact-approved genes",
  count = nrow(source_data), denominator = nrow(source_data), percent = 100,
  statistical_test = "none_descriptive_overlap",
  note = "Union is displayed for overlap accounting only and is not a directional score or Core.",
  stringsAsFactors = FALSE
)
stats <- rbind(set_stats, intersection_stats, total_stats)
write.table(stats, file.path("results", "figures", "fig1d_statistics.tsv"), sep = "\t",
            row.names = FALSE, quote = FALSE, na = "")
cat(sprintf("PASS: fig1d source data %d genes; %d exclusive patterns\n",
            nrow(source_data), nrow(intersection_stats)))
