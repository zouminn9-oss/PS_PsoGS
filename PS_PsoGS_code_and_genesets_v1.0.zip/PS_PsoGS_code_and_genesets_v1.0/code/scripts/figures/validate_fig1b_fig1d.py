#!/usr/bin/env python3
"""Data, render, print-size and manifest QA for Figure 1B and 1D."""

from __future__ import annotations

import csv
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line or line.lstrip().startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        out[key.strip()] = value.strip().strip('"')
    return out


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError(f"Not a PNG: {path}")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    width = float(root.attrib["width"].replace("pt", "")) / 72
    height = float(root.attrib["height"].replace("pt", "")) / 72
    return width, height


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    b = read_tsv(ROOT / "figures" / "source_data" / "fig1b.tsv")
    bs = read_tsv(ROOT / "results" / "figures" / "fig1b_statistics.tsv")
    d = read_tsv(ROOT / "figures" / "source_data" / "fig1d.tsv")
    ds = read_tsv(ROOT / "results" / "figures" / "fig1d_statistics.tsv")
    manifest = {row["panel_id"]: row for row in read_tsv(ROOT / "panel_manifest.tsv")}

    check("fig1b_resources", len(b), 9)
    check("fig1b_unique_resources", len({row["resource_id"] for row in b}), 9)
    check("fig1b_evidence_lanes", len({row["lane"] for row in b}), 6)
    check("fig1b_status_pass", sum(row["status_group"] == "PASS" for row in b), 4)
    check("fig1b_status_partial", sum(row["status_group"] == "PARTIAL" for row in b), 5)
    check("fig1b_status_blocked", sum(row["status_group"] == "BLOCKED" for row in b), 0)
    gse212126 = next(row for row in b if row["resource_id"] == "GSE212126_FACTORIAL")
    check("fig1b_gse212126_f1_source", gse212126["member_mode"], "FROZEN_F1_DEVELOPMENT_SOURCE")
    check("fig1b_gse212126_pass", gse212126["freeze_status"], "PASS_F1_SOURCE")
    check("fig1b_no_automatic_core", sum(row["automatic_core_eligibility"] == "NO" for row in b), 9)
    check("fig1b_no_automatic_score", sum(row["automatic_directional_score"] == "NO" for row in b), 9)
    check("fig1b_statistics_tests_descriptive", all(row["statistical_test"] == "none_descriptive_audit" for row in bs), True)

    check("fig1d_union_genes", len(d), 3940)
    check("fig1d_unique_genes", len({row["gene_symbol"] for row in d}), 3940)
    check("fig1d_ctra_size", sum(int(row["CTRA_fixed"]) for row in d), 53)
    check("fig1d_gse70603_size", sum(int(row["GSE70603_time_locked"]) for row in d), 3871)
    check("fig1d_quickgo_size", sum(int(row["QuickGO_exact_human"]) for row in d), 46)
    pattern_counts = Counter(row["membership_pattern"] for row in d)
    check("fig1d_patterns", dict(sorted(pattern_counts.items())),
          {"001": 37, "010": 3841, "011": 9, "100": 32, "110": 21})
    check("fig1d_no_automatic_core", sum(row["core_eligibility"] == "NO_AUTOMATIC_CORE_ELIGIBILITY" for row in d), 3940)
    check("fig1d_no_directional_union", sum(row["directional_union_score_generated"] == "NO" for row in d), 3940)
    check("fig1d_statistics_tests_descriptive", all(row["statistical_test"] == "none_descriptive_overlap" for row in ds), True)

    for panel, expected_mm in [("fig1b", (178, 92)), ("fig1d", (178, 98))]:
        cfg = read_config(ROOT / "config" / "figures" / f"{panel}.yaml")
        svg = ROOT / "figures" / "panels" / f"{panel}.svg"
        png = ROOT / "figures" / "previews" / f"{panel}.png"
        caption = ROOT / "figures" / "captions" / f"{panel}.md"
        check(f"{panel}_minimum_text_pt", float(cfg["minimum_text_pt"]) >= 8, True)
        check(f"{panel}_print_width_mm", cfg["print_width_mm"], expected_mm[0])
        check(f"{panel}_print_height_mm", cfg["print_height_mm"], expected_mm[1])
        check(f"{panel}_svg_exists", svg.exists() and svg.stat().st_size > 5000, True)
        check(f"{panel}_png_exists", png.exists() and png.stat().st_size > 20000, True)
        check(f"{panel}_caption_exists", caption.exists() and caption.stat().st_size > 500, True)
        svg_w, svg_h = svg_dimensions(svg)
        check(f"{panel}_svg_width_inches", abs(svg_w - float(cfg["width_inches"])) < 0.02, True)
        check(f"{panel}_svg_height_inches", abs(svg_h - float(cfg["height_inches"])) < 0.02, True)
        png_w, png_h = png_dimensions(png)
        check(f"{panel}_png_width_pixels", abs(png_w - round(float(cfg["width_inches"]) * int(cfg["png_dpi"]))) <= 1, True)
        check(f"{panel}_png_height_pixels", abs(png_h - round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))) <= 1, True)
        panel_id = panel[-2:].upper().replace("1", "1")
        check(f"{panel}_manifest_vector", manifest[panel_id]["vector_output"], f"figures/panels/{panel}.svg")
        check(f"{panel}_manifest_preview", manifest[panel_id]["preview_output"], f"figures/previews/{panel}.png")

    out = ROOT / "audits" / "fig1b_fig1d_qa_checks.tsv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 1B/1D data and render QA checks")


if __name__ == "__main__":
    main()
