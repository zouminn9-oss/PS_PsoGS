options(stringsAsFactors = FALSE)
dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)

stats <- read.delim(file.path("results", "stage03", "sensitivity", "stage03_sensitivity.tsv"), check.names = FALSE)
scores <- read.delim(file.path("results", "stage03", "sensitivity", "stage03_sensitivity_patient_scores.tsv"), check.names = FALSE)
availability <- read.delim(file.path("results", "stage03", "sensitivity", "stage03_sensitivity_availability.tsv"), check.names = FALSE)
array_audit <- read.delim(file.path("audits", "stage03_array_mean_preparation_checks.tsv"), check.names = FALSE)
stopifnot(nrow(stats) == 13L, nrow(scores) == 513L, all(array_audit$status == "PASS"),
          availability$value[availability$metric == "shared_SEP"] == 2550L)

labels <- c(PRIMARY_FULL_SEP = "Primary full SEP",
            SHARED_PLATFORM_SEP = "Shared-platform SEP",
            HIGH_CONFIDENCE_SEP = "F1 high-confidence SEP",
            HIGH_CONFIDENCE_SHARED = "High-confidence + shared",
            ARRAY_ALL_PROBE_MEAN = "Array: all-probe mean",
            CLINICAL_COVARIATE_ADJUSTED = "Clinical covariate adjusted",
            KNOWN_DONOR_OVERLAP_EXCLUSION = "Known-overlap exclusion")
stats$display_label <- labels[stats$variant_id]
stats$display_order <- match(stats$variant_id, names(labels))
stats$display_status <- ifelse(stats$status == "ESTIMATED", "ESTIMATED", stats$status)
stats$timing_flag <- ifelse(stats$variant_id == "ARRAY_ALL_PROBE_MEAN", "POST_PRIMARY_DETERMINISTIC",
                            ifelse(stats$status == "ESTIMATED", "FROZEN", "INPUT_LIMIT"))
write.table(stats, file.path("figures", "source_data", "fig2h.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(stats, file.path("results", "figures", "fig2h_statistics.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: Figure 2H has %d estimable and %d blocked/not-estimable rows\n",
            sum(stats$status == "ESTIMATED"), sum(stats$status != "ESTIMATED")))

