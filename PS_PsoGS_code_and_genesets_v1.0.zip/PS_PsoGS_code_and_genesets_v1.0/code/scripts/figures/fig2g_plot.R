options(stringsAsFactors = FALSE)
source(file.path("scripts", "figures", "fig2g_analysis.R"))
dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)

draw_panel <- function(device_fun) {
  device_fun()
  on.exit(dev.off(), add = TRUE)
  layout(matrix(1:4, nrow = 2, byrow = TRUE), widths = c(4.8, 1.7), heights = c(1, 1))
  par(oma = c(2.7, 0.5, 2.6, 0.5), family = "sans")
  cohorts <- c("GSE30999", "GSE121212")
  colors <- c("#0072B2", "#D55E00")
  subtitles <- c("Array: expression-decile matched", "RNA-seq: expression x detection matched")
  for (i in seq_along(cohorts)) {
    d <- cohorts[i]
    values <- source$null_z[source$dataset_id == d & source$record_type == "matched_random_signature"]
    stat <- summary[summary$dataset_id == d, ]
    par(mar = c(if (i == 2) 3.5 else 1.7, 3.7, if (i == 1) 2.2 else 1.2, 0.5), mgp = c(2.0, 0.6, 0), tcl = -0.25)
    hist(values, breaks = seq(-4.5, 4.5, by = 0.3), freq = FALSE,
         xlim = c(-4.5, 4.5), col = "#D9E0E4", border = "white",
         xaxt = if (i == 2) "s" else "n", yaxt = "n", xlab = "", ylab = "Density", main = "")
    den <- density(values, from = -4.5, to = 4.5)
    lines(den, col = colors[i], lwd = 2)
    abline(v = 0, col = "#60676D", lty = 3)
    q <- quantile(values, c(0.025, 0.975))
    segments(q[1], 0.012, q[2], 0.012, col = "#343B42", lwd = 2)
    mtext(paste0(cohorts[i], "  |  ", subtitles[i]), side = 3, line = 0.4, adj = 0, cex = 0.88, font = 2)
    if (i == 2) mtext("Matched-random effect (null SD units)", side = 1, line = 2.2, cex = 0.78)
    text(-4.25, max(den$y) * 0.88, labels = "2,000 random sets", adj = 0, cex = 0.72, col = "#4C555C")

    par(mar = c(if (i == 2) 3.5 else 1.7, 1.0, if (i == 1) 2.2 else 1.2, 0.8), mgp = c(2.0, 0.6, 0), tcl = -0.25)
    oz <- stat$observed_z_vs_null
    plot(NA, xlim = c(oz - 2.6, oz + 2.6), ylim = c(0, 1), axes = FALSE, xlab = "", ylab = "")
    axis(1, at = round(oz), labels = if (i == 2) round(oz) else FALSE, cex.axis = 0.72)
    abline(h = 0.5, col = "#D9E0E4", lwd = 1.2)
    points(oz, 0.5, pch = 23, bg = colors[i], col = "white", cex = 1.8, lwd = 1.2)
    text(oz, 0.76, labels = sprintf("SEP effect %.4f", stat$observed_effect), cex = 0.72, font = 2)
    text(oz, 0.23, labels = sprintf("0/2,000 exceed\nP = %.4g", stat$empirical_p_greater), cex = 0.68)
    mtext("Observed SEP\n(separate x-axis)", side = 3, line = 0.1, cex = 0.72, font = 2)
    if (i == 2) mtext("Null SD units", side = 1, line = 2.2, cex = 0.78)
    usr <- par("usr")
    text(usr[1] - diff(usr[1:2]) * 0.035, 0.5, "//", xpd = NA, cex = 1.0, font = 2)
    box(col = "#AEB7BD")
  }
  mtext("Expression- and detection-matched random signature null", side = 3, outer = TRUE, line = 1.35, cex = 1.05, font = 2)
  mtext("Membership generated without lesion labels; empirical one-sided test with +1 correction", side = 3, outer = TRUE, line = 0.15, cex = 0.72, col = "#4C555C")
  mtext("Matching addresses size and coarse measurement structure, not all biological or cell-composition confounding.", side = 1, outer = TRUE, line = 1.25, cex = 0.66, col = "#4C555C")
}

draw_panel(function() svg(file.path("figures", "panels", "fig2g.svg"), width = 7.0079, height = 4.7244, pointsize = 10))
draw_panel(function() png(file.path("figures", "previews", "fig2g.png"), width = 7.0079, height = 4.7244, units = "in", res = 300, pointsize = 10))
cat("PASS: rendered Figure 2G SVG and 300-dpi PNG\n")

