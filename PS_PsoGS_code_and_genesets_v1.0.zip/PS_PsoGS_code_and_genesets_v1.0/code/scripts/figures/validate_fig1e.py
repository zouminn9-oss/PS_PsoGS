#!/usr/bin/env python3
"""Data, isolation, render and print QA for Figure 1E."""

from __future__ import annotations

import csv
import math
import re
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    config: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            config[key.strip()] = value.strip().strip('"')
    return config


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError(f"not a PNG: {path}")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    source = read_tsv(ROOT / "figures" / "source_data" / "fig1e.tsv")
    stats_rows = read_tsv(ROOT / "results" / "figures" / "fig1e_statistics.tsv")
    stats = {row["metric"]: row for row in stats_rows}
    registry = read_tsv(ROOT / "metadata" / "gse212126_library_animal_registry.tsv")
    decision = read_tsv(ROOT / "results" / "stage02" / "counts" /
                        "gse212126_strand_decision.tsv")
    count_audit = read_tsv(ROOT / "audits" / "stage02_counts" /
                           "gse212126_count_integrity_checks.tsv")
    model_audit = read_tsv(ROOT / "audits" / "stage02_counts" /
                           "gse212126_edger_integrity_checks.tsv")
    pca = [row for row in source if row["record_type"] == "PCA"]
    strand = [row for row in source if row["record_type"] == "STRAND"]
    library = [row for row in source if row["record_type"] == "LIBRARY"]

    check("fig1e_source_rows", len(source), 60)
    check("fig1e_pca_rows", len(pca), 12)
    check("fig1e_strand_rows", len(strand), 36)
    check("fig1e_library_rows", len(library), 12)
    check("fig1e_unique_pca_mice", len({row["canonical_animal_id"] for row in pca}), 12)
    check("fig1e_unique_library_mice", len({row["canonical_animal_id"] for row in library}), 12)
    check("fig1e_group_balance", Counter(row["condition"] for row in pca),
          Counter({"Control": 3, "CRS": 3, "IMQ": 3, "CRS+IMQ": 3}))
    check("fig1e_registry_identity", {row["srr"] for row in pca}, {row["srr"] for row in registry})
    check("fig1e_independent_mouse_unit",
          all(row["statistical_unit"] == "independent_mouse" for row in pca), True)
    check("fig1e_finite_pca", all(math.isfinite(float(row[key])) for row in pca
                                  for key in ("PC1", "PC2")), True)
    check("fig1e_pc1_variance", abs(float(stats["PC1_variance_explained"]["value"]) -
                                     0.428978582424355) < 1e-12, True)
    check("fig1e_pc2_variance", abs(float(stats["PC2_variance_explained"]["value"]) -
                                     0.291062366233702) < 1e-12, True)
    check("fig1e_all_three_strand_settings",
          Counter(row["strand_setting"] for row in strand), Counter({"0": 12, "1": 12, "2": 12}))
    check("fig1e_assignment_fractions_bounded",
          all(0 <= float(row["assignment_fraction"]) <= 1 for row in strand), True)
    check("fig1e_selected_strand", {row["selected_strand"] for row in decision}, {"2"})
    check("fig1e_no_DE_based_strand_selection",
          all(row["selection_used_differential_expression"] == "FALSE" for row in decision), True)
    check("fig1e_reverse_assignment_range",
          (round(min(float(row["assignment_fraction"]) for row in strand
                     if row["strand_setting"] == "2"), 3),
           round(max(float(row["assignment_fraction"]) for row in strand
                     if row["strand_setting"] == "2"), 3)), (0.871, 0.885))
    check("fig1e_forward_assignment_range",
          (round(min(float(row["assignment_fraction"]) for row in strand
                     if row["strand_setting"] == "1"), 3),
           round(max(float(row["assignment_fraction"]) for row in strand
                   if row["strand_setting"] == "1"), 3)), (0.046, 0.055))
    raw_sizes = [int(float(row["raw_library_size"])) for row in library]
    check("fig1e_library_size_range", (min(raw_sizes), max(raw_sizes)), (18329821, 20272392))
    tmm = [float(row["TMM_norm_factor"]) for row in library]
    check("fig1e_tmm_positive", all(math.isfinite(value) and value > 0 for value in tmm), True)
    check("fig1e_count_audits", (len(count_audit), {row["status"] for row in count_audit}),
          (15, {"PASS"}))
    check("fig1e_model_audits", (len(model_audit), {row["status"] for row in model_audit}),
          (27, {"PASS"}))
    check("fig1e_statistics_rows", len(stats_rows), 17)
    check("fig1e_validation_locked", stats["validation_expression_accessed"]["value"], "0")

    cfg = read_config(ROOT / "config" / "figures" / "fig1e.yaml")
    plot_script = (ROOT / "scripts" / "figures" / "fig1e_plot.R").read_text(encoding="utf-8")
    analysis_script = (ROOT / "scripts" / "figures" / "fig1e_analysis.R").read_text(encoding="utf-8")
    svg = ROOT / "figures" / "panels" / "fig1e.svg"
    png = ROOT / "figures" / "previews" / "fig1e.png"
    caption = ROOT / "figures" / "captions" / "fig1e.md"
    check("fig1e_minimum_text_pt", float(cfg["minimum_text_pt"]) >= 8, True)
    text_cex = [float(value) for value in re.findall(r"cex(?:\.axis|\.lab)?\s*=\s*([0-9.]+)", plot_script)]
    check("fig1e_implemented_text_cex", min(text_cex) >= 0.67, True,
          "12-point device font makes cex=0.67 approximately 8 pt")
    check("fig1e_static_renderer", cfg["renderer"], "base_R_static")
    check("fig1e_validation_datasets_absent_from_analysis",
          "GSE30999" not in analysis_script and "GSE121212" not in analysis_script, True)
    check("fig1e_svg_exists", svg.exists() and svg.stat().st_size > 10000, True)
    check("fig1e_png_exists", png.exists() and png.stat().st_size > 50000, True)
    check("fig1e_caption_exists", caption.exists() and caption.stat().st_size > 1200, True)
    png_w, png_h = png_dimensions(png)
    check("fig1e_png_dimensions", (png_w, png_h),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    svg_w, svg_h = svg_dimensions(svg)
    check("fig1e_svg_width", abs(svg_w - float(cfg["width_inches"])) < 0.02, True)
    check("fig1e_svg_height", abs(svg_h - float(cfg["height_inches"])) < 0.02, True)
    svg_text = svg.read_text(encoding="utf-8")
    svg_rgb = {
        tuple(round(float(channel) * 255 / 100) for channel in match)
        for match in re.findall(r"rgb\(([0-9.]+)%, ([0-9.]+)%, ([0-9.]+)%\)", svg_text)
    }
    for color_key in ("control", "crs", "imq", "crs_imq", "ink"):
        color = cfg[color_key].lstrip("#")
        expected_rgb = tuple(int(color[index:index + 2], 16) for index in (0, 2, 4))
        check(f"fig1e_svg_uses_{color_key}", expected_rgb in svg_rgb, True)

    audit_path = ROOT / "audits" / "fig1e_qa_checks.tsv"
    with audit_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=("check_id", "observed", "expected", "status", "note"),
                                delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 1E data, isolation, render and print QA checks")


if __name__ == "__main__":
    main()
