#!/usr/bin/env python3
"""Sensitivity result, blocked-input, render and print QA for Figure 2H."""

from __future__ import annotations

import csv
import statistics
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
AUDIT = ROOT / "audits/fig2h_qa_checks.tsv"


def read_tsv(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def config(path):
    out = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            k, v = line.split(":", 1); out[k.strip()] = v.strip().strip('"')
    return out


def png_dimensions(path):
    with Path(path).open("rb") as handle: header = handle.read(24)
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path):
    root = ET.parse(path).getroot()
    return float(root.attrib["width"].replace("pt", "")) / 72, float(root.attrib["height"].replace("pt", "")) / 72


def main():
    checks = []

    def check(name, observed, expected):
        ok = observed == expected
        checks.append({"check_id": name, "observed": str(observed), "expected": str(expected), "status": "PASS" if ok else "FAIL"})
        if not ok: raise AssertionError(f"{name}: {observed!r} != {expected!r}")

    upstream = read_tsv(ROOT / "results/stage03/sensitivity/stage03_sensitivity.tsv")
    source = read_tsv(ROOT / "figures/source_data/fig2h.tsv")
    stats = read_tsv(ROOT / "results/figures/fig2h_statistics.tsv")
    scores = read_tsv(ROOT / "results/stage03/sensitivity/stage03_sensitivity_patient_scores.tsv")
    availability = read_tsv(ROOT / "metadata/stage03_covariate_availability.tsv")
    prep = read_tsv(ROOT / "audits/stage03_array_mean_preparation_checks.tsv")
    check("fig2h_rows", (len(upstream), len(source), len(stats)), (13, 13, 13))
    check("fig2h_source_identity", source, stats)
    check("fig2h_upstream_keys", {(r["dataset_id"], r["variant_id"]) for r in upstream},
          {(r["dataset_id"], r["variant_id"]) for r in source})
    check("fig2h_score_rows", len(scores), 513)
    check("fig2h_score_distribution", Counter((r["dataset_id"], r["variant_id"]) for r in scores),
          Counter({("GSE30999", "PRIMARY_FULL_SEP"): 81, ("GSE30999", "SHARED_PLATFORM_SEP"): 81,
                   ("GSE30999", "HIGH_CONFIDENCE_SEP"): 81, ("GSE30999", "HIGH_CONFIDENCE_SHARED"): 81,
                   ("GSE30999", "ARRAY_ALL_PROBE_MEAN"): 81, ("GSE121212", "PRIMARY_FULL_SEP"): 27,
                   ("GSE121212", "SHARED_PLATFORM_SEP"): 27, ("GSE121212", "HIGH_CONFIDENCE_SEP"): 27,
                   ("GSE121212", "HIGH_CONFIDENCE_SHARED"): 27}))
    smap = {(r["dataset_id"], r["variant_id"]): r for r in stats}
    for key, group in __import__("itertools").groupby(sorted(scores, key=lambda r: (r["dataset_id"], r["variant_id"])), key=lambda r: (r["dataset_id"], r["variant_id"])):
        rows = list(group); deltas = [float(r["delta_LS_minus_NL"]) for r in rows]
        check(f"fig2h_mean::{key}", abs(statistics.mean(deltas) - float(smap[key]["mean_delta"])) < 1e-13, True)
        check(f"fig2h_n::{key}", len(deltas), int(smap[key]["n_pairs"]))
        check(f"fig2h_positive::{key}", sum(x > 0 for x in deltas), int(smap[key]["positive_pairs"]))
    check("fig2h_estimated", sum(r["status"] == "ESTIMATED" for r in stats), 9)
    check("fig2h_blocked", Counter(r["status"] for r in stats if r["status"] != "ESTIMATED"),
          Counter({"BLOCKED_UNAVAILABLE_GEO_FIELDS": 2, "NOT_ESTIMABLE_NO_IDENTIFIED_OVERLAP": 2}))
    check("fig2h_all_estimated_positive", all(float(r["ci_low"]) > 0 for r in stats if r["status"] == "ESTIMATED"), True)
    check("fig2h_ratio_range", all(0.94 < float(r["ratio_to_primary"]) < 1.012 for r in stats if r["status"] == "ESTIMATED"), True)
    check("fig2h_primary_values", (round(float(smap[("GSE30999", "PRIMARY_FULL_SEP")]["mean_delta"]), 10),
                                      round(float(smap[("GSE121212", "PRIMARY_FULL_SEP")]["mean_delta"]), 10)),
          (0.0741412288, 0.0888004583))
    check("fig2h_array_mean_ratio", abs(float(smap[("GSE30999", "ARRAY_ALL_PROBE_MEAN")]["ratio_to_primary"]) - 1.01112527698543) < 1e-12, True)
    check("fig2h_covariate_rows", len(availability), 15)
    check("fig2h_missing_covariates", sum(r["status"] == "BLOCKED_UNAVAILABLE" for r in availability), 10)
    check("fig2h_preparation_audit", (len(prep), {r["status"] for r in prep}), (347, {"PASS"}))

    cfg = config(ROOT / "config/figures/fig2h.yaml")
    check("fig2h_manual_visual", cfg["manual_visual_inspection"], "PASS_2026-09-11_SECOND_RENDER_ALIGNED_VARIANT_ROWS")
    check("fig2h_min_text", float(cfg["minimum_text_pt"]) >= 8, True)
    plot_text = (ROOT / "scripts/figures/fig2h_plot.R").read_text(encoding="utf-8")
    check("fig2h_ascii_plot", all(ord(ch) < 128 for ch in plot_text), True)
    svg = ROOT / "figures/panels/fig2h.svg"; png = ROOT / "figures/previews/fig2h.png"
    caption = ROOT / "figures/captions/fig2h.md"
    check("fig2h_svg", svg.is_file() and svg.stat().st_size > 100000, True)
    check("fig2h_png", png.is_file() and png.stat().st_size > 60000, True)
    check("fig2h_caption", caption.is_file() and caption.stat().st_size > 1800, True)
    caption_text = caption.read_text(encoding="utf-8")
    for phrase in ("2,550 frozen members", "1,530 SEP members", "frozen after the primary result",
                   "no clinical-covariate model was fitted", "independence therefore remains provisional"):
        check(f"fig2h_caption::{phrase}", phrase in caption_text, True)
    check("fig2h_png_dimensions", png_dimensions(png),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])), round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    sw, sh = svg_dimensions(svg)
    check("fig2h_svg_size", abs(sw - float(cfg["width_inches"])) < 0.02 and abs(sh - float(cfg["height_inches"])) < 0.02, True)
    panel = {r["panel_id"]: r for r in read_tsv(ROOT / "panel_manifest.tsv")}["2H"]
    check("fig2h_panel", (panel["status"], panel["qa_status"], panel["figure_ready"]), ("PASS", "PASS_RENDER_DATA_PRINT", "YES"))
    with AUDIT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n"); writer.writeheader(); writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 2H sensitivity, blocked-input, render and print QA checks")


if __name__ == "__main__": main()
