options(stringsAsFactors = FALSE)
dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
claims <- read.delim(file.path("results", "stage03", "claim_matrix.tsv"), check.names = FALSE)
summary <- read.delim(file.path("results", "stage03", "claim_matrix_summary.tsv"), check.names = FALSE)
stopifnot(nrow(claims) == 11L,
          claims$synthesis_status[claims$claim_id == "C5"] == "FAIL",
          claims$synthesis_status[claims$claim_id == "C10"] == "BLOCKED",
          claims$synthesis_status[claims$claim_id == "C11"] == "NOT_TESTED")
write.table(claims, file.path("figures", "source_data", "fig2j.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(summary, file.path("results", "figures", "fig2j_statistics.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: Figure 2J source contains %d adjudicated claims\n", nrow(claims)))

