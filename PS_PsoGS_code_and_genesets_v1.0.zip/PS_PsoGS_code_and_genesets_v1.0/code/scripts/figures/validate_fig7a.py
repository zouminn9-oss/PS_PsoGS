#!/usr/bin/env python3
"""Data, cohort-role, render and print-size QA for Figure 7A."""

from __future__ import annotations

import csv
import struct
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line or line.lstrip().startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        out[key.strip()] = value.strip().strip('"')
    return out


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError(f"Not a PNG: {path}")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": str(observed),
                       "expected": str(expected), "status": "PASS" if passed else "FAIL",
                       "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    source = read_tsv(ROOT / "figures" / "source_data" / "fig7a.tsv")
    stats = read_tsv(ROOT / "results" / "figures" / "fig7a_statistics.tsv")
    registry = read_tsv(ROOT / "metadata" / "gse117468_patient_registry.tsv")
    panels = read_tsv(ROOT / "panel_manifest.tsv")

    def one(record_type: str, dataset_id: str, label: str) -> dict[str, str]:
        hits = [r for r in source if r["record_type"] == record_type and
                r["dataset_id"] == dataset_id and r["label"] == label]
        check(f"unique_{record_type}_{dataset_id}_{label}", len(hits), 1)
        return hits[0]

    check("fig7a_source_records", len(source), 26)
    check("fig7a_no_expression_access", sum(r["expression_values_accessed"] != "NO" for r in source), 0)
    check("fig7a_statistics_descriptive", all(r["statistical_test"] == "none_descriptive_cohort_audit" for r in stats), True)
    check("fig7a_statistics_rows", len(stats), len(source))

    g228_cohort = one("COHORT", "GSE228421", "Audited patients")
    check("gse228421_patients", g228_cohort["count"], 5)
    check("gse228421_libraries", g228_cohort["total"], 20)
    g228_time = [r for r in source if r["record_type"] == "TIMEPOINT_TISSUE" and r["dataset_id"] == "GSE228421"]
    check("gse228421_time_tissue_cells", len(g228_time), 4)
    check("gse228421_each_cell_n5", sum(r["count"] == "5" for r in g228_time), 4)
    g228_gate = one("MODEL_GATE", "GSE228421", "General response prediction")
    check("gse228421_prediction_not_eligible", g228_gate["eligibility"], "NOT_ELIGIBLE")

    g117_cohort = one("COHORT", "GSE117468", "Public deposit")
    check("gse117468_public_ids", g117_cohort["count"], 133)
    check("gse117468_public_arrays", g117_cohort["total"], 565)
    arms = [r for r in source if r["record_type"] == "TREATMENT_ARM"]
    check("gse117468_arm_patients", ",".join(r["count"] for r in arms), "46,42,29,16")
    check("gse117468_arm_arrays", ",".join(r["total"] for r in arms), "207,167,117,74")
    pairs = [r for r in source if r["record_type"] == "PAIRING"]
    check("gse117468_pair_counts", ",".join(r["count"] for r in pairs), "124,78,112,105")
    gates = [r for r in source if r["record_type"] == "PREDICTION_GATE"]
    check("gse117468_prediction_gate_counts", ",".join(r["count"] for r in gates), "88,75,74")
    check("gse117468_prediction_internal_only", gates[-1]["eligibility"], "METADATA_ELIGIBLE_INTERNAL_ONLY")
    check("gse117468_pasi75_yes", one("OUTCOME_CLASS", "GSE117468", "PASI75 responder")["count"], 62)
    check("gse117468_pasi75_no", one("OUTCOME_CLASS", "GSE117468", "PASI75 nonresponder")["count"], 12)
    check("gse117468_pasi90_yes", one("OUTCOME_CLASS", "GSE117468", "PASI90 responder")["count"], 50)
    check("gse117468_pasi90_no", one("OUTCOME_CLASS", "GSE117468", "PASI90 nonresponder")["count"], 24)
    check("gse117468_registry_rows", len(registry), 133)
    check("gse117468_registry_no_expression", sum(r["expression_values_accessed"] != "NO" for r in registry), 0)
    check("gse117468_sex_missing", one("FIELD_GATE", "GSE117468", "Sex available")["count"], 0)
    check("gse117468_no_external_cohort", one("EXTERNAL_GATE", "GSE117468", "Frozen external response cohort")["count"], 0)
    narrative = one("DENOMINATOR", "GSE117468", "Series narrative patients")
    public = one("DENOMINATOR", "GSE117468", "Public patient IDs")
    check("gse117468_narrative_denominator", narrative["count"] + "/" + narrative["total"], "116/844")
    check("gse117468_public_denominator", public["count"] + "/" + public["total"], "133/565")
    check("gse117468_denominators_separate", narrative["branch"] != public["branch"], True)

    cfg = read_config(ROOT / "config" / "figures" / "fig7a.yaml")
    svg = ROOT / "figures" / "panels" / "fig7a.svg"
    png = ROOT / "figures" / "previews" / "fig7a.png"
    caption = ROOT / "figures" / "captions" / "fig7a.md"
    check("fig7a_minimum_text_pt", float(cfg["minimum_text_pt"]) >= 8, True)
    check("fig7a_print_width_mm", cfg["print_width_mm"], 178)
    check("fig7a_print_height_mm", cfg["print_height_mm"], 125)
    check("fig7a_svg_exists", svg.exists() and svg.stat().st_size > 5000, True)
    check("fig7a_png_exists", png.exists() and png.stat().st_size > 20000, True)
    check("fig7a_caption_exists", caption.exists() and caption.stat().st_size > 1000, True)
    svg_w, svg_h = svg_dimensions(svg)
    check("fig7a_svg_width_inches", abs(svg_w - float(cfg["width_inches"])) < 0.02, True)
    check("fig7a_svg_height_inches", abs(svg_h - float(cfg["height_inches"])) < 0.02, True)
    png_w, png_h = png_dimensions(png)
    check("fig7a_png_width_pixels", abs(png_w - round(float(cfg["width_inches"]) * int(cfg["png_dpi"]))) <= 1, True)
    check("fig7a_png_height_pixels", abs(png_h - round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))) <= 1, True)

    manifest = {row["panel_id"]: row for row in panels}["7A"]
    check("fig7a_manifest_status", manifest["status"], "PASS")
    check("fig7a_manifest_qa", manifest["qa_status"], "PASS_RENDER_DATA_PRINT")
    check("fig7a_manifest_ready", manifest["figure_ready"], "YES")

    out = ROOT / "audits" / "fig7a_qa_checks.tsv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 7A cohort, isolation and render QA checks")


if __name__ == "__main__":
    main()
