options(stringsAsFactors = FALSE)
source(file.path("scripts", "figures", "fig2h_analysis.R"))
dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)

draw_one <- function(dataset, color, show_y = TRUE) {
  d <- stats[stats$dataset_id == dataset & stats$status == "ESTIMATED", ]
  d <- d[order(d$display_order), ]
  y <- 6 - d$display_order
  plot(NA, xlim = c(0, 0.112), ylim = c(0.45, 5.65),
       xlab = "Mean paired LS-minus-NL score shift", ylab = "", yaxt = "n", bty = "n",
       main = dataset, cex.main = 0.95, font.main = 2, cex.lab = 0.78, cex.axis = 0.72)
  abline(v = 0, col = "#70777D", lty = 3)
  primary <- d$mean_delta[d$variant_id == "PRIMARY_FULL_SEP"]
  abline(v = primary, col = color, lty = 3, lwd = 1.2)
  segments(d$ci_low, y, d$ci_high, y, col = color, lwd = 1.6)
  points(d$mean_delta, y, pch = ifelse(d$variant_id == "PRIMARY_FULL_SEP", 23, 21),
         bg = ifelse(d$variant_id == "PRIMARY_FULL_SEP", color, "white"), col = color,
         cex = ifelse(d$variant_id == "PRIMARY_FULL_SEP", 1.35, 1.05), lwd = 1.4)
  text(0.111, y, labels = sprintf("%.3f x", d$ratio_to_primary), adj = 1, cex = 0.64, col = "#4C555C")
  if (show_y) axis(2, at = y, labels = d$display_label, las = 1, tick = FALSE, cex.axis = 0.68, line = -0.2)
  mtext("ratio to primary", side = 3, line = -0.2, adj = 1, cex = 0.60, col = "#4C555C")
}

draw_panel <- function(device_fun) {
  device_fun(); on.exit(dev.off(), add = TRUE)
  layout(matrix(c(1, 2, 3, 3), nrow = 2, byrow = TRUE), heights = c(3.5, 1.15), widths = c(1, 1))
  par(oma = c(0.5, 0.5, 2.5, 0.5), family = "sans")
  par(mar = c(3.2, 9.0, 1.8, 0.5), mgp = c(2.0, 0.6, 0), tcl = -0.25)
  draw_one("GSE30999", "#0072B2", TRUE)
  par(mar = c(3.2, 1.0, 1.8, 0.8), mgp = c(2.0, 0.6, 0), tcl = -0.25)
  draw_one("GSE121212", "#D55E00", FALSE)
  par(mar = c(0.6, 0.8, 0.3, 0.8))
  plot.new(); plot.window(xlim = c(0, 1), ylim = c(0, 1))
  rect(0.01, 0.09, 0.99, 0.91, col = "#F3F5F6", border = "#C4CBD0")
  text(0.03, 0.72, "Input-limited specifications", adj = 0, font = 2, cex = 0.78, col = "#3E474D")
  text(0.03, 0.43, "Clinical covariate adjustment: BLOCKED - age, sex, numeric severity, medication and explicit batch absent from GEO sample fields.",
       adj = 0, cex = 0.66, col = "#59636A")
  text(0.03, 0.20, "Overlap exclusion: no exact public donor labels identified; cross-accession independence remains provisional, so no samples were removed.",
       adj = 0, cex = 0.66, col = "#59636A")
  mtext("Predefined score and mapping sensitivities", side = 3, outer = TRUE, line = 1.25, cex = 1.05, font = 2)
  mtext("Intervals are two-sided 95% CIs; dashed colored lines mark each cohort's frozen primary estimate", side = 3, outer = TRUE, line = 0.15, cex = 0.69, col = "#4C555C")
}

draw_panel(function() svg(file.path("figures", "panels", "fig2h.svg"), width = 7.0079, height = 4.7244, pointsize = 10))
draw_panel(function() png(file.path("figures", "previews", "fig2h.png"), width = 7.0079, height = 4.7244, units = "in", res = 300, pointsize = 10))
cat("PASS: rendered Figure 2H SVG and 300-dpi PNG\n")
