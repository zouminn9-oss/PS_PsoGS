options(stringsAsFactors = FALSE)

cfg_lines <- readLines(file.path("config", "figures", "fig1a.yaml"), warn = FALSE)
cfg <- function(key, default = NA_character_) {
  hit <- grep(paste0("^", key, ":"), cfg_lines, value = TRUE)
  if (!length(hit)) return(default)
  value <- trimws(sub("^[^:]+:", "", hit[1]))
  gsub('^"|"$', "", value)
}

dat <- read.delim(file.path("figures", "source_data", "fig1a.tsv"),
                  check.names = FALSE, stringsAsFactors = FALSE)
nodes <- dat[dat$record_type == "NODE", ]
edges <- dat[dat$record_type == "EDGE" & dat$edge_type == "ALLOWED_DEPENDENCY", ]
stopifnot(nrow(nodes) == 10L, nrow(edges) == 9L,
          all(nodes$biological_result == "NO"))

width <- as.numeric(cfg("width_inches"))
height <- as.numeric(cfg("height_inches"))
dpi <- as.numeric(cfg("png_dpi"))
ink <- cfg("ink")
blue <- cfg("blue")
orange <- cfg("orange")
mid_grey <- cfg("mid_grey")
light_grey <- cfg("light_grey")
pass_fill <- cfg("pass_fill")
blocked_fill <- cfg("blocked_fill")

node_map <- setNames(seq_len(nrow(nodes)), nodes$record_id)
line_breaks <- function(x) gsub("|", "\n", x, fixed = TRUE)

draw_arrow <- function(from, to) {
  a <- nodes[node_map[[from]], ]
  b <- nodes[node_map[[to]], ]
  if (a$y == b$y && b$x > a$x) {
    arrows(a$x + 0.82, a$y, b$x - 0.82, b$y, length = 0.065,
           angle = 24, lwd = 1.1, col = mid_grey)
  } else if (a$y == b$y && b$x < a$x) {
    arrows(a$x - 0.82, a$y, b$x + 0.82, b$y, length = 0.065,
           angle = 24, lwd = 1.1, col = mid_grey)
  } else {
    arrows(a$x, a$y - 0.68, b$x, b$y + 0.68, length = 0.065,
           angle = 24, lwd = 1.1, col = mid_grey)
  }
}

draw_node <- function(row) {
  fill <- switch(row$status,
                 PASS = pass_fill,
                 BLOCKED = blocked_fill,
                 PARTIAL = light_grey,
                 PLANNED = "white",
                 "white")
  border <- switch(row$status,
                   PASS = blue,
                   BLOCKED = orange,
                   PARTIAL = mid_grey,
                   PLANNED = mid_grey,
                   mid_grey)
  status_col <- switch(row$status,
                       PASS = blue,
                       BLOCKED = orange,
                       PARTIAL = ink,
                       PLANNED = mid_grey,
                       ink)
  if (row$gate_type == "FREEZE") {
    polygon(c(row$x, row$x + 0.78, row$x, row$x - 0.78),
            c(row$y + 0.70, row$y, row$y - 0.70, row$y),
            col = fill, border = border, lwd = 1.35)
    text(row$x, row$y + 0.22, row$label, cex = 0.88, font = 2, col = ink)
    text(row$x, row$y - 0.06, row$detail, cex = 0.67, col = ink)
    text(row$x, row$y - 0.39, row$status_label, cex = 0.67, font = 2, col = status_col)
  } else {
    rect(row$x - 0.78, row$y - 0.62, row$x + 0.78, row$y + 0.62,
         col = fill, border = border, lwd = 1.35)
    text(row$x, row$y + 0.42, row$stage, cex = 0.67, font = 2, col = mid_grey)
    text(row$x, row$y + 0.13, row$label, cex = 0.72, font = 2, col = ink)
    text(row$x, row$y - 0.16, row$detail, cex = 0.67, col = ink)
    text(row$x, row$y - 0.43, row$status_label, cex = 0.67, font = 2,
         col = status_col)
  }
  points(row$x - 0.67, row$y + 0.53, pch = 21, bg = ink, col = ink, cex = 1.12)
  text(row$x - 0.67, row$y + 0.53, row$step, cex = 0.67, font = 2, col = "white")
}

draw_panel <- function() {
  par(family = "sans", fg = ink, bty = "n", mar = c(4.5, 1.0, 3.8, 1.0), xpd = NA)
  plot(NA, xlim = c(0.05, 9.95), ylim = c(0.2, 7.15), axes = FALSE,
       xlab = "", ylab = "", xaxs = "i", yaxs = "i")

  title(main = "A  Evidence-governed analysis workflow", adj = 0,
        cex.main = 1.02, font.main = 2, line = 2.05)
  mtext("13 audited datasets | 1,381 metadata records | F1/F2/F3 freeze before downstream use",
        side = 3, adj = 0, line = 0.48, cex = 0.74, col = mid_grey)

  top_headers <- c("AUDIT", "REFERENCE", "DISCOVERY", "FREEZE", "LOCKED VALIDATION")
  text(c(1, 3, 5, 7, 9), rep(6.08, 5), top_headers,
       cex = 0.67, font = 2, col = mid_grey)

  for (i in seq_len(nrow(edges))) draw_arrow(edges$from_id[i], edges$to_id[i])
  for (i in seq_len(nrow(nodes))) draw_node(nodes[i, ])

  segments(0.30, 0.66, 0.68, 0.66, col = orange, lwd = 1.4)
  points(0.49, 0.66, pch = 4, col = orange, lwd = 1.4, cex = 0.95)
  text(0.82, 0.66,
       "LOCKED: validation cannot tune F1 membership, direction, thresholds or coverage rules.",
       adj = 0, cex = 0.67, col = ink)
  text(0.82, 0.34,
       "Stages remain PASS, PARTIAL, PLANNED or BLOCKED as audited; this panel contains no biological result.",
       adj = 0, cex = 0.67, col = mid_grey)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig1a.svg"), width = width, height = height,
    pointsize = 12, bg = "white", family = "sans")
draw_panel()
dev.off()
png(file.path("figures", "previews", "fig1a.png"), width = width, height = height,
    units = "in", res = dpi, pointsize = 12, bg = "white")
draw_panel()
dev.off()
cat("PASS: rendered fig1a SVG and 300-dpi PNG\n")
