from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

SRC=ROOT/"figures/source_data"; OUT=ROOT/"figures/panels"; PRE=ROOT/"figures/previews"
OUT.mkdir(parents=True,exist_ok=True); PRE.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.spines.top":False,"axes.spines.right":False,"svg.fonttype":"none"})
COL={"Q1_SEP":"#D55E00","Q2_ORDINARY_LESION":"#0072B2"}
def save(fig,name):
 fig.savefig(OUT/f"{name}.svg",bbox_inches="tight"); fig.savefig(PRE/f"{name}.png",dpi=300,bbox_inches="tight"); plt.close(fig)

a=pd.read_csv(SRC/"fig8a.tsv",sep="\t")
fig,ax=plt.subplots(figsize=(8.2,4.4)); y=np.arange(len(a)); up=a.landmark_up; down=a.landmark_down
ax.barh(y,up,color="#D55E00",label="landmark UP"); ax.barh(y,-down,color="#0072B2",label="landmark DOWN")
ax.axvline(0,color="#222",lw=.8); ax.set_yticks(y); ax.set_yticklabels(a.query_id); ax.invert_yaxis(); ax.set_xlabel("Frozen landmark coverage (directional count)"); ax.legend(frameon=False,ncol=2)
for i,r in a.iterrows():
 route="SIGCOM_RANKTWOSIDED_SEPARATE" if r.query_id=="Q3_CTRA" else r.connectivity_route
 ax.text(max(r.landmark_up,2)+6,i,route,va="center",fontsize=7)
ax.set_title("8A  Frozen queries take explicitly separated routes",loc="left",fontsize=15,fontweight="bold")
fig.text(.05,.015,"Q3 lacks landmark DOWN coverage and therefore uses a separate SigCom score family; scores are never combined.",fontsize=8,color="#444")
fig.tight_layout(rect=[.03,.06,1,.95]); save(fig,"fig8a")

b=pd.read_csv(SRC/"fig8b.tsv",sep="\t"); order=b.groupby(["pert_id","pert_desc"]).reversal_rank.sum().sort_values().index
mat=b.pivot(index=["pert_id","pert_desc"],columns="query_id",values="median_cosine").loc[order]
fig,ax=plt.subplots(figsize=(6.8,6.0)); vmax=max(abs(mat.to_numpy()).max(),.01); im=ax.imshow(mat,cmap="RdBu_r",vmin=-vmax,vmax=vmax,aspect="auto")
ax.set_xticks(range(2)); ax.set_xticklabels(["Q1 SEP","Q2 ordinary lesion"]); ax.set_yticks(range(len(mat))); ax.set_yticklabels([x[1] for x in mat.index])
for i in range(len(mat)):
 for j in range(2): ax.text(j,i,f"{mat.iloc[i,j]:.3f}",ha="center",va="center",fontsize=7)
fig.colorbar(im,ax=ax,label="Median cosine (negative = reversal)",shrink=.75); ax.set_title("8B  Top joint hypotheses show modest reversal",loc="left",fontsize=15,fontweight="bold")
fig.text(.03,.015,"Selected by the sum of independently computed Q1 and Q2 reversal ranks; not evidence of clinical efficacy.",fontsize=8,color="#444")
fig.tight_layout(rect=[.02,.05,1,.95]); save(fig,"fig8b")

c=pd.read_csv(SRC/"fig8c.tsv",sep="\t").dropna(); fig,ax=plt.subplots(figsize=(6.0,5.2)); ax.scatter(c.rank_Q1,c.rank_Q2,s=9,alpha=.25,color="#555")
ax.plot([1,c.rank_Q1.max()],[1,c.rank_Q2.max()],ls="--",color="#999",lw=1); ax.set_xlabel("Q1 SEP reversal rank"); ax.set_ylabel("Q2 lesion reversal rank"); ax.grid(alpha=.15)
ax.set_title("8C  Stress-linked and lesion ranks only partly agree",loc="left",fontsize=14,fontweight="bold")
fig.text(.04,.015,"Spearman ρ = 0.412 across 3,435 shared eligible perturbagens; Q3 excluded because its score family differs.",fontsize=8,color="#444")
fig.tight_layout(rect=[.03,.06,1,.95]); save(fig,"fig8c")

d=pd.read_csv(SRC/"fig8d.tsv",sep="\t"); fig,ax=plt.subplots(figsize=(7.0,5.7)); ax.scatter(d.Q1_SEP,d.Q2_ORDINARY_LESION,s=9,alpha=.18,color="#777")
h=d[d.highlight].sort_values("rank_sum"); ax.scatter(h.Q1_SEP,h.Q2_ORDINARY_LESION,s=28,color=np.where(h.pareto_nondominated_more_negative,"#009E73","#E69F00"),zorder=3)
offsets=[(4,5),(4,-10),(4,6),(4,-10),(4,5),(4,-10)]
for ((_,r),off) in zip(h.iterrows(),offsets): ax.annotate(r.pert_desc,(r.Q1_SEP,r.Q2_ORDINARY_LESION),xytext=off,textcoords="offset points",fontsize=7)
ax.axvline(0,color="#aaa",lw=.7); ax.axhline(0,color="#aaa",lw=.7); ax.set_xlabel("Q1 SEP median cosine"); ax.set_ylabel("Q2 lesion median cosine"); ax.grid(alpha=.12)
ax.set_title("8D  Two-axis Pareto screen remains hypothesis-generating",loc="left",fontsize=14,fontweight="bold")
fig.text(.04,.012,"Green: non-dominated for more-negative Q1/Q2 cosine. Ranking does not encode approval, safety, dose feasibility, or efficacy.",fontsize=8,color="#444")
fig.tight_layout(rect=[.03,.06,1,.95]); save(fig,"fig8d")

e=pd.read_csv(SRC/"fig8e.tsv",sep="\t"); drugs=e.groupby(["pert_id","pert_desc"]).cell_median_cosine.median().sort_values().index
fig,axs=plt.subplots(2,3,figsize=(11,6.5),sharey=True); axs=axs.ravel()
for ax,key in zip(axs,drugs):
 z=e[(e.pert_id==key[0])].copy()
 for qi,q in enumerate(["Q1_SEP","Q2_ORDINARY_LESION"]):
  v=z[z.query_id==q].cell_median_cosine.to_numpy(); x=np.full(len(v),qi)+np.linspace(-.08,.08,len(v)); ax.scatter(x,v,s=14,alpha=.7,color=COL[q]); ax.plot([qi-.18,qi+.18],[np.median(v)]*2,color=COL[q],lw=2)
 ax.axhline(0,color="#999",ls="--",lw=.7); ax.set_xticks([0,1]); ax.set_xticklabels(["Q1","Q2"]); ax.set_title(key[1],fontsize=10); ax.grid(axis="y",alpha=.12)
axs[0].set_ylabel("Cell-line median cosine"); axs[3].set_ylabel("Cell-line median cosine")
fig.suptitle("8E  Reversal varies substantially by cellular context",x=.04,ha="left",fontsize=15,fontweight="bold")
fig.text(.04,.015,"Each point is one cell-line median after dose/time aggregation; this is context consistency, not biological replication.",fontsize=8,color="#444")
fig.tight_layout(rect=[.03,.05,1,.93]); save(fig,"fig8e")

f=pd.read_csv(SRC/"fig8f.tsv",sep="\t"); f["short"]=f.variant.str.replace("TOP50_SOURCE_EFFECT","top 50",regex=False).str.replace("TOP100_SOURCE_EFFECT","top 100",regex=False).str.replace("DROP_","drop ",regex=False)
fig,axs=plt.subplots(1,2,figsize=(10.5,5.3),sharey=False)
for ax,q in zip(axs,["Q1_SEP","Q2_ORDINARY_LESION"]):
 z=f[f.query_id==q].sort_values("spearman_rho_primary"); y=np.arange(len(z)); ax.scatter(z.spearman_rho_primary,y,c=np.where(z.short.str.startswith("top"),"#D55E00","#0072B2"),s=32); ax.set_yticks(y); ax.set_yticklabels(z.short,fontsize=7); ax.set_xlim(0,1.02); ax.axvline(.9,color="#999",ls="--",lw=.8); ax.set_xlabel("Spearman ρ vs primary rank"); ax.set_title(q.replace("_"," ")); ax.grid(axis="x",alpha=.15)
fig.suptitle("8F  Truncation is unstable; leave-one-gene-out is stable",x=.04,ha="left",fontsize=15,fontweight="bold")
fig.text(.04,.012,"Primary ranking uses all available frozen landmark genes. Sensitivity analyses do not replace the frozen specification.",fontsize=8,color="#444")
fig.tight_layout(rect=[.03,.05,1,.93]); save(fig,"fig8f")
print("PASS: rendered Figure 8 panels A-F")
