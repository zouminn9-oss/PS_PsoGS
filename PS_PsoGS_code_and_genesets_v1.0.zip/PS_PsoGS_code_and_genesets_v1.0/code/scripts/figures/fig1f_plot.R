options(stringsAsFactors = FALSE)

cfg_lines <- readLines(file.path("config", "figures", "fig1f.yaml"), warn = FALSE)
cfg <- function(key, default = NA_character_) {
  hit <- grep(paste0("^", key, ":"), cfg_lines, value = TRUE)
  if (!length(hit)) return(default)
  gsub('^"|"$', '', trimws(sub("^[^:]+:", "", hit[1])))
}
dat <- read.delim(file.path("figures", "source_data", "fig1f.tsv"), check.names = FALSE)
stats_tab <- read.delim(file.path("results", "figures", "fig1f_statistics.tsv"), check.names = FALSE)
stats <- setNames(stats_tab$value, stats_tab$metric)
stopifnot(nrow(dat) == 18484L, !anyDuplicated(dat$gene_id))

width <- as.numeric(cfg("width_inches")); height <- as.numeric(cfg("height_inches"))
dpi <- as.numeric(cfg("png_dpi")); ink <- cfg("ink"); mid <- cfg("mid_grey")
light <- cfg("light_grey")
cats <- c("Neither", "S0 only", "SD only", "Both FDR<0.05")
cols <- setNames(c(cfg("control_grey"), cfg("s0_only"), cfg("sd_only"), cfg("both")), cats)
pchs <- setNames(c(1, 16, 17, 15), cats)
alphas <- setNames(c(0.32, 0.52, 0.52, 0.42), cats)
count_label <- setNames(c(stats["neither_FDR_lt_0.05"], stats["S0_only_FDR_lt_0.05"],
                          stats["SD_only_FDR_lt_0.05"], stats["both_FDR_lt_0.05"]), cats)
lim <- ceiling(max(abs(c(dat$S0_logFC, dat$SD_logFC))))
ymax <- ceiling(max(c(dat$S0_neg_log10_FDR, dat$SD_neg_log10_FDR)))

draw_scatter <- function() {
  par(family = "sans", fg = ink, mar = c(4.15, 4.2, 4.25, 0.8), xpd = FALSE)
  plot(NA, xlim = c(-lim, lim), ylim = c(-lim, lim), asp = 1, las = 1,
       xlab = expression(S[0]~log[2]~fold~change),
       ylab = expression(S[D]~log[2]~fold~change), cex.axis = 0.68, cex.lab = 0.78,
       main = "F  Frozen factorial stress effects", cex.main = 0.98, font.main = 2, adj = 0)
  abline(h = 0, v = 0, col = light, lwd = 0.8)
  abline(a = 0, b = 1, col = mid, lty = 2, lwd = 0.8)
  for (category in cats) {
    ix <- dat$significance_category == category
    points(dat$S0_logFC[ix], dat$SD_logFC[ix], pch = pchs[category], cex = 0.34,
           col = adjustcolor(cols[category], alpha.f = alphas[category]))
  }
  legend("bottomleft", legend = sprintf("%s  n=%s", cats, format(count_label[cats], big.mark = ",")),
         pch = pchs[cats], col = cols[cats], pt.cex = 0.72, cex = 0.67,
         bty = "n", y.intersp = 0.9, x.intersp = 0.7)
  text(lim * 0.96, lim * 0.95,
       sprintf("Pearson r = %.3f", as.numeric(stats["pearson_S0_SD_logFC"])),
       adj = c(1, 1), cex = 0.67, font = 2, col = ink)
  mtext("All 18,484 tested genes; dashed line denotes equal effects", side = 3,
        adj = 0, line = 0.65, cex = 0.67, col = mid)
}

draw_effect_fdr <- function(estimand, add_xlab = TRUE) {
  x <- dat[[paste0(estimand, "_logFC")]]
  y <- dat[[paste0(estimand, "_neg_log10_FDR")]]
  sig <- dat[[paste0(estimand, "_FDR")]] < 0.05
  col_sig <- if (estimand == "S0") cfg("s0_only") else cfg("sd_only")
  par(family = "sans", fg = ink, mar = c(if (add_xlab) 3.75 else 2.05, 3.65, 3.0, 0.8), xpd = FALSE)
  plot(x, y, pch = 16, cex = 0.29, col = adjustcolor(cfg("control_grey"), alpha.f = 0.28),
       xlim = c(-lim, lim), ylim = c(0, ymax), las = 1,
       xlab = if (add_xlab) expression(log[2]~fold~change) else "", ylab = expression(-log[10]~FDR),
       cex.axis = 0.67, cex.lab = 0.72, main = "")
  abline(h = -log10(0.05), col = mid, lty = 2, lwd = 0.8)
  abline(v = 0, col = light, lwd = 0.8)
  points(x[sig], y[sig], pch = if (estimand == "S0") 16 else 17, cex = 0.34,
         col = adjustcolor(col_sig, alpha.f = 0.48))
  mtext(if (estimand == "S0") expression(S[0]~":"~stress~without~IMQ)
        else expression(S[D]~":"~stress~with~IMQ), side = 3, adj = 0,
        line = 1.2, cex = 0.78, font = 2, col = ink)
  text(lim * 0.96, ymax * 0.95,
       sprintf("FDR<0.05: %s", format(sum(sig), big.mark = ",")),
       adj = c(1, 1), cex = 0.67, font = 2, col = ink)
  text(-lim * 0.96, -log10(0.05) + 0.32, "FDR 0.05", adj = 0, cex = 0.67, col = mid)
}

draw_panel <- function() {
  layout(matrix(c(1, 2, 1, 3), nrow = 2, byrow = TRUE), widths = c(1.62, 1), heights = c(1, 1))
  draw_scatter()
  draw_effect_fdr("S0", add_xlab = FALSE)
  draw_effect_fdr("SD", add_xlab = TRUE)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig1f.svg"), width = width, height = height,
    pointsize = 12, bg = "white", family = "sans")
draw_panel(); dev.off()
png(file.path("figures", "previews", "fig1f.png"), width = width, height = height,
    units = "in", res = dpi, pointsize = 12, bg = "white")
draw_panel(); dev.off()
cat("PASS: rendered Figure 1F SVG and 300-dpi PNG\n")
