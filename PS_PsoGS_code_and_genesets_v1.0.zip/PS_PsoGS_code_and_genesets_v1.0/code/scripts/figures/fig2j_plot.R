options(stringsAsFactors = FALSE)
source(file.path("scripts", "figures", "fig2j_analysis.R"))
dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)

status_colors <- c(PASS = "#009E73", PASS_WITH_LIMITATION = "#E69F00", FAIL = "#D55E00",
                   BLOCKED = "#6F777D", NOT_TESTED = "#8D70B3", NOT_APPLICABLE = "#D9E0E4")
status_labels <- c(PASS = "PASS", PASS_WITH_LIMITATION = "LIMIT", FAIL = "FAIL",
                   BLOCKED = "BLOCKED", NOT_TESTED = "NOT TESTED", NOT_APPLICABLE = "N/A")

draw_panel <- function(device_fun) {
  device_fun(); on.exit(dev.off(), add = TRUE)
  par(mar = c(4.0, 0.6, 3.2, 0.6), family = "sans")
  n <- nrow(claims)
  plot.new(); plot.window(xlim = c(0, 6.3), ylim = c(0.1, n + 1.7), xaxs = "i", yaxs = "i")
  y <- rev(seq_len(n))
  xcells <- c(3.25, 4.25, 5.45)
  headers <- c("GSE30999\narray", "GSE121212\nRNA-seq", "Synthesis\nclaim ceiling")
  text(xcells, n + 1.2, headers, font = 2, cex = 0.72)
  for (i in seq_len(n)) {
    if (i %% 2 == 0) rect(0.05, y[i] - 0.43, 6.18, y[i] + 0.43, col = "#F5F7F8", border = NA)
    text(0.12, y[i], paste0(claims$claim_id[i], "  ", claims$short_label[i]), adj = 0, cex = 0.70,
         font = ifelse(claims$claim_id[i] %in% c("C5", "C8", "C10", "C11"), 2, 1), col = "#30383E")
    statuses <- c(claims$GSE30999_status[i], claims$GSE121212_status[i], claims$synthesis_status[i])
    widths <- c(0.78, 0.78, 1.02)
    for (j in 1:3) {
      rect(xcells[j] - widths[j]/2, y[i] - 0.31, xcells[j] + widths[j]/2, y[i] + 0.31,
           col = status_colors[statuses[j]], border = "white", lwd = 1.2)
      text(xcells[j], y[i], status_labels[statuses[j]], cex = ifelse(statuses[j] == "NOT_TESTED", 0.53, 0.59),
           col = ifelse(statuses[j] == "NOT_APPLICABLE", "#4B555C", "white"), font = 2)
    }
  }
  abline(v = 4.84, col = "#B8C0C5", lwd = 1)
  legend_x <- c(0.3, 1.28, 2.42, 3.25, 4.25, 5.45)
  legend_status <- names(status_colors)
  for (i in seq_along(legend_status)) {
    rect(legend_x[i], 0.12, legend_x[i] + 0.20, 0.34, col = status_colors[legend_status[i]], border = NA)
    text(legend_x[i] + 0.25, 0.23, status_labels[legend_status[i]], adj = 0, cex = 0.55, col = "#424B51")
  }
  title("Stage 03 validation evidence matrix", line = 2.05, cex.main = 1.08, font.main = 2)
  mtext("Synthesis cannot exceed the relevant design/input ceiling; negative and unavailable results remain explicit", side = 3, line = 0.72, cex = 0.70, col = "#4C555C")
  mtext("No claim adjudication changes frozen F1 membership, direction, weight or threshold.", side = 1, line = 2.75, cex = 0.66, col = "#4C555C")
}

draw_panel(function() svg(file.path("figures", "panels", "fig2j.svg"), width = 7.0079, height = 4.7244, pointsize = 10))
draw_panel(function() png(file.path("figures", "previews", "fig2j.png"), width = 7.0079, height = 4.7244, units = "in", res = 300, pointsize = 10))
cat("PASS: rendered Figure 2J SVG and 300-dpi PNG\n")
