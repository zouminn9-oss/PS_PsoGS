from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

SRC=ROOT/"figures/source_data"; OUT=ROOT/"figures/panels"; PRE=ROOT/"figures/previews"
OUT.mkdir(parents=True,exist_ok=True); PRE.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.spines.top":False,"axes.spines.right":False,"svg.fonttype":"none"})
colors={"Brodalumab 140 mg Q2W":"#0072B2","Brodalumab 210 mg Q2W":"#56B4E9","Placebo":"#777777","Ustekinumab":"#CC79A7"}

def save(fig,name):
  fig.savefig(OUT/f"{name}.svg",bbox_inches="tight"); fig.savefig(PRE/f"{name}.png",dpi=300,bbox_inches="tight"); plt.close(fig)

h=pd.read_csv(SRC/"fig7h.tsv",sep="\t")
order=[]
for arm in ["Brodalumab 140 mg Q2W","Brodalumab 210 mg Q2W","Ustekinumab","Placebo"]:
  for tissue in ["lesional skin","non-lesional skin","LS_minus_NL"]: order.append((arm,tissue))
fig,axs=plt.subplots(1,2,figsize=(11,6.2),sharey=True)
for ax,program in zip(axs,["sep","core"]):
  z=h[h.program==program].set_index(["treatment","tissue"])
  for y,key in enumerate(order):
    if key not in z.index: continue
    r=z.loc[key]; ax.errorbar(r.mean_difference,y,xerr=[[r.mean_difference-r.ci_low],[r.ci_high-r.mean_difference]],fmt="o",color=colors[key[0]],capsize=2.5,ms=5)
  ax.axvline(0,color="#222",lw=.8,ls="--"); ax.set_title(program.upper()); ax.set_xlabel("W12 − baseline score (95% CI)"); ax.grid(axis="x",alpha=.18)
axs[0].set_yticks(range(len(order))); axs[0].set_yticklabels([f"{a.replace('Brodalumab ','Brod ')} · {t.replace('lesional skin','LS').replace('non-lesional skin','NL').replace('LS_minus_NL','ΔLS−NL')}" for a,t in order]); axs[0].invert_yaxis()
fig.suptitle("7H  Frozen transcript scores decrease in treated lesions",fontsize=16,fontweight="bold",x=.04,ha="left")
fig.text(.04,.01,"Points are patient-paired effects; spots or arrays are not treated as independent replicates. Placebo effects remain visible.",fontsize=8,color="#444")
fig.tight_layout(rect=[0.03,.04,1,.94]); save(fig,"fig7h")

i=pd.read_csv(SRC/"fig7i.tsv",sep="\t")
labels={"M0_CLINICAL":"M0 clinical","M0_PLUS_SEP_SENSITIVITY_NOT_CANONICAL_M2":"M0 + frozen SEP\n(restricted sensitivity)"}
fig,axs=plt.subplots(1,3,figsize=(10.5,3.8))
for ax,metric in zip(axs,["auroc","auprc","brier"]):
  z=i[i.metric==metric].copy(); x=np.arange(len(z)); vals=z["median"].to_numpy(); lo=vals-z.q025.to_numpy(); hi=z.q975.to_numpy()-vals
  ax.bar(x,vals,color=["#777777","#D55E00"],width=.65); ax.errorbar(x,vals,yerr=[lo,hi],fmt="none",ecolor="#222",capsize=3)
  ax.set_xticks(x); ax.set_xticklabels([labels[m] for m in z.model],rotation=15,ha="right"); ax.set_title(metric.upper()); ax.grid(axis="y",alpha=.18)
  if metric!="brier": ax.set_ylim(.5,1)
fig.suptitle("7I  SEP increment is uncertain in internal repeated nested CV",fontsize=15,fontweight="bold",x=.04,ha="left")
fig.text(.04,.01,"M1 is unavailable; M0+SEP is not the pre-specified canonical M2. Intervals are 2.5–97.5% across 20 repeat-level metrics.",fontsize=8,color="#444")
fig.tight_layout(rect=[.03,.08,1,.9]); save(fig,"fig7i")

j=pd.read_csv(SRC/"fig7j.tsv",sep="\t")
fig,axs=plt.subplots(1,2,figsize=(8.2,4.1),sharex=True,sharey=True)
for ax,(model,z) in zip(axs,j.groupby("model",sort=False)):
  ax.plot([0,1],[0,1],ls="--",color="#999",lw=1); ax.plot(z.mean_predicted,z.observed_fraction,"o-",color="#D55E00" if "SEP" in model else "#777777")
  for _,r in z.iterrows(): ax.annotate(str(int(r.n)),(r.mean_predicted,r.observed_fraction),xytext=(3,3),textcoords="offset points",fontsize=7)
  ax.set_title(labels[model]); ax.set_xlabel("Mean held-out probability"); ax.grid(alpha=.18)
axs[0].set_ylabel("Observed PASI75 fraction")
fig.suptitle("7J  Calibration remains internal and event-imbalanced",fontsize=15,fontweight="bold",x=.04,ha="left")
fig.text(.04,.01,"Numbers label patients per quantile bin; 62/74 achieved PASI75. No external response cohort is available.",fontsize=8,color="#444")
fig.tight_layout(rect=[.03,.07,1,.9]); save(fig,"fig7j")
print("PASS: rendered Figure 7 bulk panels")
