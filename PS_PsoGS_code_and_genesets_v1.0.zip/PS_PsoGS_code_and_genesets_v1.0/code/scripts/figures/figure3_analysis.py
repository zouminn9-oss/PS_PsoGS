#!/usr/bin/env python3
"""Assemble audited Figure 3 source-data and statistics tables."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))

import numpy as np
import pandas as pd
from scipy import sparse

SOURCE = ROOT / "figures/source_data"
STATS = ROOT / "results/figures"
SOURCE.mkdir(parents=True, exist_ok=True)
STATS.mkdir(parents=True, exist_ok=True)


def save(panel, source, stats):
    source.to_csv(SOURCE / f"fig{panel}.tsv", sep="\t", index=False)
    stats.to_csv(STATS / f"fig{panel}_statistics.tsv", sep="\t", index=False)


def decomposition(composition, scores, group0, group1, group_column):
    comp = composition.groupby([group_column, "cell_type"], observed=True)["cell_fraction"].mean().unstack(fill_value=0)
    means = scores.loc[scores["eligible_min_cells"]].groupby([group_column, "cell_type"], observed=True)["ucell_sep_directed"].mean().unstack()
    common = sorted(set(comp.columns) & set(means.columns) & set(means.loc[group0].dropna().index) & set(means.loc[group1].dropna().index))
    p0 = comp.loc[group0, common].to_numpy(float).copy(); p1 = comp.loc[group1, common].to_numpy(float).copy()
    p0 /= p0.sum(); p1 /= p1.sum()
    m0 = means.loc[group0, common].to_numpy(float); m1 = means.loc[group1, common].to_numpy(float)
    return {
        "composition": float(np.sum((p1 - p0) * m0)),
        "within_cell": float(np.sum(p0 * (m1 - m0))),
        "interaction": float(np.sum((p1 - p0) * (m1 - m0))),
        "total": float(np.sum(p1 * m1) - np.sum(p0 * m0)),
        "cell_types_used": len(common),
    }


def main():
    obs = pd.read_csv(ROOT / "data/processed/stage04/GSE173706_cell_metadata.tsv.gz", sep="\t")
    genes = pd.read_csv(ROOT / "data/processed/stage04/gse173706_selected_genes.tsv", sep="\t")
    counts = sparse.load_npz(ROOT / "data/processed/stage04/gse173706_selected_counts.npz").tocsr().astype(np.float32)
    donor = pd.read_csv(ROOT / "results/stage04/donor_celltype_scores.tsv", sep="\t")
    effects = pd.read_csv(ROOT / "results/stage04/paired_donor_scores.tsv", sep="\t")
    composition = pd.read_csv(ROOT / "results/stage04/composition_qc.tsv", sep="\t")
    abundance = pd.read_csv(ROOT / "results/stage04/differential_abundance.tsv", sep="\t")
    replication = pd.read_csv(ROOT / "results/stage04/GSE162183_replication.tsv", sep="\t")
    replication_donor = pd.read_csv(ROOT / "results/stage04/gse162183_donor_celltype_scores.tsv", sep="\t")
    replication_obs = pd.read_csv(ROOT / "data/processed/stage04/gse162183_cell_metadata_annotated.tsv.gz", sep="\t")
    sub = pd.read_csv(ROOT / "data/processed/stage04/subatlas_metadata.tsv.gz", sep="\t")

    a = obs[["cell_id", "umap_1", "umap_2", "cell_type", "donor_id", "tissue"]]
    a_stats = obs.groupby("cell_type", observed=True).agg(cells=("cell_id", "size"), donors=("donor_id", "nunique"), libraries=("sample_id", "nunique")).reset_index()
    save("3a", a, a_stats)

    marker_panel = {
        "Keratinocyte": ["KRT14", "KRT1", "DMKN"], "Fibroblast": ["DCN", "COL1A1", "SFRP2"],
        "Endothelial": ["PECAM1", "VWF", "CLDN5"], "T_cell": ["CD3D", "TRAC", "IL7R"],
        "Myeloid": ["LYZ", "TYROBP", "HLA-DRA"], "Mast": ["TPSAB1", "CPA3", "MS4A2"],
        "Melanocyte": ["DCT", "TYRP1", "PMEL"], "Eccrine": ["DCD", "PIP", "MUCL1"],
        "Smooth_muscle": ["ACTA2", "TAGLN", "MYL9"], "Nerve_glial": ["MPZ", "PLP1", "S100B"],
    }
    symbol_col = {x: i for i, x in enumerate(genes["human_gene_symbol"].fillna("").astype(str)) if x}
    normalized = sparse.diags(10000 / np.asarray(counts.sum(axis=1)).ravel()).dot(counts).tocsr()
    normalized.data = np.log1p(normalized.data)
    marker_rows = []
    for cell_type in marker_panel:
        idx = obs["cell_type"].eq(cell_type).to_numpy()
        for expected_type, markers in marker_panel.items():
            for marker in markers:
                column = symbol_col.get(marker)
                values = normalized[idx, column].toarray().ravel() if column is not None and idx.any() else np.array([])
                marker_rows.append({"cell_type": cell_type, "expected_cell_type": expected_type, "marker": marker,
                                    "mean_log1p_cp10k": float(values.mean()) if len(values) else np.nan,
                                    "detection_fraction": float((values > 0).mean()) if len(values) else np.nan,
                                    "cells": int(idx.sum())})
    marker_frame = pd.DataFrame(marker_rows)
    save("3b", marker_frame, pd.read_csv(ROOT / "results/stage04/final_annotation_ledger.tsv", sep="\t"))

    save("3c", composition, composition.groupby(["tissue", "cell_type"], observed=True)["cell_fraction"].agg(["mean", "median", "count"]).reset_index())
    save("3d", a, obs.groupby(["tissue", "cell_type"], observed=True).size().rename("cells").reset_index())
    e = obs[["cell_id", "umap_1", "umap_2", "cell_type", "tissue", "ucell_core_directed"]]
    save("3e", e, effects.loc[effects["program"].eq("ucell_core_directed")])
    f = donor[["donor_id", "tissue", "cell_type", "n_cells", "eligible_min_cells", "ucell_sep_up", "ucell_sep_down", "ucell_sep_directed"]]
    save("3f", f, effects.loc[effects["program"].eq("ucell_sep_directed")])
    g = effects.loc[effects["program"].isin(["ucell_core_directed", "ucell_sep_directed"]) & effects["eligibility_min_pairs"]].copy()
    save("3g", g, g)
    h = donor.loc[donor["cell_type"].eq("Fibroblast") & donor["tissue"].isin(["PN", "PP"]) & donor["eligible_min_cells"],
                  ["donor_id", "tissue", "n_cells", "ucell_sep_directed"]]
    h_stats = effects.loc[(effects["cell_type"].eq("Fibroblast")) & effects["program"].isin(["ucell_sep_directed", "rankmean_sep_directed"])]
    save("3h", h, h_stats)
    i = sub[["cell_id", "donor_id", "tissue", "fibro_umap_1", "fibro_umap_2", "fibro_leiden_06", "fibroblast_subtype", "ucell_sep_directed"]]
    save("3i", i, pd.read_csv(ROOT / "results/stage04/fibroblast_subtype_paired_effects.tsv", sep="\t"))
    j = abundance.loc[abundance["program"].eq("abundance_fraction") & abundance["eligibility_min_pairs"]]
    save("3j", j, j)
    k = replication.loc[replication["program"].isin(["ucell_sep_directed", "rankmean_sep_directed"]) & replication["eligible_all_groups_ge2"]]
    save("3k", k, k)

    discovery_components = decomposition(composition.assign(group=composition["tissue"]), donor.assign(group=donor["tissue"]), "PN", "PP", "group")
    rep_comp = replication_obs.groupby(["donor_id", "condition", "cell_type"], observed=True).size().rename("n_cells").reset_index()
    rep_comp["cell_fraction"] = rep_comp["n_cells"] / rep_comp.groupby("donor_id")["n_cells"].transform("sum")
    rep_components = decomposition(rep_comp, replication_donor, "Control", "Psoriasis", "condition")
    decomp_rows = []
    for cohort, values in [("GSE173706_paired_group_mean", discovery_components), ("GSE162183_unpaired_group_mean", rep_components)]:
        for component in ["composition", "within_cell", "interaction", "total"]:
            decomp_rows.append({"cohort": cohort, "component": component, "contribution": values[component], "cell_types_used": values["cell_types_used"]})
    decomp = pd.DataFrame(decomp_rows)
    decomp.to_csv(ROOT / "results/stage04/composition_decomposition.tsv", sep="\t", index=False)
    save("3l", decomp, decomp)
    print("PASS: Figure 3A-L source and statistics tables written")


if __name__ == "__main__":
    main()
