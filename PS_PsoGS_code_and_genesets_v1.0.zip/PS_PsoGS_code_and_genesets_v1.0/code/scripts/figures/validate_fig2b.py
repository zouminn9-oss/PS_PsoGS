#!/usr/bin/env python3
"""Independent source, statistics, render and print QA for Figure 2B."""

from __future__ import annotations

import csv
import math
import statistics
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
AUDIT = ROOT / "audits/fig2b_qa_checks.tsv"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            out[key.strip()] = value.strip().strip('"')
    return out


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError("not PNG")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def write_audit(rows: list[dict[str, str]]) -> None:
    AUDIT.parent.mkdir(parents=True, exist_ok=True)
    with AUDIT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": str(observed),
                       "expected": str(expected), "status": "PASS" if passed else "FAIL",
                       "note": note})
        if not passed:
            write_audit(checks)
            raise AssertionError(f"{check_id}: observed {observed!r}; expected {expected!r}")

    source = read_tsv(ROOT / "figures/source_data/fig2b.tsv")
    figure_stats = read_tsv(ROOT / "results/figures/fig2b_statistics.tsv")
    original_scores = read_tsv(ROOT / "results/stage03/scores/paired_scores.tsv")
    original_stats = read_tsv(ROOT / "results/stage03/scores/paired_score_statistics.tsv")
    bulk_audit = read_tsv(ROOT / "audits/stage03_bulk_validation_checks.tsv")
    patient = [row for row in source if row["record_type"] == "PATIENT"]
    summary = [row for row in source if row["record_type"] == "SUMMARY"]

    check("fig2b_bulk_audit", (len(bulk_audit), {r["status"] for r in bulk_audit}), (74, {"PASS"}))
    check("fig2b_source_rows", len(source), 110)
    check("fig2b_record_types", Counter(r["record_type"] for r in source),
          Counter({"PATIENT": 108, "SUMMARY": 2}))
    check("fig2b_patient_cohorts", Counter(r["dataset_id"] for r in patient),
          Counter({"GSE30999": 81, "GSE121212": 27}))
    check("fig2b_unique_units", len({(r["dataset_id"], r["donor_id"]) for r in patient}), 108)
    check("fig2b_score_definition", {r["score_definition"] for r in patient},
          {"mean_fractional_rank_SEP_UP_minus_SEP_DOWN"})
    check("fig2b_delta_identity", all(abs(float(r["delta_LS_minus_NL"]) -
          (float(r["lesional_score"]) - float(r["nonlesional_score"]))) < 1e-14
          for r in patient), True)

    source_by_key = {(r["dataset_id"], r["donor_id"]): r for r in patient}
    original_by_key = {(r["dataset_id"], r["donor_id"]): r for r in original_scores}
    check("fig2b_source_keys_match", set(source_by_key), set(original_by_key))
    for key in sorted(original_by_key):
        left, right = source_by_key[key], original_by_key[key]
        check(f"fig2b_samples::{key}",
              (left["nonlesional_sample"], left["lesional_sample"]),
              (right["nonlesional_sample"], right["lesional_sample"]))
        check(f"fig2b_delta::{key}",
              abs(float(left["delta_LS_minus_NL"]) - float(right["delta_LS_minus_NL"])) < 1e-15,
              True)

    check("fig2b_statistics_rows", len(figure_stats), 2)
    check("fig2b_summary_rows", len(summary), 2)
    expected = {"GSE30999": (81, 79, 2, 0.0741412288058754, 0.0687338031925891,
                              0.0795486544191617, 2.79468202860178e-42),
                "GSE121212": (27, 27, 0, 0.0888004583355417, 0.0773312004915664,
                               0.100269716179517, 6.39705765742725e-15)}
    fs = {r["dataset_id"]: r for r in figure_stats}
    os = {r["dataset_id"]: r for r in original_stats}
    ss = {r["dataset_id"]: r for r in summary}
    for cohort, (n, positive, negative, mean, low, high, p_value) in expected.items():
        values = [float(r["delta_LS_minus_NL"]) for r in patient if r["dataset_id"] == cohort]
        check(f"fig2b_n::{cohort}", len(values), n)
        check(f"fig2b_positive::{cohort}", sum(v > 0 for v in values), positive)
        check(f"fig2b_negative::{cohort}", sum(v < 0 for v in values), negative)
        check(f"fig2b_mean::{cohort}", abs(statistics.mean(values) - mean) < 1e-14, True)
        check(f"fig2b_ci_positive::{cohort}", low > 0 and high > 0, True)
        check(f"fig2b_p_positive::{cohort}", 0 < p_value < 0.001, True)
        check(f"fig2b_figure_stats::{cohort}",
              all(abs(float(fs[cohort][field]) - float(os[cohort][field])) < 1e-14
                  for field in ("mean_delta", "mean_delta_ci_low", "mean_delta_ci_high",
                                "median_delta", "t_statistic", "t_p_value",
                                "wilcoxon_p_value", "BH_FDR_across_two_primary_cohorts")), True)
        check(f"fig2b_summary_mean::{cohort}", abs(float(ss[cohort]["mean_delta"]) - mean) < 1e-14, True)
        t_recomputed = statistics.mean(values) / (statistics.stdev(values) / math.sqrt(n))
        check(f"fig2b_t_recomputed::{cohort}", abs(t_recomputed - float(fs[cohort]["t_statistic"])) < 1e-10, True)

    cfg = read_config(ROOT / "config/figures/fig2b.yaml")
    analysis_script = (ROOT / "scripts/figures/fig2b_analysis.R").read_text(encoding="utf-8")
    plot_script = (ROOT / "scripts/figures/fig2b_plot.R").read_text(encoding="utf-8")
    check("fig2b_manual_visual", cfg["manual_visual_inspection"],
          "PASS_2026-09-11_SECOND_RENDER_ASCII_SYMBOL_FIX")
    check("fig2b_min_text", float(cfg["minimum_text_pt"]) >= 8, True)
    check("fig2b_print_width", float(cfg["print_width_mm"]), 178.0)
    check("fig2b_statistical_unit", cfg["data_sufficiency"].startswith("108 independent paired patients"), True)
    check("fig2b_analysis_derived_only", "data/raw" not in analysis_script, True)
    check("fig2b_plot_derived_only", "data/raw" not in plot_script, True)
    check("fig2b_ascii_plot_labels", all(ord(character) < 128 for character in plot_script), True)
    for key in ("primary_color", "secondary_color", "ink_color", "grid_color", "neutral_color"):
        check(f"fig2b_color::{key}", cfg[key] in plot_script, True)

    svg = ROOT / "figures/panels/fig2b.svg"
    png = ROOT / "figures/previews/fig2b.png"
    caption = ROOT / "figures/captions/fig2b.md"
    check("fig2b_svg", svg.is_file() and svg.stat().st_size > 100000, True)
    check("fig2b_png", png.is_file() and png.stat().st_size > 100000, True)
    check("fig2b_caption", caption.is_file() and caption.stat().st_size > 2500, True)
    caption_text = caption.read_text(encoding="utf-8")
    for phrase in ("Seventy-nine of 81", "all 27", "two are negative", "does not by itself establish causality",
                   "independent patient-level", "95% confidence intervals"):
        check(f"fig2b_caption::{phrase}", phrase in caption_text, True)
    check("fig2b_png_dimensions", png_dimensions(png),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    sw, sh = svg_dimensions(svg)
    check("fig2b_svg_width", abs(sw - float(cfg["width_inches"])) < 0.02, True)
    check("fig2b_svg_height", abs(sh - float(cfg["height_inches"])) < 0.02, True)

    panel = {r["panel_id"]: r for r in read_tsv(ROOT / "panel_manifest.tsv")}["2B"]
    check("fig2b_panel_status", panel["status"], "PASS")
    check("fig2b_panel_qa", panel["qa_status"], "PASS_RENDER_DATA_PRINT")
    check("fig2b_panel_ready", panel["figure_ready"], "YES")
    check("fig2b_panel_input", panel["input_table"],
          "results/stage03/scores/paired_scores.tsv;results/stage03/scores/paired_score_statistics.tsv;audits/stage03_bulk_validation_checks.tsv")

    write_audit(checks)
    print(f"PASS: {len(checks)} Figure 2B source, statistics, render and print QA checks")


if __name__ == "__main__":
    main()
