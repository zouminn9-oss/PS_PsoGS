#!/usr/bin/env python3
"""Independent meta-analysis, render and print QA for Figure 2C."""

from __future__ import annotations

import csv
import struct
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
AUDIT = ROOT / "audits/fig2c_qa_checks.tsv"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            out[key.strip()] = value.strip().strip('"')
    return out


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError("not PNG")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def write_audit(rows: list[dict[str, str]]) -> None:
    with AUDIT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            write_audit(checks)
            raise AssertionError(f"{check_id}: observed {observed!r}; expected {expected!r}")

    source = read_tsv(ROOT / "figures/source_data/fig2c.tsv")
    meta = read_tsv(ROOT / "results/stage03/scores/score_meta.tsv")
    figure_stats = read_tsv(ROOT / "results/figures/fig2c_statistics.tsv")
    meta_audit = read_tsv(ROOT / "audits/stage03_score_meta_checks.tsv")
    check("fig2c_meta_audit", (len(meta_audit), {r["status"] for r in meta_audit}), (30, {"PASS"}))
    check("fig2c_source_rows", len(source), 4)
    check("fig2c_source_order", [r["dataset_id"] for r in source],
          ["GSE30999", "GSE121212", "FIXED", "RANDOM_DL"])
    check("fig2c_meta_keys", {r["dataset_id"] for r in source}, {r["dataset_id"] for r in meta})
    source_map = {r["dataset_id"]: r for r in source}
    meta_map = {r["dataset_id"]: r for r in meta}
    for key in source_map:
        for field in ("record_type", "label", "n_pairs", "effect", "variance", "standard_error",
                      "ci_low", "ci_high", "weight_fixed", "estimator"):
            check(f"fig2c_source_match::{key}::{field}", source_map[key][field], meta_map[key][field])
        check(f"fig2c_positive_ci::{key}", float(source_map[key]["ci_low"]) > 0, True)
    check("fig2c_statistics_rows", len(figure_stats), 1)
    stats = figure_stats[0]
    expected_numeric = {"k_cohorts": 2.0, "total_pairs": 108.0,
                        "Q": 0.00320996172147224, "Q_df": 1.0,
                        "Q_p_value": 0.954818807105308, "I2_percent": 0.0,
                        "tau2_DL": 0.0, "fixed_effect": 2.9952800000000000}
    for field, value in expected_numeric.items():
        if field == "fixed_effect":
            value = float(meta_map["FIXED"]["effect"])
        check(f"fig2c_stat::{field}", abs(float(stats[field]) - value) < 1e-12, True)
    check("fig2c_fixed_random_equal",
          abs(float(stats["fixed_effect"]) - float(stats["random_DL_effect"])) < 1e-14, True)
    check("fig2c_heterogeneity_limit", stats["heterogeneity_claim"], "NO_K_LT_3")
    check("fig2c_limitation_text", stats["limitation"],
          "Two cohorts only; heterogeneity estimates are unstable")

    cfg = read_config(ROOT / "config/figures/fig2c.yaml")
    plot_script = (ROOT / "scripts/figures/fig2c_plot.R").read_text(encoding="utf-8")
    analysis_script = (ROOT / "scripts/figures/fig2c_analysis.R").read_text(encoding="utf-8")
    frozen_cfg = (ROOT / "config/stage03_score_meta.yaml").read_text(encoding="utf-8")
    check("fig2c_manual_visual", cfg["manual_visual_inspection"], "PASS_2026-09-11_FIRST_RENDER")
    check("fig2c_min_text", float(cfg["minimum_text_pt"]) >= 8, True)
    check("fig2c_analysis_derived_only", "data/raw" not in analysis_script, True)
    check("fig2c_plot_derived_only", "data/raw" not in plot_script, True)
    check("fig2c_ascii_plot_labels", all(ord(character) < 128 for character in plot_script), True)
    check("fig2c_no_raw_pooling", "raw_score_pooling: false" in frozen_cfg, True)
    check("fig2c_no_feedback", "validation_to_signature_feedback: false" in frozen_cfg, True)
    check("fig2c_k_limit", "minimum_cohorts_for_stable_heterogeneity_claim: 3" in frozen_cfg, True)
    for key in ("primary_color", "secondary_color", "summary_color", "grid_color", "neutral_color"):
        check(f"fig2c_color::{key}", cfg[key] in plot_script, True)

    svg = ROOT / "figures/panels/fig2c.svg"
    png = ROOT / "figures/previews/fig2c.png"
    caption = ROOT / "figures/captions/fig2c.md"
    check("fig2c_svg", svg.is_file() and svg.stat().st_size > 50000, True)
    check("fig2c_png", png.is_file() and png.stat().st_size > 100000, True)
    check("fig2c_caption", caption.is_file() and caption.stat().st_size > 1800, True)
    caption_text = caption.read_text(encoding="utf-8")
    for phrase in ("GSE30999 contributes 81", "GSE121212 contributes 27",
                   "only two cohorts", "must not be interpreted as proof",
                   "does not establish cross-platform calibration"):
        check(f"fig2c_caption::{phrase}", phrase in caption_text, True)
    check("fig2c_png_dimensions", png_dimensions(png),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    sw, sh = svg_dimensions(svg)
    check("fig2c_svg_width", abs(sw - float(cfg["width_inches"])) < 0.02, True)
    check("fig2c_svg_height", abs(sh - float(cfg["height_inches"])) < 0.02, True)

    panel = {r["panel_id"]: r for r in read_tsv(ROOT / "panel_manifest.tsv")}["2C"]
    check("fig2c_panel_status", panel["status"], "PASS")
    check("fig2c_panel_qa", panel["qa_status"], "PASS_RENDER_DATA_PRINT")
    check("fig2c_panel_ready", panel["figure_ready"], "YES")
    check("fig2c_panel_source", panel["source_data"], "figures/source_data/fig2c.tsv")

    write_audit(checks)
    print(f"PASS: {len(checks)} Figure 2C meta-analysis, render and print QA checks")


if __name__ == "__main__":
    main()
