options(stringsAsFactors = FALSE)

cfg_lines <- readLines(file.path("config", "figures", "fig1b.yaml"), warn = FALSE)
cfg <- function(key, default = NA_character_) {
  hit <- grep(paste0("^", key, ":"), cfg_lines, value = TRUE)
  if (!length(hit)) return(default)
  value <- trimws(sub("^[^:]+:", "", hit[1]))
  gsub('^"|"$', "", value)
}

dat <- read.delim(file.path("figures", "source_data", "fig1b.tsv"),
                  check.names = FALSE, stringsAsFactors = FALSE)
stopifnot(nrow(dat) == 9L, all(dat$automatic_core_eligibility == "NO"))

width <- as.numeric(cfg("width_inches"))
height <- as.numeric(cfg("height_inches"))
dpi <- as.numeric(cfg("png_dpi"))
ink <- cfg("ink")
blue <- cfg("blue")
orange <- cfg("orange")
mid_grey <- cfg("mid_grey")
light_grey <- cfg("light_grey")

lane_labels <- c("Fixed signature", "Human lab stress",
                 "Mouse stress context", "Neuroendocrine proxy",
                 "Drug proxy", "Functional annotation")

draw_panel <- function() {
  par(family = "sans", fg = ink, col.axis = ink, col.lab = ink, bty = "n",
      mar = c(5.4, 11.2, 3.7, 3.2), mgp = c(2, 0.45, 0), tcl = -0.2)
  y <- nrow(dat):1
  plot(NA, xlim = c(0.55, 7.95), ylim = c(0.35, nrow(dat) + 1.15), axes = FALSE,
       xlab = "", ylab = "", xaxs = "i", yaxs = "i")
  for (i in seq_along(lane_labels)) {
    if (i %% 2 == 0) rect(i - 0.48, 0.35, i + 0.48, nrow(dat) + 1.15,
                          col = light_grey, border = NA)
    abline(v = i, col = "#D9DEE2", lwd = 0.55)
  }
  abline(h = seq(1.5, nrow(dat) - 0.5, by = 1), col = "#EDF0F2", lwd = 0.55)

  point_pch <- c(PASS = 21, PARTIAL = 21, BLOCKED = 4)[dat$status_group]
  point_bg <- ifelse(dat$status_group == "PASS", blue, "white")
  point_col <- ifelse(dat$status_group == "BLOCKED", orange,
                      ifelse(dat$status_group == "PARTIAL", mid_grey, blue))
  points(dat$lane_order, y, pch = point_pch, bg = point_bg, col = point_col,
         cex = 1.25, lwd = 1.25)

  axis(2, at = y, labels = dat$resource_label, las = 1, tick = FALSE,
       cex.axis = 0.77, line = -0.35)
  text(seq_along(lane_labels), rep(0.18, length(lane_labels)), labels = lane_labels,
       xpd = NA, adj = c(1, 1), srt = 35, cex = 0.67, col = ink)
  text(6.45, y, dat$status_group, adj = 0, cex = 0.67,
       col = ifelse(dat$status_group == "BLOCKED", orange, ink))
  text(7.55, y, dat$member_code, cex = 0.70, font = 2,
       col = ifelse(dat$member_code == "F", blue, ink))
  text(6.45, nrow(dat) + 0.75, "AUDIT", adj = 0, cex = 0.67, font = 2, col = mid_grey)
  text(7.55, nrow(dat) + 0.75, "SET", cex = 0.67, font = 2, col = mid_grey)

  title(main = "B  Psychological-stress evidence strata", adj = 0,
        cex.main = 1.02, font.main = 2, line = 2.0)
  mtext("Nine frozen resources; position encodes evidence class, not evidence strength",
        side = 3, adj = 0, line = 0.45, cex = 0.74, col = mid_grey)
  mtext("Filled=PASS; open=PARTIAL; cross=BLOCKED. M=reference; F=F1 source; -=none.",
        side = 1, adj = 0, line = 4.35, cex = 0.67, col = mid_grey)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig1b.svg"), width = width, height = height,
    pointsize = 12, bg = "white", family = "sans")
draw_panel()
dev.off()
png(file.path("figures", "previews", "fig1b.png"), width = width, height = height,
    units = "in", res = dpi, pointsize = 12, bg = "white")
draw_panel()
dev.off()
cat("PASS: rendered fig1b SVG and 300-dpi PNG\n")
