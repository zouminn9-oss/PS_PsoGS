#!/usr/bin/env python3
"""Data, checksum, isolation, render and print QA for Figure 1J."""

from __future__ import annotations

import csv
import hashlib
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            out[key.strip()] = value.strip().strip('"')
    return out


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError(f"not a PNG: {path}")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": str(observed),
                       "expected": str(expected), "status": "PASS" if passed else "FAIL",
                       "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    manifest = read_tsv(ROOT / "metadata/signature_f1_manifest.tsv")
    source = read_tsv(ROOT / "figures/source_data/fig1j.tsv")
    stats_rows = read_tsv(ROOT / "results/figures/fig1j_statistics.tsv")
    stats = {row["metric"]: row for row in stats_rows}
    registry = read_tsv(ROOT / "metadata/signature_registry.tsv")
    completion = read_tsv(ROOT / "audits/stage02_orthology/f1_manifest_completion_checks.tsv")
    artifact_rows = {row["item_id"]: row for row in source if row["record_type"] == "ARTIFACT"}

    check("fig1j_manifest_rows", len(manifest), 20)
    check("fig1j_manifest_unique_ids", len({row["artifact_id"] for row in manifest}), 20)
    check("fig1j_source_rows", len(source), 34)
    check("fig1j_source_record_types", Counter(row["record_type"] for row in source),
          Counter({"ARTIFACT": 20, "RULE": 7, "SIGNATURE_SUMMARY": 3, "AUDIT": 4}))
    check("fig1j_source_all_artifacts", set(artifact_rows),
          {row["artifact_id"] for row in manifest})
    check("fig1j_single_version", {row["signature_version"] for row in manifest}, {"v1.0"})
    check("fig1j_single_timestamp", len({row["frozen_at_utc"] for row in manifest}), 1)
    check("fig1j_completion_audit", {row["status"] for row in completion}, {"PASS"})

    for row in manifest:
        artifact_id = row["artifact_id"]
        path = ROOT / row["path"]
        check(f"fig1j_file_present::{artifact_id}", path.is_file(), True)
        check(f"fig1j_bytes::{artifact_id}", path.stat().st_size, int(row["bytes"]))
        check(f"fig1j_sha256::{artifact_id}", sha256(path), row["sha256"])
        src = artifact_rows[artifact_id]
        check(f"fig1j_source_path::{artifact_id}", src["path"], row["path"])
        check(f"fig1j_source_digest::{artifact_id}", src["sha256"], row["sha256"])

    check("fig1j_artifact_groups", Counter(row["group"] for row in artifact_rows.values()),
          Counter({"DISCOVERY_EFFECT_INPUT": 4, "ORTHOLOGY_MAPPING_INPUT": 5,
                   "DERIVED_LEDGER": 3, "SIGNATURE_EXPORT": 6, "GOVERNANCE": 2}))
    expected_effect_records = {"source_mouse_S0_effects": "18484",
                               "source_mouse_SD_effects": "18484",
                               "source_mouse_I_effects": "18484",
                               "source_human_H_effects": "20826"}
    check("fig1j_effect_input_records",
          {key: artifact_rows[key]["value"] for key in expected_effect_records},
          expected_effect_records)

    signature_expected = {"PS-PsoGS Core": (4976, "core_tsv"),
                          "PS-PsoGS Interaction": (4085, "interaction_tsv"),
                          "SEP": (2716, "sep_tsv")}
    signature_rows = {row["label"]: row for row in source
                      if row["record_type"] == "SIGNATURE_SUMMARY"}
    for label, (count, artifact_id) in signature_expected.items():
        check(f"fig1j_signature_count::{label}", int(signature_rows[label]["value"]), count)
        check(f"fig1j_signature_hash::{label}", signature_rows[label]["sha256"],
              artifact_rows[artifact_id]["sha256"])
    registry_rows = {row["signature_id"]: row for row in registry}
    check("fig1j_registry_core", int(registry_rows["PS_PsoGS_Core_v1.0"]["members"]), 4976)
    check("fig1j_registry_interaction",
          int(registry_rows["PS_PsoGS_Interaction_v1.0"]["members"]), 4085)
    check("fig1j_registry_sep", int(registry_rows["SEP_v1.0"]["members"]), 2716)
    check("fig1j_registry_f1_status", all(registry_rows[key]["freeze_status"].startswith("PASS_F1_")
          for key in ("PS_PsoGS_Core_v1.0", "PS_PsoGS_Interaction_v1.0", "SEP_v1.0")), True)

    expected_stats = {"manifest_artifacts": 20, "discovery_effect_inputs": 4,
                      "orthology_mapping_inputs": 5, "derived_ledgers": 3,
                      "signature_exports": 6, "governance_artifacts": 2,
                      "signature_versions": 1, "freeze_timestamps": 1,
                      "core_total": 4976, "interaction_total": 4085, "sep_total": 2716,
                      "no_direction_flipping": 1, "validation_expression_files_read": 0}
    check("fig1j_statistics_rows", len(stats_rows), 15)
    for key, value in expected_stats.items():
        check(f"fig1j_stat::{key}", int(float(stats[key]["value"])), value)
    check("fig1j_primary_coverage", float(stats["minimum_primary_coverage"]["value"]), 0.70)

    frozen_cfg = (ROOT / "config/stage02_cross_species_signatures.yaml").read_text(encoding="utf-8")
    for rule in ("release: 100", "mouse_SD_fdr_lt: 0.05", "mouse_I_fdr_lt: 0.05",
                 "human_H_fdr_lt: 0.05", "minimum_primary_coverage: 0.70",
                 "no_direction_flipping: true",
                 "directed_score_formula: mean_or_rank_score_UP_minus_mean_or_rank_score_DOWN"):
        check(f"fig1j_frozen_rule::{rule}", rule in frozen_cfg, True)

    cfg = read_config(ROOT / "config/figures/fig1j.yaml")
    analysis_script = (ROOT / "scripts/figures/fig1j_analysis.R").read_text(encoding="utf-8")
    plot_script = (ROOT / "scripts/figures/fig1j_plot.R").read_text(encoding="utf-8")
    check("fig1j_manual_visual_inspection", cfg["manual_visual_inspection"],
          "PASS_2026-09-11_SECOND_RENDER")
    check("fig1j_minimum_text_pt", float(cfg["minimum_text_pt"]), 8.0)
    check("fig1j_validation_config", cfg["validation_expression_accessed"], "none")
    check("fig1j_no_validation_access_analysis",
          "GSE30999" not in analysis_script and "GSE121212" not in analysis_script, True)
    check("fig1j_no_validation_access_plot",
          "GSE30999" not in plot_script and "GSE121212" not in plot_script, True)
    for color_key in ("input_color", "rule_color", "output_color", "lock_color",
                      "neutral_color", "light_fill", "grid_color"):
        check(f"fig1j_plot_uses::{color_key}", cfg[color_key] in plot_script, True)

    svg = ROOT / "figures/panels/fig1j.svg"
    png = ROOT / "figures/previews/fig1j.png"
    caption = ROOT / "figures/captions/fig1j.md"
    check("fig1j_svg_present", svg.is_file() and svg.stat().st_size > 100000, True)
    check("fig1j_png_present", png.is_file() and png.stat().st_size > 100000, True)
    check("fig1j_caption_present", caption.is_file() and caption.stat().st_size > 2000, True)
    caption_text = caption.read_text(encoding="utf-8")
    check("fig1j_caption_manifest_repair", "without rebuilding or changing any signature file" in caption_text, True)
    check("fig1j_caption_no_validation_claim", "does not claim validation success" in caption_text, True)
    check("fig1j_caption_units", "independent mice" in caption_text and "paired patients" in caption_text, True)
    png_w, png_h = png_dimensions(png)
    check("fig1j_png_dimensions", (png_w, png_h),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    svg_w, svg_h = svg_dimensions(svg)
    check("fig1j_svg_width", abs(svg_w - float(cfg["width_inches"])) < 0.02, True)
    check("fig1j_svg_height", abs(svg_h - float(cfg["height_inches"])) < 0.02, True)

    panel = {row["panel_id"]: row for row in read_tsv(ROOT / "panel_manifest.tsv")}["1J"]
    check("fig1j_panel_status", panel["status"], "PASS")
    check("fig1j_panel_qa", panel["qa_status"], "PASS_RENDER_DATA_PRINT")
    check("fig1j_panel_ready", panel["figure_ready"], "YES")
    check("fig1j_panel_source", panel["source_data"], "figures/source_data/fig1j.tsv")

    audit_path = ROOT / "audits/fig1j_qa_checks.tsv"
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    with audit_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t",
                                lineterminator="\n")
        writer.writeheader()
        writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 1J checksum, isolation, render and print QA checks")


if __name__ == "__main__":
    main()
