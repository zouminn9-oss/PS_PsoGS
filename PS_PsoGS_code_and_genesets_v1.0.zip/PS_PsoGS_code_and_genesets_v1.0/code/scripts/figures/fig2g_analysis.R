options(stringsAsFactors = FALSE)
dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)

null <- read.delim(file.path("results", "stage03", "random_null", "random_signature_null.tsv"), check.names = FALSE)
summary <- read.delim(file.path("results", "stage03", "random_null", "random_signature_null_summary.tsv"), check.names = FALSE)
audit <- read.delim(file.path("audits", "stage03_random_signature_null_checks.tsv"), check.names = FALSE)
stopifnot(nrow(null) == 4000L, nrow(summary) == 2L, all(audit$status == "PASS"))

null$null_z <- NA_real_
for (dataset in unique(null$dataset_id)) {
  idx <- null$dataset_id == dataset
  s <- summary[summary$dataset_id == dataset, ]
  null$null_z[idx] <- (null$random_effect[idx] - s$null_mean) / s$null_sd
}
null$record_type <- "matched_random_signature"
null$observed_effect <- NA_real_
null$observed_z <- NA_real_

observed_rows <- summary
observed_rows$permutation_id <- NA_integer_
observed_rows$random_effect <- NA_real_
observed_rows$n_up.1 <- observed_rows$n_up
observed_rows$n_down.1 <- observed_rows$n_down
observed_rows$seed <- 20260911L
observed_rows$null_z <- NA_real_
observed_rows$record_type <- "observed_SEP"
observed_rows$observed_z <- (observed_rows$observed_effect - observed_rows$null_mean) / observed_rows$null_sd

source_null <- null[, c("dataset_id", "record_type", "permutation_id", "random_effect", "null_z",
                        "n_up", "n_down", "seed", "observed_effect", "observed_z")]
source_obs <- observed_rows[, c("dataset_id", "record_type", "permutation_id", "random_effect", "null_z",
                                "n_up", "n_down", "seed", "observed_effect", "observed_z")]
source <- rbind(source_null, source_obs)
write.table(source, file.path("figures", "source_data", "fig2g.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

summary$observed_z_vs_null <- (summary$observed_effect - summary$null_mean) / summary$null_sd
summary$null_exceedances <- vapply(summary$dataset_id, function(d) {
  s <- summary[summary$dataset_id == d, ]
  sum(null$random_effect[null$dataset_id == d] >= s$observed_effect)
}, integer(1))
summary$matching_statement <- c(
  "exact mapped UP/DOWN size; GCRMA mean-expression decile",
  "exact mapped UP/DOWN size; logCPM decile x detection quintile"
)[match(summary$dataset_id, c("GSE30999", "GSE121212"))]
summary$interpretation_limit <- "Does not exclude biological, cell-composition or disease-program confounding"
write.table(summary, file.path("results", "figures", "fig2g_statistics.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: Figure 2G source has %d null rows and %d observed rows\n", nrow(null), nrow(summary)))

