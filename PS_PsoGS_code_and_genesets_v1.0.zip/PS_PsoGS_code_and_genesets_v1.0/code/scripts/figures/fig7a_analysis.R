options(stringsAsFactors = FALSE)

samples <- read.delim(file.path("metadata", "sample_manifest.tsv"),
                      check.names = FALSE, stringsAsFactors = FALSE)
datasets <- read.delim(file.path("metadata", "dataset_manifest.tsv"),
                       check.names = FALSE, stringsAsFactors = FALSE)
registry <- read.delim(file.path("metadata", "gse117468_patient_registry.tsv"),
                       check.names = FALSE, stringsAsFactors = FALSE)
cohorts <- read.delim(file.path("audits", "gse117468_cohort_summary.tsv"),
                      check.names = FALSE, stringsAsFactors = FALSE)

g228 <- samples[samples$dataset_id == "GSE228421", ]
g117 <- samples[samples$dataset_id == "GSE117468", ]
stopifnot(nrow(g228) == 20L, length(unique(g228$donor_or_animal_id)) == 5L)
stopifnot(nrow(g117) == 565L, length(unique(g117$donor_or_animal_id)) == 133L)
stopifnot(nrow(registry) == 133L, all(registry$expression_values_accessed == "NO"))

expected228 <- c("day 0|lesional", "day 0|non-lesional", "day 3|lesional", "day 14|lesional")
by_patient <- split(g228, g228$donor_or_animal_id)
complete228 <- vapply(by_patient, function(z) {
  observed <- paste(z$timepoint_or_visit, z$condition, sep = "|")
  setequal(observed, expected228) && nrow(z) == 4L
}, logical(1))
stopifnot(all(complete228))

arm_names <- c("Brodalumab 140 mg Q2W", "Brodalumab 210 mg Q2W", "Placebo", "Ustekinumab")
arm_rows <- cohorts[match(arm_names, cohorts$cohort), ]
stopifnot(!any(is.na(arm_rows$cohort)))
all_row <- cohorts[cohorts$cohort == "All public records", ]
brod_row <- cohorts[cohorts$cohort == "Brodalumab combined", ]
stopifnot(nrow(all_row) == 1L, nrow(brod_row) == 1L)

eligible <- registry$baseline_ls_prediction_metadata_eligible == "YES" &
  grepl("^Brodalumab", registry$treatment)
outcome <- registry$outcome_evaluable_bl_w12 == "YES" & grepl("^Brodalumab", registry$treatment)
stopifnot(sum(outcome) == 75L, sum(eligible) == 74L)
stopifnot(sum(registry$pasi75[eligible] == "YES") == 62L,
          sum(registry$pasi75[eligible] == "NO") == 12L)
stopifnot(sum(registry$pasi90[eligible] == "YES") == 50L,
          sum(registry$pasi90[eligible] == "NO") == 24L)

records <- list()
add <- function(record_type, dataset_id, branch, display_order, label, count, total, unit,
                visit = "", tissue = "", treatment = "", inference_role = "",
                eligibility = "", expression_values_accessed = "NO", source_table = "",
                limitation = "") {
  records[[length(records) + 1L]] <<- data.frame(
    record_type = record_type, dataset_id = dataset_id, branch = branch,
    display_order = display_order, label = label, count = count, total = total,
    unit = unit, visit = visit, tissue = tissue, treatment = treatment,
    inference_role = inference_role, eligibility = eligibility,
    expression_values_accessed = expression_values_accessed,
    source_table = source_table, limitation = limitation,
    stringsAsFactors = FALSE
  )
}

add("COHORT", "GSE228421", "mechanism", 1, "Audited patients", 5, 20, "patients; libraries",
    inference_role = "paired treatment-remodeling mechanism", eligibility = "MECHANISM_ONLY",
    source_table = "metadata/sample_manifest.tsv",
    limitation = "five selected patients who later cleared; not a general response cohort")
tp228 <- data.frame(visit = c("day 0", "day 0", "day 3", "day 14"),
                    tissue = c("lesional", "non-lesional", "lesional", "lesional"),
                    stringsAsFactors = FALSE)
for (i in seq_len(nrow(tp228))) {
  n <- sum(g228$timepoint_or_visit == tp228$visit[i] & g228$condition == tp228$tissue[i])
  add("TIMEPOINT_TISSUE", "GSE228421", "mechanism", i,
      paste(tp228$visit[i], tp228$tissue[i]), n, 5, "libraries",
      visit = tp228$visit[i], tissue = tp228$tissue[i],
      inference_role = "paired mechanism", eligibility = "PASS_DESIGN",
      source_table = "metadata/sample_manifest.tsv")
}
add("MODEL_GATE", "GSE228421", "prediction", 1, "General response prediction", 0, 5,
    "eligible patients", inference_role = "prediction", eligibility = "NOT_ELIGIBLE",
    source_table = "metadata/dataset_manifest.tsv",
    limitation = "n=5 selected later-clearers; no outcome-class variation")

add("COHORT", "GSE117468", "public_deposit", 1, "Public deposit", 133, 565,
    "patient IDs; arrays", inference_role = "paired treatment change and conditional prediction",
    eligibility = "METADATA_GATE_PASS", source_table = "audits/gse117468_cohort_summary.tsv",
    limitation = "public deposit denominator differs from series narrative")
for (i in seq_len(nrow(arm_rows))) {
  add("TREATMENT_ARM", "GSE117468", "public_deposit", i, arm_names[i],
      as.integer(arm_rows$n_patients[i]), as.integer(arm_rows$n_public_arrays[i]),
      "patients; arrays", treatment = arm_names[i], inference_role = "treatment arm",
      eligibility = "PAIRED_ANALYSIS_AFTER_F1", source_table = "audits/gse117468_cohort_summary.tsv")
}

pair_labels <- c("BL LS/NL", "LS BL-W4", "LS BL-W12", "Complete BL/W12 LS/NL")
pair_counts <- c(all_row$baseline_ls_nl_pairs, all_row$ls_bl_w4_pairs,
                 all_row$ls_bl_w12_pairs, all_row$complete_bl_w12_ls_nl)
for (i in seq_along(pair_labels)) {
  add("PAIRING", "GSE117468", "paired_treatment", i, pair_labels[i],
      as.integer(pair_counts[i]), 133, "patients", inference_role = "paired treatment change",
      eligibility = "AVAILABLE_AFTER_F1", source_table = "audits/gse117468_cohort_summary.tsv")
}

add("PREDICTION_GATE", "GSE117468", "internal_prediction", 1, "Brodalumab patient IDs",
    88, 88, "patients", inference_role = "baseline response prediction",
    eligibility = "STARTING_METADATA_POOL", source_table = "audits/gse117468_cohort_summary.tsv")
add("PREDICTION_GATE", "GSE117468", "internal_prediction", 2, "BL and W12 PASI",
    75, 88, "patients", inference_role = "baseline response prediction",
    eligibility = "OUTCOME_EVALUABLE", source_table = "audits/gse117468_cohort_summary.tsv")
add("PREDICTION_GATE", "GSE117468", "internal_prediction", 3, "Plus public BL lesional array",
    74, 75, "patients", inference_role = "baseline response prediction",
    eligibility = "METADATA_ELIGIBLE_INTERNAL_ONLY", source_table = "audits/gse117468_cohort_summary.tsv",
    limitation = "no external response cohort; nested patient-level CV only")
add("OUTCOME_CLASS", "GSE117468", "internal_prediction", 1, "PASI75 responder",
    62, 74, "patients", inference_role = "internal prediction outcome",
    eligibility = "CLASS_IMBALANCED", source_table = "metadata/gse117468_patient_registry.tsv")
add("OUTCOME_CLASS", "GSE117468", "internal_prediction", 2, "PASI75 nonresponder",
    12, 74, "patients", inference_role = "internal prediction outcome",
    eligibility = "CLASS_IMBALANCED", source_table = "metadata/gse117468_patient_registry.tsv")
add("OUTCOME_CLASS", "GSE117468", "internal_prediction", 3, "PASI90 responder",
    50, 74, "patients", inference_role = "sensitivity outcome",
    eligibility = "INTERNAL_ONLY", source_table = "metadata/gse117468_patient_registry.tsv")
add("OUTCOME_CLASS", "GSE117468", "internal_prediction", 4, "PASI90 nonresponder",
    24, 74, "patients", inference_role = "sensitivity outcome",
    eligibility = "INTERNAL_ONLY", source_table = "metadata/gse117468_patient_registry.tsv")
add("FIELD_GATE", "GSE117468", "covariates", 1, "Sex available", 0, 133, "patients",
    inference_role = "clinical covariate", eligibility = "MISSING_ALL",
    source_table = "metadata/gse117468_patient_registry.tsv")
add("EXTERNAL_GATE", "GSE117468", "external_validation", 1, "Frozen external response cohort",
    0, 1, "cohort", inference_role = "external prediction validation", eligibility = "BLOCKED",
    source_table = "metadata/dataset_manifest.tsv",
    limitation = "internal performance cannot establish external generalizability")
add("DENOMINATOR", "GSE117468", "series_narrative", 1, "Series narrative patients", 116, 844,
    "patients; biopsies", inference_role = "source reconciliation", eligibility = "SEPARATE_DENOMINATOR",
    source_table = "audits/gse117468_source_reconciliation.tsv")
add("DENOMINATOR", "GSE117468", "public_deposit", 2, "Public patient IDs", 133, 565,
    "patient IDs; arrays", inference_role = "reproducible public denominator",
    eligibility = "CANONICAL_PUBLIC_DENOMINATOR", source_table = "audits/gse117468_cohort_summary.tsv")

out <- do.call(rbind, records)
dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(out, file.path("figures", "source_data", "fig7a.tsv"), sep = "\t",
            row.names = FALSE, quote = FALSE, na = "")

stats <- out[, c("record_type", "dataset_id", "branch", "label", "count", "total", "unit",
                 "eligibility", "limitation")]
stats$statistical_test <- "none_descriptive_cohort_audit"
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(stats, file.path("results", "figures", "fig7a_statistics.tsv"), sep = "\t",
            row.names = FALSE, quote = FALSE, na = "")

cat(sprintf("PASS: fig7a source data %d records; GSE228421 n=5/20 libraries; GSE117468 n=133/565 arrays; prediction n=74\n",
            nrow(out)))
