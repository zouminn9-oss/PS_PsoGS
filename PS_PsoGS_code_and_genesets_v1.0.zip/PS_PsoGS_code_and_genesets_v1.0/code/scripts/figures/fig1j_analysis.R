options(stringsAsFactors = FALSE)

manifest <- read.delim(file.path("metadata", "signature_f1_manifest.tsv"),
                       check.names = FALSE, colClasses = "character")
registry <- read.delim(file.path("metadata", "signature_registry.tsv"), check.names = FALSE)
statistics <- read.delim(file.path("results", "stage02", "signatures",
                                   "signature_statistics.tsv"), check.names = FALSE)
completion <- read.delim(file.path("audits", "stage02_orthology",
                                   "f1_manifest_completion_checks.tsv"), check.names = FALSE)
config_lines <- readLines(file.path("config", "stage02_cross_species_signatures.yaml"),
                          warn = FALSE)

required_ids <- c(
  "source_mouse_S0_effects", "source_mouse_SD_effects", "source_mouse_I_effects",
  "source_human_H_effects", "source_mouse_protein_homologies",
  "source_mouse_ncrna_homologies", "source_human_protein_homologies",
  "source_human_ncrna_homologies", "source_human_entrez_xref",
  "orthology_raw_subset", "orthology_ledger", "cross_species_ledger",
  "core_tsv", "core_gmt", "interaction_tsv", "interaction_gmt", "sep_tsv",
  "sep_gmt", "signature_statistics", "frozen_config")
stopifnot(nrow(manifest) == 20L, !anyDuplicated(manifest$artifact_id),
          setequal(manifest$artifact_id, required_ids),
          identical(unique(manifest$signature_version), "v1.0"),
          length(unique(manifest$frozen_at_utc)) == 1L,
          all(completion$status == "PASS"))

stat <- setNames(as.numeric(statistics$value), statistics$metric)
stopifnot(stat[["core_total"]] == 4976, stat[["interaction_total"]] == 4085,
          stat[["sep_total"]] == 2716,
          stat[["validation_expression_files_read"]] == 0)
sig <- registry[registry$signature_id %in% c("PS_PsoGS_Core_v1.0",
                                             "PS_PsoGS_Interaction_v1.0",
                                             "SEP_v1.0"), ]
stopifnot(nrow(sig) == 3L, all(grepl("^PASS_F1_", sig$freeze_status)),
          setequal(sig$members, c(4976, 4085, 2716)))

contains_line <- function(pattern) any(grepl(pattern, config_lines, fixed = TRUE))
stopifnot(contains_line("release: 100"),
          contains_line("mouse_SD_fdr_lt: 0.05"),
          contains_line("mouse_I_fdr_lt: 0.05"),
          contains_line("human_H_fdr_lt: 0.05"),
          contains_line("minimum_primary_coverage: 0.70"),
          contains_line("no_direction_flipping: true"),
          contains_line("directed_score_formula: mean_or_rank_score_UP_minus_mean_or_rank_score_DOWN"))

effect_ids <- required_ids[1:4]
mapping_ids <- required_ids[5:9]
ledger_ids <- required_ids[10:12]
signature_ids <- required_ids[13:18]
governance_ids <- required_ids[19:20]
manifest$artifact_group <- ifelse(manifest$artifact_id %in% effect_ids, "DISCOVERY_EFFECT_INPUT",
  ifelse(manifest$artifact_id %in% mapping_ids, "ORTHOLOGY_MAPPING_INPUT",
  ifelse(manifest$artifact_id %in% ledger_ids, "DERIVED_LEDGER",
  ifelse(manifest$artifact_id %in% signature_ids, "SIGNATURE_EXPORT", "GOVERNANCE"))))
group_order <- c("DISCOVERY_EFFECT_INPUT", "ORTHOLOGY_MAPPING_INPUT", "DERIVED_LEDGER",
                 "SIGNATURE_EXPORT", "GOVERNANCE")
manifest$display_order <- match(manifest$artifact_group, group_order) * 100 +
                          match(manifest$artifact_id, required_ids)
manifest <- manifest[order(manifest$display_order), ]

artifact_source <- data.frame(
  record_type = "ARTIFACT", display_order = manifest$display_order,
  group = manifest$artifact_group, item_id = manifest$artifact_id,
  label = manifest$artifact_id, detail = manifest$path,
  value = manifest$records_or_sets, unit = "records_or_sets",
  bytes = manifest$bytes, sha256 = manifest$sha256,
  sha256_prefix = substr(manifest$sha256, 1, 10), path = manifest$path,
  version = manifest$signature_version, frozen_at_utc = manifest$frozen_at_utc,
  status = "FROZEN_REGISTERED", stringsAsFactors = FALSE)

rules <- data.frame(
  record_type = "RULE", display_order = 1001:1007, group = "FROZEN_RULE",
  item_id = c("orthology", "core", "interaction", "sep", "score", "coverage", "direction"),
  label = c("Reciprocal 1:1 orthology", "Core", "Interaction", "SEP",
            "Directed score", "Primary coverage", "Direction lock"),
  detail = c("Ensembl Compara release 100; unique human Entrez",
             "reliable ortholog AND SD FDR<0.05 AND H FDR<0.05",
             "Core AND mouse I FDR<0.05", "Core AND sign(SD)=sign(H)",
             "mean or rank score UP minus DOWN", "at least 70% of frozen members",
             "no direction flipping in validation"),
  value = c("100", "0.05", "0.05", "same_sign", "UP_minus_DOWN", "0.70", "true"),
  unit = c("Ensembl_release", "FDR", "FDR", "rule", "formula", "fraction", "boolean"),
  bytes = "", sha256 = "", sha256_prefix = "", path = "config/stage02_cross_species_signatures.yaml",
  version = "v1.0", frozen_at_utc = unique(manifest$frozen_at_utc), status = "FROZEN",
  stringsAsFactors = FALSE)

signature_labels <- c("PS-PsoGS Core", "PS-PsoGS Interaction", "SEP")
signature_artifacts <- c("core_tsv", "interaction_tsv", "sep_tsv")
signature_counts <- c(stat[["core_total"]], stat[["interaction_total"]], stat[["sep_total"]])
signature_source <- data.frame(
  record_type = "SIGNATURE_SUMMARY", display_order = 1101:1103, group = "FROZEN_OUTPUT",
  item_id = signature_artifacts, label = signature_labels,
  detail = c("cross-species disease-responsive Core", "formal CRS-by-IMQ interaction subset",
             "direction-concordant Core subset"), value = signature_counts, unit = "genes",
  bytes = "", sha256 = manifest$sha256[match(signature_artifacts, manifest$artifact_id)],
  sha256_prefix = substr(manifest$sha256[match(signature_artifacts, manifest$artifact_id)], 1, 10),
  path = manifest$path[match(signature_artifacts, manifest$artifact_id)], version = "v1.0",
  frozen_at_utc = unique(manifest$frozen_at_utc), status = "PASS_F1", stringsAsFactors = FALSE)

audit_source <- data.frame(
  record_type = "AUDIT", display_order = 1201:1204, group = "VALIDATION_HANDOFF",
  item_id = c("artifact_count", "timestamp_count", "validation_reads", "statistical_units"),
  label = c("Frozen artifacts", "Freeze timestamps", "Validation expression reads",
            "Discovery units"),
  detail = c("all source, ledger, export and governance files are SHA-256 registered",
             "one immutable F1 timestamp", "none before or during F1",
             "12 independent mice; 58 paired patients"),
  value = c(20, 1, 0, "12_mice;58_pairs"),
  unit = c("artifacts", "timestamps", "files", "statistical_units"), bytes = "",
  sha256 = "", sha256_prefix = "", path = "metadata/signature_f1_manifest.tsv",
  version = "v1.0", frozen_at_utc = unique(manifest$frozen_at_utc), status = "LOCKED",
  stringsAsFactors = FALSE)

source <- rbind(artifact_source, rules, signature_source, audit_source)
dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(source, file.path("figures", "source_data", "fig1j.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE, na = "")

group_counts <- table(factor(manifest$artifact_group, levels = group_order))
out_stats <- data.frame(
  metric = c("manifest_artifacts", "discovery_effect_inputs", "orthology_mapping_inputs",
             "derived_ledgers", "signature_exports", "governance_artifacts",
             "signature_versions", "freeze_timestamps", "core_total", "interaction_total",
             "sep_total", "minimum_primary_coverage", "no_direction_flipping",
             "validation_expression_files_read", "manifest_completion_checks_pass"),
  value = c(nrow(manifest), unname(group_counts), length(unique(manifest$signature_version)),
            length(unique(manifest$frozen_at_utc)), signature_counts, 0.70, 1,
            stat[["validation_expression_files_read"]], sum(completion$status == "PASS")),
  unit = c("artifacts", rep("artifacts", 5), "versions", "timestamps", rep("genes", 3),
           "fraction", "boolean", "files", "checks"),
  status = c(rep("PASS", 13), "PASS_LOCKED", "PASS"), stringsAsFactors = FALSE)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(out_stats, file.path("results", "figures", "fig1j_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: exported Figure 1J source ledger (%d artifacts; %d source rows)\n",
            nrow(manifest), nrow(source)))
