#!/usr/bin/env python3
"""Cohort, coverage, isolation, render and print QA for Figure 2A."""

from __future__ import annotations

import csv
import hashlib
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            out[key.strip()] = value.strip().strip('"')
    return out


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError("not PNG")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": str(observed),
                       "expected": str(expected), "status": "PASS" if passed else "FAIL",
                       "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}; expected {expected!r}")

    cohort = read_tsv(ROOT / "metadata/stage03_validation_cohort_lock.tsv")
    samples = read_tsv(ROOT / "metadata/stage03_validation_sample_lock.tsv")
    coverage = read_tsv(ROOT / "metadata/stage03_platform_coverage.tsv")
    inputs = read_tsv(ROOT / "metadata/stage03_validation_input_manifest.tsv")
    gate = read_tsv(ROOT / "audits/stage03_validation_gate_checks.tsv")
    source = read_tsv(ROOT / "figures/source_data/fig2a.tsv")
    stats_rows = read_tsv(ROOT / "results/figures/fig2a_statistics.tsv")
    stats = {row["metric"]: row for row in stats_rows}

    check("fig2a_cohort_rows", len(cohort), 5)
    check("fig2a_sample_lock_rows", len(samples), 317)
    check("fig2a_unique_sample_keys", len({(r["dataset_id"], r["sample_id"]) for r in samples}), 317)
    check("fig2a_coverage_rows", len(coverage), 10)
    check("fig2a_input_rows", len(inputs), 8)
    check("fig2a_gate_checks", (len(gate), {r["status"] for r in gate}), (48, {"PASS"}))
    check("fig2a_source_records", Counter(r["record_type"] for r in source),
          Counter({"COVERAGE": 10, "COHORT": 5, "SUMMARY": 4}))

    sample_counts = Counter((r["dataset_id"], r["lock_status"]) for r in samples)
    check("fig2a_GSE30999_primary_samples", sample_counts[("GSE30999", "PRIMARY_INCLUDE")], 162)
    check("fig2a_GSE30999_hold_samples", sample_counts[("GSE30999", "HOLD_UNRESOLVED_PAIR")], 8)
    check("fig2a_GSE121212_primary_samples", sample_counts[("GSE121212", "PRIMARY_INCLUDE")], 54)
    check("fig2a_GSE121212_hold_samples", sample_counts[("GSE121212", "HOLD_PRIMARY_UNPAIRED")], 1)
    check("fig2a_GSE121212_specificity_samples", sample_counts[("GSE121212", "SPECIFICITY_INCLUDE")], 42)
    check("fig2a_GSE121212_sensitivity_samples", sample_counts[("GSE121212", "SENSITIVITY_INCLUDE")], 12)
    check("fig2a_GSE121212_reference_samples", sample_counts[("GSE121212", "REFERENCE_INCLUDE")], 38)
    held = [r for r in samples if r["lock_status"] in {"HOLD_UNRESOLVED_PAIR", "HOLD_PRIMARY_UNPAIRED"}]
    check("fig2a_holds_visible", len(held), 9)
    check("fig2a_unmatched_pso", [(r["donor_id"], r["skin_type"]) for r in held
          if r["dataset_id"] == "GSE121212"], [("PSO_034", "lesional")])

    expected_cov = {
        ("GSE30999", "Core"): (4976, 4921), ("GSE30999", "Interaction"): (4085, 4042),
        ("GSE30999", "SEP"): (2716, 2679), ("GSE30999", "SEP_UP"): (1399, 1383),
        ("GSE30999", "SEP_DOWN"): (1317, 1296),
        ("GSE121212", "Core"): (4976, 4721), ("GSE121212", "Interaction"): (4085, 3873),
        ("GSE121212", "SEP"): (2716, 2585), ("GSE121212", "SEP_UP"): (1399, 1345),
        ("GSE121212", "SEP_DOWN"): (1317, 1240),
    }
    check("fig2a_coverage_keys", {(r["dataset_id"], r["signature_id"]) for r in coverage},
          set(expected_cov))
    for row in coverage:
        key = (row["dataset_id"], row["signature_id"])
        frozen, measurable = expected_cov[key]
        check(f"fig2a_frozen::{key}", int(row["frozen_members"]), frozen)
        check(f"fig2a_measurable::{key}", int(row["measurable_members"]), measurable)
        check(f"fig2a_fraction::{key}", abs(float(row["coverage_fraction"]) - measurable/frozen) < 1e-9, True)
        check(f"fig2a_gate::{key}", float(row["coverage_fraction"]) >= 0.70, True)

    for row in inputs:
        path = ROOT / row["path"]
        check(f"fig2a_input_present::{row['artifact_id']}", path.is_file(), True)
        check(f"fig2a_input_bytes::{row['artifact_id']}", path.stat().st_size, int(row["bytes"]))
        check(f"fig2a_input_hash::{row['artifact_id']}", sha256(path), row["sha256"])
        check(f"fig2a_no_effect::{row['artifact_id']}", row["numeric_effects_computed"], "NO")

    check("fig2a_stats_rows", len(stats_rows), 9)
    expected_stats = {"locked_primary_array_pairs": 81, "locked_primary_rnaseq_pairs": 27,
                      "held_array_singletons": 8, "held_rnaseq_psoriasis_samples": 1,
                      "sample_lock_rows": 317, "gate_checks_pass": 48,
                      "numeric_expression_effects_computed": 0}
    for key, value in expected_stats.items():
        check(f"fig2a_stat::{key}", int(float(stats[key]["value"])), value)
    check("fig2a_array_min_coverage", float(stats["array_min_signature_coverage"]["value"]),
          min(float(r["coverage_fraction"]) for r in coverage if r["dataset_id"] == "GSE30999"))
    check("fig2a_rnaseq_min_coverage", float(stats["rnaseq_min_signature_coverage"]["value"]),
          min(float(r["coverage_fraction"]) for r in coverage if r["dataset_id"] == "GSE121212"))

    cfg = read_config(ROOT / "config/figures/fig2a.yaml")
    plot_script = (ROOT / "scripts/figures/fig2a_plot.R").read_text(encoding="utf-8")
    analysis_script = (ROOT / "scripts/figures/fig2a_analysis.R").read_text(encoding="utf-8")
    check("fig2a_manual_visual", cfg["manual_visual_inspection"], "PASS_2026-09-11_FIRST_RENDER")
    check("fig2a_no_numeric_effects", cfg["numeric_expression_effects_computed"], "no")
    check("fig2a_min_text", float(cfg["minimum_text_pt"]) >= 8, True)
    check("fig2a_analysis_uses_derived_only", "GSE121212_readcount" not in analysis_script, True)
    check("fig2a_plot_uses_derived_only", "GSE121212_readcount" not in plot_script, True)
    for key in ("primary_color", "secondary_color", "hold_color", "light_fill", "grid_color"):
        check(f"fig2a_color::{key}", cfg[key] in plot_script, True)

    svg = ROOT / "figures/panels/fig2a.svg"; png = ROOT / "figures/previews/fig2a.png"
    caption = ROOT / "figures/captions/fig2a.md"
    check("fig2a_svg", svg.is_file() and svg.stat().st_size > 100000, True)
    check("fig2a_png", png.is_file() and png.stat().st_size > 100000, True)
    check("fig2a_caption", caption.is_file() and caption.stat().st_size > 1800, True)
    caption_text = caption.read_text(encoding="utf-8")
    check("fig2a_caption_no_effect_claim", "No validation differential-expression estimate" in caption_text, True)
    check("fig2a_caption_holds", "remain `HOLD`" in caption_text, True)
    check("fig2a_caption_units", "paired patient" in caption_text, True)
    check("fig2a_png_dimensions", png_dimensions(png),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    sw, sh = svg_dimensions(svg)
    check("fig2a_svg_width", abs(sw - float(cfg["width_inches"])) < 0.02, True)
    check("fig2a_svg_height", abs(sh - float(cfg["height_inches"])) < 0.02, True)

    panel = {r["panel_id"]: r for r in read_tsv(ROOT / "panel_manifest.tsv")}["2A"]
    check("fig2a_panel_status", panel["status"], "PASS")
    check("fig2a_panel_qa", panel["qa_status"], "PASS_RENDER_DATA_PRINT")
    check("fig2a_panel_ready", panel["figure_ready"], "YES")
    check("fig2a_panel_source", panel["source_data"], "figures/source_data/fig2a.tsv")

    audit_path = ROOT / "audits/fig2a_qa_checks.tsv"
    with audit_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 2A cohort, coverage, isolation and render QA checks")


if __name__ == "__main__":
    main()
