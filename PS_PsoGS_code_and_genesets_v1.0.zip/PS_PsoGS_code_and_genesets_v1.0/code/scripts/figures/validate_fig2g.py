#!/usr/bin/env python3
"""Null membership, source/statistic, render and print QA for Figure 2G."""

from __future__ import annotations

import csv
import math
import statistics
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
AUDIT = ROOT / "audits/fig2g_qa_checks.tsv"


def read_tsv(path: Path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path):
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            out[key.strip()] = value.strip().strip('"')
    return out


def png_dimensions(path: Path):
    with path.open("rb") as handle:
        header = handle.read(24)
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path):
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def main() -> None:
    checks = []

    def check(check_id, observed, expected, note=""):
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: {observed!r} != {expected!r}")

    source = read_tsv(ROOT / "figures/source_data/fig2g.tsv")
    stats = read_tsv(ROOT / "results/figures/fig2g_statistics.tsv")
    upstream = read_tsv(ROOT / "results/stage03/random_null/random_signature_null.tsv")
    summary = read_tsv(ROOT / "results/stage03/random_null/random_signature_null_summary.tsv")
    audit = read_tsv(ROOT / "audits/stage03_random_signature_null_checks.tsv")
    check("fig2g_underlying_audit", (len(audit), {r["status"] for r in audit}), (20, {"PASS"}))
    check("fig2g_source_rows", len(source), 4002)
    check("fig2g_source_types", Counter(r["record_type"] for r in source),
          Counter({"matched_random_signature": 4000, "observed_SEP": 2}))
    check("fig2g_upstream_rows", len(upstream), 4000)
    check("fig2g_stats_rows", len(stats), 2)
    check("fig2g_cohorts", {r["dataset_id"] for r in stats}, {"GSE30999", "GSE121212"})
    source_null = {(r["dataset_id"], r["permutation_id"]): r for r in source if r["record_type"] == "matched_random_signature"}
    upstream_map = {(r["dataset_id"], r["permutation_id"]): r for r in upstream}
    check("fig2g_null_keys", set(source_null), set(upstream_map))
    for key, row in upstream_map.items():
        check(f"fig2g_effect::{key}", abs(float(source_null[key]["random_effect"]) - float(row["random_effect"])) < 1e-14, True)
        check(f"fig2g_size::{key}", (source_null[key]["n_up"], source_null[key]["n_down"]),
              (row["n_up"], row["n_down"]))
    smap = {r["dataset_id"]: r for r in summary}
    fmap = {r["dataset_id"]: r for r in stats}
    for dataset in smap:
        s, f = smap[dataset], fmap[dataset]
        values = [float(r["random_effect"]) for r in upstream if r["dataset_id"] == dataset]
        check(f"fig2g_B::{dataset}", len(values), 2000)
        check(f"fig2g_mean::{dataset}", abs(statistics.mean(values) - float(f["null_mean"])) < 1e-14, True)
        check(f"fig2g_sd::{dataset}", abs(statistics.stdev(values) - float(f["null_sd"])) < 1e-14, True)
        check(f"fig2g_observed::{dataset}", abs(float(f["observed_effect"]) - float(s["observed_effect"])) < 1e-14, True)
        check(f"fig2g_exceedance::{dataset}", int(f["null_exceedances"]), 0)
        check(f"fig2g_p::{dataset}", abs(float(f["empirical_p_greater"]) - 1 / 2001) < 1e-14, True)
        expected_z = (float(f["observed_effect"]) - float(f["null_mean"])) / float(f["null_sd"])
        check(f"fig2g_z::{dataset}", abs(float(f["observed_z_vs_null"]) - expected_z) < 1e-12, True)
        check(f"fig2g_large_separation::{dataset}", expected_z > 40, True)
        check(f"fig2g_finite::{dataset}", all(math.isfinite(v) for v in values), True)

    cfg = read_config(ROOT / "config/figures/fig2g.yaml")
    check("fig2g_manual_visual", cfg["manual_visual_inspection"], "PASS_2026-09-11_FIRST_RENDER")
    check("fig2g_min_text", float(cfg["minimum_text_pt"]) >= 8, True)
    analysis_text = (ROOT / "scripts/figures/fig2g_analysis.R").read_text(encoding="utf-8")
    plot_text = (ROOT / "scripts/figures/fig2g_plot.R").read_text(encoding="utf-8")
    check("fig2g_analysis_derived_only", "data/raw" not in analysis_text, True)
    check("fig2g_plot_derived_only", "data/raw" not in plot_text, True)
    check("fig2g_ascii_plot", all(ord(ch) < 128 for ch in plot_text), True)
    svg = ROOT / "figures/panels/fig2g.svg"
    png = ROOT / "figures/previews/fig2g.png"
    caption = ROOT / "figures/captions/fig2g.md"
    check("fig2g_svg", svg.is_file() and svg.stat().st_size > 50000, True)
    check("fig2g_png", png.is_file() and png.stat().st_size > 50000, True)
    check("fig2g_caption", caption.is_file() and caption.stat().st_size > 1800, True)
    caption_text = caption.read_text(encoding="utf-8")
    for phrase in ("2,000 random signatures", "without reading lesion labels", "1/2,001",
                   "must not be reported as P=0", "does not exclude confounding", "Figure 2F remains blocked"):
        check(f"fig2g_caption::{phrase}", phrase in caption_text, True)
    check("fig2g_png_dimensions", png_dimensions(png),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    sw, sh = svg_dimensions(svg)
    check("fig2g_svg_width", abs(sw - float(cfg["width_inches"])) < 0.02, True)
    check("fig2g_svg_height", abs(sh - float(cfg["height_inches"])) < 0.02, True)
    panel = {r["panel_id"]: r for r in read_tsv(ROOT / "panel_manifest.tsv")}["2G"]
    check("fig2g_panel_status", panel["status"], "PASS")
    check("fig2g_panel_qa", panel["qa_status"], "PASS_RENDER_DATA_PRINT")
    check("fig2g_panel_ready", panel["figure_ready"], "YES")

    with AUDIT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 2G null, render and print QA checks")


if __name__ == "__main__":
    main()
