options(stringsAsFactors = FALSE)

cfg_lines <- readLines(file.path("config", "figures", "fig1e.yaml"), warn = FALSE)
cfg <- function(key, default = NA_character_) {
  hit <- grep(paste0("^", key, ":"), cfg_lines, value = TRUE)
  if (!length(hit)) return(default)
  gsub('^"|"$', '', trimws(sub("^[^:]+:", "", hit[1])))
}
dat <- read.delim(file.path("figures", "source_data", "fig1e.tsv"), check.names = FALSE)
pca <- dat[dat$record_type == "PCA", ]
strand <- dat[dat$record_type == "STRAND", ]
lib <- dat[dat$record_type == "LIBRARY", ]
stopifnot(nrow(pca) == 12L, nrow(strand) == 36L, nrow(lib) == 12L)

width <- as.numeric(cfg("width_inches")); height <- as.numeric(cfg("height_inches"))
dpi <- as.numeric(cfg("png_dpi")); ink <- cfg("ink"); mid <- cfg("mid_grey")
light <- cfg("light_grey"); blue_light <- cfg("blue_light")
groups <- c("Control", "CRS", "IMQ", "CRS+IMQ")
cols <- setNames(c(cfg("control"), cfg("crs"), cfg("imq"), cfg("crs_imq")), groups)
pch_map <- setNames(c(21, 22, 24, 23), groups)
short_id <- function(x) sub("GSE212126_", "", x, fixed = TRUE)

draw_panel <- function() {
  layout(matrix(c(1, 1, 2, 1, 1, 3), nrow = 2, byrow = TRUE), widths = c(1, 1, 0.98),
         heights = c(1, 1))

  par(family = "sans", fg = ink, mar = c(4.1, 4.2, 4.2, 1.0), xpd = NA)
  plot(pca$PC1, pca$PC2, type = "n",
       xlab = sprintf("PC1 (%.1f%%)", 100 * pca$PC1_variance[1]),
       ylab = sprintf("PC2 (%.1f%%)", 100 * pca$PC2_variance[1]),
       main = "E  GSE212126 sample-level count QC", las = 1, cex.axis = 0.74,
       cex.lab = 0.8, cex.main = 1.0, font.main = 2, adj = 0)
  abline(h = 0, v = 0, col = light, lwd = 0.8)
  for (group in groups) {
    ix <- pca$condition == group
    points(pca$PC1[ix], pca$PC2[ix], pch = pch_map[group], bg = cols[group],
           col = ink, cex = 1.12, lwd = 0.8)
  }
  for (group in groups) {
    ix <- which(pca$condition == group)
    reps <- sub("rep", "M", pca$replicate_label[ix])
    if (group %in% c("CRS", "CRS+IMQ")) {
      label_x <- if (group == "CRS") mean(pca$PC1[ix]) - 10 else mean(pca$PC1[ix]) + 9
      label_y <- mean(pca$PC2[ix]) + c(4.5, 0, -4.5)
      label_adj <- if (group == "CRS") 1 else 0
      segment_end <- label_x + if (group == "CRS") 0.8 else -0.8
      segments(pca$PC1[ix], pca$PC2[ix], segment_end, label_y, col = mid, lwd = 0.65)
      text(label_x, label_y, reps, adj = label_adj, cex = 0.67, col = ink, font = 2)
    } else {
      text(pca$PC1[ix], pca$PC2[ix], reps, pos = 3, offset = 0.55,
           cex = 0.67, col = ink, font = 2)
    }
  }
  legend(34, 91, legend = groups, pch = pch_map[groups], pt.bg = cols[groups],
         col = ink, pt.cex = 0.95, cex = 0.67, bty = "n", ncol = 2,
         x.intersp = 0.7, y.intersp = 0.9)
  mtext("12 independent mice; M1-M3 labels identify biological replicates", side = 3,
        adj = 0, line = 0.65, cex = 0.67, col = mid)

  par(family = "sans", fg = ink, mar = c(2.7, 4.15, 3.2, 1.0), xpd = NA)
  strand_levels <- c(0, 1, 2)
  plot(NA, xlim = c(-0.25, 2.25), ylim = c(0, 0.95), xaxt = "n", las = 1,
       xlab = "", ylab = "Assigned / classified", cex.axis = 0.68, cex.lab = 0.72,
       main = "")
  mtext("Strand assignment", side = 3, adj = 0, line = 1.55, cex = 0.82, font = 2, col = ink)
  axis(1, at = strand_levels, labels = c("0\nunstranded", "1\nforward", "2\nreverse"),
       tick = FALSE, cex.axis = 0.67)
  abline(h = c(0.2, 0.8), col = light, lty = 3, lwd = 0.8)
  for (setting in strand_levels) {
    vals <- strand$assignment_fraction[strand$strand_setting == setting]
    segments(setting, min(vals), setting, max(vals), col = ink, lwd = 1.1)
    points(rep(setting, length(vals)), vals, pch = 21, bg = if (setting == 2) cols["crs"] else "white",
           col = ink, cex = 0.78, lwd = 0.7)
    points(setting, median(vals), pch = 95, cex = 1.55, col = ink, lwd = 1.5)
  }
  for (setting in strand_levels) {
    vals <- strand$assignment_fraction[strand$strand_setting == setting]
    label_y <- if (setting == 1) 0.16 else 0.93
    text(setting, label_y, sprintf("%.1f-%.1f%%", 100 * min(vals), 100 * max(vals)),
         cex = 0.67, font = 2, col = if (setting == 2) cols["crs"] else ink)
  }
  mtext("Range and median across all libraries", side = 3, adj = 0, line = 0.55,
        cex = 0.67, col = mid)

  par(family = "sans", fg = ink, mar = c(3.25, 4.15, 2.7, 1.0), xpd = NA)
  group_order <- c("Control", "CRS", "IMQ", "CRS+IMQ")
  ord <- order(match(lib$condition, group_order), lib$replicate_label)
  x <- lib$raw_library_size[ord] / 1e6
  y <- rev(seq_along(ord))
  plot(NA, xlim = c(17.7, 20.7), ylim = c(0.5, 12.5), yaxt = "n", las = 1,
       xlab = "Assigned fragments (millions)", ylab = "", cex.axis = 0.68, cex.lab = 0.72,
       main = "")
  mtext("Count depth and TMM", side = 3, adj = 0, line = 1.45, cex = 0.82, font = 2, col = ink)
  abline(v = seq(18, 20.5, 0.5), col = light, lwd = 0.65)
  axis(2, at = y, labels = short_id(lib$canonical_animal_id[ord]), las = 1,
       tick = FALSE, cex.axis = 0.67)
  points(x, y, pch = pch_map[lib$condition[ord]], bg = cols[lib$condition[ord]],
         col = ink, cex = 0.95, lwd = 0.7)
  text(x + 0.10, y, labels = sprintf("%.3f", lib$TMM_norm_factor[ord]),
       adj = 0, cex = 0.67, col = ink)
  mtext("Labels beside points: TMM factor", side = 3, adj = 0, line = 0.48,
        cex = 0.67, col = mid)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig1e.svg"), width = width, height = height,
    pointsize = 12, bg = "white", family = "sans")
draw_panel(); dev.off()
png(file.path("figures", "previews", "fig1e.png"), width = width, height = height,
    units = "in", res = dpi, pointsize = 12, bg = "white")
draw_panel(); dev.off()
cat("PASS: rendered Figure 1E SVG and 300-dpi PNG\n")
