options(stringsAsFactors = FALSE)

.libPaths(c(normalizePath(file.path("r_libs", "stage02")),
            normalizePath(file.path("r_libs", "stage01")), .libPaths()))
stopifnot(requireNamespace("edgeR", quietly = TRUE))

ledger_path <- file.path("figures", "source_data", "fig1g.tsv")
fit_path <- file.path("results", "stage02", "factorial_edger", "gse212126_edgeR_QL_fit.rds")
out_path <- file.path("figures", "source_data", "fig1k.tsv")
stats_path <- file.path("results", "figures", "fig1k_statistics.tsv")
stopifnot(file.exists(ledger_path), file.exists(fit_path))

ledger <- read.delim(ledger_path, check.names = FALSE)
classes <- c("augmentation", "attenuation", "reversal")
selected <- do.call(rbind, lapply(classes, function(cls) {
  x <- ledger[ledger$interaction_class == cls & nzchar(ledger$human_gene_symbol), ]
  x <- x[order(-abs(x$I_logFC), x$human_gene_symbol), ]
  x[1, ]
}))
stopifnot(identical(selected$interaction_class, classes))

obj <- readRDS(fit_path)
rows <- list()
for (estimand in c("S0", "SD", "I")) {
  test <- edgeR::glmQLFTest(obj$fit, contrast = obj$contrasts[, estimand])
  tab <- edgeR::topTags(test, n = Inf, sort.by = "none")$table
  idx <- match(selected$mouse_gene_id, rownames(tab))
  stopifnot(!anyNA(idx))
  beta <- tab$logFC[idx]
  se <- abs(beta) / sqrt(tab$F[idx])
  crit <- stats::qt(0.975, test$df.total[idx])
  rows[[estimand]] <- data.frame(
    interaction_class = selected$interaction_class,
    mouse_gene_id = selected$mouse_gene_id,
    mouse_gene_name = selected$mouse_gene_name,
    human_gene_symbol = selected$human_gene_symbol,
    estimand = estimand,
    log2_fold_change = beta,
    ci95_low = beta - crit * se,
    ci95_high = beta + crit * se,
    qlf_F = tab$F[idx],
    qlf_df_total = test$df.total[idx],
    p_value = tab$PValue[idx],
    fdr_bh = tab$FDR[idx],
    selection_rule = "largest absolute frozen I logFC within interaction class; tie by human symbol",
    interval_rule = "95% t interval using SE=abs(logFC)/sqrt(one-df moderated QL F) and edgeR df.total",
    stringsAsFactors = FALSE
  )
}
out <- do.call(rbind, rows)
out$interaction_class <- factor(out$interaction_class, levels = classes)
out$estimand <- factor(out$estimand, levels = c("S0", "SD", "I"))
out <- out[order(out$interaction_class, out$estimand), ]
out$interaction_class <- as.character(out$interaction_class)
out$estimand <- as.character(out$estimand)

stopifnot(nrow(out) == 9L,
          length(unique(out$human_gene_symbol)) == 3L,
          all(is.finite(out$log2_fold_change)),
          all(out$ci95_low < out$log2_fold_change),
          all(out$ci95_high > out$log2_fold_change))
write.table(out, out_path, sep = "\t", quote = FALSE, row.names = FALSE)

stats <- data.frame(
  metric = c("representative_genes", "estimands_per_gene", "selection_uses_validation",
             "membership_or_threshold_changed", "interval_rows_valid"),
  value = c(3, 3, 0, 0, 9),
  unit = c("genes", "estimands", "boolean", "boolean", "rows"),
  status = c("PASS", "PASS", "PASS_LOCKED", "PASS_LOCKED", "PASS"),
  interpretation = c(
    "one display-only representative per frozen interaction class",
    "S0, SD and I shown for each selected gene",
    "selection uses only the frozen mouse interaction ledger",
    "F1 membership, direction and FDR thresholds are unchanged",
    "all point estimates lie within their reconstructed 95% intervals"
  ), stringsAsFactors = FALSE
)
write.table(stats, stats_path, sep = "\t", quote = FALSE, row.names = FALSE)
cat("PASS: wrote Figure 1K display-only representative effects and intervals\n")
