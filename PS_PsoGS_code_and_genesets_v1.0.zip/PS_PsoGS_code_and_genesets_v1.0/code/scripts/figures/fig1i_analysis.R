options(stringsAsFactors = FALSE)

ledger <- read.delim(gzfile(file.path("results", "stage02", "signatures",
                                     "cross_species_gene_ledger.tsv.gz")),
                     check.names = FALSE)
evidence <- read.delim(file.path("metadata", "gene_evidence_ledger.tsv"),
                       check.names = FALSE)
quickgo <- read.delim(file.path("genesets", "endocrine_go_exact_2026-09-10.tsv"),
                      check.names = FALSE)
audit <- read.delim(file.path("audits", "stage02_orthology", "signature_f1_checks.tsv"),
                    check.names = FALSE)
stopifnot(nrow(ledger) == 18484L, nrow(audit) == 45L, all(audit$status == "PASS"),
          sum(ledger$core_member == "TRUE") == 4976L)

core <- ledger[ledger$core_member == "TRUE", ]
stopifnot(nrow(core) == 4976L, !anyDuplicated(core$mouse_ensembl_gene_id),
          !anyDuplicated(core$human_gene_symbol), all(core$SD_FDR < 0.05),
          all(core$H_FDR < 0.05))

ctra_rows <- evidence[grepl("^CTRA_", evidence$evidence_source), ]
stopifnot(nrow(ctra_rows) == 53L, !anyDuplicated(ctra_rows$normalized_symbol),
          all(ctra_rows$direction %in% c("UP", "DOWN")))
ctra_direction <- setNames(ctra_rows$direction, ctra_rows$normalized_symbol)

gse_rows <- evidence[grepl("^GSE70603_", evidence$evidence_source) &
                     grepl("mapping=PASS:", evidence$notes, fixed = TRUE), ]
stopifnot(length(unique(gse_rows$normalized_symbol)) == 3871L,
          all(gse_rows$direction %in% c("UP", "DOWN")))
gse_split <- split(gse_rows$direction, gse_rows$normalized_symbol)
gse_direction <- vapply(gse_split, function(x) {
  dirs <- sort(unique(x))
  if (length(dirs) == 1L) dirs else "MIXED_TIMEPOINT_DIRECTION"
}, character(1))

quickgo_rows <- quickgo[quickgo$species == "Homo sapiens" &
                        grepl("^PASS", quickgo$hgnc_exact_status), ]
quickgo_symbols <- unique(quickgo_rows$source_symbol)
stopifnot(length(quickgo_symbols) == 46L,
          all(quickgo_rows$direction == "NONE_ONTOLOGY_ANNOTATION"))

symbol <- core$human_gene_symbol
ctra <- unname(ctra_direction[symbol])
gse <- unname(gse_direction[symbol])
ctra[is.na(ctra)] <- "NONE"
gse[is.na(gse)] <- "NONE"
qgo <- symbol %in% quickgo_symbols

core_rank <- match(core$core_direction_class,
                   c("CONCORDANT_UP", "CONCORDANT_DOWN",
                     "DISCORDANT_MOUSE_DOWN_HUMAN_UP",
                     "DISCORDANT_MOUSE_UP_HUMAN_DOWN"))
interaction_rank <- match(core$interaction_class,
                          c("augmentation", "attenuation", "reversal", ""), nomatch = 4L)
display_index <- order(core_rank,
                       -(core$high_confidence_sep_interaction == "TRUE"),
                       interaction_rank, -(gse != "NONE"), -(ctra != "NONE"), -qgo,
                       symbol)
display_order <- integer(nrow(core))
display_order[display_index] <- seq_len(nrow(core))

source <- data.frame(
  display_order = display_order,
  mouse_gene_id = core$mouse_gene_id_versioned,
  mouse_gene_name = core$mouse_gene_name,
  human_ensembl_gene_id = core$selected_human_ensembl_gene_id,
  human_entrez_id = core$selected_human_entrez_id,
  human_gene_symbol = symbol,
  SD_logFC = core$SD_logFC,
  SD_FDR = core$SD_FDR,
  SD_direction = ifelse(core$SD_logFC > 0, "UP", "DOWN"),
  H_logFC = core$H_logFC,
  H_FDR = core$H_FDR,
  H_direction = ifelse(core$H_logFC > 0, "UP", "DOWN"),
  core_direction_class = core$core_direction_class,
  interaction_member = core$interaction_member,
  interaction_class = ifelse(core$interaction_member == "TRUE", core$interaction_class, "NONE"),
  sep_member = core$sep_member,
  sep_direction = ifelse(core$sep_member == "TRUE", core$sep_direction, "NONE"),
  high_confidence_sep_interaction = core$high_confidence_sep_interaction,
  CTRA_reference_direction = ctra,
  GSE70603_time_locked_direction = gse,
  QuickGO_exact_human_annotation = ifelse(qgo, "PRESENT", "ABSENT"),
  PS_reference_role = "annotation_only_not_F1_membership",
  mouse_statistical_unit = "independent mouse; 12 total and 3 per factorial group",
  human_statistical_unit = "paired patient; 58 PP-PN pairs",
  stringsAsFactors = FALSE)
source <- source[order(source$display_order), ]

stopifnot(identical(source$display_order, seq_len(nrow(source))),
          sum(source$interaction_member == "TRUE") == 4085L,
          sum(source$sep_member == "TRUE") == 2716L,
          sum(source$high_confidence_sep_interaction == "TRUE") == 1530L)

dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(source, file.path("figures", "source_data", "fig1i.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE, na = "")

direction_counts <- table(factor(source$core_direction_class,
  levels = c("CONCORDANT_UP", "CONCORDANT_DOWN", "DISCORDANT_MOUSE_DOWN_HUMAN_UP",
             "DISCORDANT_MOUSE_UP_HUMAN_DOWN")))
interaction_counts <- table(factor(source$interaction_class,
  levels = c("augmentation", "attenuation", "reversal", "NONE")))
gse_counts <- table(factor(source$GSE70603_time_locked_direction,
  levels = c("UP", "DOWN", "MIXED_TIMEPOINT_DIRECTION", "NONE")))
any_reference <- source$CTRA_reference_direction != "NONE" |
                 source$GSE70603_time_locked_direction != "NONE" |
                 source$QuickGO_exact_human_annotation == "PRESENT"

stats <- data.frame(
  metric = c("core_total", "concordant_up", "concordant_down",
             "discordant_mouse_down_human_up", "discordant_mouse_up_human_down",
             "interaction_total", "interaction_augmentation", "interaction_attenuation",
             "interaction_reversal", "core_without_significant_interaction", "sep_total",
             "high_confidence_sep_interaction", "core_overlap_ctra", "core_overlap_gse70603",
             "core_gse70603_up", "core_gse70603_down", "core_gse70603_mixed_timepoint",
             "core_overlap_quickgo_human", "core_any_ps_reference_overlap",
             "signature_f1_checks_pass", "validation_expression_accessed"),
  value = c(nrow(source), unname(direction_counts), sum(source$interaction_member == "TRUE"),
            unname(interaction_counts), sum(source$sep_member == "TRUE"),
            sum(source$high_confidence_sep_interaction == "TRUE"),
            sum(source$CTRA_reference_direction != "NONE"),
            sum(source$GSE70603_time_locked_direction != "NONE"),
            unname(gse_counts[1:3]),
            sum(source$QuickGO_exact_human_annotation == "PRESENT"), sum(any_reference),
            nrow(audit), 0),
  unit = c(rep("genes", 19), "checks", "boolean"),
  status = c(rep("PASS", 20), "PASS_LOCKED"),
  interpretation = c(
    "all frozen Core genes", "SD and H positive", "SD and H negative",
    "mouse SD negative and human H positive", "mouse SD positive and human H negative",
    "Core genes passing I BH-FDR<0.05", "same sign and larger absolute SD",
    "same sign and smaller absolute SD", "opposite S0 and SD signs",
    "Core genes without significant interaction", "direction-concordant Core genes",
    "frozen high-confidence SEP-Interaction rule", "CTRA annotation overlap",
    "time-locked GSE70603 annotation overlap", "GSE70603 only UP across selected timepoints",
    "GSE70603 only DOWN across selected timepoints", "GSE70603 direction differs by timepoint",
    "exact human QuickGO annotation overlap", "union of three PS-Reference annotations",
    "independent F1 membership and source checks", "locked validation expression remained isolated"),
  stringsAsFactors = FALSE)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(stats, file.path("results", "figures", "fig1i_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: exported Figure 1I ledger for %s Core genes; PS-Reference union=%s\n",
            format(nrow(source), big.mark = ","), format(sum(any_reference), big.mark = ",")))
