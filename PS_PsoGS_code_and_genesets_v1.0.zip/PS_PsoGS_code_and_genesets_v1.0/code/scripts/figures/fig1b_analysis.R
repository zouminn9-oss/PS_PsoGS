options(stringsAsFactors = FALSE)

dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)

registry_path <- file.path("metadata", "ps_reference_registry.tsv")
registry <- read.delim(registry_path, check.names = FALSE, stringsAsFactors = FALSE)
required <- c("resource_id", "evidence_stratum", "organism", "statistical_unit",
              "allowed_role", "member_generation_rule", "automatic_directional_score",
              "automatic_core_eligibility", "freeze_status", "critical_limitation", "source_url")
stopifnot(all(required %in% names(registry)), nrow(registry) == 9L)

lane_map <- c(
  FIXED_HUMAN_ADVERSITY_SIGNATURE = "Fixed adversity signature",
  ACTUAL_HUMAN_LAB_STRESS_TIME_LOCKED = "Human actual stress",
  ACTUAL_MOUSE_CHRONIC_RESTRAINT_STRESS_PSORIASIS_CONTEXT = "Mouse actual stress context",
  ACTUAL_MOUSE_RESTRAINT_STRESS_SKIN_CONTEXT = "Mouse actual stress context",
  NEUROENDOCRINE_PROXY_IN_VITRO = "Neuroendocrine proxy",
  GLUCOCORTICOID_PHARMACOLOGIC_PROXY = "Pharmacologic proxy",
  ONTOLOGY_FUNCTIONAL_ANNOTATION = "Functional annotation"
)
lane_levels <- c("Fixed adversity signature", "Human actual stress",
                 "Mouse actual stress context", "Neuroendocrine proxy",
                 "Pharmacologic proxy", "Functional annotation")
resource_labels <- c(
  CTRA_KOHRT2016 = "CTRA (Kohrt 2016)",
  GSE70603_STRESS_RESPONSE = "GSE70603",
  GSE212126_FACTORIAL = "GSE212126",
  GSE270712_SCRNA = "GSE270712 scRNA",
  GSE270713_MDFB = "GSE270713 mdFB",
  GSE270713_HPAD = "GSE270713 HPAd",
  GSE270713_SKIN = "GSE270713 skin",
  GSE26487_DEX_KERATINOCYTE = "GSE26487 keratinocyte",
  `ENDOCRINE_GO_EXACT_2026-09-10` = "QuickGO exact terms"
)

registry$lane <- unname(lane_map[registry$evidence_stratum])
registry$lane_order <- match(registry$lane, lane_levels)
registry$resource_label <- unname(resource_labels[registry$resource_id])
stopifnot(!anyNA(registry$lane_order), !anyNA(registry$resource_label))
registry$status_group <- ifelse(registry$freeze_status == "BLOCKED", "BLOCKED",
                                ifelse(grepl("^PASS", registry$freeze_status), "PASS", "PARTIAL"))
registry$member_mode <- ifelse(
  registry$resource_id == "GSE212126_FACTORIAL", "FROZEN_F1_DEVELOPMENT_SOURCE",
  ifelse(registry$resource_id %in% c("CTRA_KOHRT2016", "GSE70603_STRESS_RESPONSE",
                                     "ENDOCRINE_GO_EXACT_2026-09-10"),
         "FROZEN_REFERENCE_OR_ANNOTATION", "NO_MEMBER_GENERATION")
)
registry$member_code <- c(FROZEN_REFERENCE_OR_ANNOTATION = "M",
                          FROZEN_F1_DEVELOPMENT_SOURCE = "F",
                          NO_MEMBER_GENERATION = "-")[registry$member_mode]
registry$resource_order <- seq_len(nrow(registry))
registry$analysis_scope <- "descriptive provenance audit; no inferential test"

out <- registry[, c("resource_id", "resource_label", "resource_order", "evidence_stratum",
                    "lane", "lane_order", "organism", "statistical_unit", "freeze_status",
                    "status_group", "member_mode", "member_code", "allowed_role",
                    "member_generation_rule", "automatic_directional_score",
                    "automatic_core_eligibility", "critical_limitation", "source_url",
                    "analysis_scope")]
write.table(out, file.path("figures", "source_data", "fig1b.tsv"), sep = "\t",
            row.names = FALSE, quote = FALSE, na = "")

make_stats <- function(type, groups, counts, denominator, note) {
  data.frame(statistic_type = type, group = groups, count = as.integer(counts),
             denominator = denominator, percent = 100 * as.integer(counts) / denominator,
             statistical_test = "none_descriptive_audit", note = note,
             stringsAsFactors = FALSE)
}
stats <- rbind(
  make_stats("TOTAL_RESOURCES", "all", nrow(out), nrow(out),
             "Frozen PS-Reference registry rows."),
  make_stats("EVIDENCE_LANE", names(table(factor(out$lane, levels = lane_levels))),
             as.integer(table(factor(out$lane, levels = lane_levels))), nrow(out),
             "Lane is defined by source design, not by gene overlap."),
  make_stats("FREEZE_STATUS", names(table(factor(out$status_group, levels = c("PASS", "PARTIAL", "BLOCKED")))),
             as.integer(table(factor(out$status_group, levels = c("PASS", "PARTIAL", "BLOCKED")))), nrow(out),
             "PASS_WITH_CAUSAL_LIMIT is displayed within PASS; PARTIAL_HOLD within PARTIAL."),
  make_stats("MEMBER_MODE", names(table(factor(out$member_mode,
             levels = c("FROZEN_REFERENCE_OR_ANNOTATION", "FROZEN_F1_DEVELOPMENT_SOURCE", "NO_MEMBER_GENERATION")))),
             as.integer(table(factor(out$member_mode,
             levels = c("FROZEN_REFERENCE_OR_ANNOTATION", "FROZEN_F1_DEVELOPMENT_SOURCE", "NO_MEMBER_GENERATION")))),
             nrow(out), "M includes frozen reference members or non-directional annotation; F marks the frozen F1 development source."),
  make_stats("AUTOMATIC_CORE_ELIGIBILITY", "NO", sum(out$automatic_core_eligibility == "NO"), nrow(out),
             "No resource is automatically eligible for PS-PsoGS Core.")
)
write.table(stats, file.path("results", "figures", "fig1b_statistics.tsv"), sep = "\t",
            row.names = FALSE, quote = FALSE, na = "")

cat(sprintf("PASS: fig1b source data %d resources; statistics %d rows\n", nrow(out), nrow(stats)))
