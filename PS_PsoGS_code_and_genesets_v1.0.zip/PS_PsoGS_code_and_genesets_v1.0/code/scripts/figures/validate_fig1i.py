#!/usr/bin/env python3
"""Data, isolation, render and print QA for Figure 1I."""

from __future__ import annotations

import csv
import gzip
import struct
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def read_tsv(path: Path, compressed: bool = False) -> list[dict[str, str]]:
    opener = gzip.open if compressed else open
    mode = "rt" if compressed else "r"
    with opener(path, mode, encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            out[key.strip()] = value.strip().strip('"')
    return out


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError(f"not a PNG: {path}")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def sign_label(value: str) -> str:
    return "UP" if float(value) > 0 else "DOWN"


def interaction_class(s0: float, sd: float) -> str:
    sign0 = 1 if s0 > 0 else -1
    signd = 1 if sd > 0 else -1
    if sign0 != signd:
        return "reversal"
    if abs(sd) > abs(s0):
        return "augmentation"
    if abs(sd) < abs(s0):
        return "attenuation"
    return "unchanged_magnitude"


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": str(observed),
                       "expected": str(expected), "status": "PASS" if passed else "FAIL",
                       "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    source = read_tsv(ROOT / "figures/source_data/fig1i.tsv")
    ledger = read_tsv(ROOT / "results/stage02/signatures/cross_species_gene_ledger.tsv.gz",
                      compressed=True)
    evidence = read_tsv(ROOT / "metadata/gene_evidence_ledger.tsv")
    quickgo = read_tsv(ROOT / "genesets/endocrine_go_exact_2026-09-10.tsv")
    f1_audit = read_tsv(ROOT / "audits/stage02_orthology/signature_f1_checks.tsv")
    stats_rows = read_tsv(ROOT / "results/figures/fig1i_statistics.tsv")
    stats = {row["metric"]: row for row in stats_rows}

    check("fig1i_source_rows", len(source), 4976)
    check("fig1i_unique_mouse_genes", len({row["mouse_gene_id"] for row in source}), 4976)
    check("fig1i_unique_human_symbols", len({row["human_gene_symbol"] for row in source}), 4976)
    check("fig1i_display_order", [int(row["display_order"]) for row in source], list(range(1, 4977)))
    check("fig1i_f1_checks", (len(f1_audit), {row["status"] for row in f1_audit}),
          (45, {"PASS"}))
    core_rows = {row["mouse_gene_id_versioned"]: row for row in ledger
                 if row["core_member"] == "TRUE"}
    check("fig1i_members_match_f1", set(row["mouse_gene_id"] for row in source),
          set(core_rows))
    check("fig1i_all_core_thresholds", all(float(row["SD_FDR"]) < 0.05 and
          float(row["H_FDR"]) < 0.05 for row in source), True)
    check("fig1i_sd_direction", all(row["SD_direction"] == sign_label(row["SD_logFC"])
          for row in source), True)
    check("fig1i_h_direction", all(row["H_direction"] == sign_label(row["H_logFC"])
          for row in source), True)
    check("fig1i_source_matches_ledger", all(
          row["human_gene_symbol"] == core_rows[row["mouse_gene_id"]]["human_gene_symbol"] and
          row["core_direction_class"] == core_rows[row["mouse_gene_id"]]["core_direction_class"] and
          row["interaction_member"] == core_rows[row["mouse_gene_id"]]["interaction_member"] and
          row["sep_member"] == core_rows[row["mouse_gene_id"]]["sep_member"] and
          row["high_confidence_sep_interaction"] ==
          core_rows[row["mouse_gene_id"]]["high_confidence_sep_interaction"]
          for row in source), True)
    check("fig1i_interaction_class_recalculation", all(
          row["interaction_class"] == (
              interaction_class(float(core_rows[row["mouse_gene_id"]]["S0_logFC"]),
                                float(core_rows[row["mouse_gene_id"]]["SD_logFC"]))
              if row["interaction_member"] == "TRUE" else "NONE")
          for row in source), True)

    direction_counts = Counter(row["core_direction_class"] for row in source)
    check("fig1i_direction_counts", direction_counts,
          Counter({"CONCORDANT_UP": 1399, "CONCORDANT_DOWN": 1317,
                   "DISCORDANT_MOUSE_DOWN_HUMAN_UP": 1226,
                   "DISCORDANT_MOUSE_UP_HUMAN_DOWN": 1034}))
    check("fig1i_direction_blocks_contiguous", sum(
          source[index]["core_direction_class"] != source[index - 1]["core_direction_class"]
          for index in range(1, len(source))), 3)
    interaction_counts = Counter(row["interaction_class"] for row in source)
    check("fig1i_interaction_counts", interaction_counts,
          Counter({"reversal": 3521, "NONE": 891, "augmentation": 423,
                   "attenuation": 141}))
    check("fig1i_sep_count", sum(row["sep_member"] == "TRUE" for row in source), 2716)
    check("fig1i_high_confidence_count",
          sum(row["high_confidence_sep_interaction"] == "TRUE" for row in source), 1530)

    ctra = {row["normalized_symbol"]: row["direction"] for row in evidence
            if row["evidence_source"].startswith("CTRA_")}
    check("fig1i_ctra_source_size", (len(ctra), set(ctra.values())), (53, {"UP", "DOWN"}))
    gse_sets: dict[str, set[str]] = defaultdict(set)
    for row in evidence:
        if (row["evidence_source"].startswith("GSE70603_") and
                "mapping=PASS:" in row["notes"]):
            gse_sets[row["normalized_symbol"]].add(row["direction"])
    check("fig1i_gse70603_source_size", len(gse_sets), 3871)
    gse = {symbol: (next(iter(directions)) if len(directions) == 1
                    else "MIXED_TIMEPOINT_DIRECTION")
           for symbol, directions in gse_sets.items()}
    quickgo_symbols = {row["source_symbol"] for row in quickgo
                       if row["species"] == "Homo sapiens" and
                       row["hgnc_exact_status"].startswith("PASS")}
    check("fig1i_quickgo_human_source_size", len(quickgo_symbols), 46)
    check("fig1i_ctra_flags", all(row["CTRA_reference_direction"] ==
          ctra.get(row["human_gene_symbol"], "NONE") for row in source), True)
    check("fig1i_gse70603_flags", all(row["GSE70603_time_locked_direction"] ==
          gse.get(row["human_gene_symbol"], "NONE") for row in source), True)
    check("fig1i_quickgo_flags", all(row["QuickGO_exact_human_annotation"] ==
          ("PRESENT" if row["human_gene_symbol"] in quickgo_symbols else "ABSENT")
          for row in source), True)
    check("fig1i_reference_role", {row["PS_reference_role"] for row in source},
          {"annotation_only_not_F1_membership"})

    overlap_ctra = sum(row["CTRA_reference_direction"] != "NONE" for row in source)
    overlap_gse = sum(row["GSE70603_time_locked_direction"] != "NONE" for row in source)
    overlap_quickgo = sum(row["QuickGO_exact_human_annotation"] == "PRESENT" for row in source)
    overlap_any = sum(row["CTRA_reference_direction"] != "NONE" or
                      row["GSE70603_time_locked_direction"] != "NONE" or
                      row["QuickGO_exact_human_annotation"] == "PRESENT" for row in source)
    check("fig1i_reference_overlap_counts",
          (overlap_ctra, overlap_gse, overlap_quickgo, overlap_any), (21, 1258, 11, 1273))
    gse_counts = Counter(row["GSE70603_time_locked_direction"] for row in source)
    check("fig1i_gse70603_direction_counts",
          (gse_counts["UP"], gse_counts["DOWN"], gse_counts["MIXED_TIMEPOINT_DIRECTION"]),
          (579, 673, 6))
    check("fig1i_mouse_unit", {row["mouse_statistical_unit"] for row in source},
          {"independent mouse; 12 total and 3 per factorial group"})
    check("fig1i_human_unit", {row["human_statistical_unit"] for row in source},
          {"paired patient; 58 PP-PN pairs"})

    check("fig1i_statistics_rows", len(stats_rows), 21)
    count_keys = ("core_total", "concordant_up", "concordant_down",
                  "discordant_mouse_down_human_up", "discordant_mouse_up_human_down",
                  "interaction_total", "interaction_augmentation", "interaction_attenuation",
                  "interaction_reversal", "core_without_significant_interaction", "sep_total",
                  "high_confidence_sep_interaction", "core_overlap_ctra",
                  "core_overlap_gse70603", "core_gse70603_up", "core_gse70603_down",
                  "core_gse70603_mixed_timepoint", "core_overlap_quickgo_human",
                  "core_any_ps_reference_overlap")
    expected_counts = (4976, 1399, 1317, 1226, 1034, 4085, 423, 141, 3521, 891,
                       2716, 1530, 21, 1258, 579, 673, 6, 11, 1273)
    check("fig1i_statistics_counts",
          tuple(int(float(stats[key]["value"])) for key in count_keys), expected_counts)
    check("fig1i_validation_locked", stats["validation_expression_accessed"]["value"], "0")

    cfg = read_config(ROOT / "config/figures/fig1i.yaml")
    analysis_script = (ROOT / "scripts/figures/fig1i_analysis.R").read_text(encoding="utf-8")
    plot_script = (ROOT / "scripts/figures/fig1i_plot.R").read_text(encoding="utf-8")
    caption = ROOT / "figures/captions/fig1i.md"
    svg = ROOT / "figures/panels/fig1i.svg"
    png = ROOT / "figures/previews/fig1i.png"
    check("fig1i_all_rows_policy", cfg["row_policy"],
          "all Core genes; no top-gene selection; deterministic frozen-class ordering")
    check("fig1i_reference_policy", cfg["reference_policy"],
          "PS-Reference overlap is annotation only and does not define Core, SEP or direction")
    check("fig1i_validation_config", cfg["validation_expression_accessed"], "none")
    check("fig1i_manual_visual_inspection", cfg["manual_visual_inspection"], "PASS_2026-09-11")
    check("fig1i_minimum_text_pt", float(cfg["minimum_text_pt"]) >= 8, True)
    check("fig1i_rasterized_cells", "useRaster = TRUE" in plot_script, True)
    check("fig1i_validation_absent_analysis", "GSE30999" not in analysis_script and
          "GSE121212" not in analysis_script, True)
    check("fig1i_validation_absent_plot", "GSE30999" not in plot_script and
          "GSE121212" not in plot_script, True)
    for color_key in ("positive_color", "negative_color", "membership_color",
                      "absent_color", "grid_color"):
        check(f"fig1i_plot_uses_{color_key}", cfg[color_key] in plot_script, True)
    check("fig1i_svg_exists", svg.exists() and svg.stat().st_size > 100000, True)
    check("fig1i_png_exists", png.exists() and png.stat().st_size > 100000, True)
    check("fig1i_caption_exists", caption.exists() and caption.stat().st_size > 1800, True)
    caption_text = caption.read_text(encoding="utf-8")
    check("fig1i_caption_all_rows", "no top-gene selection" in caption_text, True)
    check("fig1i_caption_reference_boundary", "did not generate Core membership" in caption_text, True)
    check("fig1i_caption_validation_lock",
          "GSE30999 and GSE121212 expression values were not accessed" in caption_text, True)
    png_w, png_h = png_dimensions(png)
    check("fig1i_png_dimensions", (png_w, png_h),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    svg_w, svg_h = svg_dimensions(svg)
    check("fig1i_svg_width", abs(svg_w - float(cfg["width_inches"])) < 0.02, True)
    check("fig1i_svg_height", abs(svg_h - float(cfg["height_inches"])) < 0.02, True)

    manifest = {row["panel_id"]: row for row in read_tsv(ROOT / "panel_manifest.tsv")}["1I"]
    check("fig1i_manifest_status", manifest["status"], "PASS")
    check("fig1i_manifest_qa", manifest["qa_status"], "PASS_RENDER_DATA_PRINT")
    check("fig1i_manifest_ready", manifest["figure_ready"], "YES")
    check("fig1i_manifest_source", manifest["source_data"], "figures/source_data/fig1i.tsv")
    check("fig1i_manifest_quickgo_input",
          "genesets/endocrine_go_exact_2026-09-10.tsv" in manifest["input_table"], True)

    audit_path = ROOT / "audits/fig1i_qa_checks.tsv"
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    with audit_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t",
                                lineterminator="\n")
        writer.writeheader()
        writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 1I data, isolation, render and print QA checks")


if __name__ == "__main__":
    main()
