options(stringsAsFactors = FALSE)

registry <- read.delim(file.path("metadata", "gse212126_library_animal_registry.tsv"),
                       check.names = FALSE, stringsAsFactors = FALSE)
confirmation <- read.delim(file.path("audits", "gse212126_user_confirmation.tsv"),
                           check.names = FALSE, stringsAsFactors = FALSE)
datasets <- read.delim(file.path("metadata", "dataset_manifest.tsv"),
                       check.names = FALSE, stringsAsFactors = FALSE)
count_audit <- read.delim(file.path("audits", "stage02_counts", "gse212126_count_integrity_checks.tsv"),
                          check.names = FALSE, stringsAsFactors = FALSE)
model_audit <- read.delim(file.path("audits", "stage02_counts", "gse212126_edger_integrity_checks.tsv"),
                          check.names = FALSE, stringsAsFactors = FALSE)

stopifnot(nrow(registry) == 12L)
stopifnot(length(unique(registry$canonical_animal_id)) == 12L)
stopifnot(all(registry$libraries_per_animal == 1L))
stopifnot(all(registry$animals_per_library == 1L))
stopifnot(all(registry$pooling_status == "NO_POOLING_USER_CONFIRMED"))
stopifnot(confirmation$animal_gate_status == "PASS_USER_CONFIRMED")
stopifnot(confirmation$remaining_stage02_blocker == "RAW_INTEGER_COUNTS_NOT_YET_RECONSTRUCTED")
stopifnot(datasets$stage00_status[datasets$dataset_id == "GSE212126"] ==
            "PASS_WITH_USER_CONFIRMED_ANIMAL_PROVENANCE")
stopifnot(nrow(count_audit) == 15L, all(count_audit$status == "PASS"),
          nrow(model_audit) == 27L, all(model_audit$status == "PASS"))

groups <- data.frame(
  record_type = "GROUP",
  record_id = c("G00", "G10", "G01", "G11"),
  label = c("Control", "CRS", "IMQ", "CRS+IMQ"),
  crs = c(0, 1, 0, 1),
  imq = c(0, 0, 1, 1),
  n = c(3, 3, 3, 3),
  statistical_unit = "independent mouse",
  library_relation = "one RNA-seq library per mouse",
  pooling_status = "NO_POOLING_USER_CONFIRMED",
  gate_status = "PASS_USER_CONFIRMED",
  formula = "",
  interpretation = "four-group factorial design cell",
  provenance = "USER_PROVIDED_PROJECT_CONFIRMATION_IN_CODEX_TASK",
  limitation = "Original animal identifiers and supporting source document are not archived locally",
  stringsAsFactors = FALSE
)

observed <- table(factor(registry$condition, levels = groups$label))
stopifnot(all(as.integer(observed) == groups$n))

estimands <- data.frame(
  record_type = "ESTIMAND",
  record_id = c("S0", "SD", "I"),
  label = c("Stress effect without IMQ", "Stress effect with IMQ", "CRS-by-IMQ interaction"),
  crs = "",
  imq = "",
  n = "",
  statistical_unit = "gene across independent mice",
  library_relation = "negative-binomial model after count QC",
  pooling_status = "NO_POOLING_USER_CONFIRMED",
  gate_status = "PASS_MOUSE_FACTORIAL_MODEL",
  formula = c("mu_CRS - mu_Control",
              "mu_CRS+IMQ - mu_IMQ",
              "(mu_CRS+IMQ - mu_IMQ) - (mu_CRS - mu_Control)"),
  interpretation = c("S0", "SD", "I = SD - S0"),
  provenance = "PRE_SPECIFIED_IN_SIGNATURE_SPECIFICATION",
  limitation = "Effects are estimated in frozen outputs but intentionally not displayed in this design panel",
  stringsAsFactors = FALSE
)

gates <- data.frame(
  record_type = "GATE",
  record_id = c("ANIMAL", "COUNTS"),
  label = c("Independent-animal and no-pooling gate", "Integer raw-count and QC gate"),
  crs = "",
  imq = "",
  n = c(12, 12),
  statistical_unit = c("mouse/library", "RNA-seq library"),
  library_relation = c("12 mice : 12 libraries", "12 audited integer-count libraries"),
  pooling_status = c("NO_POOLING_USER_CONFIRMED", "NOT_APPLICABLE"),
  gate_status = c("PASS_USER_CONFIRMED", "PASS_COUNT_AND_MODEL_AUDITS"),
  formula = "",
  interpretation = c("Design-only panel is executable", "Mouse factorial expression inference completed"),
  provenance = c("USER_PROVIDED_PROJECT_CONFIRMATION_IN_CODEX_TASK", "OFFICIAL_SRA_RECONSTRUCTION_AND_FROZEN_EDGER_MODEL"),
  limitation = c("Original animal IDs/source document are not archived locally",
                 "GENCODE M25 reconstruction is reproducible but not claimed identical to the original annotation"),
  stringsAsFactors = FALSE
)

out <- rbind(groups, estimands, gates)
dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(out, file.path("figures", "source_data", "fig1c.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE, na = "")

stats <- data.frame(
  record_id = out$record_id,
  record_type = out$record_type,
  label = out$label,
  n = out$n,
  gate_status = out$gate_status,
  formula = out$formula,
  statistical_test = "none_design_and_estimand_specification",
  result_status = ifelse(out$record_type == "GROUP", "DESIGN_CONFIRMED",
                         ifelse(out$record_id == "ANIMAL", "PASS_USER_CONFIRMED",
                                ifelse(out$record_id == "COUNTS", "PASS_COUNT_AND_MODEL_AUDITS",
                                       "MODEL_OUTPUT_AVAILABLE_NOT_DISPLAYED"))),
  limitation = out$limitation,
  stringsAsFactors = FALSE
)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(stats, file.path("results", "figures", "fig1c_statistics.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE, na = "")

cat("PASS: fig1c design has four groups x three independent unpooled mice; count/model gate synchronized\n")
