options(stringsAsFactors = FALSE)

cfg_lines <- readLines(file.path("config", "figures", "fig1d.yaml"), warn = FALSE)
cfg <- function(key, default = NA_character_) {
  hit <- grep(paste0("^", key, ":"), cfg_lines, value = TRUE)
  if (!length(hit)) return(default)
  value <- trimws(sub("^[^:]+:", "", hit[1]))
  gsub('^"|"$', "", value)
}

dat <- read.delim(file.path("figures", "source_data", "fig1d.tsv"),
                  check.names = FALSE, stringsAsFactors = FALSE)
stats <- read.delim(file.path("results", "figures", "fig1d_statistics.tsv"),
                    check.names = FALSE, stringsAsFactors = FALSE)
patterns <- stats[stats$statistic_type == "EXCLUSIVE_INTERSECTION", ]
patterns <- patterns[order(-patterns$count, patterns$group), ]
set_sizes <- setNames(stats$count[stats$statistic_type == "SET_SIZE"],
                      stats$display_label[stats$statistic_type == "SET_SIZE"])
stopifnot(nrow(dat) == 3940L, nrow(patterns) == 5L)

width <- as.numeric(cfg("width_inches"))
height <- as.numeric(cfg("height_inches"))
dpi <- as.numeric(cfg("png_dpi"))
ink <- cfg("ink")
blue <- cfg("blue")
mid_grey <- cfg("mid_grey")
light_grey <- cfg("light_grey")

draw_panel <- function() {
  layout(matrix(c(1, 2), nrow = 2), heights = c(2.3, 1.15))
  par(family = "sans", fg = ink, col.axis = ink, col.lab = ink, bty = "n")
  x <- seq_len(nrow(patterns))
  log_count <- log10(patterns$count)

  par(mar = c(0.4, 5.8, 3.9, 1.4), mgp = c(2.1, 0.45, 0), tcl = -0.2)
  plot(NA, xlim = c(0.45, nrow(patterns) + 0.55), ylim = c(0, 3.82), axes = FALSE,
       xlab = "", ylab = "", xaxs = "i", yaxs = "i")
  abline(h = 0:3, col = light_grey, lwd = 0.7)
  rect(x - 0.31, 0, x + 0.31, log_count, col = blue, border = ink, lwd = 0.6)
  axis(2, at = 0:3, labels = c("1", "10", "100", "1,000"), las = 1,
       cex.axis = 0.72)
  mtext("Exclusive intersection size (log10 scale)", side = 2, line = 4.25,
        cex = 0.72, col = ink)
  text(x, log_count + 0.10, labels = format(patterns$count, big.mark = ","),
       cex = 0.72, font = 2, col = ink)
  title(main = "D  Candidate evidence overlap", adj = 0, cex.main = 1.02,
        font.main = 2, line = 2.05)
  mtext("Exact-approved human symbols; bar height is logarithmic and exact counts are labelled",
        side = 3, adj = 0, line = 0.48, cex = 0.74, col = mid_grey)

  par(mar = c(3.7, 13.2, 0.1, 1.4), mgp = c(2, 0.45, 0), tcl = -0.2)
  plot(NA, xlim = c(0.45, nrow(patterns) + 0.55), ylim = c(0.45, 3.55), axes = FALSE,
       xlab = "", ylab = "", xaxs = "i", yaxs = "i")
  source_names <- c("CTRA fixed", "GSE70603 time-locked", "QuickGO exact human")
  y <- 3:1
  axis(2, at = y,
       labels = sprintf("%s  (n=%s)", source_names,
                        format(set_sizes[source_names], big.mark = ",", trim = TRUE, scientific = FALSE)),
       las = 1, tick = FALSE, cex.axis = 0.73, line = -0.6)
  abline(h = y, col = light_grey, lwd = 0.65)
  for (i in x) {
    bits <- as.integer(strsplit(patterns$group[i], "", fixed = TRUE)[[1]])
    included_y <- y[bits == 1]
    if (length(included_y) > 1) segments(i, min(included_y), i, max(included_y),
                                         col = ink, lwd = 1.25)
    points(rep(i, 3), y, pch = 21, bg = ifelse(bits == 1, blue, "white"),
           col = ifelse(bits == 1, ink, mid_grey), cex = 1.05, lwd = 0.9)
  }
  axis(1, at = x, labels = FALSE, tick = FALSE)
  mtext("Exclusive membership patterns; overlap does not define a union score or Core.",
        side = 1, adj = 0, line = 2.7, cex = 0.67, col = mid_grey)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig1d.svg"), width = width, height = height,
    pointsize = 12, bg = "white", family = "sans")
draw_panel()
dev.off()
png(file.path("figures", "previews", "fig1d.png"), width = width, height = height,
    units = "in", res = dpi, pointsize = 12, bg = "white")
draw_panel()
dev.off()
cat("PASS: rendered fig1d SVG and 300-dpi PNG\n")
