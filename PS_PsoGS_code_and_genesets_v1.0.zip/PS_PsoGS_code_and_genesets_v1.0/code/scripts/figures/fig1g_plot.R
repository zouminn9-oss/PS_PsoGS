options(stringsAsFactors = FALSE)

dat <- read.delim(file.path("figures", "source_data", "fig1g.tsv"), check.names = FALSE)
stats_rows <- read.delim(file.path("results", "figures", "fig1g_statistics.tsv"),
                         check.names = FALSE)
stats <- setNames(stats_rows$value, stats_rows$metric)
stopifnot(nrow(dat) == 4085L, all(dat$interaction_class %in%
          c("augmentation", "attenuation", "reversal", "unchanged_magnitude")))

colors <- c(augmentation = "#D55E00", attenuation = "#0072B2",
            reversal = "#7A5195", unchanged_magnitude = "#7F878E")
ink <- "#20262E"
mid <- "#6F7881"
grid <- "#E7EBEE"
class_order <- c("reversal", "attenuation", "augmentation", "unchanged_magnitude")
lim <- max(abs(c(dat$S0_logFC, dat$SD_logFC)))
lim <- ceiling(lim * 10) / 10 * 1.04

draw_panel <- function() {
  layout(matrix(c(1, 2), nrow = 1), widths = c(3.5, 1.25))
  par(oma = c(0, 0, 3.0, 0), mar = c(4.7, 5.0, 0.6, 0.5), family = "sans", las = 1,
      cex.axis = 0.72, cex.lab = 0.80, cex.main = 0.88,
      col.axis = ink, col.lab = ink, col.main = ink, xaxs = "i", yaxs = "i", pty = "s")
  plot(NA, xlim = c(-lim, lim), ylim = c(-lim, lim), asp = 1,
       xlab = expression(S[0]~"stress effect without IMQ (log"[2]*" FC)"),
       ylab = expression(S[D]~"stress effect with IMQ (log"[2]*" FC)"),
       bty = "n")
  abline(h = pretty(c(-lim, lim)), v = pretty(c(-lim, lim)), col = grid, lwd = 0.7)
  abline(h = 0, v = 0, col = mid, lwd = 0.9)
  abline(a = 0, b = 1, col = ink, lwd = 1.0, lty = 2)
  for (group in class_order) {
    ix <- dat$interaction_class == group
    points(dat$S0_logFC[ix], dat$SD_logFC[ix], pch = 16, cex = 0.48,
           col = adjustcolor(colors[group], alpha.f = if (group == "reversal") 0.46 else 0.62))
  }
  box(col = ink, lwd = 0.8)

  par(mar = c(1.0, 0.7, 0.6, 0.5), pty = "m", xaxs = "i", yaxs = "i")
  plot.new()
  plot.window(xlim = c(0, 1), ylim = c(0, 1))
  counts <- as.integer(stats[c("augmentation", "attenuation", "reversal", "unchanged_magnitude")])
  groups <- c("augmentation", "attenuation", "reversal", "unchanged_magnitude")
  labels <- c("Augmentation", "Attenuation", "Reversal", "Equal magnitude")
  text(0.05, 0.95, "Frozen class", adj = c(0, 1), cex = 0.74, font = 2, col = ink)
  ys <- c(0.86, 0.78, 0.70, 0.62)
  points(rep(0.08, 4), ys, pch = 16, cex = 0.92, col = colors[groups])
  text(rep(0.16, 4), ys, labels, adj = c(0, 0.5), cex = 0.67, col = ink)
  text(rep(0.96, 4), ys, format(counts, big.mark = ","), adj = c(1, 0.5),
       cex = 0.67, col = ink)
  segments(0.05, 0.54, 0.96, 0.54, col = grid, lwd = 1)
  text(0.05, 0.47, expression(I == S[D] - S[0]), adj = c(0, 0.5), cex = 0.70, col = ink)
  text(0.05, 0.38, "All points:", adj = c(0, 0.5), cex = 0.67, font = 2, col = ink)
  text(0.05, 0.31, "Core and I FDR < 0.05", adj = c(0, 0.5), cex = 0.67, col = ink)
  text(0.05, 0.20, "Classes are descriptive,", adj = c(0, 0.5), cex = 0.67, col = mid)
  text(0.05, 0.13, "not causal labels", adj = c(0, 0.5), cex = 0.67, col = mid)
  mtext("Formal interaction classes within PS-PsoGS-Core", side = 3, outer = TRUE,
        line = 1.25, cex = 0.98, font = 2, col = ink)
  mtext("No effect-size threshold; every Interaction member is shown", side = 3,
        outer = TRUE, line = 0.15, cex = 0.68, col = mid)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig1g.svg"), width = 7.0079, height = 4.7244,
    pointsize = 12, family = "sans", bg = "white")
draw_panel()
dev.off()
png(file.path("figures", "previews", "fig1g.png"), width = 7.0079, height = 4.7244,
    units = "in", res = 300, pointsize = 12, type = "cairo", bg = "white")
draw_panel()
dev.off()
cat("PASS: rendered Figure 1G SVG and 300-dpi PNG\n")
