options(stringsAsFactors = FALSE)

dat <- read.delim(file.path("figures", "source_data", "fig1h.tsv"), check.names = FALSE)
stats_rows <- read.delim(file.path("results", "figures", "fig1h_statistics.tsv"),
                         check.names = FALSE)
stats <- setNames(stats_rows$value, stats_rows$metric)
stopifnot(nrow(dat) == 4976L,
          all(dat$core_direction_class %in% c("CONCORDANT_UP", "CONCORDANT_DOWN",
          "DISCORDANT_MOUSE_DOWN_HUMAN_UP", "DISCORDANT_MOUSE_UP_HUMAN_DOWN")))

colors <- c(CONCORDANT_UP = "#D55E00", CONCORDANT_DOWN = "#0072B2",
            DISCORDANT_MOUSE_DOWN_HUMAN_UP = "#7C848B",
            DISCORDANT_MOUSE_UP_HUMAN_DOWN = "#B5BBC0")
ink <- "#20262E"
mid <- "#6F7881"
grid <- "#E7EBEE"
xlim <- max(abs(dat$SD_logFC)) * 1.04
ylim <- max(abs(dat$H_logFC)) * 1.04

draw_panel <- function() {
  layout(matrix(c(1, 2), nrow = 1), widths = c(3.55, 1.20))
  par(oma = c(0, 0, 3.0, 0), mar = c(4.7, 5.0, 0.6, 0.5), family = "sans", las = 1,
      cex.axis = 0.72, cex.lab = 0.80, col.axis = ink, col.lab = ink,
      xaxs = "i", yaxs = "i")
  plot(NA, xlim = c(-xlim, xlim), ylim = c(-ylim, ylim),
       xlab = expression(S[D]~"mouse stress effect with IMQ (log"[2]*" FC)"),
       ylab = expression(H~"paired human PP - PN effect (log"[2]*" FC)"), bty = "n")
  abline(h = pretty(c(-ylim, ylim)), v = pretty(c(-xlim, xlim)), col = grid, lwd = 0.7)
  abline(h = 0, v = 0, col = ink, lwd = 0.9)
  for (group in c("DISCORDANT_MOUSE_UP_HUMAN_DOWN", "DISCORDANT_MOUSE_DOWN_HUMAN_UP",
                  "CONCORDANT_DOWN", "CONCORDANT_UP")) {
    ix <- dat$core_direction_class == group
    points(dat$SD_logFC[ix], dat$H_logFC[ix], pch = 16, cex = 0.45,
           col = adjustcolor(colors[group], alpha.f = if (grepl("DISCORDANT", group)) 0.40 else 0.52))
  }
  box(col = ink, lwd = 0.8)

  par(mar = c(1.0, 0.7, 0.6, 0.5), xaxs = "i", yaxs = "i")
  plot.new()
  plot.window(xlim = c(0, 1), ylim = c(0, 1))
  groups <- c("CONCORDANT_UP", "CONCORDANT_DOWN",
              "DISCORDANT_MOUSE_DOWN_HUMAN_UP", "DISCORDANT_MOUSE_UP_HUMAN_DOWN")
  labels <- c("Concordant UP", "Concordant DOWN", "Discordant M- / H+", "Discordant M+ / H-")
  counts <- as.integer(stats[c("concordant_up", "concordant_down",
                               "discordant_mouse_down_human_up", "discordant_mouse_up_human_down")])
  text(0.04, 0.95, "Frozen Core class", adj = c(0, 1), cex = 0.74, font = 2, col = ink)
  ys <- c(0.85, 0.77, 0.69, 0.61)
  points(rep(0.08, 4), ys, pch = 16, cex = 0.88, col = colors[groups])
  text(rep(0.16, 4), ys, labels, adj = c(0, 0.5), cex = 0.59, col = ink)
  text(rep(0.96, 4), ys, format(counts, big.mark = ","), adj = c(1, 0.5), cex = 0.59, col = ink)
  segments(0.04, 0.53, 0.96, 0.53, col = grid, lwd = 1)
  text(0.04, 0.46, paste0("Core  ", format(as.integer(stats["core_total"]), big.mark = ",")),
       adj = c(0, 0.5), cex = 0.68, font = 2, col = ink)
  text(0.04, 0.38, paste0("Pearson r  ", sprintf("%.3f", as.numeric(stats["pearson_r_selected_core"]))),
       adj = c(0, 0.5), cex = 0.66, col = ink)
  text(0.04, 0.30, paste0("Spearman ", intToUtf8(961), "  ",
       sprintf("%.3f", as.numeric(stats["spearman_rho_selected_core"]))),
       adj = c(0, 0.5), cex = 0.66, col = ink)
  text(0.04, 0.18, "Correlations are descriptive", adj = c(0, 0.5), cex = 0.62, col = mid)
  text(0.04, 0.11, "after Core selection", adj = c(0, 0.5), cex = 0.62, col = mid)
  text(0.04, 0.04, "not independent validation", adj = c(0, 0.5), cex = 0.62, col = mid)
  mtext("Mouse-human discovery direction among frozen Core genes", side = 3,
        outer = TRUE, line = 1.25, cex = 0.98, font = 2, col = ink)
  mtext("All Core genes shown; direction disagreement is retained, not filtered", side = 3,
        outer = TRUE, line = 0.15, cex = 0.68, col = mid)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig1h.svg"), width = 7.0079, height = 4.7244,
    pointsize = 12, family = "sans", bg = "white")
draw_panel()
dev.off()
png(file.path("figures", "previews", "fig1h.png"), width = 7.0079, height = 4.7244,
    units = "in", res = 300, pointsize = 12, type = "cairo", bg = "white")
draw_panel()
dev.off()
cat("PASS: rendered Figure 1H SVG and 300-dpi PNG\n")
