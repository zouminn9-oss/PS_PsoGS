options(stringsAsFactors = FALSE)

dat <- read.delim(file.path("figures", "source_data", "fig1i.tsv"), check.names = FALSE)
stats_rows <- read.delim(file.path("results", "figures", "fig1i_statistics.tsv"),
                         check.names = FALSE)
stats <- setNames(stats_rows$value, stats_rows$metric)
stopifnot(nrow(dat) == 4976L, identical(dat$display_order, seq_len(nrow(dat))))

present <- function(x) ifelse(x, 2, 0)
signed <- function(x) ifelse(x == "UP", 1, ifelse(x == "DOWN", -1,
                          ifelse(x == "MIXED_TIMEPOINT_DIRECTION", 3, 0)))
matrix_values <- cbind(
  signed(dat$SD_direction),
  signed(dat$H_direction),
  present(dat$interaction_member == "TRUE"),
  present(dat$sep_member == "TRUE"),
  present(dat$high_confidence_sep_interaction == "TRUE"),
  present(dat$interaction_class == "augmentation"),
  present(dat$interaction_class == "attenuation"),
  present(dat$interaction_class == "reversal"),
  signed(dat$CTRA_reference_direction),
  signed(dat$GSE70603_time_locked_direction),
  present(dat$QuickGO_exact_human_annotation == "PRESENT")
)
column_labels <- c("SD sign", "H sign", "Interaction", "SEP", "High-conf.",
                   "I: aug.", "I: att.", "I: rev.", "CTRA", "GSE70603", "QuickGO")
stopifnot(ncol(matrix_values) == length(column_labels), !anyNA(matrix_values))

colors <- c("#0072B2", "#F4F6F7", "#D55E00", "#343B42", "#747C83")
breaks <- c(-1.5, -0.5, 0.5, 1.5, 2.5, 3.5)
ink <- "#20262E"
mid <- "#6F7881"
grid <- "#DDE2E5"
n <- nrow(dat)
class_levels <- c("CONCORDANT_UP", "CONCORDANT_DOWN",
                  "DISCORDANT_MOUSE_DOWN_HUMAN_UP", "DISCORDANT_MOUSE_UP_HUMAN_DOWN")
class_labels <- c("Concordant UP", "Concordant DOWN", "Mouse- / human+", "Mouse+ / human-")
class_counts <- as.integer(table(factor(dat$core_direction_class, levels = class_levels)))
class_end <- cumsum(class_counts)
class_start <- c(1, head(class_end, -1) + 1)
class_y <- n - (class_start + class_end) / 2 + 1

draw_panel <- function() {
  layout(matrix(c(1, 2), nrow = 1), widths = c(3.65, 1.15))
  par(oma = c(0, 0, 3.0, 0), mar = c(7.0, 7.8, 1.8, 0.4), family = "sans",
      fg = ink, xpd = FALSE)
  image(x = seq_len(ncol(matrix_values)), y = seq_len(n),
        z = t(matrix_values[n:1, , drop = FALSE]), breaks = breaks, col = colors,
        xlim = c(0.5, ncol(matrix_values) + 0.5), ylim = c(0.5, n + 0.5),
        axes = FALSE, xlab = "", ylab = "", useRaster = TRUE)
  abline(v = seq(0.5, ncol(matrix_values) + 0.5, by = 1), col = grid, lwd = 0.55)
  boundary_y <- n - head(class_end, -1) + 0.5
  abline(h = boundary_y, col = ink, lwd = 0.8)
  box(col = ink, lwd = 0.8)
  text(seq_along(column_labels), rep(-105, length(column_labels)), column_labels,
       srt = 43, adj = 1, cex = 0.63, col = ink, xpd = NA)
  text(rep(0.20, length(class_y)), class_y,
       paste0(class_labels, "  n=", format(class_counts, big.mark = ",")),
       adj = c(1, 0.5), cex = 0.58, col = ink, xpd = NA)
  text(c(1.5, 4, 7, 10), rep(n + 115, 4),
       c("DISCOVERY", "MEMBERSHIP", "INTERACTION CLASS", "PS-REFERENCE"),
       cex = 0.59, font = 2, col = mid, xpd = NA)
  segments(c(0.55, 2.55, 5.55, 8.55), rep(n + 55, 4),
           c(2.45, 5.45, 8.45, 11.45), rep(n + 55, 4), col = grid, lwd = 1.1,
           xpd = NA)
  mtext("Core genes (deterministic display order; every row retained)", side = 2,
        line = 6.2, cex = 0.66, col = mid)

  par(mar = c(1.0, 0.8, 0.7, 0.4), xpd = NA)
  plot.new()
  plot.window(xlim = c(0, 1), ylim = c(0, 1))
  text(0.04, 0.97, "Cell key", adj = c(0, 1), cex = 0.72, font = 2, col = ink)
  key_y <- c(0.90, 0.84, 0.78, 0.72, 0.66)
  rect(0.04, key_y - 0.018, 0.12, key_y + 0.018,
       col = colors[c(3, 1, 4, 5, 2)], border = grid, lwd = 0.5)
  text(0.17, key_y, c("UP / positive", "DOWN / negative", "member / class",
                      "mixed time direction", "absent"),
       adj = c(0, 0.5), cex = 0.58, col = ink)
  segments(0.04, 0.60, 0.96, 0.60, col = grid, lwd = 1)
  text(0.04, 0.55, "Frozen counts", adj = c(0, 0.5), cex = 0.70, font = 2, col = ink)
  count_labels <- c("Core", "Interaction", "SEP", "High-conf.",
                    "CTRA overlap", "GSE70603 overlap", "QuickGO overlap", "Any PS-reference")
  count_keys <- c("core_total", "interaction_total", "sep_total",
                  "high_confidence_sep_interaction", "core_overlap_ctra",
                  "core_overlap_gse70603", "core_overlap_quickgo_human",
                  "core_any_ps_reference_overlap")
  count_y <- seq(0.49, 0.14, length.out = length(count_labels))
  text(rep(0.04, length(count_y)), count_y, count_labels,
       adj = c(0, 0.5), cex = 0.58, col = ink)
  text(rep(0.96, length(count_y)), count_y,
       format(as.integer(stats[count_keys]), big.mark = ","),
       adj = c(1, 0.5), cex = 0.58, col = ink)
  text(0.04, 0.07, "PS-reference = annotation only", adj = c(0, 0.5),
       cex = 0.57, col = mid)
  text(0.04, 0.025, "not an F1 membership rule", adj = c(0, 0.5),
       cex = 0.57, col = mid)
  mtext("Core gene evidence ledger", side = 3, outer = TRUE,
        line = 1.25, cex = 0.98, font = 2, col = ink)
  mtext("4,976 frozen genes; signed discovery evidence, memberships and reference-only overlaps",
        side = 3, outer = TRUE, line = 0.15, cex = 0.68, col = mid)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig1i.svg"), width = 7.0079, height = 5.1181,
    pointsize = 12, family = "sans", bg = "white")
draw_panel()
dev.off()
png(file.path("figures", "previews", "fig1i.png"), width = 7.0079, height = 5.1181,
    units = "in", res = 300, pointsize = 12, type = "cairo", bg = "white")
draw_panel()
dev.off()
cat("PASS: rendered Figure 1I SVG and 300-dpi PNG\n")
