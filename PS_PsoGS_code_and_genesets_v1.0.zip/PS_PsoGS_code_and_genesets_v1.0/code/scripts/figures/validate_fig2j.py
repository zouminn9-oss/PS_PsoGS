#!/usr/bin/env python3
"""Claim-matrix source, render and print QA for Figure 2J."""
from __future__ import annotations
import csv
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "audits/fig2j_qa_checks.tsv"

def read(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))

def read_config(path):
    out = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            out[key.strip()] = value.strip().strip('"')
    return out

def main():
    checks = []
    def check(name, observed, expected):
        passed = observed == expected
        checks.append({"check_id": name, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL"})
        if not passed:
            raise AssertionError(f"{name}: {observed!r} != {expected!r}")

    source = read(ROOT / "figures/source_data/fig2j.tsv")
    claims = read(ROOT / "results/stage03/claim_matrix.tsv")
    stats = read(ROOT / "results/figures/fig2j_statistics.tsv")
    audit = read(ROOT / "audits/stage03_claim_matrix_checks.tsv")
    check("fig2j_source_identity", source, claims)
    check("fig2j_claims", len(source), 11)
    check("fig2j_synthesis_counts", Counter(row["synthesis_status"] for row in source),
          Counter({"PASS": 3, "PASS_WITH_LIMITATION": 4, "FAIL": 1, "BLOCKED": 2, "NOT_TESTED": 1}))
    check("fig2j_stats", {row["status"]: int(row["n_synthesis_claims"]) for row in stats},
          {"PASS": 3, "PASS_WITH_LIMITATION": 4, "FAIL": 1, "BLOCKED": 2,
           "NOT_TESTED": 1, "NOT_APPLICABLE": 0})
    check("fig2j_audit", (len(audit), {row["status"] for row in audit}), (12, {"PASS"}))

    cfg = read_config(ROOT / "config/figures/fig2j.yaml")
    check("fig2j_manual", cfg["manual_visual_inspection"], "PASS_2026-09-11_SECOND_RENDER_HEADER_CLEARANCE")
    check("fig2j_min_text", float(cfg["minimum_text_pt"]) >= 8, True)
    plot_text = (ROOT / "scripts/figures/fig2j_plot.R").read_text(encoding="utf-8")
    check("fig2j_ascii_plot", all(ord(char) < 128 for char in plot_text), True)
    for color in ("pass_color", "limit_color", "fail_color", "blocked_color", "not_tested_color", "not_applicable_color"):
        check(f"fig2j_color::{color}", cfg[color] in plot_text, True)

    svg = ROOT / "figures/panels/fig2j.svg"
    png = ROOT / "figures/previews/fig2j.png"
    caption = ROOT / "figures/captions/fig2j.md"
    check("fig2j_svg", svg.is_file() and svg.stat().st_size > 100000, True)
    check("fig2j_png", png.is_file() and png.stat().st_size > 80000, True)
    check("fig2j_caption", caption.is_file() and caption.stat().st_size > 1800, True)
    caption_text = caption.read_text(encoding="utf-8")
    for phrase in ("Psoriasis exclusivity fails", "remain blocked",
                   "psychological-stress exposure and causality are not tested", "not psoriasis exclusivity"):
        check(f"fig2j_caption::{phrase}", phrase in caption_text, True)
    with png.open("rb") as handle:
        header = handle.read(24)
    check("fig2j_png_dimensions", struct.unpack(">II", header[16:24]),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    root = ET.parse(svg).getroot()
    width = float(root.attrib["width"].replace("pt", "")) / 72
    height = float(root.attrib["height"].replace("pt", "")) / 72
    check("fig2j_svg_dimensions", abs(width - float(cfg["width_inches"])) < 0.02 and
          abs(height - float(cfg["height_inches"])) < 0.02, True)
    panel = {row["panel_id"]: row for row in read(ROOT / "panel_manifest.tsv")}["2J"]
    check("fig2j_manifest", (panel["status"], panel["qa_status"], panel["figure_ready"]),
          ("PASS", "PASS_RENDER_DATA_PRINT", "YES"))
    with OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 2J claim, render and print QA checks")

if __name__ == "__main__":
    main()

