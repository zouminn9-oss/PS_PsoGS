from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import pandas as pd

SRC=ROOT/"figures/source_data"; STATS=ROOT/"results/figures"; CFG=ROOT/"config/figures"
for p in (SRC,STATS,CFG): p.mkdir(parents=True,exist_ok=True)
BASE=ROOT/"results/stage07/gse228421"
scores=pd.read_csv(BASE/"patient_celltype_scores.tsv",sep="\t")
effects=pd.read_csv(BASE/"within_celltype_program_effects.tsv",sep="\t")

b=scores[(scores.cell_type=="Keratinocyte")&(scores.tissue=="lesional")&(scores.eligible_min_20_cells)][["patient_id","visit","n_cells","ucell_core_directed","ucell_sep_directed"]]
b.to_csv(SRC/"fig7b.tsv",sep="\t",index=False)
effects[(effects.cell_type=="Keratinocyte")&effects.program.isin(["ucell_core_directed","ucell_sep_directed"])].to_csv(STATS/"fig7b_statistics.tsv",sep="\t",index=False)

c=pd.read_csv(BASE/"composition_effects.tsv",sep="\t"); c=c[(c.contrast=="day 14_minus_day 0_lesional")&(c.cell_type!="Uncertain")]
c.to_csv(SRC/"fig7c.tsv",sep="\t",index=False); c.to_csv(STATS/"fig7c_statistics.tsv",sep="\t",index=False)

d=effects[(effects.contrast=="day 14_minus_day 0_lesional")&(effects.program=="ucell_sep_directed")&(effects.cell_type!="Uncertain")]
d.to_csv(SRC/"fig7d.tsv",sep="\t",index=False); d.to_csv(STATS/"fig7d_statistics.tsv",sep="\t",index=False)

e=pd.read_csv(BASE/"jag2_notch2_axis.tsv",sep="\t"); e.to_csv(SRC/"fig7e.tsv",sep="\t",index=False)
pd.read_csv(BASE/"jag2_notch2_axis_effects.tsv",sep="\t").to_csv(STATS/"fig7e_statistics.tsv",sep="\t",index=False)

f=effects[(effects.contrast=="day 14_minus_day 0_lesional")&(effects.program=="glutathione_score")&(effects.cell_type!="Uncertain")]
f.to_csv(SRC/"fig7f.tsv",sep="\t",index=False); f.to_csv(STATS/"fig7f_statistics.tsv",sep="\t",index=False)

g=pd.read_csv(BASE/"day14_residual_sep.tsv",sep="\t"); g=g[g.cell_type!="Uncertain"]
g.to_csv(SRC/"fig7g.tsv",sep="\t",index=False); g.to_csv(STATS/"fig7g_statistics.tsv",sep="\t",index=False)

configs={
 "fig7b":"panel_id: 7B\ndataset: GSE228421\nstatistical_unit: patient\ncell_type: Keratinocyte\nminimum_cells_per_patient_group: 20\n",
 "fig7c":"panel_id: 7C\ndataset: GSE228421\ncontrast: day14_lesional_minus_day0_lesional\nstatistical_unit: patient\nmethod: exact_two_sided_wilcoxon\n",
 "fig7d":"panel_id: 7D\nprogram: frozen_SEP\ncontrast: day14_lesional_minus_day0_lesional\nstatistical_unit: patient\nmethod: exact_two_sided_wilcoxon\n",
 "fig7e":"panel_id: 7E\naxis: endothelial_JAG2_x_fibroblast_NOTCH2_expression_compatibility\nclaim: expression_compatibility_not_ligand_receptor_activity\n",
 "fig7f":"panel_id: 7F\nprogram: Reactome_R-HSA-174403_glutathione\ncontrast: day14_lesional_minus_day0_lesional\nstatistical_unit: patient\n",
 "fig7g":"panel_id: 7G\ncontrast: day14_lesional_minus_baseline_nonlesional\nprogram: frozen_SEP\nstatistical_unit: patient\n"
}
for name,txt in configs.items(): (CFG/f"{name}.yaml").write_text(txt,encoding="utf-8")
print("PASS: Figure 7 single-cell source data/statistics/configs")
