#!/usr/bin/env python3
"""Data, isolation, render and print QA for Figure 1H."""

from __future__ import annotations

import csv
import gzip
import math
import re
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def read_tsv(path: Path, compressed: bool = False) -> list[dict[str, str]]:
    opener = gzip.open if compressed else open
    mode = "rt" if compressed else "r"
    with opener(path, mode, encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    config: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            config[key.strip()] = value.strip().strip('"')
    return config


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError(f"not a PNG: {path}")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def direction_class(sd: float, h: float) -> str:
    if sd > 0 and h > 0:
        return "CONCORDANT_UP"
    if sd < 0 and h < 0:
        return "CONCORDANT_DOWN"
    if sd < 0 and h > 0:
        return "DISCORDANT_MOUSE_DOWN_HUMAN_UP"
    return "DISCORDANT_MOUSE_UP_HUMAN_DOWN"


def pearson(x: list[float], y: list[float]) -> float:
    mx, my = sum(x) / len(x), sum(y) / len(y)
    numerator = sum((a - mx) * (b - my) for a, b in zip(x, y))
    denominator = math.sqrt(sum((a - mx) ** 2 for a in x) * sum((b - my) ** 2 for b in y))
    return numerator / denominator


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    source = read_tsv(ROOT / "figures/source_data/fig1h.tsv")
    ledger = read_tsv(ROOT / "results/stage02/signatures/cross_species_gene_ledger.tsv.gz", compressed=True)
    audit = read_tsv(ROOT / "audits/stage02_orthology/signature_f1_checks.tsv")
    stats_rows = read_tsv(ROOT / "results/figures/fig1h_statistics.tsv")
    stats = {row["metric"]: row for row in stats_rows}
    check("fig1h_source_rows", len(source), 4976)
    check("fig1h_unique_mouse_genes", len({row["mouse_gene_id"] for row in source}), 4976)
    check("fig1h_unique_human_symbols", len({row["human_gene_symbol"] for row in source}), 4976)
    check("fig1h_f1_checks", (len(audit), {row["status"] for row in audit}), (45, {"PASS"}))
    expected_members = {row["mouse_gene_id_versioned"] for row in ledger if row["core_member"] == "TRUE"}
    check("fig1h_members_match_f1", {row["mouse_gene_id"] for row in source} == expected_members, True)
    check("fig1h_all_core_thresholds", all(float(row["SD_FDR"]) < 0.05 and
          float(row["H_FDR"]) < 0.05 for row in source), True)
    check("fig1h_direction_recalculation", all(row["core_direction_class"] ==
          direction_class(float(row["SD_logFC"]), float(row["H_logFC"])) for row in source), True)
    counts = Counter(row["core_direction_class"] for row in source)
    check("fig1h_direction_counts", counts,
          Counter({"CONCORDANT_UP": 1399, "CONCORDANT_DOWN": 1317,
                   "DISCORDANT_MOUSE_DOWN_HUMAN_UP": 1226,
                   "DISCORDANT_MOUSE_UP_HUMAN_DOWN": 1034}))
    check("fig1h_classes_exhaustive", sum(counts.values()), 4976)
    check("fig1h_sep_count", sum(row["sep_member"] == "TRUE" for row in source), 2716)
    check("fig1h_interaction_count", sum(row["interaction_member"] == "TRUE" for row in source), 4085)
    check("fig1h_mouse_unit", {row["mouse_statistical_unit"] for row in source},
          {"independent mouse; 12 total and 3 per factorial group"})
    check("fig1h_human_unit", {row["human_statistical_unit"] for row in source},
          {"paired patient; 58 PP-PN pairs"})
    check("fig1h_statistics_rows", len(stats_rows), 14)
    check("fig1h_statistics_counts",
          tuple(int(float(stats[key]["value"])) for key in
                ("core_total", "concordant_up", "concordant_down", "discordant_total",
                 "discordant_mouse_down_human_up", "discordant_mouse_up_human_down",
                 "sep_total", "interaction_within_core")),
          (4976, 1399, 1317, 2260, 1226, 1034, 2716, 4085))
    x = [float(row["SD_logFC"]) for row in source]
    y = [float(row["H_logFC"]) for row in source]
    check("fig1h_pearson_recalculation",
          abs(float(stats["pearson_r_selected_core"]["value"]) - pearson(x, y)) < 1e-12, True)
    check("fig1h_validation_locked", stats["validation_expression_accessed"]["value"], "0")

    cfg = read_config(ROOT / "config/figures/fig1h.yaml")
    analysis_script = (ROOT / "scripts/figures/fig1h_analysis.R").read_text(encoding="utf-8")
    plot_script = (ROOT / "scripts/figures/fig1h_plot.R").read_text(encoding="utf-8")
    caption = ROOT / "figures/captions/fig1h.md"
    svg = ROOT / "figures/panels/fig1h.svg"
    png = ROOT / "figures/previews/fig1h.png"
    check("fig1h_no_effect_threshold", cfg["effect_threshold"], "none")
    check("fig1h_all_core_policy", cfg["gene_label_policy"], "none; all Core members shown")
    check("fig1h_validation_config", cfg["validation_expression_accessed"], "none")
    check("fig1h_manual_visual_inspection", cfg["manual_visual_inspection"], "PASS_2026-09-11")
    check("fig1h_minimum_text_pt", float(cfg["minimum_text_pt"]) >= 8, True)
    check("fig1h_all_classes_plotted", 'for (group in c("DISCORDANT_MOUSE_UP_HUMAN_DOWN", "DISCORDANT_MOUSE_DOWN_HUMAN_UP"' in plot_script, True)
    check("fig1h_validation_absent_analysis", "GSE30999" not in analysis_script and
          "GSE121212" not in analysis_script, True)
    check("fig1h_validation_absent_plot", "GSE30999" not in plot_script and
          "GSE121212" not in plot_script, True)
    check("fig1h_svg_exists", svg.exists() and svg.stat().st_size > 500000, True)
    check("fig1h_png_exists", png.exists() and png.stat().st_size > 100000, True)
    check("fig1h_caption_exists", caption.exists() and caption.stat().st_size > 1400, True)
    caption_text = caption.read_text(encoding="utf-8")
    check("fig1h_caption_selection_caution", "preselected Core effects" in caption_text, True)
    check("fig1h_caption_validation_lock", "GSE30999 and GSE121212 expression values were not accessed" in caption_text, True)
    png_w, png_h = png_dimensions(png)
    check("fig1h_png_dimensions", (png_w, png_h),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    svg_w, svg_h = svg_dimensions(svg)
    check("fig1h_svg_width", abs(svg_w - float(cfg["width_inches"])) < 0.02, True)
    check("fig1h_svg_height", abs(svg_h - float(cfg["height_inches"])) < 0.02, True)
    svg_text = svg.read_text(encoding="utf-8")
    svg_rgb = {tuple(round(float(channel) * 255 / 100) for channel in match)
               for match in re.findall(r"rgb\(([0-9.]+)%, ([0-9.]+)%, ([0-9.]+)%\)", svg_text)}
    for color_key in ("concordant_up_color", "concordant_down_color",
                      "discordant_mouse_down_human_up_color",
                      "discordant_mouse_up_human_down_color", "ink"):
        color = cfg[color_key].lstrip("#")
        expected_rgb = tuple(int(color[index:index + 2], 16) for index in (0, 2, 4))
        check(f"fig1h_svg_uses_{color_key}", expected_rgb in svg_rgb, True)

    manifest = {row["panel_id"]: row for row in read_tsv(ROOT / "panel_manifest.tsv")}["1H"]
    check("fig1h_manifest_status", manifest["status"], "PASS")
    check("fig1h_manifest_qa", manifest["qa_status"], "PASS_RENDER_DATA_PRINT")
    check("fig1h_manifest_ready", manifest["figure_ready"], "YES")
    check("fig1h_manifest_source", manifest["source_data"], "figures/source_data/fig1h.tsv")

    audit_path = ROOT / "audits/fig1h_qa_checks.tsv"
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    with audit_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 1H data, isolation, render and print QA checks")


if __name__ == "__main__":
    main()
