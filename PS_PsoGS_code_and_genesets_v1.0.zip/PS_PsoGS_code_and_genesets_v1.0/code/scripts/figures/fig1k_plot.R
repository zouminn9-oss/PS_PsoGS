options(stringsAsFactors = FALSE)

source_path <- file.path("figures", "source_data", "fig1k.tsv")
svg_path <- file.path("figures", "panels", "fig1k.svg")
png_path <- file.path("figures", "previews", "fig1k.png")
d <- read.delim(source_path, check.names = FALSE)
stopifnot(nrow(d) == 9L)

gene_order <- c("CXCL6", "IL36RN", "KRT73")
est_order <- c("S0", "SD", "I")
cols <- c(S0 = "#4D4D4D", SD = "#D55E00", I = "#0072B2")
offset <- c(S0 = 0.22, SD = 0, I = -0.22)

draw_panel <- function() {
  par(mar = c(5.2, 9.2, 5.0, 2.0), family = "sans", xpd = NA)
  ylim <- c(0.45, 3.55)
  xlim <- range(c(d$ci95_low, d$ci95_high)) + c(-1.2, 1.2)
  plot(NA, xlim = xlim, ylim = ylim, yaxt = "n", xlab = "log2 fold change (95% interval)",
       ylab = "", bty = "n", cex.lab = 1.35, cex.axis = 1.12)
  abline(v = 0, col = "#BDBDBD", lty = 2, lwd = 2)
  abline(h = 1:3, col = "#EFEFEF", lwd = 1)
  axis(2, at = 3:1, labels = c("CXCL6\naugmentation", "IL36RN\nattenuation", "KRT73\nreversal"),
       las = 1, tick = FALSE, cex.axis = 1.15)
  for (g in gene_order) {
    base_y <- 4 - match(g, gene_order)
    for (est in est_order) {
      z <- d[d$human_gene_symbol == g & d$estimand == est, ]
      y <- base_y + offset[[est]]
      segments(z$ci95_low, y, z$ci95_high, y, col = cols[[est]], lwd = 4)
      points(z$log2_fold_change, y, pch = 21, bg = cols[[est]], col = "white", lwd = 1.2, cex = 1.65)
    }
  }
  legend("bottomright", legend = c("S0: CRS - Control", "SD: CRS+IMQ - IMQ", "I: SD - S0"),
         col = cols, pt.bg = cols, pch = 21, lwd = 3, bty = "n", cex = 1.02)
  title("Representative context-dependent effects", adj = 0, cex.main = 1.7, font.main = 2, line = 2.4)
  mtext("Display-only genes: largest |I| within each frozen interaction class", side = 3,
        adj = 0, line = 0.5, cex = 1.05, col = "#555555")
}

svg(svg_path, width = 14.013, height = 9.447, pointsize = 12, family = "Arial")
draw_panel()
dev.off()
png(png_path, width = 2102, height = 1417, res = 150, type = "cairo")
draw_panel()
dev.off()
cat("PASS: rendered Figure 1K SVG and PNG\n")
