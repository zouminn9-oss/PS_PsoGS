#!/usr/bin/env python3
"""Data, isolation, render and print QA for Figure 1F."""

from __future__ import annotations

import csv
import math
import re
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    config: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            config[key.strip()] = value.strip().strip('"')
    return config


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError(f"not a PNG: {path}")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def pearson(xs: list[float], ys: list[float]) -> float:
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    numerator = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    denominator = math.sqrt(sum((x - mx) ** 2 for x in xs) *
                            sum((y - my) ** 2 for y in ys))
    return numerator / denominator


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    source = read_tsv(ROOT / "figures" / "source_data" / "fig1f.tsv")
    s0 = read_tsv(ROOT / "results" / "stage02" / "factorial_edger" /
                  "gse212126_S0_all_genes.tsv")
    sd = read_tsv(ROOT / "results" / "stage02" / "factorial_edger" /
                  "gse212126_SD_all_genes.tsv")
    stats_rows = read_tsv(ROOT / "results" / "figures" / "fig1f_statistics.tsv")
    stats = {row["metric"]: row for row in stats_rows}
    audit = read_tsv(ROOT / "audits" / "stage02_counts" /
                     "gse212126_edger_integrity_checks.tsv")
    check("fig1f_source_rows", len(source), 18484)
    check("fig1f_unique_gene_ids", len({row["gene_id"] for row in source}), 18484)
    check("fig1f_input_rows", (len(s0), len(sd)), (18484, 18484))
    check("fig1f_input_gene_alignment", {row["gene_id"] for row in s0},
          {row["gene_id"] for row in sd})
    check("fig1f_source_gene_alignment", {row["gene_id"] for row in source},
          {row["gene_id"] for row in s0})
    check("fig1f_independent_mouse_unit",
          {row["statistical_unit"] for row in source}, {"independent_mouse"})
    check("fig1f_model_frozen", {row["model"] for row in source},
          {"TMM + filterByExpr + robust edgeR QL"})
    check("fig1f_all_finite", all(math.isfinite(float(row[key])) for row in source
                                    for key in ("S0_logFC", "SD_logFC", "S0_FDR", "SD_FDR",
                                                "S0_neg_log10_FDR", "SD_neg_log10_FDR")), True)
    check("fig1f_fdr_positive_bounded",
          all(0 < float(row[key]) <= 1 for row in source for key in ("S0_FDR", "SD_FDR")), True)

    category_counts = Counter(row["significance_category"] for row in source)
    expected_counts = Counter({"Both FDR<0.05": 5388, "S0 only": 3752,
                               "SD only": 3593, "Neither": 5751})
    check("fig1f_joint_category_counts", category_counts, expected_counts)
    check("fig1f_category_exhaustive", sum(category_counts.values()), 18484)
    check("fig1f_s0_significant", sum(float(row["S0_FDR"]) < 0.05 for row in source), 9140)
    check("fig1f_sd_significant", sum(float(row["SD_FDR"]) < 0.05 for row in source), 8981)
    check("fig1f_category_recalculated",
          all(row["significance_category"] ==
              ("Both FDR<0.05" if float(row["S0_FDR"]) < 0.05 and float(row["SD_FDR"]) < 0.05
               else "S0 only" if float(row["S0_FDR"]) < 0.05
               else "SD only" if float(row["SD_FDR"]) < 0.05 else "Neither")
              for row in source), True)
    check("fig1f_neglog_recalculated",
          all(abs(float(row[f"{est}_neg_log10_FDR"]) + math.log10(float(row[f"{est}_FDR"])))
                  < 1e-12 for row in source for est in ("S0", "SD")), True)

    source_by_gene = {row["gene_id"]: row for row in source}
    check("fig1f_s0_values_match_input",
          all(abs(float(source_by_gene[row["gene_id"]]["S0_logFC"]) - float(row["logFC"])) < 1e-12
              and abs(float(source_by_gene[row["gene_id"]]["S0_FDR"]) - float(row["FDR"])) < 1e-15
              for row in s0), True)
    check("fig1f_sd_values_match_input",
          all(abs(float(source_by_gene[row["gene_id"]]["SD_logFC"]) - float(row["logFC"])) < 1e-12
              and abs(float(source_by_gene[row["gene_id"]]["SD_FDR"]) - float(row["FDR"])) < 1e-15
              for row in sd), True)
    xs = [float(row["S0_logFC"]) for row in source]
    ys = [float(row["SD_logFC"]) for row in source]
    check("fig1f_pearson_recalculated",
          abs(float(stats["pearson_S0_SD_logFC"]["value"]) - pearson(xs, ys)) < 1e-12, True)
    check("fig1f_full_extrema_retained",
          (round(min(xs), 9), round(max(xs), 9), round(min(ys), 9), round(max(ys), 9)),
          (-8.581164859, 10.383848839, -8.78182939, 11.489068485))
    check("fig1f_statistics_rows", len(stats_rows), 19)
    check("fig1f_statistics_counts",
          tuple(int(float(stats[name]["value"])) for name in
                ("tested_genes", "S0_FDR_lt_0.05", "SD_FDR_lt_0.05",
                 "both_FDR_lt_0.05", "S0_only_FDR_lt_0.05", "SD_only_FDR_lt_0.05",
                 "neither_FDR_lt_0.05")), (18484, 9140, 8981, 5388, 3752, 3593, 5751))
    check("fig1f_model_audits", (len(audit), {row["status"] for row in audit}), (27, {"PASS"}))
    check("fig1f_validation_locked", stats["validation_expression_accessed"]["value"], "0")

    cfg = read_config(ROOT / "config" / "figures" / "fig1f.yaml")
    plot_script = (ROOT / "scripts" / "figures" / "fig1f_plot.R").read_text(encoding="utf-8")
    analysis_script = (ROOT / "scripts" / "figures" / "fig1f_analysis.R").read_text(encoding="utf-8")
    svg = ROOT / "figures" / "panels" / "fig1f.svg"
    png = ROOT / "figures" / "previews" / "fig1f.png"
    caption = ROOT / "figures" / "captions" / "fig1f.md"
    check("fig1f_no_effect_threshold", cfg["effect_threshold"], "none")
    check("fig1f_no_gene_selection", cfg["gene_label_policy"],
          "none; all genes retained and no post hoc gene selection")
    check("fig1f_minimum_text_pt", float(cfg["minimum_text_pt"]) >= 8, True)
    check("fig1f_manual_visual_inspection", cfg["manual_visual_inspection"], "PASS_2026-09-11")
    text_cex = [float(value) for value in re.findall(r"cex(?:\.axis|\.lab|\.main)\s*=\s*([0-9.]+)", plot_script)]
    check("fig1f_axis_label_text_cex", min(text_cex) >= 0.67, True,
          "12-point device font makes cex=0.67 approximately 8 pt")
    check("fig1f_annotation_text_floor", "cex = 0.67" in plot_script, True,
          "all legend, annotation and threshold-label text is explicitly set to at least 0.67; smaller cex values apply only to point marks")
    check("fig1f_static_renderer", cfg["renderer"], "base_R_static")
    check("fig1f_validation_datasets_absent_from_analysis",
          "GSE30999" not in analysis_script and "GSE121212" not in analysis_script, True)
    check("fig1f_validation_datasets_absent_from_plot",
          "GSE30999" not in plot_script and "GSE121212" not in plot_script, True)
    check("fig1f_all_genes_plotted", "for (category in cats)" in plot_script and
          "points(dat$S0_logFC[ix], dat$SD_logFC[ix]" in plot_script, True)
    check("fig1f_svg_exists", svg.exists() and svg.stat().st_size > 100000, True)
    check("fig1f_png_exists", png.exists() and png.stat().st_size > 50000, True)
    check("fig1f_caption_exists", caption.exists() and caption.stat().st_size > 1200, True)
    png_w, png_h = png_dimensions(png)
    check("fig1f_png_dimensions", (png_w, png_h),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    svg_w, svg_h = svg_dimensions(svg)
    check("fig1f_svg_width", abs(svg_w - float(cfg["width_inches"])) < 0.02, True)
    check("fig1f_svg_height", abs(svg_h - float(cfg["height_inches"])) < 0.02, True)
    svg_text = svg.read_text(encoding="utf-8")
    svg_rgb = {tuple(round(float(channel) * 255 / 100) for channel in match)
               for match in re.findall(r"rgb\(([0-9.]+)%, ([0-9.]+)%, ([0-9.]+)%\)", svg_text)}
    for color_key in ("control_grey", "s0_only", "sd_only", "both", "ink"):
        color = cfg[color_key].lstrip("#")
        expected_rgb = tuple(int(color[index:index + 2], 16) for index in (0, 2, 4))
        check(f"fig1f_svg_uses_{color_key}", expected_rgb in svg_rgb, True)

    audit_path = ROOT / "audits" / "fig1f_qa_checks.tsv"
    with audit_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=("check_id", "observed", "expected", "status", "note"),
                                delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 1F data, isolation, render and print QA checks")


if __name__ == "__main__":
    main()
