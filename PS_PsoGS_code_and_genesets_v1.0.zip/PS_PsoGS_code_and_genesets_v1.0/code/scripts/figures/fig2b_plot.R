options(stringsAsFactors = FALSE)

dat <- read.delim(file.path("figures", "source_data", "fig2b.tsv"), check.names = FALSE)
patients <- dat[dat$record_type == "PATIENT", ]
summary <- dat[dat$record_type == "SUMMARY", ]

ink <- "#343B42"; blue <- "#0072B2"; orange <- "#D55E00"
grid <- "#DDE2E5"; neutral <- "#7A7F85"
cohorts <- c("GSE30999", "GSE121212")
centers <- c(2, 1)
colors <- c(blue, orange)

p_label <- function(p) {
  if (p < 1e-4) return(formatC(p, format = "e", digits = 2))
  formatC(p, format = "f", digits = 4)
}

draw_panel <- function() {
  par(mar = c(3.9, 1.0, 3.0, 1.0), family = "sans", xpd = NA)
  plot.new()
  plot.window(xlim = c(-0.032, 0.142), ylim = c(0.45, 2.70))
  abline(v = seq(-0.02, 0.14, 0.02), col = grid, lwd = 0.65)
  abline(v = 0, col = neutral, lwd = 1.1, lty = 2)

  for (i in seq_along(cohorts)) {
    cohort <- cohorts[i]; y0 <- centers[i]; color <- colors[i]
    x <- patients$delta_LS_minus_NL[patients$dataset_id == cohort]
    s <- summary[summary$dataset_id == cohort, ]
    den <- density(x, from = min(x) - 0.008, to = max(x) + 0.008, n = 256)
    den_y <- y0 + 0.08 + 0.29 * den$y / max(den$y)
    polygon(c(den$x, rev(den$x)), c(rep(y0 + 0.08, length(den$x)), rev(den_y)),
            col = adjustcolor(color, alpha.f = 0.28), border = color, lwd = 0.9)

    set.seed(if (cohort == "GSE30999") 30999 else 121212)
    jitter_y <- y0 - 0.15 + runif(length(x), -0.065, 0.065)
    points(x, jitter_y, pch = 21, cex = 0.61, lwd = 0.45,
           bg = adjustcolor(color, alpha.f = 0.68), col = "white")

    segments(s$ci_low, y0 + 0.015, s$ci_high, y0 + 0.015,
             col = ink, lwd = 2.2)
    segments(s$ci_low, y0 - 0.020, s$ci_low, y0 + 0.050, col = ink, lwd = 1)
    segments(s$ci_high, y0 - 0.020, s$ci_high, y0 + 0.050, col = ink, lwd = 1)
    points(s$mean_delta, y0 + 0.015, pch = 23, cex = 1.15, bg = color, col = ink, lwd = 0.7)
    segments(s$median_delta, y0 + 0.075, s$median_delta, y0 + 0.145,
             col = ink, lwd = 1.15)

    text(-0.029, y0 + 0.48, s$cohort_label, adj = c(0, 0.5), cex = 0.80,
         font = 2, col = color)
    stat_line <- sprintf("n=%d  |  %d/%d positive  |  mean Delta %.3f [%.3f, %.3f]",
                         s$n_pairs, s$positive_pairs, s$n_pairs, s$mean_delta,
                         s$ci_low, s$ci_high)
    text(-0.029, y0 + 0.405, stat_line, adj = c(0, 0.5), cex = 0.67, col = ink)
    test_line <- sprintf("paired t P=%s  |  Wilcoxon P=%s",
                         p_label(s$t_p_value), p_label(s$wilcoxon_p_value))
    text(0.139, y0 + 0.405, test_line, adj = c(1, 0.5), cex = 0.65, col = neutral)
  }

  axis(1, at = seq(-0.02, 0.14, 0.02), labels = sprintf("%.2f", seq(-0.02, 0.14, 0.02)),
       cex.axis = 0.72, col.axis = ink, col = ink, lwd = 0.8, tck = -0.018)
  mtext("Lesional - non-lesional frozen SEP directional score", side = 1,
        line = 2.45, cex = 0.78, col = ink)
  text(-0.029, 2.67, "Within-person frozen SEP shifts", adj = c(0, 1),
       cex = 1.02, font = 2, col = ink)
  text(0.139, 2.67, "each dot = one independent paired patient", adj = c(1, 1),
       cex = 0.67, col = neutral)
  text(-0.029, 0.51,
       "Density and dots show all differences; diamond and bar show mean and 95% CI; tick shows median.",
       adj = c(0, 0.5), cex = 0.64, col = neutral)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig2b.svg"), width = 7.0079, height = 4.3307,
    pointsize = 12, family = "sans", bg = "white")
draw_panel(); dev.off()
png(file.path("figures", "previews", "fig2b.png"), width = 7.0079, height = 4.3307,
    units = "in", res = 300, pointsize = 12, type = "cairo", bg = "white")
draw_panel(); dev.off()
cat("PASS: rendered Figure 2B SVG and 300-dpi PNG\n")
