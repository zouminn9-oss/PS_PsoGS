options(stringsAsFactors = FALSE)

s0 <- read.delim(file.path("results", "stage02", "factorial_edger",
                           "gse212126_S0_all_genes.tsv"), check.names = FALSE)
sd <- read.delim(file.path("results", "stage02", "factorial_edger",
                           "gse212126_SD_all_genes.tsv"), check.names = FALSE)
audit <- read.delim(file.path("audits", "stage02_counts",
                              "gse212126_edger_integrity_checks.tsv"), check.names = FALSE)
required <- c("gene_id", "gene_name", "gene_type", "estimand", "logFC", "logCPM",
              "F", "PValue", "FDR", "significant_FDR_0_05", "direction")
stopifnot(identical(colnames(s0), required), identical(colnames(sd), required),
          nrow(s0) == 18484L, nrow(sd) == 18484L, !anyDuplicated(s0$gene_id),
          !anyDuplicated(sd$gene_id), setequal(s0$gene_id, sd$gene_id),
          all(s0$estimand == "S0"), all(sd$estimand == "SD"),
          all(is.finite(s0$logFC)), all(is.finite(sd$logFC)),
          all(is.finite(s0$FDR)), all(is.finite(sd$FDR)),
          all(s0$FDR > 0 & s0$FDR <= 1), all(sd$FDR > 0 & sd$FDR <= 1),
          all(audit$status == "PASS"), nrow(audit) == 27L)

sd <- sd[match(s0$gene_id, sd$gene_id), ]
stopifnot(identical(s0$gene_id, sd$gene_id), identical(s0$gene_name, sd$gene_name),
          identical(s0$gene_type, sd$gene_type))
s0_sig <- s0$FDR < 0.05
sd_sig <- sd$FDR < 0.05
category <- ifelse(s0_sig & sd_sig, "Both FDR<0.05",
                   ifelse(s0_sig, "S0 only", ifelse(sd_sig, "SD only", "Neither")))
direction_relation <- ifelse(sign(s0$logFC) == sign(sd$logFC), "same direction",
                             "opposite direction")
source <- data.frame(
  gene_id = s0$gene_id, gene_name = s0$gene_name, gene_type = s0$gene_type,
  S0_logFC = s0$logFC, S0_logCPM = s0$logCPM, S0_F = s0$F,
  S0_PValue = s0$PValue, S0_FDR = s0$FDR, S0_neg_log10_FDR = -log10(s0$FDR),
  SD_logFC = sd$logFC, SD_logCPM = sd$logCPM, SD_F = sd$F,
  SD_PValue = sd$PValue, SD_FDR = sd$FDR, SD_neg_log10_FDR = -log10(sd$FDR),
  significance_category = category, direction_relation = direction_relation,
  statistical_unit = "independent_mouse", model = "TMM + filterByExpr + robust edgeR QL",
  stringsAsFactors = FALSE)

dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(source, file.path("figures", "source_data", "fig1f.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE, na = "")

counts <- table(factor(category, levels = c("Both FDR<0.05", "S0 only", "SD only", "Neither")))
same <- sum(direction_relation == "same direction")
opposite <- sum(direction_relation == "opposite direction")
stats <- data.frame(
  metric = c("tested_genes", "S0_FDR_lt_0.05", "SD_FDR_lt_0.05",
             "both_FDR_lt_0.05", "S0_only_FDR_lt_0.05", "SD_only_FDR_lt_0.05",
             "neither_FDR_lt_0.05", "same_direction", "opposite_direction",
             "pearson_S0_SD_logFC", "spearman_S0_SD_logFC", "S0_logFC_min",
             "S0_logFC_max", "SD_logFC_min", "SD_logFC_max", "S0_FDR_min",
             "SD_FDR_min", "edgeR_integrity_checks_pass", "validation_expression_accessed"),
  value = c(nrow(source), sum(s0_sig), sum(sd_sig), unname(counts[1]), unname(counts[2]),
            unname(counts[3]), unname(counts[4]), same, opposite,
            cor(s0$logFC, sd$logFC, method = "pearson"),
            cor(s0$logFC, sd$logFC, method = "spearman"), min(s0$logFC), max(s0$logFC),
            min(sd$logFC), max(sd$logFC), min(s0$FDR), min(sd$FDR), nrow(audit), 0),
  unit = c(rep("genes", 9), rep("correlation", 2), rep("log2_fold_change", 4),
           rep("FDR", 2), "checks", "boolean"),
  status = c(rep("PASS", 18), "PASS_LOCKED"),
  interpretation = c(
    "all genes retained by the frozen design-aware filter", "frozen S0 BH rule",
    "frozen SD BH rule", "significant under both distinct estimands",
    "significant only for S0", "significant only for SD", "significant for neither",
    "logFC signs agree", "logFC signs differ", "all-gene linear association",
    "all-gene rank association", "full observed S0 minimum", "full observed S0 maximum",
    "full observed SD minimum", "full observed SD maximum", "smallest observed S0 FDR",
    "smallest observed SD FDR", "independent model-output checks",
    "validation cohorts remained isolated"), stringsAsFactors = FALSE)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(stats, file.path("results", "figures", "fig1f_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
cat("PASS: exported Figure 1F source data and statistics for all 18,484 genes\n")
