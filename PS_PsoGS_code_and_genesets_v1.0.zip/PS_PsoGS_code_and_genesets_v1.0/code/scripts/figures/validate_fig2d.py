#!/usr/bin/env python3
"""Complete-denominator, render and print QA for Figure 2D."""

from __future__ import annotations

import csv
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
AUDIT = ROOT / "audits/fig2d_qa_checks.tsv"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            out[key.strip()] = value.strip().strip('"')
    return out


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError("not PNG")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def write_audit(rows: list[dict[str, str]]) -> None:
    with AUDIT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            write_audit(checks)
            raise AssertionError(f"{check_id}: observed {observed!r}; expected {expected!r}")

    source = read_tsv(ROOT / "figures/source_data/fig2d.tsv")
    upstream = read_tsv(ROOT / "results/stage03/gene_replication.tsv")
    stats = read_tsv(ROOT / "results/figures/fig2d_statistics.tsv")
    upstream_summary = read_tsv(ROOT / "results/stage03/gene_replication_summary.tsv")
    gene_audit = read_tsv(ROOT / "audits/stage03_gene_replication_checks.tsv")

    check("fig2d_gene_audit", (len(gene_audit), {r["status"] for r in gene_audit}), (30, {"PASS"}))
    check("fig2d_source_rows", len(source), 2716)
    check("fig2d_unique_symbols", len({r["human_gene_symbol"] for r in source}), 2716)
    check("fig2d_direction_counts", Counter(r["sep_direction"] for r in source),
          Counter({"UP": 1399, "DOWN": 1317}))
    check("fig2d_display_index", [int(r["display_index"]) for r in source], list(range(1, 2717)))
    expected_order = sorted(upstream, key=lambda r: (0 if r["sep_direction"] == "UP" else 1,
                                                     r["human_gene_symbol"]))
    check("fig2d_frozen_sort", [r["human_gene_symbol"] for r in source],
          [r["human_gene_symbol"] for r in expected_order])
    source_map = {r["human_gene_symbol"]: r for r in source}
    upstream_map = {r["human_gene_symbol"]: r for r in upstream}
    check("fig2d_source_keys", set(source_map), set(upstream_map))
    text_fields = ("selected_human_entrez_id", "sep_direction", "array_state", "rnaseq_state",
                   "cross_cohort_state", "both_strict_replication")
    for field in text_fields:
        check(f"fig2d_source_field::{field}",
              all(source_map[key][field] == upstream_map[key][field] for key in source_map), True)
    for field in ("array_logFC", "array_FDR", "rnaseq_logFC", "rnaseq_FDR"):
        matches = True
        for key in source_map:
            left, right = source_map[key][field], upstream_map[key][field]
            if left == "" or right == "":
                matches = matches and left == right
            else:
                matches = matches and abs(float(left) - float(right)) < 1e-12
        check(f"fig2d_source_numeric::{field}", matches, True)

    display_counts = {
        "array": Counter(r["array_display_state"] for r in source),
        "rnaseq": Counter(r["rnaseq_display_state"] for r in source),
    }
    check("fig2d_array_display_counts", display_counts["array"],
          Counter({"CONCORDANT_STRICT": 1940, "CONCORDANT_NON_FDR": 421,
                   "DISCORDANT_NON_FDR": 202, "DISCORDANT_FDR": 116, "UNAVAILABLE": 37}))
    check("fig2d_rna_display_counts", display_counts["rnaseq"],
          Counter({"CONCORDANT_STRICT": 2070, "CONCORDANT_NON_FDR": 263,
                   "DISCORDANT_NON_FDR": 134, "DISCORDANT_FDR": 105, "UNAVAILABLE": 144}))
    check("fig2d_stats_rows", len(stats), 9)
    figure_stats_map = {(r["dataset_id"], r["direction_stratum"]): r for r in stats}
    upstream_stats_map = {(r["dataset_id"], r["direction_stratum"]): r for r in upstream_summary}
    check("fig2d_stats_keys", set(figure_stats_map), set(upstream_stats_map))
    for key in figure_stats_map:
        for field in ("summary_type", "frozen_members", "platform_mappable", "tested_members",
                      "filtered_low_expression", "not_platform_mappable", "direction_concordant",
                      "direction_discordant", "strict_replication", "discordant_FDR_lt_0.05"):
            check(f"fig2d_stats_text::{key}::{field}",
                  figure_stats_map[key][field], upstream_stats_map[key][field])
        for field in ("direction_concordance_rate_tested", "strict_replication_rate_tested",
                      "strict_replication_rate_frozen"):
            check(f"fig2d_stats_numeric::{key}::{field}",
                  abs(float(figure_stats_map[key][field]) - float(upstream_stats_map[key][field])) < 1e-12,
                  True)
    stats_map = {(r["dataset_id"], r["direction_stratum"]): r for r in stats}
    expected_all = {
        "GSE30999": (2716, 2679, 2361, 318, 1940),
        "GSE121212": (2716, 2572, 2333, 239, 2070),
        "BOTH": (2716, 2537, 2065, 66, 1589),
    }
    for dataset, expected in expected_all.items():
        row = stats_map[(dataset, "ALL")]
        observed = tuple(int(row[field]) for field in
                         ("frozen_members", "tested_members", "direction_concordant",
                          "direction_discordant", "strict_replication"))
        check(f"fig2d_summary::{dataset}", observed, expected)
    check("fig2d_cross_mixed", sum(r["cross_cohort_state"] == "MIXED_DIRECTION" for r in source), 406)
    check("fig2d_cross_not_joint", sum(r["both_tested"] != "YES" for r in source), 179)

    cfg = read_config(ROOT / "config/figures/fig2d.yaml")
    plot_script = (ROOT / "scripts/figures/fig2d_plot.R").read_text(encoding="utf-8")
    analysis_script = (ROOT / "scripts/figures/fig2d_analysis.R").read_text(encoding="utf-8")
    frozen_cfg = (ROOT / "config/stage03_gene_replication.yaml").read_text(encoding="utf-8")
    check("fig2d_manual_visual", cfg["manual_visual_inspection"], "PASS_2026-09-11_FIRST_RENDER")
    check("fig2d_min_text", float(cfg["minimum_text_pt"]) >= 8, True)
    check("fig2d_denominator", cfg["denominator"], "all 2716 frozen SEP genes for every composition bar")
    check("fig2d_analysis_derived_only", "data/raw" not in analysis_script, True)
    check("fig2d_plot_derived_only", "data/raw" not in plot_script, True)
    check("fig2d_no_selection", "gene_display_selection: \"none" in frozen_cfg, True)
    check("fig2d_no_feedback", "validation_to_signature_feedback: false" in frozen_cfg, True)
    check("fig2d_filtered_not_failure", "filtered_low_expression_is_direction_failure: false" in frozen_cfg, True)
    for key in ("concordant_strict_color", "concordant_nonsignificant_color",
                "discordant_nonsignificant_color", "discordant_fdr_color", "unavailable_color"):
        check(f"fig2d_color::{key}", cfg[key] in plot_script, True)

    svg = ROOT / "figures/panels/fig2d.svg"
    png = ROOT / "figures/previews/fig2d.png"
    caption = ROOT / "figures/captions/fig2d.md"
    check("fig2d_svg", svg.is_file() and svg.stat().st_size > 1000000, True)
    check("fig2d_png", png.is_file() and png.stat().st_size > 100000, True)
    check("fig2d_caption", caption.is_file() and caption.stat().st_size > 3000, True)
    caption_text = caption.read_text(encoding="utf-8")
    for phrase in ("all 2,716 genes", "2,361 (88.1%)", "2,333 (90.7%)",
                   "Four hundred and six genes", "66 are directionally discordant in both cohorts",
                   "does not prove that every SEP member is stress-specific"):
        check(f"fig2d_caption::{phrase}", phrase in caption_text, True)
    check("fig2d_png_dimensions", png_dimensions(png),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    sw, sh = svg_dimensions(svg)
    check("fig2d_svg_width", abs(sw - float(cfg["width_inches"])) < 0.02, True)
    check("fig2d_svg_height", abs(sh - float(cfg["height_inches"])) < 0.02, True)

    panel = {r["panel_id"]: r for r in read_tsv(ROOT / "panel_manifest.tsv")}["2D"]
    check("fig2d_panel_status", panel["status"], "PASS")
    check("fig2d_panel_qa", panel["qa_status"], "PASS_RENDER_DATA_PRINT")
    check("fig2d_panel_ready", panel["figure_ready"], "YES")
    check("fig2d_panel_source", panel["source_data"], "figures/source_data/fig2d.tsv")

    write_audit(checks)
    print(f"PASS: {len(checks)} Figure 2D complete-denominator, render and print QA checks")


if __name__ == "__main__":
    main()
