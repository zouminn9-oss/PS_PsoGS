from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import pandas as pd

src=ROOT/"figures/source_data"; stats=ROOT/"results/figures"; cfg=ROOT/"config/figures"
src.mkdir(parents=True,exist_ok=True); stats.mkdir(parents=True,exist_ok=True); cfg.mkdir(parents=True,exist_ok=True)

effects=pd.read_csv(ROOT/"results/stage07/gse117468_longitudinal_effects.tsv",sep="\t")
h=effects[effects.contrast.str.contains("W12")].copy()
h.to_csv(src/"fig7h.tsv",sep="\t",index=False); h.to_csv(stats/"fig7h_statistics.tsv",sep="\t",index=False)

summary=pd.read_csv(ROOT/"results/stage07/prediction_model_summary.tsv",sep="\t")
deltas=pd.read_csv(ROOT/"results/stage07/prediction_model_deltas.tsv",sep="\t")
long=[]
for _,r in summary.iterrows():
  for metric in ["auroc","auprc","brier"]:
    long.append({"model":r.model,"metric":metric,"median":r[f"{metric}_median"],"q025":r[f"{metric}_q025"],"q975":r[f"{metric}_q975"]})
pd.DataFrame(long).to_csv(src/"fig7i.tsv",sep="\t",index=False)
deltas.assign(interpretation="M0+SEP sensitivity minus M0; not canonical M2 because M1 is blocked").to_csv(stats/"fig7i_statistics.tsv",sep="\t",index=False)

cal=pd.read_csv(ROOT/"results/stage07/prediction_calibration.tsv",sep="\t")
cal.to_csv(src/"fig7j.tsv",sep="\t",index=False)
summary.assign(validation="internal repeated nested CV only",canonical_M1="BLOCKED_MISSING_FROZEN_COMPARATOR_SIGNATURES").to_csv(stats/"fig7j_statistics.tsv",sep="\t",index=False)

configs={
"fig7h":"panel_id: 7H\ntitle: Bulk treatment and tissue effects\nstatistical_unit: patient\ncontrast: W12_minus_BL\nffpe_or_spot_pseudoreplication: not_applicable\n",
"fig7i":"panel_id: 7I\ntitle: Restricted internal model comparison\nouter_cv: repeated_stratified_5_fold_x20\ninner_cv: stratified_4_fold\ncanonical_M1: BLOCKED\nclaim: sensitivity_not_canonical_M2\n",
"fig7j":"panel_id: 7J\ntitle: Held-out calibration diagnostic\nprobability: mean_across_20_outer_predictions_per_patient\nvalidation: internal_only\n",
}
for name,text in configs.items(): (cfg/f"{name}.yaml").write_text(text,encoding="utf-8")
print("PASS: Figure 7 bulk source data/statistics/configs")
