options(stringsAsFactors = FALSE)

ledger <- read.delim(gzfile(file.path("results", "stage02", "signatures",
                                     "cross_species_gene_ledger.tsv.gz")),
                     check.names = FALSE)
audit <- read.delim(file.path("audits", "stage02_orthology", "signature_f1_checks.tsv"),
                    check.names = FALSE)
stopifnot(nrow(ledger) == 18484L, !anyDuplicated(ledger$mouse_ensembl_gene_id),
          all(audit$status == "PASS"), nrow(audit) == 45L,
          sum(ledger$core_member == "TRUE") == 4976L,
          sum(ledger$interaction_member == "TRUE") == 4085L)

dat <- ledger[ledger$interaction_member == "TRUE", ]
allowed_classes <- c("augmentation", "attenuation", "reversal", "unchanged_magnitude")
stopifnot(nrow(dat) == 4085L, all(dat$core_member == "TRUE"),
          all(dat$I_FDR < 0.05), all(dat$SD_FDR < 0.05), all(dat$H_FDR < 0.05),
          all(dat$interaction_class %in% allowed_classes),
          max(abs(dat$I_logFC - (dat$SD_logFC - dat$S0_logFC))) < 1e-10)

source <- data.frame(
  mouse_gene_id = dat$mouse_gene_id_versioned,
  mouse_gene_name = dat$mouse_gene_name,
  human_ensembl_gene_id = dat$selected_human_ensembl_gene_id,
  human_entrez_id = dat$selected_human_entrez_id,
  human_gene_symbol = dat$human_gene_symbol,
  S0_logFC = dat$S0_logFC,
  S0_FDR = dat$S0_FDR,
  SD_logFC = dat$SD_logFC,
  SD_FDR = dat$SD_FDR,
  I_logFC = dat$I_logFC,
  I_FDR = dat$I_FDR,
  H_logFC = dat$H_logFC,
  H_FDR = dat$H_FDR,
  core_direction_class = dat$core_direction_class,
  interaction_class = dat$interaction_class,
  sep_member = dat$sep_member,
  high_confidence_sep_interaction = dat$high_confidence_sep_interaction,
  statistical_unit = "gene effects estimated from 12 independent mice",
  stringsAsFactors = FALSE)

dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(source, file.path("figures", "source_data", "fig1g.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE, na = "")

class_counts <- table(factor(source$interaction_class, levels = allowed_classes))
stats <- data.frame(
  metric = c("interaction_total", "augmentation", "attenuation", "reversal",
             "unchanged_magnitude", "interaction_sep", "high_confidence_sep_interaction",
             "median_abs_S0_logFC", "median_abs_SD_logFC", "max_I_identity_error",
             "signature_f1_checks_pass", "validation_expression_accessed"),
  value = c(nrow(source), unname(class_counts), sum(source$sep_member == "TRUE"),
            sum(source$high_confidence_sep_interaction == "TRUE"),
            median(abs(source$S0_logFC)), median(abs(source$SD_logFC)),
            max(abs(source$I_logFC - (source$SD_logFC - source$S0_logFC))),
            nrow(audit), 0),
  unit = c(rep("genes", 7), "absolute_log2_fold_change", "absolute_log2_fold_change",
           "absolute_log2_fold_change", "checks", "boolean"),
  status = c(rep("PASS", 11), "PASS_LOCKED"),
  interpretation = c(
    "Core genes with formal interaction BH-FDR < 0.05",
    "same S0/SD sign with larger absolute SD effect",
    "same S0/SD sign with smaller absolute SD effect",
    "opposite S0/SD signs; descriptive, not automatically causal",
    "same sign and exactly equal magnitude",
    "Interaction members with concordant SD and H directions",
    "members satisfying the frozen high-confidence SEP-Interaction rule",
    "typical absolute S0 effect", "typical absolute SD effect",
    "numerical check of I = SD - S0", "independent F1 membership and source checks",
    "validation cohorts remained isolated"),
  stringsAsFactors = FALSE)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(stats, file.path("results", "figures", "fig1g_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
cat("PASS: exported Figure 1G source data and statistics for 4,085 Interaction genes\n")
