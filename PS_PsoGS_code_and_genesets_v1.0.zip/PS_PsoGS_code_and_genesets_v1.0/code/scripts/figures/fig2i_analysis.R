options(stringsAsFactors = FALSE)
dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)

influence <- read.delim(file.path("results", "stage03", "influence", "stage03_gene_leave_one_out.tsv"), check.names = FALSE)
coverage <- read.delim(file.path("results", "stage03", "influence", "stage03_score_coverage.tsv"), check.names = FALSE)
summary <- read.delim(file.path("results", "stage03", "influence", "stage03_influence_summary.tsv"), check.names = FALSE)
stopifnot(nrow(influence) == 5432L, nrow(coverage) == 4L, nrow(summary) == 2L,
          all(coverage$coverage_fraction > 0.94), all(summary$max_relative_loo_change < 0.005))
write.table(influence, file.path("figures", "source_data", "fig2i.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
coverage$record_type <- "DIRECTION_COVERAGE"
summary$record_type <- "COHORT_INFLUENCE_SUMMARY"
all_names <- union(names(coverage), names(summary))
for (name in setdiff(all_names, names(coverage))) coverage[[name]] <- NA
for (name in setdiff(all_names, names(summary))) summary[[name]] <- NA
statistics <- rbind(coverage[, all_names], summary[, all_names])
write.table(statistics, file.path("results", "figures", "fig2i_statistics.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: Figure 2I retains %d frozen gene-cohort rows\n", nrow(influence)))

