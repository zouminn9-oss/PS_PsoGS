options(stringsAsFactors = FALSE)

scores <- read.delim(file.path("results", "stage03", "scores", "paired_scores.tsv"),
                     check.names = FALSE)
stats <- read.delim(file.path("results", "stage03", "scores", "paired_score_statistics.tsv"),
                    check.names = FALSE)
audit <- read.delim(file.path("audits", "stage03_bulk_validation_checks.tsv"),
                    check.names = FALSE)

stopifnot(nrow(scores) == 108L, nrow(stats) == 2L, all(audit$status == "PASS"),
          identical(sort(as.integer(table(scores$dataset_id))), c(27L, 81L)),
          length(unique(paste(scores$dataset_id, scores$donor_id))) == 108L,
          max(abs(scores$delta_LS_minus_NL -
                  (scores$lesional_score - scores$nonlesional_score))) < 1e-14)

labels <- c(GSE30999 = "GSE30999 | GPL570 array",
            GSE121212 = "GSE121212 | RNA-seq")
patient <- data.frame(
  record_type = "PATIENT",
  dataset_id = scores$dataset_id,
  cohort_label = unname(labels[scores$dataset_id]),
  donor_id = scores$donor_id,
  nonlesional_sample = scores$nonlesional_sample,
  lesional_sample = scores$lesional_sample,
  nonlesional_score = scores$nonlesional_score,
  lesional_score = scores$lesional_score,
  delta_LS_minus_NL = scores$delta_LS_minus_NL,
  n_pairs = NA_integer_, mean_delta = NA_real_, median_delta = NA_real_,
  ci_low = NA_real_, ci_high = NA_real_, positive_pairs = NA_integer_,
  negative_pairs = NA_integer_, t_p_value = NA_real_, wilcoxon_p_value = NA_real_,
  BH_FDR = NA_real_, score_definition = scores$score_definition
)
summary <- data.frame(
  record_type = "SUMMARY",
  dataset_id = stats$dataset_id,
  cohort_label = unname(labels[stats$dataset_id]),
  donor_id = NA_character_, nonlesional_sample = NA_character_, lesional_sample = NA_character_,
  nonlesional_score = stats$mean_nonlesional, lesional_score = stats$mean_lesional,
  delta_LS_minus_NL = stats$mean_delta,
  n_pairs = stats$n_pairs, mean_delta = stats$mean_delta, median_delta = stats$median_delta,
  ci_low = stats$mean_delta_ci_low, ci_high = stats$mean_delta_ci_high,
  positive_pairs = stats$positive_pairs, negative_pairs = stats$negative_pairs,
  t_p_value = stats$t_p_value, wilcoxon_p_value = stats$wilcoxon_p_value,
  BH_FDR = stats$BH_FDR_across_two_primary_cohorts,
  score_definition = "mean_fractional_rank_SEP_UP_minus_SEP_DOWN"
)
source <- rbind(patient, summary)

dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(source, file.path("figures", "source_data", "fig2b.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE, na = "")

figure_stats <- data.frame(
  dataset_id = stats$dataset_id,
  cohort_label = unname(labels[stats$dataset_id]),
  n_pairs = stats$n_pairs,
  mean_delta = stats$mean_delta,
  mean_delta_ci_low = stats$mean_delta_ci_low,
  mean_delta_ci_high = stats$mean_delta_ci_high,
  median_delta = stats$median_delta,
  standardized_mean_change = stats$standardized_mean_change,
  positive_pairs = stats$positive_pairs,
  negative_pairs = stats$negative_pairs,
  t_statistic = stats$t_statistic,
  t_df = stats$t_df,
  t_p_value = stats$t_p_value,
  wilcoxon_statistic = stats$wilcoxon_statistic,
  wilcoxon_p_value = stats$wilcoxon_p_value,
  BH_FDR_across_two_primary_cohorts = stats$BH_FDR_across_two_primary_cohorts,
  effect_definition = "lesional minus non-lesional frozen SEP directional score",
  statistical_unit = "paired patient"
)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(figure_stats, file.path("results", "figures", "fig2b_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
cat("PASS: exported all 108 patient differences and two frozen Figure 2B summaries\n")
