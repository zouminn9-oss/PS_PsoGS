#!/usr/bin/env python3
"""Data, isolation, render and print QA for Figure 1G."""

from __future__ import annotations

import csv
import gzip
import math
import re
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def read_tsv(path: Path, compressed: bool = False) -> list[dict[str, str]]:
    opener = gzip.open if compressed else open
    with opener(path, "rt" if compressed else "r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    config: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            config[key.strip()] = value.strip().strip('"')
    return config


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError(f"not a PNG: {path}")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def sign(value: float) -> int:
    return 1 if value > 0 else (-1 if value < 0 else 0)


def classify(s0: float, sd: float) -> str:
    if sign(s0) != sign(sd):
        return "reversal"
    if abs(sd) > abs(s0):
        return "augmentation"
    if abs(sd) < abs(s0):
        return "attenuation"
    return "unchanged_magnitude"


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    source = read_tsv(ROOT / "figures/source_data/fig1g.tsv")
    ledger = read_tsv(ROOT / "results/stage02/signatures/cross_species_gene_ledger.tsv.gz", compressed=True)
    audit = read_tsv(ROOT / "audits/stage02_orthology/signature_f1_checks.tsv")
    stats_rows = read_tsv(ROOT / "results/figures/fig1g_statistics.tsv")
    stats = {row["metric"]: row for row in stats_rows}
    check("fig1g_source_rows", len(source), 4085)
    check("fig1g_unique_mouse_genes", len({row["mouse_gene_id"] for row in source}), 4085)
    check("fig1g_unique_human_symbols", len({row["human_gene_symbol"] for row in source}), 4085)
    check("fig1g_f1_checks", (len(audit), {row["status"] for row in audit}), (45, {"PASS"}))
    expected_members = {row["mouse_gene_id_versioned"] for row in ledger if row["interaction_member"] == "TRUE"}
    check("fig1g_members_match_f1", {row["mouse_gene_id"] for row in source} == expected_members, True)
    check("fig1g_all_formal_interaction_significant", all(float(row["I_FDR"]) < 0.05 for row in source), True)
    check("fig1g_all_core_thresholds", all(float(row["SD_FDR"]) < 0.05 and float(row["H_FDR"]) < 0.05 for row in source), True)
    check("fig1g_i_identity", max(abs(float(row["I_logFC"]) -
          (float(row["SD_logFC"]) - float(row["S0_logFC"]))) for row in source) < 1e-10, True)
    check("fig1g_class_recalculation", all(row["interaction_class"] ==
          classify(float(row["S0_logFC"]), float(row["SD_logFC"])) for row in source), True)
    counts = Counter(row["interaction_class"] for row in source)
    check("fig1g_class_counts", counts,
          Counter({"augmentation": 423, "attenuation": 141, "reversal": 3521}))
    check("fig1g_classes_exhaustive", sum(counts.values()), 4085)
    check("fig1g_no_equal_magnitude", counts["unchanged_magnitude"], 0)
    check("fig1g_interaction_sep", sum(row["sep_member"] == "TRUE" for row in source), 2268)
    check("fig1g_high_confidence", sum(row["high_confidence_sep_interaction"] == "TRUE" for row in source), 1530)
    check("fig1g_statistics_rows", len(stats_rows), 12)
    check("fig1g_statistics_counts",
          tuple(int(float(stats[key]["value"])) for key in
                ("interaction_total", "augmentation", "attenuation", "reversal",
                 "unchanged_magnitude", "interaction_sep", "high_confidence_sep_interaction")),
          (4085, 423, 141, 3521, 0, 2268, 1530))
    check("fig1g_statistics_i_identity", float(stats["max_I_identity_error"]["value"]) < 1e-10, True)
    check("fig1g_validation_locked", stats["validation_expression_accessed"]["value"], "0")

    cfg = read_config(ROOT / "config/figures/fig1g.yaml")
    analysis_script = (ROOT / "scripts/figures/fig1g_analysis.R").read_text(encoding="utf-8")
    plot_script = (ROOT / "scripts/figures/fig1g_plot.R").read_text(encoding="utf-8")
    caption = ROOT / "figures/captions/fig1g.md"
    svg = ROOT / "figures/panels/fig1g.svg"
    png = ROOT / "figures/previews/fig1g.png"
    check("fig1g_no_effect_threshold", cfg["effect_threshold"], "none")
    check("fig1g_no_gene_selection", cfg["gene_label_policy"], "none; all Interaction members shown")
    check("fig1g_membership_rule", cfg["membership_rule"], "Core AND I BH-FDR < 0.05")
    check("fig1g_manual_visual_inspection", cfg["manual_visual_inspection"], "PASS_2026-09-11")
    check("fig1g_minimum_text_pt", float(cfg["minimum_text_pt"]) >= 8, True)
    check("fig1g_square_data_region", "pty = \"s\"" in plot_script and "asp = 1" in plot_script, True)
    check("fig1g_separate_legend_column", "layout(matrix(c(1, 2)" in plot_script, True)
    check("fig1g_all_members_plotted", "for (group in class_order)" in plot_script and
          "points(dat$S0_logFC[ix], dat$SD_logFC[ix]" in plot_script, True)
    check("fig1g_validation_absent_analysis", "GSE30999" not in analysis_script and
          "GSE121212" not in analysis_script, True)
    check("fig1g_validation_absent_plot", "GSE30999" not in plot_script and
          "GSE121212" not in plot_script, True)
    check("fig1g_svg_exists", svg.exists() and svg.stat().st_size > 500000, True)
    check("fig1g_png_exists", png.exists() and png.stat().st_size > 100000, True)
    check("fig1g_caption_exists", caption.exists() and caption.stat().st_size > 1500, True)
    caption_text = caption.read_text(encoding="utf-8")
    check("fig1g_caption_causal_caution", "does not by itself establish exacerbation" in caption_text, True)
    check("fig1g_caption_validation_lock", "GSE30999 and GSE121212 expression values remained inaccessible" in caption_text, True)
    png_w, png_h = png_dimensions(png)
    check("fig1g_png_dimensions", (png_w, png_h),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    svg_w, svg_h = svg_dimensions(svg)
    check("fig1g_svg_width", abs(svg_w - float(cfg["width_inches"])) < 0.02, True)
    check("fig1g_svg_height", abs(svg_h - float(cfg["height_inches"])) < 0.02, True)
    svg_text = svg.read_text(encoding="utf-8")
    svg_rgb = {tuple(round(float(channel) * 255 / 100) for channel in match)
               for match in re.findall(r"rgb\(([0-9.]+)%, ([0-9.]+)%, ([0-9.]+)%\)", svg_text)}
    for color_key in ("augmentation_color", "attenuation_color", "reversal_color", "ink"):
        color = cfg[color_key].lstrip("#")
        expected_rgb = tuple(int(color[index:index + 2], 16) for index in (0, 2, 4))
        check(f"fig1g_svg_uses_{color_key}", expected_rgb in svg_rgb, True)

    audit_path = ROOT / "audits/fig1g_qa_checks.tsv"
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    with audit_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 1G data, isolation, render and print QA checks")


if __name__ == "__main__":
    main()
