options(stringsAsFactors = FALSE)

dat <- read.delim(file.path("figures", "source_data", "fig1j.tsv"), check.names = FALSE)
stats_rows <- read.delim(file.path("results", "figures", "fig1j_statistics.tsv"),
                         check.names = FALSE)
stats <- setNames(stats_rows$value, stats_rows$metric)
artifacts <- dat[dat$record_type == "ARTIFACT", ]
outputs <- dat[dat$record_type == "SIGNATURE_SUMMARY", ]
stopifnot(nrow(artifacts) == 20L, nrow(outputs) == 3L)

ink <- "#343B42"
input_col <- "#0072B2"
rule_col <- "#D55E00"
output_col <- "#2A6F5B"
lock_col <- "#6B5B95"
light <- "#F4F6F7"
grid <- "#DDE2E5"

rounded_rect <- function(x0, y0, x1, y1, fill, border = grid, lwd = 1) {
  rect(x0, y0, x1, y1, col = fill, border = border, lwd = lwd)
}

draw_card <- function(x0, x1, title, number, color, lines, y0 = 0.24, y1 = 0.81) {
  rounded_rect(x0, y0, x1, y1, "white", grid, 1)
  rect(x0, y1 - 0.075, x1, y1, col = color, border = color)
  text(x0 + 0.018, y1 - 0.037, number, adj = c(0, 0.5), cex = 0.66,
       col = "white", font = 2)
  text(x0 + 0.055, y1 - 0.037, title, adj = c(0, 0.5), cex = 0.70,
       col = "white", font = 2)
  yy <- seq(y1 - 0.125, y0 + 0.055, length.out = length(lines))
  text(rep(x0 + 0.022, length(lines)), yy, lines, adj = c(0, 0.5), cex = 0.68,
       col = ink)
}

draw_panel <- function() {
  par(mar = c(0.4, 0.4, 0.5, 0.4), oma = c(0, 0, 0, 0), family = "sans", xpd = NA)
  plot.new()
  plot.window(xlim = c(0, 1), ylim = c(0, 1))
  text(0.025, 0.955, "Frozen F1 signature package", adj = c(0, 1), cex = 1.00,
       font = 2, col = ink)
  text(0.025, 0.900,
       "One immutable v1.0 handoff: inputs, rules, outputs and validation boundaries",
       adj = c(0, 1), cex = 0.70, col = "#6F7881")

  xs <- matrix(c(0.025, 0.245, 0.270, 0.490, 0.515, 0.735, 0.760, 0.980),
               ncol = 2, byrow = TRUE)
  input_lines <- c(
    "Mouse S0 / SD / I", "12 mice; no pooling",
    "Human paired H", "58 PP-PN pairs",
    "Ensembl release 100", "9 hashed source files")
  rule_lines <- c(
    "1:1 + unique Entrez", "Core: SD,H q < 0.05",
    "Inter.: Core+I q<0.05", "SEP: same SD/H sign",
    "No effect-size cutoff", "Pre-validation freeze")
  output_lines <- c(
    paste0("Core  ", format(as.integer(stats[["core_total"]]), big.mark = ",")),
    paste0("SHA  ", outputs$sha256_prefix[outputs$label == "PS-PsoGS Core"]),
    paste0("Interaction  ", format(as.integer(stats[["interaction_total"]]), big.mark = ",")),
    paste0("SHA  ", outputs$sha256_prefix[outputs$label == "PS-PsoGS Interaction"]),
    paste0("SEP  ", format(as.integer(stats[["sep_total"]]), big.mark = ",")),
    paste0("SHA  ", outputs$sha256_prefix[outputs$label == "SEP"]),
    "6 signature exports", "v1.0")
  handoff_lines <- c(
    "Score: UP minus DOWN", "Coverage at least 70%",
    "No direction flipping", "Members/weights locked",
    "Validation files read: 0", "Next: lock cohorts")
  draw_card(xs[1, 1], xs[1, 2], "INPUTS", "1", input_col, input_lines)
  draw_card(xs[2, 1], xs[2, 2], "RULES", "2", rule_col, rule_lines)
  draw_card(xs[3, 1], xs[3, 2], "OUTPUTS", "3", output_col, output_lines)
  draw_card(xs[4, 1], xs[4, 2], "HANDOFF", "4", lock_col, handoff_lines)
  for (x in c(0.252, 0.497, 0.742)) {
    arrows(x - 0.006, 0.525, x + 0.010, 0.525, length = 0.07, angle = 25,
           col = "#8B949C", lwd = 1.2)
  }

  rounded_rect(0.025, 0.075, 0.980, 0.175, light, grid, 1)
  audit_x <- c(0.055, 0.265, 0.475, 0.685, 0.895)
  audit_big <- c("20", "20", "1", "v1.0", "0")
  audit_small <- c("frozen artifacts", "SHA-256 registrations", "freeze timestamp",
                   "signature version", "validation files read")
  text(audit_x, rep(0.135, 5), audit_big, cex = 0.76, font = 2,
       col = c(input_col, input_col, rule_col, output_col, lock_col))
  text(audit_x, rep(0.095, 5), audit_small, cex = 0.67, col = ink)
  segments(c(0.16, 0.37, 0.58, 0.79), 0.095, c(0.16, 0.37, 0.58, 0.79), 0.155,
           col = grid, lwd = 1)
  text(0.025, 0.028,
       paste0("Freeze time: ", unique(artifacts$frozen_at_utc),
              "  |  full paths and digests in source data"),
       adj = c(0, 0), cex = 0.67, col = "#6F7881")
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig1j.svg"), width = 7.0079, height = 4.7244,
    pointsize = 12, family = "sans", bg = "white")
draw_panel()
dev.off()
png(file.path("figures", "previews", "fig1j.png"), width = 7.0079, height = 4.7244,
    units = "in", res = 300, pointsize = 12, type = "cairo", bg = "white")
draw_panel()
dev.off()
cat("PASS: rendered Figure 1J SVG and 300-dpi PNG\n")
