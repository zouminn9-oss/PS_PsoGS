options(stringsAsFactors = FALSE)

cohorts <- read.delim(file.path("metadata", "stage03_validation_cohort_lock.tsv"), check.names = FALSE)
samples <- read.delim(file.path("metadata", "stage03_validation_sample_lock.tsv"), check.names = FALSE)
coverage <- read.delim(file.path("metadata", "stage03_platform_coverage.tsv"), check.names = FALSE)
inputs <- read.delim(file.path("metadata", "stage03_validation_input_manifest.tsv"), check.names = FALSE)
audit <- read.delim(file.path("audits", "stage03_validation_gate_checks.tsv"), check.names = FALSE)
stopifnot(nrow(cohorts) == 5L, nrow(samples) == 317L, nrow(coverage) == 10L,
          nrow(inputs) == 8L, all(audit$status == "PASS"),
          all(coverage$coverage_status == "PASS"), min(coverage$coverage_fraction) > 0.94)

cohort_source <- data.frame(record_type = "COHORT", dataset_id = cohorts$dataset_id,
  item_id = cohorts$analysis_stratum, label = cohorts$analysis_stratum,
  numerator = cohorts$samples, denominator = cohorts$independent_units,
  value = cohorts$independent_units, unit = cohorts$statistical_unit,
  status = cohorts$inclusion_status, detail = cohorts$limitation)
coverage_source <- data.frame(record_type = "COVERAGE", dataset_id = coverage$dataset_id,
  item_id = coverage$signature_id, label = coverage$signature_id,
  numerator = coverage$measurable_members, denominator = coverage$frozen_members,
  value = coverage$coverage_fraction, unit = "fraction_measurable",
  status = coverage$coverage_status, detail = coverage$mapping_rule)
summary_source <- data.frame(
  record_type = "SUMMARY", dataset_id = c("GSE30999", "GSE30999", "GSE121212", "GSE121212"),
  item_id = c("PUBLIC_SAMPLES", "HELD_SAMPLES", "PUBLIC_SAMPLES", "HELD_PRIMARY_SAMPLES"),
  label = c("public samples", "held unresolved", "public samples", "held unmatched"),
  numerator = c(170, 8, 147, 1), denominator = c(89, 4, 93, 1),
  value = c(170, 8, 147, 1), unit = "samples", status = c("SOURCE", "HOLD", "SOURCE", "HOLD"),
  detail = c("89 public subject IDs", "four NL-only and four LS-only IDs",
             "93 public donor labels", "PSO_034 lesion has no non-lesional mate"))
source <- rbind(cohort_source, coverage_source, summary_source)
dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(source, file.path("figures", "source_data", "fig2a.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)

stats <- data.frame(
  metric = c("locked_primary_array_pairs", "locked_primary_rnaseq_pairs",
             "held_array_singletons", "held_rnaseq_psoriasis_samples",
             "array_min_signature_coverage", "rnaseq_min_signature_coverage",
             "sample_lock_rows", "gate_checks_pass", "numeric_expression_effects_computed"),
  value = c(81, 27, 8, 1,
            min(coverage$coverage_fraction[coverage$dataset_id == "GSE30999"]),
            min(coverage$coverage_fraction[coverage$dataset_id == "GSE121212"]),
            nrow(samples), nrow(audit), 0),
  unit = c("paired_patients", "paired_patients", "samples", "samples", "fraction",
           "fraction", "samples", "checks", "boolean"),
  status = c(rep("PASS", 8), "PASS_LOCKED"))
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(stats, file.path("results", "figures", "fig2a_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
cat("PASS: exported Figure 2A locked-cohort and platform-coverage source data\n")
