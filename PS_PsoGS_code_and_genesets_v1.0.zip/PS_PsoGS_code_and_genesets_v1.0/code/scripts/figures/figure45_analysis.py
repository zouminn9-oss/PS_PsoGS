from __future__ import annotations

import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))
import numpy as np
import pandas as pd
import scipy.sparse as sp
from scipy import stats

SRC = ROOT / "figures/source_data"; STAT = ROOT / "results/figures"
SRC.mkdir(parents=True, exist_ok=True); STAT.mkdir(parents=True, exist_ok=True)

traj = pd.read_csv(ROOT / "results/stage05/trajectory_input_gate.tsv", sep="\t")
traj.to_csv(SRC / "fig4a.tsv", sep="\t", index=False)
pd.DataFrame([{"decision": traj.module_decision.iloc[0], "criteria_pass": int(traj['pass'].sum()), "criteria_total": len(traj)}]).to_csv(STAT / "fig4a_statistics.tsv", sep="\t", index=False)

tf = pd.read_csv(ROOT / "results/stage05/fibroblast_dorothea_paired_effects.tsv", sep="\t")
tf_elig = tf[tf.eligible].sort_values("paired_t_p").copy()
tf_elig.head(15).to_csv(SRC / "fig4h.tsv", sep="\t", index=False)
tf.to_csv(STAT / "fig4h_statistics.tsv", sep="\t", index=False)

flow = pd.DataFrame([
    ("F2 fibroblast state", "PASS", "Discovery and independent replication"),
    ("Trajectory/root", "BLOCKED", "No independently defined start/end states"),
    ("TF regulons", "NEGATIVE", "0/76 BH FDR < 0.05"),
    ("JAG2-NOTCH2", "PASS", "Discovery FDR and 3+3 direction replication"),
    ("Glutathione RNA program", "LIMIT", "Discovery FDR; replication P=0.415"),
    ("Predicted flux", "BLOCKED", "No validated scFEA network/metabolomics"),
])
flow.columns = ["module", "status", "evidence"]
flow.to_csv(SRC / "fig5a.tsv", sep="\t", index=False)
flow.to_csv(STAT / "fig5a_statistics.tsv", sep="\t", index=False)

# Reconstruct frozen discovery LR score from registered donor-celltype pseudobulk.
idx = pd.read_csv(ROOT / "results/stage05/donor_celltype_pseudobulk_index.tsv", sep="\t")
gen = pd.read_csv(ROOT / "results/stage05/donor_celltype_pseudobulk_genes.tsv", sep="\t")
mat = sp.load_npz(ROOT / "results/stage05/donor_celltype_pseudobulk_log1p_cp10k.npz").tocsr()
col = dict(zip(gen.gene_symbol.astype(str), gen.matrix_column.astype(int)))
disc = []
for donor in sorted(idx.donor_id.unique()):
    for tissue in ["PN", "PP"]:
        se = idx.index[(idx.donor_id == donor) & (idx.tissue == tissue) & (idx.cell_type == "Endothelial") & idx.eligible_min_cells]
        rf = idx.index[(idx.donor_id == donor) & (idx.tissue == tissue) & (idx.cell_type == "Fibroblast") & idx.eligible_min_cells]
        if len(se) == len(rf) == 1:
            lig = float(mat[se[0], col["JAG2"]]); rec = float(mat[rf[0], col["NOTCH2"]])
            disc.append({"cohort": "GSE173706", "donor_id": donor, "condition": tissue, "score": math.sqrt(max(lig, 0) * max(rec, 0)), "ligand_expression": lig, "receptor_expression": rec})
disc = pd.DataFrame(disc)
rep = pd.read_csv(ROOT / "results/stage05/gse162183_jag2_notch2_replication_scores.tsv", sep="\t").rename(columns={"compatibility_score": "score", "ligand_log1p_cp10k": "ligand_expression", "receptor_log1p_cp10k": "receptor_expression"})
rep["cohort"] = "GSE162183"
pd.concat([disc, rep[["cohort", "donor_id", "condition", "score", "ligand_expression", "receptor_expression"]]], ignore_index=True).to_csv(SRC / "fig5b.tsv", sep="\t", index=False)
lr_eff = pd.read_csv(ROOT / "results/stage05/cellphonedb_v5_lr_paired_effects.tsv.gz", sep="\t")
lr_sel = lr_eff[(lr_eff.sender == "Endothelial") & (lr_eff.interaction == "JAG2-NOTCH2")].copy()
lr_rep = pd.read_csv(ROOT / "results/stage05/gse162183_jag2_notch2_replication_statistics.tsv", sep="\t")
pd.concat([lr_sel.assign(cohort="GSE173706"), lr_rep.assign(cohort="GSE162183")], ignore_index=True, sort=False).to_csv(STAT / "fig5b_statistics.tsv", sep="\t", index=False)

cp_tf = pd.read_csv(ROOT / "data/raw/stage05/cellphonedb-v5.0.0/cellphonedb-data-5.0.0/data/transcription_factor_input.csv")
cp_tf = cp_tf[cp_tf.receptor_id.astype(str).eq("NOTCH2")].copy()
cp_tf = cp_tf[["receptor_id", "TF_symbol", "Effect", "Source", "Brivanlou_class"]]
cp_tf.insert(0, "ligand", "JAG2")
cp_tf.insert(1, "relation", "curated receptor-to-TF")
cp_tf.to_csv(SRC / "fig5d.tsv", sep="\t", index=False)
pd.DataFrame([{"ligand_receptor_source": "PMID:22353464", "downstream_tf_relations": len(cp_tf), "direct_signaling_claim": False}]).to_csv(STAT / "fig5d_statistics.tsv", sep="\t", index=False)

met_eff = pd.read_csv(ROOT / "results/stage05/fibroblast_reactome_metabolism_paired_effects.tsv", sep="\t")
met_eff[met_eff.variant == "primary"].sort_values("fdr_bh").to_csv(SRC / "fig5f.tsv", sep="\t", index=False)
met_eff.to_csv(STAT / "fig5f_statistics.tsv", sep="\t", index=False)

met_disc = pd.read_csv(ROOT / "results/stage05/fibroblast_reactome_metabolism_scores.tsv", sep="\t")
met_disc = met_disc[(met_disc.pathway_id == "R-HSA-174403") & (met_disc.variant == "primary")].copy()
met_disc = met_disc[met_disc.tissue.isin(["PN", "PP"])].copy()
met_disc["cohort"] = "GSE173706"; met_disc["condition"] = met_disc.tissue
met_rep = pd.read_csv(ROOT / "results/stage05/gse162183_glutathione_replication_scores.tsv", sep="\t")
met_rep["cohort"] = "GSE162183"
pd.concat([met_disc[["cohort", "donor_id", "condition", "score", "n_genes"]], met_rep[["cohort", "donor_id", "condition", "score", "n_genes"]]], ignore_index=True).to_csv(SRC / "fig5g.tsv", sep="\t", index=False)
met_stats = pd.concat([
    met_eff[(met_eff.pathway_id == "R-HSA-174403") & (met_eff.variant == "primary")].assign(cohort="GSE173706"),
    pd.read_csv(ROOT / "results/stage05/gse162183_glutathione_replication_statistics.tsv", sep="\t").assign(cohort="GSE162183")
], ignore_index=True, sort=False)
met_stats.to_csv(STAT / "fig5g_statistics.tsv", sep="\t", index=False)

# Primary versus overlap-removed sensitivity; explicit NOT_ESTIMABLE rows are retained.
pathways = met_eff[["pathway_id", "pathway"]].drop_duplicates()
sens = pathways.merge(met_eff, on=["pathway_id", "pathway"], how="left")
missing = []
for row in pathways.itertuples(index=False):
    if not ((met_eff.pathway_id == row.pathway_id) & (met_eff.variant == "remove_sep_cell_cycle")).any():
        x = met_eff[(met_eff.pathway_id == row.pathway_id) & (met_eff.variant == "primary")].iloc[0].to_dict()
        x.update({"variant": "remove_sep_cell_cycle", "mean_pp_minus_pn": np.nan, "ci95_low": np.nan, "ci95_high": np.nan, "paired_t_p": np.nan, "fdr_bh": np.nan, "eligible": False})
        missing.append(x)
sens = pd.concat([met_eff, pd.DataFrame(missing)], ignore_index=True).sort_values(["pathway", "variant"])
sens.to_csv(SRC / "fig5i.tsv", sep="\t", index=False)
sens.to_csv(STAT / "fig5i_statistics.tsv", sep="\t", index=False)

# Exploratory association of the two independently screened discovery changes.
lr_w = disc.pivot(index="donor_id", columns="condition", values="score").dropna()
met_w = met_disc.pivot(index="donor_id", columns="condition", values="score").dropna()
common = sorted(set(lr_w.index) & set(met_w.index))
couple = pd.DataFrame({"donor_id": common, "lr_delta": [lr_w.loc[d, "PP"] - lr_w.loc[d, "PN"] for d in common], "glutathione_delta": [met_w.loc[d, "PP"] - met_w.loc[d, "PN"] for d in common]})
rho, p = stats.spearmanr(couple.lr_delta, couple.glutathione_delta)
couple.to_csv(SRC / "fig5j.tsv", sep="\t", index=False)
pd.DataFrame([{"n_donors": len(couple), "spearman_rho": rho, "spearman_p": p, "analysis_status": "EXPLORATORY_POST_SCREEN"}]).to_csv(STAT / "fig5j_statistics.tsv", sep="\t", index=False)

claims = pd.DataFrame([
    ("Fibroblast carries F2", "PASS", "paired discovery + independent direction replication", "association"),
    ("Ordered fibroblast trajectory", "BLOCKED", "no defensible root or distinct terminal states", "not tested"),
    ("Differential TF activity", "FAIL", "0/76 regulons at BH FDR<0.05", "negative result"),
    ("Endothelial JAG2-Fibroblast NOTCH2 compatibility", "LIMIT", "discovery FDR<0.05 and 3+3 replication P<0.05", "expression compatibility, not signaling"),
    ("Glutathione transcript program", "LIMIT", "discovery FDR<0.05; independent replication failed", "not metabolite/flux"),
    ("Metabolic flux remodeling", "BLOCKED", "no metabolomics or validated model run", "not tested"),
])
claims.columns = ["claim", "status", "evidence", "claim_ceiling"]
claims.to_csv(SRC / "fig5l.tsv", sep="\t", index=False)
claims.to_csv(STAT / "fig5l_statistics.tsv", sep="\t", index=False)

print("PASS: Figure 4/5 source data and statistics written")
