options(stringsAsFactors = FALSE)

cfg_lines <- readLines(file.path("config", "figures", "fig1c.yaml"), warn = FALSE)
cfg <- function(key, default = NA_character_) {
  hit <- grep(paste0("^", key, ":"), cfg_lines, value = TRUE)
  if (!length(hit)) return(default)
  gsub('^"|"$', '', trimws(sub("^[^:]+:", "", hit[1])))
}

dat <- read.delim(file.path("figures", "source_data", "fig1c.tsv"),
                  check.names = FALSE, stringsAsFactors = FALSE)
groups <- dat[dat$record_type == "GROUP", ]
stopifnot(nrow(groups) == 4L, all(groups$n == 3L))

width <- as.numeric(cfg("width_inches"))
height <- as.numeric(cfg("height_inches"))
dpi <- as.numeric(cfg("png_dpi"))
blue <- cfg("blue"); orange <- cfg("orange"); ink <- cfg("ink")
mid_grey <- cfg("mid_grey"); light_grey <- cfg("light_grey")
blue_light <- cfg("blue_light"); orange_light <- cfg("orange_light")

draw_panel <- function() {
  par(family = "sans", fg = ink, bty = "n", mar = c(3.6, 1, 3.8, 1), xpd = NA)
  plot(NA, xlim = c(0, 10), ylim = c(0.25, 8.4), axes = FALSE,
       xlab = "", ylab = "", xaxs = "i", yaxs = "i")
  title(main = "C  GSE212126 factorial design and estimands", adj = 0,
        cex.main = 1.02, font.main = 2, line = 2.05)
  mtext("12 independent mice | one RNA-seq library per mouse | no pooling | design only", side = 3,
        adj = 0, line = 0.48, cex = 0.74, col = mid_grey)

  text(0.55, 7.95, "2 x 2 DESIGN", adj = 0, cex = 0.72, font = 2, col = blue)
  text(0.55, 6.75, "IMQ", adj = 0.5, cex = 0.72, font = 2, col = ink)
  text(1.25, 7.02, "0", cex = 0.7, font = 2, col = mid_grey)
  text(1.25, 4.7, "1", cex = 0.7, font = 2, col = mid_grey)
  text(2.55, 7.62, "CRS = 0", cex = 0.72, font = 2, col = ink)
  text(4.65, 7.62, "CRS = 1", cex = 0.72, font = 2, col = ink)

  cells <- data.frame(x = c(2.55, 4.65, 2.55, 4.65), y = c(6.6, 6.6, 4.3, 4.3),
                      label = c("Control", "CRS", "IMQ", "CRS + IMQ"),
                      fill = c(light_grey, blue_light, orange_light, "#E9E3DA"),
                      border = c(mid_grey, blue, orange, ink), stringsAsFactors = FALSE)
  for (i in seq_len(nrow(cells))) {
    rect(cells$x[i] - 0.9, cells$y[i] - 0.78, cells$x[i] + 0.9, cells$y[i] + 0.78,
         col = cells$fill[i], border = cells$border[i], lwd = 1.2)
    text(cells$x[i], cells$y[i] + 0.45, cells$label[i], cex = 0.76, font = 2, col = ink)
    points(cells$x[i] + c(-0.42, 0, 0.42), rep(cells$y[i] - 0.02, 3),
           pch = 21, bg = "white", col = cells$border[i], cex = 1.12, lwd = 1.1)
    text(cells$x[i], cells$y[i] - 0.47, "n = 3 mice / 3 libraries", cex = 0.67, col = ink)
  }
  arrows(3.48, 6.6, 3.72, 6.6, length = 0.06, angle = 24, col = blue, lwd = 1.1)
  arrows(3.48, 4.3, 3.72, 4.3, length = 0.06, angle = 24, col = blue, lwd = 1.1)
  text(3.6, 6.9, "S0", cex = 0.7, font = 2, col = blue)
  text(3.6, 4.6, "SD", cex = 0.7, font = 2, col = blue)

  rect(5.9, 3.65, 9.72, 7.45, col = "white", border = mid_grey, lwd = 1.1)
  text(6.15, 7.08, "PRE-SPECIFIED ESTIMANDS", adj = 0, cex = 0.72, font = 2, col = ink)
  text(6.15, 6.48, "S0", adj = 0, cex = 0.78, font = 2, col = blue)
  text(6.82, 6.48, "=  mu(CRS) - mu(Control)", adj = 0, cex = 0.7, col = ink)
  text(6.15, 5.72, "SD", adj = 0, cex = 0.78, font = 2, col = blue)
  text(6.82, 5.72, "=  mu(CRS+IMQ) - mu(IMQ)", adj = 0, cex = 0.7, col = ink)
  text(6.15, 4.96, "I", adj = 0, cex = 0.78, font = 2, col = orange)
  text(6.82, 4.96, "=  SD - S0", adj = 0, cex = 0.7, col = ink)
  text(6.15, 4.28, "Model after count QC:  ~ CRS + IMQ + CRS:IMQ", adj = 0,
       cex = 0.67, font = 2, col = mid_grey)

  rect(0.55, 2.25, 4.95, 3.08, col = blue_light, border = blue, lwd = 1.1)
  text(2.75, 2.78, "PASS: independent-animal / no-pooling design", cex = 0.7,
       font = 2, col = blue)
  text(2.75, 2.48, "User-confirmed; original animal IDs/source document not archived", cex = 0.67, col = ink)
  rect(5.2, 2.25, 9.72, 3.08, col = blue_light, border = blue, lwd = 1.1)
  text(7.46, 2.78, "PASS: count and model audits", cex = 0.7, font = 2, col = blue)
  text(7.46, 2.48, "12 libraries; frozen S0 / SD / I outputs", cex = 0.67, col = ink)

  text(0.55, 1.45, "Statistical unit after count QC: independent mouse (not read, library fragment or gene).", adj = 0,
       cex = 0.67, col = ink)
  text(0.55, 1.02, "Effects exist in Stage 02 outputs but are not displayed in this design-only panel.", adj = 0,
       cex = 0.67, col = mid_grey)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig1c.svg"), width = width, height = height,
    pointsize = 12, bg = "white", family = "sans")
draw_panel(); dev.off()
png(file.path("figures", "previews", "fig1c.png"), width = width, height = height,
    units = "in", res = dpi, pointsize = 12, bg = "white")
draw_panel(); dev.off()
cat("PASS: rendered fig1c SVG and 300-dpi PNG\n")
