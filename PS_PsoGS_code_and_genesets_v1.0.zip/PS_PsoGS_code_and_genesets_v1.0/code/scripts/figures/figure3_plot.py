#!/usr/bin/env python3
"""Render Figure 3A-L from frozen source-data tables."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

SRC = ROOT / "figures/source_data"
PANELS = ROOT / "figures/panels"
PREVIEWS = ROOT / "figures/previews"
CAPTIONS = ROOT / "figures/captions"
for path in [PANELS, PREVIEWS, CAPTIONS]: path.mkdir(parents=True, exist_ok=True)

COLORS = {
    "Keratinocyte": "#D55E00", "Fibroblast": "#0072B2", "Endothelial": "#009E73",
    "T_cell": "#CC79A7", "Myeloid": "#E69F00", "Mast": "#56B4E9",
    "Melanocyte": "#000000", "Eccrine": "#F0E442", "Smooth_muscle": "#6A3D9A",
    "Nerve_glial": "#8C564B", "Uncertain": "#BDBDBD",
}


def read(panel): return pd.read_csv(SRC / f"fig{panel}.tsv", sep="\t")


def finish(fig, panel):
    fig.savefig(PANELS / f"fig{panel}.svg", bbox_inches="tight")
    fig.savefig(PREVIEWS / f"fig{panel}.png", dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def scatter_groups(ax, data, x, y, group, size=1.0):
    for label in sorted(data[group].unique()):
        subset = data.loc[data[group] == label]
        ax.scatter(subset[x], subset[y], s=size, c=COLORS.get(label, "#777777"), alpha=0.65,
                   linewidths=0, rasterized=True, label=label)
    ax.set(xticks=[], yticks=[], xlabel="UMAP 1", ylabel="UMAP 2")


def main():
    rng = np.random.default_rng(20260911)
    a = read("3a")
    display = a.iloc[np.sort(rng.choice(len(a), min(50000, len(a)), replace=False))]
    fig, ax = plt.subplots(figsize=(7.2, 5.2), constrained_layout=True)
    scatter_groups(ax, display, "umap_1", "umap_2", "cell_type", 1.2)
    ax.legend(markerscale=5, frameon=False, bbox_to_anchor=(1.01, 0.5), loc="center left", fontsize=7)
    ax.set_title("A  QC-filtered discovery atlas (75,209 cells)", loc="left", fontweight="bold")
    finish(fig, "3a")

    b = read("3b")
    types = [x for x in COLORS if x != "Uncertain" and x in set(b["cell_type"])]
    markers = list(dict.fromkeys(b["marker"]))
    b = b.loc[b["cell_type"].isin(types)]
    fig, ax = plt.subplots(figsize=(9, 5.5), constrained_layout=True)
    x = b["marker"].map({v: i for i, v in enumerate(markers)}); y = b["cell_type"].map({v: i for i, v in enumerate(types)})
    points = ax.scatter(x, y, s=8 + 75 * b["detection_fraction"].fillna(0), c=b["mean_log1p_cp10k"], cmap="viridis", linewidths=0)
    ax.set_xticks(range(len(markers)), markers, rotation=90, fontsize=7); ax.set_yticks(range(len(types)), types, fontsize=8)
    ax.set_title("B  Canonical multi-marker support", loc="left", fontweight="bold")
    fig.colorbar(points, ax=ax, label="Mean log1p(CP10k)", shrink=.75)
    finish(fig, "3b")

    c = read("3c")
    samples = c[["sample_id", "tissue"]].drop_duplicates().sort_values(["tissue", "sample_id"])["sample_id"].tolist()
    celltypes = [x for x in COLORS if x in set(c["cell_type"])]
    pivot = c.pivot(index="sample_id", columns="cell_type", values="cell_fraction").fillna(0).reindex(samples)
    fig, ax = plt.subplots(figsize=(10, 5.5), constrained_layout=True)
    bottom = np.zeros(len(samples))
    for celltype in celltypes:
        values = pivot.get(celltype, pd.Series(0, index=samples)).to_numpy()
        ax.bar(range(len(samples)), values, bottom=bottom, width=.85, color=COLORS[celltype], label=celltype)
        bottom += values
    ax.set_xticks(range(len(samples)), samples, rotation=90, fontsize=6); ax.set_ylabel("Fraction of retained library cells"); ax.set_ylim(0, 1)
    ax.legend(ncol=2, frameon=False, fontsize=7, bbox_to_anchor=(1.01, .5), loc="center left")
    ax.set_title("C  Per-library cell composition (denominator = retained cells)", loc="left", fontweight="bold")
    finish(fig, "3c")

    d = read("3d")
    fig, axes = plt.subplots(1, 3, figsize=(10, 3.8), sharex=True, sharey=True, constrained_layout=True)
    for ax, tissue in zip(axes, ["NS", "PN", "PP"]):
        subset = d.loc[d["tissue"] == tissue]
        scatter_groups(ax, subset, "umap_1", "umap_2", "cell_type", .7)
        ax.set_title(f"{tissue}  n={len(subset):,}")
    axes[0].set_ylabel("Shared UMAP 2")
    fig.suptitle("D  Condition facets on one fixed embedding", x=.01, ha="left", fontweight="bold")
    finish(fig, "3d")

    e = read("3e")
    show = e.iloc[np.sort(rng.choice(len(e), min(50000, len(e)), replace=False))]
    low, high = np.quantile(show["ucell_core_directed"], [.01, .99])
    fig, ax = plt.subplots(figsize=(7.2, 5.2), constrained_layout=True)
    point = ax.scatter(show["umap_1"], show["umap_2"], s=1.1, c=show["ucell_core_directed"], cmap="coolwarm", vmin=low, vmax=high, linewidths=0, rasterized=True)
    ax.set(xticks=[], yticks=[], xlabel="UMAP 1", ylabel="UMAP 2"); fig.colorbar(point, ax=ax, label="Core UCell UP − DOWN")
    ax.set_title("E  Frozen Core localization", loc="left", fontweight="bold")
    finish(fig, "3e")

    f = read("3f"); f = f.loc[f["eligible_min_cells"].astype(str).str.lower().eq("true")]
    summary = f.groupby(["cell_type", "tissue"], observed=True).agg(score=("ucell_sep_directed", "mean"), donors=("donor_id", "nunique")).reset_index()
    types = sorted(summary["cell_type"].unique()); tissues = [x for x in ["NS", "PN", "PP"] if x in set(summary["tissue"])]
    fig, ax = plt.subplots(figsize=(7.5, 6), constrained_layout=True)
    x = summary["tissue"].map({v:i for i,v in enumerate(tissues)}); y = summary["cell_type"].map({v:i for i,v in enumerate(types)})
    point = ax.scatter(x, y, s=20 + 12 * summary["donors"], c=summary["score"], cmap="coolwarm", linewidths=.3, edgecolors="black")
    ax.set_xticks(range(len(tissues)), tissues); ax.set_yticks(range(len(types)), types)
    fig.colorbar(point, ax=ax, label="Mean donor SEP UCell UP − DOWN")
    ax.set_title("F  SEP localization across cell types and tissues", loc="left", fontweight="bold")
    finish(fig, "3f")

    g = read("3g"); programs = ["ucell_core_directed", "ucell_sep_directed"]; types = sorted(g["cell_type"].unique())
    matrix = g.pivot(index="cell_type", columns="program", values="mean_pp_minus_pn").reindex(types)[programs]
    fdr = g.pivot(index="cell_type", columns="program", values="paired_t_fdr_bh").reindex(types)[programs]
    fig, ax = plt.subplots(figsize=(6.5, 5.5), constrained_layout=True)
    vmax = np.nanmax(np.abs(matrix.to_numpy())); image = ax.imshow(matrix, cmap="coolwarm", vmin=-vmax, vmax=vmax, aspect="auto")
    ax.set_xticks(range(2), ["Core", "SEP"]); ax.set_yticks(range(len(types)), types)
    for iy in range(len(types)):
        for ix in range(2):
            value = matrix.iloc[iy, ix]; mark = "*" if fdr.iloc[iy, ix] < .05 else ""
            ax.text(ix, iy, f"{value:.3f}{mark}", ha="center", va="center", fontsize=7)
    fig.colorbar(image, ax=ax, label="Mean paired PP − PN")
    ax.set_title("G  Donor-level paired program effects", loc="left", fontweight="bold")
    finish(fig, "3g")

    h = read("3h"); pivot = h.pivot(index="donor_id", columns="tissue", values="ucell_sep_directed").dropna()
    fig, ax = plt.subplots(figsize=(5.2, 5.2), constrained_layout=True)
    for donor_id, row in pivot.iterrows():
        ax.plot([0, 1], [row["PN"], row["PP"]], color="#777777", alpha=.65, linewidth=.8)
        ax.scatter([0, 1], [row["PN"], row["PP"]], c=["#56B4E9", "#D55E00"], s=24, zorder=3)
    ax.set_xticks([0, 1], ["PN", "PP"]); ax.set_ylabel("Fibroblast SEP UCell UP − DOWN")
    ax.set_title(f"H  Paired F2 fibroblasts (n={len(pivot)} donors)", loc="left", fontweight="bold")
    finish(fig, "3h")

    i = read("3i"); fig, axes = plt.subplots(1, 2, figsize=(9, 4.5), constrained_layout=True)
    clusters = sorted(i["fibro_leiden_06"].astype(str).unique(), key=int)
    cmap = plt.get_cmap("tab20")
    for j, cluster in enumerate(clusters):
        sub = i.loc[i["fibro_leiden_06"].astype(str) == cluster]
        axes[0].scatter(sub["fibro_umap_1"], sub["fibro_umap_2"], s=1.5, color=cmap(j), linewidths=0, rasterized=True, label=cluster)
    axes[0].legend(title="Cluster", ncol=2, frameon=False, fontsize=6); axes[0].set_title("Label-blind clusters")
    for label, color in [("SFRP2", "#0072B2"), ("Uncertain_fibroblast", "#BDBDBD")]:
        sub = i.loc[i["fibroblast_subtype"] == label]
        axes[1].scatter(sub["fibro_umap_1"], sub["fibro_umap_2"], s=1.5, color=color, linewidths=0, rasterized=True, label=label)
    axes[1].legend(frameon=False, fontsize=7); axes[1].set_title("Marker-adjudicated subtype")
    for ax in axes: ax.set(xticks=[], yticks=[], xlabel="Fibro UMAP 1", ylabel="Fibro UMAP 2")
    fig.suptitle("I  F2 fibroblast subatlas (9,501 cells)", x=.01, ha="left", fontweight="bold")
    finish(fig, "3i")

    j = read("3j").sort_values("mean_pp_minus_pn")
    fig, ax = plt.subplots(figsize=(7.2, 5.5), constrained_layout=True); y = np.arange(len(j))
    ax.errorbar(j["mean_pp_minus_pn"], y, xerr=[j["mean_pp_minus_pn"]-j["ci95_low"], j["ci95_high"]-j["mean_pp_minus_pn"]], fmt="o", color="#0072B2", capsize=2)
    ax.axvline(0, color="black", linewidth=.8); ax.set_yticks(y, j["cell_type"]); ax.set_xlabel("Paired PP − PN cell fraction")
    ax.set_title("J  Donor-level differential abundance", loc="left", fontweight="bold")
    finish(fig, "3j")

    k = read("3k"); k = k.loc[k["program"].eq("ucell_sep_directed")].sort_values("mean_psoriasis_minus_control")
    fig, ax = plt.subplots(figsize=(8, 6), constrained_layout=True); y = np.arange(len(k))
    colors = np.where(k["f2_target"].astype(str).str.lower().eq("true"), "#D55E00", "#0072B2")
    for yi, (_, row), color in zip(y, k.iterrows(), colors):
        ax.errorbar(row["mean_psoriasis_minus_control"], yi, xerr=[[row["mean_psoriasis_minus_control"]-row["ci95_low"]], [row["ci95_high"]-row["mean_psoriasis_minus_control"]]], fmt="o", color=color, capsize=2)
    ax.axvline(0, color="black", linewidth=.8); ax.set_yticks(y, k["cell_type"]); ax.set_xlabel("Psoriasis − control SEP score")
    ax.set_title("K  Independent GSE162183 replication (3 vs 3 donors)", loc="left", fontweight="bold")
    finish(fig, "3k")

    l = read("3l"); cohorts = list(l["cohort"].unique()); components = ["composition", "within_cell", "interaction"]
    fig, ax = plt.subplots(figsize=(7.2, 5.2), constrained_layout=True); width=.22; positions=np.arange(len(cohorts))
    colors_l = ["#56B4E9", "#D55E00", "#999999"]
    for offset, component, color in zip([-width, 0, width], components, colors_l):
        values = [l.loc[(l["cohort"]==cohort)&(l["component"]==component), "contribution"].iloc[0] for cohort in cohorts]
        ax.bar(positions+offset, values, width, label=component, color=color)
    totals = [l.loc[(l["cohort"]==cohort)&(l["component"]=="total"), "contribution"].iloc[0] for cohort in cohorts]
    ax.scatter(positions, totals, marker="D", c="black", label="total", zorder=4)
    ax.axhline(0, color="black", linewidth=.8); ax.set_xticks(positions, ["GSE173706\npaired", "GSE162183\nunpaired"])
    ax.set_ylabel("SEP score contribution"); ax.legend(frameon=False)
    ax.set_title("L  Composition versus within-cell decomposition", loc="left", fontweight="bold")
    finish(fig, "3l")

    captions = {
        "3a": "Figure 3A. Harmony-integrated UMAP of 75,209 QC- and doublet-filtered GSE173706 cells, colored by final multi-marker major lineage. Cells are display units; donors are inferential units.",
        "3b": "Figure 3B. Dot plot of three canonical markers per adjudicated lineage. Dot size is the fraction detected and color is mean log1p counts per 10,000. Ambiguous cells were not forced into a lineage.",
        "3c": "Figure 3C. Cell composition for all 33 discovery libraries after QC. Each bar sums to one using retained cells in that library as denominator; this is yield/composition description, not differential-abundance inference.",
        "3d": "Figure 3D. Healthy normal (NS), psoriasis non-lesional (PN), and psoriasis lesional (PP) cells shown on the same fixed embedding and axes. Apparent cell density is descriptive.",
        "3e": "Figure 3E. Frozen Core UCell directed score (UP minus DOWN; maxRank 5,000) on the discovery embedding. Color limits are fixed at the 1st and 99th percentiles for display only; statistics are donor-level.",
        "3f": "Figure 3F. Mean donor-cell-type SEP directed UCell score by tissue. Only donor-cell-type groups with at least 20 cells enter; size encodes donor count and color encodes mean score.",
        "3g": "Figure 3G. Paired PP-minus-PN Core and SEP effects across eligible cell types. Values are mean donor differences; asterisks denote BH FDR below 0.05 across eligible cell types within program.",
        "3h": "Figure 3H. Within-donor PN-to-PP SEP changes in the frozen F2 fibroblast target (8 complete donors with at least 20 cells per tissue). Lines join the same donor; inference uses the paired donor differences.",
        "3i": "Figure 3I. Label-blind fibroblast subatlas. Ten clusters were tested against four literature-defined marker modules; only SFRP2 had sufficient marker dominance, while non-dominant cells remain Uncertain_fibroblast.",
        "3j": "Figure 3J. Paired PP-minus-PN library-fraction effects with t-based 95% confidence intervals. Donor/library is the replicate; abundance is not conflated with within-cell expression.",
        "3k": "Figure 3K. Independent GSE162183 psoriasis-minus-control SEP effects (3 independent donors per group) after frozen discovery-label transfer. Orange marks the pre-frozen fibroblast target. Intervals are Welch 95% CIs.",
        "3l": "Figure 3L. Oaxaca-style algebraic decomposition of the cohort mean SEP shift into composition, within-cell, and interaction terms. GSE173706 is paired and GSE162183 is an unpaired group summary; decomposition is model-based, not causal.",
    }
    for panel, caption in captions.items():
        (CAPTIONS / f"fig{panel}.md").write_text(caption + "\n", encoding="utf-8")
    print("PASS: rendered Figure 3A-L SVG and 300-dpi PNG with captions")


if __name__ == "__main__":
    main()
