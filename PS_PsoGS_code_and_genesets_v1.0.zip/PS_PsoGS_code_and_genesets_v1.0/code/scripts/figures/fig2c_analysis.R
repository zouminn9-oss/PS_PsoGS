options(stringsAsFactors = FALSE)

meta <- read.delim(file.path("results", "stage03", "scores", "score_meta.tsv"),
                   check.names = FALSE)
heterogeneity <- read.delim(file.path("results", "stage03", "scores",
                                     "score_meta_heterogeneity.tsv"), check.names = FALSE)
audit <- read.delim(file.path("audits", "stage03_score_meta_checks.tsv"), check.names = FALSE)
stopifnot(nrow(meta) == 4L, nrow(heterogeneity) == 1L, all(audit$status == "PASS"),
          sum(meta$record_type == "COHORT") == 2L, sum(meta$record_type == "SUMMARY") == 2L,
          all(meta$ci_low > 0), heterogeneity$k_cohorts == 2L,
          heterogeneity$stable_heterogeneity_claim_allowed == "NO_K_LT_3")

source <- meta
source$direction <- "positive means stronger frozen SEP direction in lesion"
source$display_order <- match(source$dataset_id,
                              c("GSE30999", "GSE121212", "FIXED", "RANDOM_DL"))
source <- source[order(source$display_order), ]
dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(source, file.path("figures", "source_data", "fig2c.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE, na = "")

figure_stats <- data.frame(
  k_cohorts = heterogeneity$k_cohorts,
  total_pairs = sum(meta$n_pairs[meta$record_type == "COHORT"]),
  Q = heterogeneity$Q,
  Q_df = heterogeneity$Q_df,
  Q_p_value = heterogeneity$Q_p_value,
  I2_percent = heterogeneity$I2_percent,
  tau2_DL = heterogeneity$tau2_DL,
  fixed_effect = meta$effect[meta$dataset_id == "FIXED"],
  fixed_ci_low = meta$ci_low[meta$dataset_id == "FIXED"],
  fixed_ci_high = meta$ci_high[meta$dataset_id == "FIXED"],
  random_DL_effect = meta$effect[meta$dataset_id == "RANDOM_DL"],
  random_DL_ci_low = meta$ci_low[meta$dataset_id == "RANDOM_DL"],
  random_DL_ci_high = meta$ci_high[meta$dataset_id == "RANDOM_DL"],
  heterogeneity_claim = heterogeneity$stable_heterogeneity_claim_allowed,
  limitation = heterogeneity$interpretation
)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(figure_stats, file.path("results", "figures", "fig2c_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
cat("PASS: exported Figure 2C frozen meta-analysis source and heterogeneity statistics\n")
