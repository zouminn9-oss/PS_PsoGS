from pathlib import Path
import csv
from PIL import Image

root = Path(__file__).resolve().parents[2]
checks = []

def check(name, condition):
    checks.append((name, bool(condition)))

source = root / "figures/source_data/fig1k.tsv"
stats = root / "results/figures/fig1k_statistics.tsv"
svg = root / "figures/panels/fig1k.svg"
png = root / "figures/previews/fig1k.png"
caption = root / "figures/captions/fig1k.md"
config = root / "config/figures/fig1k.yaml"
analysis = root / "scripts/figures/fig1k_analysis.R"
plot = root / "scripts/figures/fig1k_plot.R"
for p in (source, stats, svg, png, caption, config, analysis, plot):
    check(f"exists:{p.relative_to(root)}", p.exists() and p.stat().st_size > 0)

if source.exists():
    rows = list(csv.DictReader(source.open(encoding="utf-8"), delimiter="\t"))
    check("source_rows_9", len(rows) == 9)
    check("three_genes", len({r["human_gene_symbol"] for r in rows}) == 3)
    check("three_estimands", {r["estimand"] for r in rows} == {"S0", "SD", "I"})
    check("interval_contains_estimate", all(float(r["ci95_low"]) < float(r["log2_fold_change"]) < float(r["ci95_high"]) for r in rows))
if png.exists():
    with Image.open(png) as im:
        check("png_dimensions", im.size == (2102, 1417))
        check("png_mode", im.mode in {"RGB", "RGBA"})

out = root / "results/figures/fig1k_qa.tsv"
with out.open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh, delimiter="\t")
    w.writerow(["check", "status"])
    for name, ok in checks:
        w.writerow([name, "PASS" if ok else "FAIL"])
failed = [name for name, ok in checks if not ok]
if failed:
    raise SystemExit("FAIL: " + ", ".join(failed))
print(f"PASS: {len(checks)} Figure 1K checks")
