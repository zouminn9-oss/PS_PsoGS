from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'python_libs/stage04'))
import pandas as pd
import numpy as np

SRC=ROOT/'figures/source_data';STAT=ROOT/'results/figures';SRC.mkdir(parents=True,exist_ok=True);STAT.mkdir(parents=True,exist_ok=True)
qc=pd.read_csv(ROOT/'results/stage06/section_qc.tsv',sep='\t')
spots=pd.read_csv(ROOT/'results/stage06/spot_scores.tsv.gz',sep='\t')
mapping=pd.read_csv(ROOT/'results/stage06/cell_mapping.tsv.gz',sep='\t')
comp=pd.read_csv(ROOT/'results/stage06/compartments.tsv',sep='\t')
sens=pd.read_csv(ROOT/'results/stage06/reference_sensitivity.tsv',sep='\t')
effects=pd.read_csv(ROOT/'results/stage06/section_effects.tsv',sep='\t')

qc.to_csv(SRC/'fig6a.tsv',sep='\t',index=False);qc.to_csv(STAT/'fig6a_statistics.tsv',sep='\t',index=False)
coords=spots[['section','barcode','x_hires','y_hires','qc_pass']]
b=coords.merge(mapping[['section','barcode','disease','chemistry','expression_compartment']],on=['section','barcode'])
b.to_csv(SRC/'fig6b.tsv',sep='\t',index=False);comp.to_csv(STAT/'fig6b_statistics.tsv',sep='\t',index=False)

ct=[c for c in mapping.columns if c not in ['section','barcode','disease','chemistry','qc_pass','expression_compartment','nnls_residual']]
c=mapping[mapping.qc_pass].groupby(['section','disease','chemistry'])[ct].median().reset_index()
c.to_csv(SRC/'fig6c.tsv',sep='\t',index=False);c.to_csv(STAT/'fig6c_statistics.tsv',sep='\t',index=False)

for panel,score in [('6d','core_directed'),('6e','sep_directed'),('6g','glutathione_rna')]:
    z=spots.loc[spots.qc_pass,['section','barcode','disease','chemistry','x_hires','y_hires',score]].copy()
    z.to_csv(SRC/f'fig{panel}.tsv',sep='\t',index=False)
    st=z.groupby(['section','disease','chemistry'])[score].agg(['count','median',lambda x:np.quantile(x,.25),lambda x:np.quantile(x,.75)]).reset_index()
    st.columns=['section','disease','chemistry','n_spots','median','q25','q75'];st.to_csv(STAT/f'fig{panel}_statistics.tsv',sep='\t',index=False)

f=spots.loc[spots.qc_pass,['section','barcode','disease','chemistry','x_hires','y_hires','JAG2_log1p_cp10k','NOTCH2_log1p_cp10k']].copy()
f.to_csv(SRC/'fig6f.tsv',sep='\t',index=False)
fs=[]
for (s,d,ch),x in f.groupby(['section','disease','chemistry']):
    fs.append({'section':s,'disease':d,'chemistry':ch,'n_spots':len(x),'JAG2_detection_fraction':(x.JAG2_log1p_cp10k>0).mean(),'NOTCH2_detection_fraction':(x.NOTCH2_log1p_cp10k>0).mean(),'JAG2_median':x.JAG2_log1p_cp10k.median(),'NOTCH2_median':x.NOTCH2_log1p_cp10k.median(),'colocalization_test':'BLOCKED_BY_PRIMARY_PAPER_QUALITY_LIMITATION'})
pd.DataFrame(fs).to_csv(STAT/'fig6f_statistics.tsv',sep='\t',index=False)

effects.to_csv(SRC/'fig6k.tsv',sep='\t',index=False);effects.to_csv(STAT/'fig6k_statistics.tsv',sep='\t',index=False)
sens.to_csv(SRC/'fig6l.tsv',sep='\t',index=False);sens.to_csv(STAT/'fig6l_statistics.tsv',sep='\t',index=False)
print('PASS: Figure 6 source data and statistics written')
