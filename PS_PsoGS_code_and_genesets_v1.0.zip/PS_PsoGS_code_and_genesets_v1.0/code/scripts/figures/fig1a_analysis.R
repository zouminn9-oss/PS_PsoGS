options(stringsAsFactors = FALSE)

datasets <- read.delim(file.path("metadata", "dataset_manifest.tsv"),
                       check.names = FALSE, stringsAsFactors = FALSE)
signatures <- read.delim(file.path("metadata", "signature_registry.tsv"),
                         check.names = FALSE, stringsAsFactors = FALSE)
panels <- read.delim("panel_manifest.tsv", check.names = FALSE,
                     stringsAsFactors = FALSE)
animal_registry <- read.delim(file.path("metadata", "gse212126_library_animal_registry.tsv"),
                              check.names = FALSE, stringsAsFactors = FALSE)
animal_confirmation <- read.delim(file.path("audits", "gse212126_user_confirmation.tsv"),
                                  check.names = FALSE, stringsAsFactors = FALSE)

stopifnot(nrow(datasets) == 13L)
stopifnot(sum(as.integer(datasets$public_sample_records)) == 1381L)
stopifnot(nrow(panels) == 90L)
stopifnot(all(c("PS_PsoGS_Core_v1.0", "PS_PsoGS_Interaction_v1.0", "SEP_v1.0") %in%
              signatures$signature_id))
stopifnot(datasets$stage00_status[datasets$dataset_id == "GSE212126"] ==
            "PASS_WITH_USER_CONFIRMED_ANIMAL_PROVENANCE")
stopifnot(nrow(animal_registry) == 12L,
          length(unique(animal_registry$canonical_animal_id)) == 12L)
stopifnot(all(animal_registry$libraries_per_animal == 1L),
          all(animal_registry$animals_per_library == 1L))
stopifnot(all(animal_registry$pooling_status == "NO_POOLING_USER_CONFIRMED"))
stopifnot(animal_confirmation$animal_gate_status == "PASS_USER_CONFIRMED")

nodes <- data.frame(
  record_type = "NODE",
  record_id = paste0("N", 1:10),
  step = as.character(1:10),
  stage = c("Stage 00", "Stage 01", "Stage 02", "F1", "Stage 03",
            "Stage 04", "F2", "Stage 05-07", "F3", "Stage 08"),
  label = c("Audit", "PS-Reference", "Discovery", "F1", "Bulk validation",
            "Cell localization", "F2", "Context / treatment", "F3", "Drug ranking"),
  detail = c("13 datasets", "strata frozen", "S0 / SD / I frozen", "Core / Int. / SEP",
             "locked cohorts", "donor-level", "state/target freeze", "gated modules",
             "drug-query freeze", "multi-axis evidence"),
  status = c("PARTIAL", "PASS", "PASS", "PASS", "PLANNED",
             "PLANNED", "BLOCKED", "PARTIAL", "BLOCKED", "BLOCKED"),
  status_label = c("PARTIAL", "PASS", "PASS", "PASS", "READY F1",
                   "READY F1", "WAIT S4", "PARTIAL / GATED", "WAIT", "BLOCKED"),
  gate_type = c("STAGE", "STAGE", "STAGE", "FREEZE", "STAGE",
                "STAGE", "FREEZE", "STAGE", "FREEZE", "STAGE"),
  x = c(1, 3, 5, 7, 9, 9, 7, 5, 3, 1),
  y = c(rep(5.25, 5), rep(2.35, 5)),
  source_ids = c(
    "13 audited GEO series",
    "CTRA;GSE70603;GSE270712;GSE270713;GSE26487;QuickGO",
    "GSE212126;GSE13355",
    "PS_PsoGS_Core;PS_PsoGS_Interaction;SEP",
    "GSE30999;GSE121212",
    "GSE173706;GSE162183",
    "F2 registry",
    "GSE225475;GSE228421;GSE117468",
    "F3 query registry",
    "LINCS or frozen public equivalent"
  ),
  data_role = c("audit", "reference", "development", "freeze", "locked_validation",
                "localization", "freeze", "context_and_treatment", "freeze", "translation"),
  validation_accessed = c(rep("NO", 4), "NO_LOCKED", rep("NO", 5)),
  biological_result = "NO",
  from_id = "",
  to_id = "",
  edge_type = "",
  edge_rule = "",
  evidence_boundary = c(
    "Inventory and provenance only",
    "Distinct reference layers; no union score",
    "Independent unpooled mice user-confirmed; integer counts and S0/SD/I frozen",
    "Core 4,976; Interaction 4,085; SEP 2,716; validation expression not accessed",
    "Cannot change F1 membership, direction or thresholds",
    "Donor is the inferential unit; F1 prerequisite passed",
    "Cell states and mechanism targets frozen before downstream testing",
    "Measured, descriptive and predicted evidence remain distinct",
    "Queries and aggregation rules frozen before connectivity ranking",
    "Computational priority is not efficacy"
  ),
  stringsAsFactors = FALSE
)

edges <- data.frame(
  record_type = "EDGE",
  record_id = c(paste0("E", 1:9), "X1"),
  step = "",
  stage = "",
  label = "",
  detail = "",
  status = "",
  status_label = "",
  gate_type = "",
  x = "",
  y = "",
  source_ids = "",
  data_role = "",
  validation_accessed = "NO",
  biological_result = "NO",
  from_id = c(paste0("N", 1:9), "N5"),
  to_id = c(paste0("N", 2:10), "N4"),
  edge_type = c(rep("ALLOWED_DEPENDENCY", 9), "FORBIDDEN_FEEDBACK"),
  edge_rule = c(
    "audit precedes reference freeze", "reference precedes discovery",
    "discovery evidence precedes F1", "F1 unlocks bulk validation",
    "validated signal supports localization", "localization supports F2",
    "F2 unlocks contextual mechanism work", "mechanism evidence precedes F3",
    "F3 unlocks perturbation ranking", "validation cannot redefine F1"
  ),
  evidence_boundary = "",
  stringsAsFactors = FALSE
)

out <- rbind(nodes, edges)
dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(out, file.path("figures", "source_data", "fig1a.tsv"), sep = "\t",
            row.names = FALSE, quote = FALSE, na = "")

stats <- data.frame(
  metric = c("audited_datasets", "public_sample_records", "registered_panels",
             "workflow_nodes", "freeze_gates", "allowed_dependencies",
             "forbidden_feedback_edges", "validation_expression_accessed",
             "biological_result_nodes", "gse212126_confirmed_independent_unpooled_mice"),
  value = c(nrow(datasets), sum(as.integer(datasets$public_sample_records)), nrow(panels),
            nrow(nodes), sum(nodes$gate_type == "FREEZE"),
            sum(edges$edge_type == "ALLOWED_DEPENDENCY"),
            sum(edges$edge_type == "FORBIDDEN_FEEDBACK"), 0, 0,
            length(unique(animal_registry$canonical_animal_id))),
  unit = c("dataset", "GEO sample record", "panel", "workflow node", "freeze gate",
           "directed edge", "prohibited edge", "expression dataset", "node", "mouse/library"),
  statistical_test = "none_descriptive_protocol_map",
  interpretation = c(
    "All registered public datasets are represented by the audit gate",
    "Metadata records only; not independent biological replicates",
    "Panel inventory, not completed results",
    "Ordered stages and freezes shown in Figure 1A",
    "F1, F2 and F3 are explicit pre-specified freezes",
    "Only forward dependencies are executable",
    "Validation-to-F1 feedback is explicitly prohibited",
    "Locked validation expression was not used to build this panel",
    "The panel reports design governance only",
    "User-confirmed one library per independent mouse with no pooling; original animal IDs/source document are not archived locally"
  ),
  stringsAsFactors = FALSE
)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(stats, file.path("results", "figures", "fig1a_statistics.tsv"), sep = "\t",
            row.names = FALSE, quote = FALSE, na = "")

cat(sprintf("PASS: fig1a source data %d nodes, %d allowed edges, %d forbidden edge\n",
            nrow(nodes), sum(edges$edge_type == "ALLOWED_DEPENDENCY"),
            sum(edges$edge_type == "FORBIDDEN_FEEDBACK")))
