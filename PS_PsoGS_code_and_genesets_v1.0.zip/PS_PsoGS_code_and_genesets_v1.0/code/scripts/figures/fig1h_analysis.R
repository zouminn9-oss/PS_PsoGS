options(stringsAsFactors = FALSE)

ledger <- read.delim(gzfile(file.path("results", "stage02", "signatures",
                                     "cross_species_gene_ledger.tsv.gz")),
                     check.names = FALSE)
audit <- read.delim(file.path("audits", "stage02_orthology", "signature_f1_checks.tsv"),
                    check.names = FALSE)
stopifnot(nrow(ledger) == 18484L, !anyDuplicated(ledger$mouse_ensembl_gene_id),
          nrow(audit) == 45L, all(audit$status == "PASS"),
          sum(ledger$core_member == "TRUE") == 4976L)

dat <- ledger[ledger$core_member == "TRUE", ]
recomputed_class <- ifelse(dat$SD_logFC > 0 & dat$H_logFC > 0, "CONCORDANT_UP",
                           ifelse(dat$SD_logFC < 0 & dat$H_logFC < 0, "CONCORDANT_DOWN",
                                  ifelse(dat$SD_logFC < 0 & dat$H_logFC > 0,
                                         "DISCORDANT_MOUSE_DOWN_HUMAN_UP",
                                         "DISCORDANT_MOUSE_UP_HUMAN_DOWN")))
stopifnot(nrow(dat) == 4976L,
          all(dat$orthology_status == "PASS_RELIABLE_ONE2ONE_ENTREZ"),
          all(dat$analysis_join_status == "PASS_JOINED_H"),
          all(dat$SD_FDR < 0.05), all(dat$H_FDR < 0.05),
          all(dat$core_direction_class == recomputed_class),
          sum(dat$sep_member == "TRUE") == 2716L)

source <- data.frame(
  mouse_gene_id = dat$mouse_gene_id_versioned,
  mouse_gene_name = dat$mouse_gene_name,
  human_ensembl_gene_id = dat$selected_human_ensembl_gene_id,
  human_entrez_id = dat$selected_human_entrez_id,
  human_gene_symbol = dat$human_gene_symbol,
  SD_logFC = dat$SD_logFC,
  SD_FDR = dat$SD_FDR,
  H_logFC = dat$H_logFC,
  H_FDR = dat$H_FDR,
  core_direction_class = recomputed_class,
  sep_member = dat$sep_member,
  interaction_member = dat$interaction_member,
  mouse_statistical_unit = "independent mouse; 12 total and 3 per factorial group",
  human_statistical_unit = "paired patient; 58 PP-PN pairs",
  stringsAsFactors = FALSE)

dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(source, file.path("figures", "source_data", "fig1h.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE, na = "")

class_levels <- c("CONCORDANT_UP", "CONCORDANT_DOWN",
                  "DISCORDANT_MOUSE_DOWN_HUMAN_UP", "DISCORDANT_MOUSE_UP_HUMAN_DOWN")
class_counts <- table(factor(source$core_direction_class, levels = class_levels))
stats <- data.frame(
  metric = c("core_total", "concordant_up", "concordant_down", "discordant_total",
             "discordant_mouse_down_human_up", "discordant_mouse_up_human_down",
             "sep_total", "interaction_within_core", "pearson_r_selected_core",
             "spearman_rho_selected_core", "median_abs_SD_logFC", "median_abs_H_logFC",
             "signature_f1_checks_pass", "validation_expression_accessed"),
  value = c(nrow(source), unname(class_counts[1:2]), sum(unname(class_counts[3:4])),
            unname(class_counts[3:4]), sum(source$sep_member == "TRUE"),
            sum(source$interaction_member == "TRUE"),
            cor(source$SD_logFC, source$H_logFC, method = "pearson"),
            cor(source$SD_logFC, source$H_logFC, method = "spearman"),
            median(abs(source$SD_logFC)), median(abs(source$H_logFC)), nrow(audit), 0),
  unit = c(rep("genes", 8), "correlation", "correlation",
           "absolute_log2_fold_change", "absolute_log2_fold_change", "checks", "boolean"),
  status = c(rep("PASS", 13), "PASS_LOCKED"),
  interpretation = c(
    "all frozen Core genes", "mouse SD and human H are both positive",
    "mouse SD and human H are both negative", "mouse SD and human H have opposite signs",
    "mouse SD is negative and human H is positive", "mouse SD is positive and human H is negative",
    "direction-concordant Core genes", "Core genes also passing formal interaction FDR",
    "descriptive correlation after dual-significance selection; not validation",
    "descriptive rank correlation after dual-significance selection; not validation",
    "typical absolute mouse SD effect", "typical absolute paired human H effect",
    "independent F1 membership and source checks", "locked validation expression remained isolated"),
  stringsAsFactors = FALSE)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(stats, file.path("results", "figures", "fig1h_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
cat("PASS: exported Figure 1H source data and statistics for 4,976 Core genes\n")
