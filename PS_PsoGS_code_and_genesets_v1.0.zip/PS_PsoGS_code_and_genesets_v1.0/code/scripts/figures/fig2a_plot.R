options(stringsAsFactors = FALSE)

dat <- read.delim(file.path("figures", "source_data", "fig2a.tsv"), check.names = FALSE)
coverage <- dat[dat$record_type == "COVERAGE", ]
ink <- "#343B42"; blue <- "#0072B2"; orange <- "#D55E00"
hold <- "#7A7F85"; light <- "#F4F6F7"; grid <- "#DDE2E5"

card <- function(x0, x1, title, subtitle, color, lines) {
  rect(x0, 0.47, x1, 0.82, col = "white", border = grid, lwd = 1)
  rect(x0, 0.74, x1, 0.82, col = color, border = color)
  text(x0 + 0.02, 0.785, title, adj = c(0, 0.5), cex = 0.82, font = 2, col = "white")
  text(x1 - 0.02, 0.785, subtitle, adj = c(1, 0.5), cex = 0.68, col = "white")
  yy <- seq(0.69, 0.51, length.out = length(lines))
  text(rep(x0 + 0.025, length(lines)), yy, lines, adj = c(0, 0.5), cex = 0.68, col = ink)
}

draw_coverage <- function(dataset, x0, x1, color) {
  d <- coverage[coverage$dataset_id == dataset, ]
  d <- d[match(c("Core", "Interaction", "SEP", "SEP_UP", "SEP_DOWN"), d$item_id), ]
  y <- seq(0.37, 0.17, length.out = 5)
  text(rep(x0, 5), y, d$item_id, adj = c(0, 0.5), cex = 0.67, col = ink)
  bar0 <- x0 + 0.13; bar1 <- x1 - 0.09
  rect(bar0, y - 0.012, bar1, y + 0.012, col = light, border = grid, lwd = 0.5)
  rect(bar0, y - 0.012, bar0 + (bar1 - bar0) * as.numeric(d$value), y + 0.012,
       col = color, border = color)
  gate <- bar0 + (bar1 - bar0) * 0.70
  segments(rep(gate, 5), y - 0.020, rep(gate, 5), y + 0.020, col = hold, lty = 2, lwd = 0.7)
  text(rep(x1, 5), y, sprintf("%.1f%%", 100 * as.numeric(d$value)),
       adj = c(1, 0.5), cex = 0.67, col = ink)
}

draw_panel <- function() {
  par(mar = c(0.4, 0.4, 0.5, 0.4), family = "sans", xpd = NA)
  plot.new(); plot.window(xlim = c(0, 1), ylim = c(0, 1))
  text(0.035, 0.955, "Validation cohort and platform lock", adj = c(0, 1), cex = 1.0,
       font = 2, col = ink)
  text(0.035, 0.900,
       "Metadata-defined inclusion and frozen-signature coverage; no expression effect calculated",
       adj = c(0, 1), cex = 0.70, col = "#6F7881")
  card(0.035, 0.485, "GSE30999", "GPL570 array", blue,
       c("170 samples / 89 public IDs", "PRIMARY: 162 samples = 81 pairs",
         "HOLD: 8 singleton samples", "4 reported pairs unresolved",
         "Exact public-ID pairing only"))
  card(0.515, 0.965, "GSE121212", "RNA-seq", orange,
       c("147 samples / 93 donors", "PRIMARY: 54 samples = 27 PSO pairs",
         "HOLD: PSO_034 lesion", "AD: 21 ordinary + 6 chronic pairs",
         "Healthy: 38 references"))
  text(0.035, 0.425, "Frozen member coverage", adj = c(0, 0.5), cex = 0.76,
       font = 2, col = ink)
  text(0.965, 0.425, "dashed mark = 70% gate", adj = c(1, 0.5), cex = 0.67, col = hold)
  draw_coverage("GSE30999", 0.055, 0.475, blue)
  draw_coverage("GSE121212", 0.535, 0.955, orange)
  text(0.035, 0.095,
       "Array: unique Entrez probes, gene median | RNA-seq: exact frozen symbol",
       adj = c(0, 0.5), cex = 0.67, col = "#6F7881")
  text(0.035, 0.048,
       "Rules locked before numeric validation effects; held samples remain visible.",
       adj = c(0, 0.5), cex = 0.67, col = ink)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig2a.svg"), width = 7.0079, height = 5.1181,
    pointsize = 12, family = "sans", bg = "white"); draw_panel(); dev.off()
png(file.path("figures", "previews", "fig2a.png"), width = 7.0079, height = 5.1181,
    units = "in", res = 300, pointsize = 12, type = "cairo", bg = "white")
draw_panel(); dev.off()
cat("PASS: rendered Figure 2A SVG and 300-dpi PNG\n")
