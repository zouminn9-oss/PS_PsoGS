options(stringsAsFactors = FALSE)

genes <- read.delim(file.path("figures", "source_data", "fig2d.tsv"), check.names = FALSE)
stats <- read.delim(file.path("results", "figures", "fig2d_statistics.tsv"), check.names = FALSE)
strict <- "#0072B2"; concordant <- "#9ECAE1"; discordant <- "#F2C7A5"
discordant_fdr <- "#D55E00"; unavailable <- "#DDE2E5"; ink <- "#343B42"
state_colors <- c(CONCORDANT_STRICT = strict, CONCORDANT_NON_FDR = concordant,
                  DISCORDANT_NON_FDR = discordant, DISCORDANT_FDR = discordant_fdr,
                  UNAVAILABLE = unavailable)
state_order <- names(state_colors)

draw_stack <- function(counts, y, x0 = 0.40, x1 = 0.965, height = 0.085) {
  total <- sum(counts)
  cursor <- x0
  for (state in state_order) {
    width <- (x1 - x0) * counts[state] / total
    rect(cursor, y - height / 2, cursor + width, y + height / 2,
         col = state_colors[state], border = "white", lwd = 0.45)
    if (counts[state] / total >= 0.055) {
      text(cursor + width / 2, y, counts[state], cex = 0.61,
           col = ifelse(state %in% c("CONCORDANT_STRICT", "DISCORDANT_FDR"), "white", ink),
           font = 2)
    }
    cursor <- cursor + width
  }
  rect(x0, y - height / 2, x1, y + height / 2, border = ink, lwd = 0.6)
}

draw_panel <- function() {
  par(mar = c(0.5, 0.5, 0.6, 0.5), family = "sans", xpd = NA)
  plot.new(); plot.window(xlim = c(0, 1), ylim = c(0, 1))
  text(0.035, 0.965, "Frozen SEP gene-level replication states", adj = c(0, 1),
       cex = 1.02, font = 2, col = ink)
  text(0.965, 0.965, "complete denominator: 2,716 frozen genes", adj = c(1, 1),
       cex = 0.66, col = "#6F7881")

  legend_labels <- c("concordant + FDR<0.05", "concordant, FDR>=0.05",
                     "discordant, FDR>=0.05", "discordant + FDR<0.05", "unavailable")
  legend_x <- c(0.035, 0.245, 0.455, 0.665, 0.855)
  for (i in seq_along(state_order)) {
    rect(legend_x[i], 0.883, legend_x[i] + 0.022, 0.905,
         col = state_colors[state_order[i]], border = ink, lwd = 0.45)
    text(legend_x[i] + 0.028, 0.894, legend_labels[i], adj = c(0, 0.5), cex = 0.56, col = ink)
  }

  y_top <- 0.82; y_bottom <- 0.25
  n <- nrow(genes); row_height <- (y_top - y_bottom) / n
  y_positions <- y_top - (seq_len(n) - 0.5) * row_height
  matrix_x <- c(0.105, 0.175)
  matrix_w <- 0.050
  for (j in seq_along(matrix_x)) {
    states <- if (j == 1) genes$array_display_state else genes$rnaseq_display_state
    for (i in seq_len(n)) {
      rect(matrix_x[j] - matrix_w / 2, y_positions[i] - row_height / 2,
           matrix_x[j] + matrix_w / 2, y_positions[i] + row_height / 2,
           col = state_colors[states[i]], border = NA)
    }
    rect(matrix_x[j] - matrix_w / 2, y_bottom, matrix_x[j] + matrix_w / 2, y_top,
         border = ink, lwd = 0.6)
  }
  split_index <- sum(genes$sep_direction == "UP")
  split_y <- y_top - split_index * row_height
  segments(0.070, split_y, 0.210, split_y, col = "white", lwd = 1.2)
  text(matrix_x, rep(0.845, 2), c("Array", "RNA-seq"), cex = 0.63, font = 2, col = ink)
  text(0.055, (y_top + split_y) / 2, "SEP_UP\n1,399", adj = c(1, 0.5), cex = 0.61, col = ink)
  text(0.055, (split_y + y_bottom) / 2, "SEP_DOWN\n1,317", adj = c(1, 0.5), cex = 0.61, col = ink)
  text(0.140, 0.215, "all genes; alphabetic within frozen direction", cex = 0.56, col = "#6F7881")

  all_rows <- stats[stats$summary_type == "COHORT_DIRECTION" & stats$direction_stratum == "ALL", ]
  array_counts <- c(CONCORDANT_STRICT = 1940, CONCORDANT_NON_FDR = 421,
                    DISCORDANT_NON_FDR = 202, DISCORDANT_FDR = 116, UNAVAILABLE = 37)
  rna_counts <- c(CONCORDANT_STRICT = 2070, CONCORDANT_NON_FDR = 263,
                  DISCORDANT_NON_FDR = 134, DISCORDANT_FDR = 105, UNAVAILABLE = 144)
  text(0.285, 0.795, "Cohort states", adj = c(0, 0.5), cex = 0.76, font = 2, col = ink)
  text(0.285, 0.700, "GSE30999", adj = c(0, 0.5), cex = 0.68, font = 2, col = "#0072B2")
  draw_stack(array_counts, 0.645)
  text(0.400, 0.585, "2,361/2,679 tested concordant (88.1%); strict 1,940", adj = c(0, 0.5),
       cex = 0.61, col = ink)
  text(0.285, 0.500, "GSE121212", adj = c(0, 0.5), cex = 0.68, font = 2, col = "#D55E00")
  draw_stack(rna_counts, 0.445)
  text(0.400, 0.385, "2,333/2,572 tested concordant (90.7%); strict 2,070", adj = c(0, 0.5),
       cex = 0.61, col = ink)

  cross_counts <- c(CONCORDANT_STRICT = 1589, CONCORDANT_NON_FDR = 476,
                    DISCORDANT_NON_FDR = 406, DISCORDANT_FDR = 66, UNAVAILABLE = 179)
  text(0.285, 0.300, "Cross-cohort states", adj = c(0, 0.5), cex = 0.76, font = 2, col = ink)
  draw_stack(cross_counts, 0.245)
  text(0.400, 0.180,
       "both tested: 2,537 | both concordant: 2,065 | both strict: 1,589",
       adj = c(0, 0.5), cex = 0.61, col = ink)
  text(0.400, 0.125,
       "mixed direction: 406 | both discordant: 66 | not jointly tested: 179",
       adj = c(0, 0.5), cex = 0.61, col = "#6F7881")
  text(0.035, 0.050,
       "Unavailable includes platform-missing genes and 13 RNA-seq genes removed by frozen filterByExpr.",
       adj = c(0, 0.5), cex = 0.58, col = "#6F7881")
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig2d.svg"), width = 7.0079, height = 4.7244,
    pointsize = 12, family = "sans", bg = "white")
draw_panel(); dev.off()
png(file.path("figures", "previews", "fig2d.png"), width = 7.0079, height = 4.7244,
    units = "in", res = 300, pointsize = 12, type = "cairo", bg = "white")
draw_panel(); dev.off()
cat("PASS: rendered Figure 2D SVG and 300-dpi PNG\n")
