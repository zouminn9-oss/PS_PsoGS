options(stringsAsFactors = FALSE)

dat <- read.delim(file.path("figures", "source_data", "fig2c.tsv"), check.names = FALSE)
stats <- read.delim(file.path("results", "figures", "fig2c_statistics.tsv"), check.names = FALSE)
ink <- "#343B42"; blue <- "#0072B2"; orange <- "#D55E00"
grid <- "#DDE2E5"; neutral <- "#7A7F85"
row_colors <- c(blue, orange, ink, neutral)
y <- c(4.1, 3.2, 1.9, 1.05)

draw_diamond <- function(center, low, high, ypos, color) {
  polygon(c(low, center, high, center), c(ypos, ypos + 0.16, ypos, ypos - 0.16),
          col = color, border = ink, lwd = 0.8)
}

draw_panel <- function() {
  par(mar = c(4.0, 1.0, 3.0, 1.0), family = "sans", xpd = NA)
  plot.new(); plot.window(xlim = c(-1.0, 5.15), ylim = c(0.35, 5.05))
  for (tick in 0:4) segments(tick, 0.65, tick, 4.65, col = grid, lwd = 0.65)
  segments(0, 0.65, 0, 4.65, col = neutral, lty = 2, lwd = 1.1)
  segments(-0.9, 2.55, 5.05, 2.55, col = grid, lwd = 0.9)

  for (i in seq_len(nrow(dat))) {
    row <- dat[i, ]; color <- row_colors[i]
    segments(row$ci_low, y[i], row$ci_high, y[i], col = color, lwd = 2.1)
    segments(row$ci_low, y[i] - 0.07, row$ci_low, y[i] + 0.07, col = color, lwd = 0.9)
    segments(row$ci_high, y[i] - 0.07, row$ci_high, y[i] + 0.07, col = color, lwd = 0.9)
    if (row$record_type == "COHORT") {
      cex_value <- 0.9 + 1.0 * sqrt(row$weight_fixed)
      points(row$effect, y[i], pch = 22, cex = cex_value, bg = color, col = ink, lwd = 0.7)
    } else {
      draw_diamond(row$effect, row$ci_low, row$ci_high, y[i], color)
    }
    text(-0.92, y[i] + 0.10, row$label, adj = c(0, 0.5), cex = 0.74,
         font = ifelse(row$record_type == "SUMMARY", 2, 1), col = color)
    detail <- if (row$record_type == "COHORT") {
      sprintf("n=%d | fixed weight %.1f%%", row$n_pairs, 100 * row$weight_fixed)
    } else if (row$dataset_id == "FIXED") {
      "primary inverse-variance summary"
    } else {
      "sensitivity; DL tau2 = 0"
    }
    text(-0.92, y[i] - 0.14, detail, adj = c(0, 0.5), cex = 0.62, col = neutral)
    text(5.05, y[i], sprintf("%.2f [%.2f, %.2f]", row$effect, row$ci_low, row$ci_high),
         adj = c(1, 0.5), cex = 0.69, font = ifelse(row$record_type == "SUMMARY", 2, 1), col = ink)
  }

  axis(1, at = 0:4, labels = 0:4, cex.axis = 0.72, col.axis = ink,
       col = ink, lwd = 0.8, tck = -0.018)
  mtext("Hedges g of paired lesional - non-lesional SEP score", side = 1,
        line = 2.45, cex = 0.77, col = ink)
  text(-0.92, 5.00, "Cross-cohort standardized SEP effects", adj = c(0, 1),
       cex = 1.02, font = 2, col = ink)
  text(5.05, 5.00, "effect [95% CI]", adj = c(1, 1), cex = 0.69, font = 2, col = ink)
  heterogeneity_line <- sprintf("k=2 | Q=%.3f, P=%.3f | I2=%.1f%% | DL tau2=%.3f",
                                stats$Q, stats$Q_p_value, stats$I2_percent, stats$tau2_DL)
  text(-0.92, 0.52, heterogeneity_line, adj = c(0, 0.5), cex = 0.64, col = ink)
  text(5.05, 0.52, "heterogeneity is unstable with only two cohorts",
       adj = c(1, 0.5), cex = 0.64, col = neutral)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig2c.svg"), width = 7.0079, height = 4.3307,
    pointsize = 12, family = "sans", bg = "white")
draw_panel(); dev.off()
png(file.path("figures", "previews", "fig2c.png"), width = 7.0079, height = 4.3307,
    units = "in", res = 300, pointsize = 12, type = "cairo", bg = "white")
draw_panel(); dev.off()
cat("PASS: rendered Figure 2C SVG and 300-dpi PNG\n")
