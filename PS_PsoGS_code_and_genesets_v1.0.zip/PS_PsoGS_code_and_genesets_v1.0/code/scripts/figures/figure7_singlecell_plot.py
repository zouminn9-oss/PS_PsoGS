from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
SRC=ROOT/"figures/source_data"; OUT=ROOT/"figures/panels"; PRE=ROOT/"figures/previews"
OUT.mkdir(parents=True,exist_ok=True); PRE.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.spines.top":False,"axes.spines.right":False,"svg.fonttype":"none"})
def save(fig,name): fig.savefig(OUT/f"{name}.svg",bbox_inches="tight"); fig.savefig(PRE/f"{name}.png",dpi=300,bbox_inches="tight"); plt.close(fig)
def forest(data,value,lo,hi,title,xlabel,name):
 z=data.sort_values(value); y=np.arange(len(z)); fig,ax=plt.subplots(figsize=(7.2,5.0)); x=z[value].to_numpy(); ax.errorbar(x,y,xerr=[x-z[lo].to_numpy(),z[hi].to_numpy()-x],fmt="o",color="#0072B2",capsize=2.5)
 ax.axvline(0,color="#222",ls="--",lw=.8); ax.set_yticks(y); ax.set_yticklabels(z.cell_type); ax.set_xlabel(xlabel); ax.grid(axis="x",alpha=.15); ax.set_title(title,loc="left",fontsize=14,fontweight="bold")
 fig.text(.04,.012,"Points are five-patient paired mean differences with 95% t intervals; exact Wilcoxon P cannot be below 0.0625 at n=5.",fontsize=8,color="#444"); fig.tight_layout(rect=[.03,.06,1,.95]); save(fig,name)

b=pd.read_csv(SRC/"fig7b.tsv",sep="\t"); visits=["day 0","day 3","day 14"]; fig,axs=plt.subplots(1,2,figsize=(9.5,4.4))
for ax,(col,label,color) in zip(axs,[("ucell_core_directed","Core","#D55E00"),("ucell_sep_directed","SEP","#0072B2")]):
 for patient,z in b.groupby("patient_id"):
  z=z.set_index("visit").reindex(visits); ax.plot(range(3),z[col],"o-",color=color,alpha=.55,lw=1); ax.annotate(patient,(2,z[col].iloc[-1]),xytext=(3,0),textcoords="offset points",fontsize=7)
 ax.set_xticks(range(3)); ax.set_xticklabels(visits); ax.set_title(label); ax.set_ylabel("Directed UCell score"); ax.grid(alpha=.15)
fig.suptitle("7B  Keratinocyte programs trend downward after risankizumab",x=.04,ha="left",fontsize=15,fontweight="bold"); fig.text(.04,.012,"Lines connect the same patient. Scores are cell-averaged within patient, visit and cell type; cells are not replicates.",fontsize=8,color="#444"); fig.tight_layout(rect=[.03,.06,1,.92]); save(fig,"fig7b")

c=pd.read_csv(SRC/"fig7c.tsv",sep="\t"); forest(c,"mean_proportion_difference","ci_low","ci_high","7C  Cell-type composition changes are uncertain","Day 14 − baseline lesional proportion","fig7c")
d=pd.read_csv(SRC/"fig7d.tsv",sep="\t"); forest(d,"mean_difference","ci_low","ci_high","7D  SEP tends to fall within several cell types","Day 14 − baseline directed SEP score","fig7d")

e=pd.read_csv(SRC/"fig7e.tsv",sep="\t"); fig,axs=plt.subplots(1,3,figsize=(11,4.0),sharex=True)
for ax,(metric,label,color) in zip(axs,[("endothelial_JAG2","Endothelial JAG2","#009E73"),("fibroblast_NOTCH2","Fibroblast NOTCH2","#CC79A7"),("expression_compatibility","Geometric compatibility","#E69F00")]):
 for patient,z in e.groupby("patient_id"):
  z=z.set_index("visit").reindex(["day 0","day 3","day 14"]); ax.plot(range(3),z[metric],"o-",color=color,alpha=.55,lw=1)
 ax.set_xticks(range(3)); ax.set_xticklabels(["day 0","day 3","day 14"],rotation=15); ax.set_title(label); ax.grid(alpha=.15)
fig.suptitle("7E  JAG2–NOTCH2 expression compatibility is not consistently reduced",x=.04,ha="left",fontsize=15,fontweight="bold"); fig.text(.04,.01,"Patient-paired expression summaries do not establish ligand–receptor signaling or spatial contact.",fontsize=8,color="#444"); fig.tight_layout(rect=[.03,.06,1,.91]); save(fig,"fig7e")

f=pd.read_csv(SRC/"fig7f.tsv",sep="\t"); forest(f,"mean_difference","ci_low","ci_high","7F  Glutathione-program changes are cell-type dependent","Day 14 − baseline UCell score","fig7f")
g=pd.read_csv(SRC/"fig7g.tsv",sep="\t"); forest(g,"mean_difference","ci_low","ci_high","7G  Day-14 SEP is often above baseline nonlesional skin","Day 14 lesion − baseline nonlesion SEP score","fig7g")
print("PASS: rendered Figure 7 single-cell panels B-G")
