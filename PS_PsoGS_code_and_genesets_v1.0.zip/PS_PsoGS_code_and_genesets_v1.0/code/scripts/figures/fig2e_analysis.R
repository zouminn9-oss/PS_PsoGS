options(stringsAsFactors = FALSE)

scores <- read.delim(file.path("results", "stage03", "specificity",
                               "gse121212_pso_ad_paired_scores.tsv"), check.names = FALSE)
groups <- read.delim(file.path("results", "stage03", "specificity",
                               "gse121212_pso_ad_group_statistics.tsv"), check.names = FALSE)
contrasts <- read.delim(file.path("results", "stage03", "specificity",
                                  "gse121212_pso_ad_direct_comparisons.tsv"), check.names = FALSE)
audit <- read.delim(file.path("audits", "stage03_pso_ad_specificity_checks.tsv"), check.names = FALSE)
stopifnot(nrow(scores) == 54L, nrow(groups) == 3L, nrow(contrasts) == 3L,
          all(audit$status == "PASS"), sum(scores$group_id == "PSO_PRIMARY") == 27L,
          sum(scores$group_id == "AD_ORDINARY") == 21L,
          sum(scores$group_id == "AD_CHRONIC") == 6L)

group_labels <- c(PSO_PRIMARY = "Psoriasis", AD_ORDINARY = "Ordinary AD",
                  AD_CHRONIC = "Chronic AD sensitivity")
scores$group_label <- unname(group_labels[scores$group_id])
scores$statistical_unit <- "paired patient"
write.table(scores, file.path("figures", "source_data", "fig2e.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)

group_out <- data.frame(record_type = "GROUP", record_id = groups$group_id,
  label = unname(group_labels[groups$group_id]), analysis_role = c("PRIMARY", "PRIMARY", "SENSITIVITY"),
  n_left = groups$n_pairs, n_right = NA_integer_, estimate = groups$mean_delta,
  ci_low = groups$ci_low, ci_high = groups$ci_high, primary_p_value = groups$t_p_value,
  sensitivity_p_value = groups$wilcoxon_p_value, BH_FDR = NA_real_,
  estimand = "mean patient-level lesion minus non-lesional SEP score")
contrast_labels <- c(PSO_MINUS_AD_ORDINARY = "Psoriasis - ordinary AD",
                     PSO_MINUS_AD_CHRONIC = "Psoriasis - chronic AD",
                     AD_ORDINARY_MINUS_AD_CHRONIC = "Ordinary AD - chronic AD")
contrast_out <- data.frame(record_type = "CONTRAST", record_id = contrasts$contrast_id,
  label = unname(contrast_labels[contrasts$contrast_id]), analysis_role = contrasts$analysis_role,
  n_left = contrasts$n_left, n_right = contrasts$n_right,
  estimate = contrasts$difference_left_minus_right, ci_low = contrasts$ci_low,
  ci_high = contrasts$ci_high, primary_p_value = contrasts$t_p_value,
  sensitivity_p_value = contrasts$wilcoxon_p_value,
  BH_FDR = contrasts$BH_FDR_three_between_group_tests,
  estimand = "difference between patient-level lesion minus non-lesional SEP shifts")
figure_stats <- rbind(group_out, contrast_out)
write.table(figure_stats, file.path("results", "figures", "fig2e_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE, na = "")
cat("PASS: exported 54 patient differences and six Figure 2E estimates\n")
