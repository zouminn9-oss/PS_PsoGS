#!/usr/bin/env python3
"""Source, statistic, render and print QA for Figure 2I."""

from __future__ import annotations
import csv, struct, xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "audits/fig2i_qa_checks.tsv"

def read(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as h: return list(csv.DictReader(h, delimiter="\t"))

def cfg(path):
    out = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            k, v = line.split(":", 1); out[k.strip()] = v.strip().strip('"')
    return out

def main():
    checks = []
    def check(name, obs, exp):
        ok = obs == exp; checks.append({"check_id": name, "observed": str(obs), "expected": str(exp), "status": "PASS" if ok else "FAIL"})
        if not ok: raise AssertionError(f"{name}: {obs!r} != {exp!r}")
    source = read(ROOT / "figures/source_data/fig2i.tsv")
    upstream = read(ROOT / "results/stage03/influence/stage03_gene_leave_one_out.tsv")
    stats = read(ROOT / "results/figures/fig2i_statistics.tsv")
    audit = read(ROOT / "audits/stage03_score_influence_checks.tsv")
    check("fig2i_source_rows", len(source), 5432)
    check("fig2i_source_identity", source, upstream)
    check("fig2i_stat_rows", len(stats), 6)
    check("fig2i_audit", (len(audit), {r["status"] for r in audit}), (33, {"PASS"}))
    check("fig2i_complete_denominator", all(sum(r["dataset_id"] == d for r in source) == 2716 for d in ("GSE30999", "GSE121212")), True)
    c = cfg(ROOT / "config/figures/fig2i.yaml")
    check("fig2i_manual", c["manual_visual_inspection"], "PASS_2026-09-11_FIRST_RENDER")
    check("fig2i_min_text", float(c["minimum_text_pt"]) >= 8, True)
    plot = (ROOT / "scripts/figures/fig2i_plot.R").read_text(encoding="utf-8")
    check("fig2i_ascii_plot", all(ord(x) < 128 for x in plot), True)
    svg = ROOT / "figures/panels/fig2i.svg"; png = ROOT / "figures/previews/fig2i.png"; cap = ROOT / "figures/captions/fig2i.md"
    check("fig2i_svg", svg.is_file() and svg.stat().st_size > 100000, True)
    check("fig2i_png", png.is_file() and png.stat().st_size > 70000, True)
    check("fig2i_caption", cap.is_file() and cap.stat().st_size > 1700, True)
    text = cap.read_text(encoding="utf-8")
    for phrase in ("98.9%", "94.2%", "IL19", "IL36A", "No influence cutoff", "do not establish psychological-stress causality"):
        check(f"caption::{phrase}", phrase in text, True)
    with png.open("rb") as h: header = h.read(24)
    check("fig2i_png_dimensions", struct.unpack(">II", header[16:24]),
          (round(float(c["width_inches"]) * int(c["png_dpi"])), round(float(c["height_inches"]) * int(c["png_dpi"]))))
    root = ET.parse(svg).getroot(); sw = float(root.attrib["width"].replace("pt", "")) / 72; sh = float(root.attrib["height"].replace("pt", "")) / 72
    check("fig2i_svg_dimensions", abs(sw - float(c["width_inches"])) < 0.02 and abs(sh - float(c["height_inches"])) < 0.02, True)
    Ring = {r["panel_id"]: r for r in read(ROOT / "panel_manifest.tsv")}["2I"]
    check("fig2i_manifest", (Ring["status"], Ring["qa_status"], Ring["figure_ready"]), ("PASS", "PASS_RENDER_DATA_PRINT", "YES"))
    with OUT.open("w", encoding="utf-8", newline="") as h:
        w = csv.DictWriter(h, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n"); w.writeheader(); w.writerows(checks)
    print(f"PASS: {len(checks)} Figure 2I source, render and print QA checks")

if __name__ == "__main__": main()
