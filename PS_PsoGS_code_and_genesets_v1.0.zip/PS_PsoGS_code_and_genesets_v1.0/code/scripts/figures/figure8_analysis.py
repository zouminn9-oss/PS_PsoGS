from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"python_libs/stage04"))
import pandas as pd

SRC=ROOT/"figures/source_data"; STATS=ROOT/"results/figures"; CFG=ROOT/"config/figures"
for p in (SRC,STATS,CFG): p.mkdir(parents=True,exist_ok=True)

registry=pd.read_csv(ROOT/"results/stage08/query_registry.tsv",sep="\t")
gate=pd.read_csv(ROOT/"results/stage08/stage08_module_gate.tsv",sep="\t")
registry.to_csv(SRC/"fig8a.tsv",sep="\t",index=False)
gate.to_csv(STATS/"fig8a_statistics.tsv",sep="\t",index=False)

drug=pd.read_csv(ROOT/"results/stage08/l1000_drug_scores.tsv",sep="\t")
primary=drug[(drug.variant=="PRIMARY_ALL_LANDMARK_OVERLAP")&drug.eligible_min_3_cell_lines].copy()
wide=primary.pivot(index=["pert_id","pert_desc"],columns="query_id",values="median_cosine").reset_index().dropna()
ranks=primary.pivot(index=["pert_id","pert_desc"],columns="query_id",values="reversal_rank").reset_index().dropna()
ranks["rank_sum"]=ranks.Q1_SEP+ranks.Q2_ORDINARY_LESION
top=ranks.nsmallest(12,"rank_sum")[["pert_id","pert_desc"]]
b=primary.merge(top,on=["pert_id","pert_desc"])
b.to_csv(SRC/"fig8b.tsv",sep="\t",index=False)
primary[primary.pert_id.isin(top.pert_id)].to_csv(STATS/"fig8b_statistics.tsv",sep="\t",index=False)

comparison=pd.read_csv(ROOT/"results/stage08/query_rank_comparison.tsv",sep="\t")
comparison.to_csv(SRC/"fig8c.tsv",sep="\t",index=False)
pd.read_csv(ROOT/"results/stage08/query_rank_comparison_statistics.tsv",sep="\t").to_csv(STATS/"fig8c_statistics.tsv",sep="\t",index=False)

pareto=pd.read_csv(ROOT/"results/stage08/l1000_two_axis_pareto.tsv",sep="\t").dropna(subset=["rank_Q1","rank_Q2"])
pareto["rank_sum"]=pareto.rank_Q1+pareto.rank_Q2
pareto["highlight"]=pareto.pareto_nondominated_more_negative | pareto.rank_sum.le(pareto.rank_sum.nsmallest(4).max())
pareto.to_csv(SRC/"fig8d.tsv",sep="\t",index=False)
pareto[pareto.highlight].sort_values("rank_sum").to_csv(STATS/"fig8d_statistics.tsv",sep="\t",index=False)

contexts=pd.read_csv(ROOT/"results/stage08/l1000_cell_context_scores.tsv.gz",sep="\t")
top6=ranks.nsmallest(6,"rank_sum").pert_id
e=contexts[(contexts.variant=="PRIMARY_ALL_LANDMARK_OVERLAP")&contexts.pert_id.isin(top6)].copy()
e.to_csv(SRC/"fig8e.tsv",sep="\t",index=False)
e.groupby(["pert_id","pert_desc","query_id"]).agg(n_cell_lines=("cell_id","nunique"),median=("cell_median_cosine","median"),min=("cell_median_cosine","min"),max=("cell_median_cosine","max")).reset_index().to_csv(STATS/"fig8e_statistics.tsv",sep="\t",index=False)

sensitivity=pd.read_csv(ROOT/"results/stage08/l1000_sensitivity.tsv",sep="\t")
sensitivity.to_csv(SRC/"fig8f.tsv",sep="\t",index=False)
sensitivity.to_csv(STATS/"fig8f_statistics.tsv",sep="\t",index=False)

configs={
 "fig8a":"panel_id: 8A\ntitle: Frozen query routes and coverage\nfreeze: F3_STAGE08_v1.0\nscore_families_mixed: false\n",
 "fig8b":"panel_id: 8B\ntitle: L1000 landmark reversal heatmap\naggregation: median_within_cell_then_median_across_cells\nminimum_cell_lines: 3\n",
 "fig8c":"panel_id: 8C\ntitle: Q1-Q2 rank comparison\nstatistical_unit: perturbagen\nq3_included: false\n",
 "fig8d":"panel_id: 8D\ntitle: Two-axis computational Pareto map\nclaim_ceiling: perturbational_hypothesis_only\nmarketed_status: not_used_for_ranking\n",
 "fig8e":"panel_id: 8E\ntitle: Cell-context consistency\nstatistical_unit: cell_line_median\n",
 "fig8f":"panel_id: 8F\ntitle: Query sensitivity analysis\nvariants: top50_top100_leave_one_landmark_gene_out\n"
}
for name,txt in configs.items(): (CFG/f"{name}.yaml").write_text(txt,encoding="utf-8")
print("PASS: Figure 8 source data/statistics/configs")
