#!/usr/bin/env python3
"""Data, isolation, render and print-size QA for Figure 1A."""

from __future__ import annotations

import csv
import struct
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line or line.lstrip().startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        out[key.strip()] = value.strip().strip('"')
    return out


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError(f"Not a PNG: {path}")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": str(observed),
                       "expected": str(expected), "status": "PASS" if passed else "FAIL",
                       "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    source = read_tsv(ROOT / "figures" / "source_data" / "fig1a.tsv")
    stats = read_tsv(ROOT / "results" / "figures" / "fig1a_statistics.tsv")
    datasets = read_tsv(ROOT / "metadata" / "dataset_manifest.tsv")
    panels = read_tsv(ROOT / "panel_manifest.tsv")
    animal_registry = read_tsv(ROOT / "metadata" / "gse212126_library_animal_registry.tsv")
    animal_confirmation = read_tsv(ROOT / "audits" / "gse212126_user_confirmation.tsv")
    nodes = [row for row in source if row["record_type"] == "NODE"]
    edges = [row for row in source if row["record_type"] == "EDGE"]
    allowed = [row for row in edges if row["edge_type"] == "ALLOWED_DEPENDENCY"]
    forbidden = [row for row in edges if row["edge_type"] == "FORBIDDEN_FEEDBACK"]
    node_by_id = {row["record_id"]: row for row in nodes}

    check("fig1a_nodes", len(nodes), 10)
    check("fig1a_unique_node_ids", len(node_by_id), 10)
    check("fig1a_ordered_steps", ",".join(row["step"] for row in nodes),
          ",".join(str(i) for i in range(1, 11)))
    check("fig1a_freeze_gates", sum(row["gate_type"] == "FREEZE" for row in nodes), 3)
    check("fig1a_freeze_ids", ",".join(row["stage"] for row in nodes if row["gate_type"] == "FREEZE"),
          "F1,F2,F3")
    check("fig1a_allowed_edges", len(allowed), 9)
    check("fig1a_allowed_chain",
          ",".join(f"{row['from_id']}>{row['to_id']}" for row in allowed),
          ",".join(f"N{i}>N{i+1}" for i in range(1, 10)))
    check("fig1a_forbidden_feedback_edges", len(forbidden), 1)
    check("fig1a_forbidden_feedback_rule", forbidden[0]["from_id"] + ">" + forbidden[0]["to_id"],
          "N5>N4")
    check("fig1a_no_biological_results", sum(row["biological_result"] != "NO" for row in source), 0)
    check("fig1a_validation_locked", node_by_id["N5"]["validation_accessed"], "NO_LOCKED")
    check("fig1a_validation_sources", node_by_id["N5"]["source_ids"], "GSE30999;GSE121212")
    check("fig1a_development_sources", node_by_id["N3"]["source_ids"], "GSE212126;GSE13355")
    check("fig1a_discovery_pass", node_by_id["N3"]["status"], "PASS")
    check("fig1a_f1_pass", node_by_id["N4"]["status"], "PASS")
    check("fig1a_gse212126_animal_gate", animal_confirmation[0]["animal_gate_status"], "PASS_USER_CONFIRMED")
    check("fig1a_gse212126_animal_count", len({r["canonical_animal_id"] for r in animal_registry}), 12)
    check("fig1a_gse212126_no_pooling", sum(r["pooling_status"] == "NO_POOLING_USER_CONFIRMED" for r in animal_registry), 12)
    check("fig1a_gse212126_one_to_one", sum(r["libraries_per_animal"] == "1" and r["animals_per_library"] == "1" for r in animal_registry), 12)
    check("fig1a_discovery_effects_frozen", node_by_id["N3"]["detail"], "S0 / SD / I frozen")
    check("fig1a_f1_membership_frozen", node_by_id["N4"]["detail"], "Core / Int. / SEP")
    check("fig1a_bulk_validation_ready", node_by_id["N5"]["status_label"], "READY F1")
    check("fig1a_reference_pass", node_by_id["N2"]["status"], "PASS")
    check("fig1a_audited_datasets", len(datasets), 13)
    check("fig1a_public_metadata_records", sum(int(row["public_sample_records"]) for row in datasets), 1381)
    check("fig1a_registered_panels", len(panels), 90)
    check("fig1a_stats_descriptive", all(row["statistical_test"] == "none_descriptive_protocol_map" for row in stats), True)
    check("fig1a_stats_metrics", len(stats), 10)

    cfg = read_config(ROOT / "config" / "figures" / "fig1a.yaml")
    svg = ROOT / "figures" / "panels" / "fig1a.svg"
    png = ROOT / "figures" / "previews" / "fig1a.png"
    caption = ROOT / "figures" / "captions" / "fig1a.md"
    check("fig1a_minimum_text_pt", float(cfg["minimum_text_pt"]) >= 8, True)
    check("fig1a_print_width_mm", cfg["print_width_mm"], 178)
    check("fig1a_print_height_mm", cfg["print_height_mm"], 110)
    check("fig1a_svg_exists", svg.exists() and svg.stat().st_size > 5000, True)
    check("fig1a_png_exists", png.exists() and png.stat().st_size > 20000, True)
    check("fig1a_caption_exists", caption.exists() and caption.stat().st_size > 700, True)
    svg_w, svg_h = svg_dimensions(svg)
    check("fig1a_svg_width_inches", abs(svg_w - float(cfg["width_inches"])) < 0.02, True)
    check("fig1a_svg_height_inches", abs(svg_h - float(cfg["height_inches"])) < 0.02, True)
    png_w, png_h = png_dimensions(png)
    check("fig1a_png_width_pixels", abs(png_w - round(float(cfg["width_inches"]) * int(cfg["png_dpi"]))) <= 1, True)
    check("fig1a_png_height_pixels", abs(png_h - round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))) <= 1, True)

    manifest = {row["panel_id"]: row for row in panels}["1A"]
    check("fig1a_manifest_vector", manifest["vector_output"], "figures/panels/fig1a.svg")
    check("fig1a_manifest_preview", manifest["preview_output"], "figures/previews/fig1a.png")
    check("fig1a_manifest_source", manifest["source_data"], "figures/source_data/fig1a.tsv")
    check("fig1a_manifest_status", manifest["status"], "PASS")
    check("fig1a_manifest_qa", manifest["qa_status"], "PASS_RENDER_DATA_PRINT")
    check("fig1a_manifest_ready", manifest["figure_ready"], "YES")

    out = ROOT / "audits" / "fig1a_qa_checks.tsv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 1A data, isolation and render QA checks")


if __name__ == "__main__":
    main()
