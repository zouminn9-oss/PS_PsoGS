#!/usr/bin/env python3
"""Patient-source, direct-contrast, render and print QA for Figure 2E."""

from __future__ import annotations

import csv
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
AUDIT = ROOT / "audits/fig2e_qa_checks.tsv"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            out[key.strip()] = value.strip().strip('"')
    return out


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError("not PNG")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def write_audit(rows: list[dict[str, str]]) -> None:
    with AUDIT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)


def main() -> None:
    checks: list[dict[str, str]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            write_audit(checks)
            raise AssertionError(f"{check_id}: observed {observed!r}; expected {expected!r}")

    source = read_tsv(ROOT / "figures/source_data/fig2e.tsv")
    upstream_scores = read_tsv(ROOT / "results/stage03/specificity/gse121212_pso_ad_paired_scores.tsv")
    stats = read_tsv(ROOT / "results/figures/fig2e_statistics.tsv")
    group_stats = read_tsv(ROOT / "results/stage03/specificity/gse121212_pso_ad_group_statistics.tsv")
    contrasts = read_tsv(ROOT / "results/stage03/specificity/gse121212_pso_ad_direct_comparisons.tsv")
    specificity_audit = read_tsv(ROOT / "audits/stage03_pso_ad_specificity_checks.tsv")
    check("fig2e_specificity_audit", (len(specificity_audit), {r["status"] for r in specificity_audit}),
          (53, {"PASS"}))
    check("fig2e_source_rows", len(source), 54)
    check("fig2e_source_groups", Counter(r["group_id"] for r in source),
          Counter({"PSO_PRIMARY": 27, "AD_ORDINARY": 21, "AD_CHRONIC": 6}))
    check("fig2e_unique_donors", len({r["donor_id"] for r in source}), 54)
    source_map = {(r["group_id"], r["donor_id"]): r for r in source}
    upstream_map = {(r["group_id"], r["donor_id"]): r for r in upstream_scores}
    check("fig2e_source_keys", set(source_map), set(upstream_map))
    for key in source_map:
        for field in ("nonlesional_sample", "lesional_sample", "lesion_definition"):
            check(f"fig2e_source::{key}::{field}", source_map[key][field], upstream_map[key][field])
        for field in ("nonlesional_score", "lesional_score", "delta_LS_minus_NL"):
            check(f"fig2e_source::{key}::{field}",
                  abs(float(source_map[key][field]) - float(upstream_map[key][field])) < 1e-12, True)
    check("fig2e_stat_rows", len(stats), 6)
    check("fig2e_stat_types", Counter(r["record_type"] for r in stats),
          Counter({"GROUP": 3, "CONTRAST": 3}))
    stat_map = {r["record_id"]: r for r in stats}
    for row in group_stats:
        figure = stat_map[row["group_id"]]
        for source_field, figure_field in (("n_pairs", "n_left"), ("mean_delta", "estimate"),
                                           ("ci_low", "ci_low"), ("ci_high", "ci_high"),
                                           ("t_p_value", "primary_p_value"),
                                           ("wilcoxon_p_value", "sensitivity_p_value")):
            check(f"fig2e_group_stat::{row['group_id']}::{source_field}",
                  abs(float(row[source_field]) - float(figure[figure_field])) < 1e-12, True)
    for row in contrasts:
        figure = stat_map[row["contrast_id"]]
        for source_field, figure_field in (("n_left", "n_left"), ("n_right", "n_right"),
                                           ("difference_left_minus_right", "estimate"),
                                           ("ci_low", "ci_low"), ("ci_high", "ci_high"),
                                           ("t_p_value", "primary_p_value"),
                                           ("wilcoxon_p_value", "sensitivity_p_value"),
                                           ("BH_FDR_three_between_group_tests", "BH_FDR")):
            check(f"fig2e_contrast_stat::{row['contrast_id']}::{source_field}",
                  abs(float(row[source_field]) - float(figure[figure_field])) < 1e-12, True)
    primary = stat_map["PSO_MINUS_AD_ORDINARY"]
    check("fig2e_primary_role", primary["analysis_role"], "PRIMARY")
    check("fig2e_primary_effect", abs(float(primary["estimate"]) - 0.0337067431795434) < 1e-14, True)
    check("fig2e_primary_ci_positive", float(primary["ci_low"]) > 0, True)
    check("fig2e_primary_fdr", float(primary["BH_FDR"]) < 0.001, True)
    check("fig2e_all_group_deltas_positive", all(float(r["delta_LS_minus_NL"]) > 0 for r in source), True)
    check("fig2e_ordinary_chronic_crosses_zero",
          float(stat_map["AD_ORDINARY_MINUS_AD_CHRONIC"]["ci_low"]) < 0 <
          float(stat_map["AD_ORDINARY_MINUS_AD_CHRONIC"]["ci_high"]), True)

    cfg = read_config(ROOT / "config/figures/fig2e.yaml")
    plot_script = (ROOT / "scripts/figures/fig2e_plot.R").read_text(encoding="utf-8")
    analysis_script = (ROOT / "scripts/figures/fig2e_analysis.R").read_text(encoding="utf-8")
    check("fig2e_manual_visual", cfg["manual_visual_inspection"],
          "PASS_2026-09-11_SECOND_RENDER_LABEL_LAYOUT")
    check("fig2e_min_text", float(cfg["minimum_text_pt"]) >= 8, True)
    check("fig2e_analysis_derived_only", "data/raw" not in analysis_script, True)
    check("fig2e_plot_derived_only", "data/raw" not in plot_script, True)
    check("fig2e_ascii_plot", all(ord(ch) < 128 for ch in plot_script), True)
    for key in ("psoriasis_color", "ad_color", "chronic_color", "grid_color", "ink_color"):
        check(f"fig2e_color::{key}", cfg[key] in plot_script, True)

    svg = ROOT / "figures/panels/fig2e.svg"; png = ROOT / "figures/previews/fig2e.png"
    caption = ROOT / "figures/captions/fig2e.md"
    check("fig2e_svg", svg.is_file() and svg.stat().st_size > 100000, True)
    check("fig2e_png", png.is_file() and png.stat().st_size > 100000, True)
    check("fig2e_caption", caption.is_file() and caption.stat().st_size > 2400, True)
    caption_text = caption.read_text(encoding="utf-8")
    for phrase in ("all 27 psoriasis patients", "all 21 ordinary AD patients",
                   "not evaluated by contrasting a significant psoriasis result",
                   "supports a larger frozen SEP lesion shift", "lack of evidence",
                   "not psychological-stress causality"):
        check(f"fig2e_caption::{phrase}", phrase in caption_text, True)
    check("fig2e_png_dimensions", png_dimensions(png),
          (round(float(cfg["width_inches"]) * int(cfg["png_dpi"])),
           round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))))
    sw, sh = svg_dimensions(svg)
    check("fig2e_svg_width", abs(sw - float(cfg["width_inches"])) < 0.02, True)
    check("fig2e_svg_height", abs(sh - float(cfg["height_inches"])) < 0.02, True)
    panel = {r["panel_id"]: r for r in read_tsv(ROOT / "panel_manifest.tsv")}["2E"]
    check("fig2e_panel_status", panel["status"], "PASS")
    check("fig2e_panel_qa", panel["qa_status"], "PASS_RENDER_DATA_PRINT")
    check("fig2e_panel_ready", panel["figure_ready"], "YES")
    check("fig2e_panel_source", panel["source_data"], "figures/source_data/fig2e.tsv")

    write_audit(checks)
    print(f"PASS: {len(checks)} Figure 2E patient, contrast, render and print QA checks")


if __name__ == "__main__":
    main()
