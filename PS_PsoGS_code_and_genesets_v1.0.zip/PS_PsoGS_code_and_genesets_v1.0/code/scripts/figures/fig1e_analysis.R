options(stringsAsFactors = FALSE)

pca <- read.delim(file.path("results", "stage02", "factorial_edger", "gse212126_PCA_coordinates.tsv"),
                  check.names = FALSE)
pca_var <- read.delim(file.path("results", "stage02", "factorial_edger", "gse212126_PCA_variance.tsv"),
                      check.names = FALSE)
library_qc <- read.delim(file.path("results", "stage02", "factorial_edger", "gse212126_library_QC.tsv"),
                         check.names = FALSE)
decision <- read.delim(file.path("results", "stage02", "counts", "gse212126_strand_decision.tsv"),
                       check.names = FALSE)
registry <- read.delim(file.path("metadata", "gse212126_library_animal_registry.tsv"),
                       check.names = FALSE)
count_audit <- read.delim(file.path("audits", "stage02_counts", "gse212126_count_integrity_checks.tsv"),
                          check.names = FALSE)
model_audit <- read.delim(file.path("audits", "stage02_counts", "gse212126_edger_integrity_checks.tsv"),
                          check.names = FALSE)

stopifnot(nrow(registry) == 12L, length(unique(registry$canonical_animal_id)) == 12L,
          all(table(registry$condition) == 3L), all(count_audit$status == "PASS"),
          all(model_audit$status == "PASS"), nrow(count_audit) == 15L, nrow(model_audit) == 27L)
stopifnot(setequal(pca$srr, registry$srr), setequal(library_qc$srr, registry$srr),
          setequal(decision$srr, registry$srr), all(decision$selected_strand == 2L),
          all(!decision$selection_used_differential_expression))

read_assignment <- function(strand) {
  tab <- read.delim(file.path("results", "stage02", "counts",
                              paste0("gse212126_assignment_status_strand", strand, ".tsv")),
                    check.names = FALSE)
  stopifnot(identical(colnames(tab)[-1L], registry$srr), sum(tab$Status == "Assigned") == 1L)
  total <- colSums(tab[, -1L, drop = FALSE])
  assigned <- as.numeric(tab[tab$Status == "Assigned", -1L, drop = TRUE])
  data.frame(srr = registry$srr, strand_setting = strand,
             assigned_fragments = assigned, total_classified_fragments = total,
             assignment_fraction = assigned / total, stringsAsFactors = FALSE)
}

strand <- do.call(rbind, lapply(0:2, read_assignment))
stopifnot(nrow(strand) == 36L, all(is.finite(strand$assignment_fraction)),
          all(strand$assignment_fraction >= 0 & strand$assignment_fraction <= 1))

meta <- registry[, c("srr", "canonical_animal_id", "condition", "replicate_label")]
pca <- merge(meta, pca[, c("srr", "PC1", "PC2")], by = "srr", sort = FALSE)
pca <- pca[match(registry$srr, pca$srr), ]
library_qc <- merge(meta, library_qc[, c("srr", "raw_library_size", "filtered_library_size",
                                         "TMM_norm_factor", "effective_library_size")],
                    by = "srr", sort = FALSE)
library_qc <- library_qc[match(registry$srr, library_qc$srr), ]
strand <- merge(meta, strand, by = "srr", sort = FALSE)
strand <- strand[order(match(strand$srr, registry$srr), strand$strand_setting), ]

pca_source <- data.frame(
  record_type = "PCA", srr = pca$srr, canonical_animal_id = pca$canonical_animal_id,
  condition = pca$condition, replicate_label = pca$replicate_label,
  PC1 = pca$PC1, PC2 = pca$PC2,
  PC1_variance = pca_var$variance_explained[pca_var$PC == 1L],
  PC2_variance = pca_var$variance_explained[pca_var$PC == 2L],
  strand_setting = NA, assigned_fragments = NA, total_classified_fragments = NA,
  assignment_fraction = NA, raw_library_size = NA, filtered_library_size = NA,
  TMM_norm_factor = NA, effective_library_size = NA,
  statistical_unit = "independent_mouse", stringsAsFactors = FALSE)
strand_source <- data.frame(
  record_type = "STRAND", srr = strand$srr, canonical_animal_id = strand$canonical_animal_id,
  condition = strand$condition, replicate_label = strand$replicate_label,
  PC1 = NA, PC2 = NA, PC1_variance = NA, PC2_variance = NA,
  strand_setting = strand$strand_setting, assigned_fragments = strand$assigned_fragments,
  total_classified_fragments = strand$total_classified_fragments,
  assignment_fraction = strand$assignment_fraction, raw_library_size = NA,
  filtered_library_size = NA, TMM_norm_factor = NA, effective_library_size = NA,
  statistical_unit = "independent_mouse_library", stringsAsFactors = FALSE)
library_source <- data.frame(
  record_type = "LIBRARY", srr = library_qc$srr,
  canonical_animal_id = library_qc$canonical_animal_id, condition = library_qc$condition,
  replicate_label = library_qc$replicate_label,
  PC1 = NA, PC2 = NA, PC1_variance = NA, PC2_variance = NA,
  strand_setting = NA, assigned_fragments = NA, total_classified_fragments = NA,
  assignment_fraction = NA, raw_library_size = library_qc$raw_library_size,
  filtered_library_size = library_qc$filtered_library_size,
  TMM_norm_factor = library_qc$TMM_norm_factor,
  effective_library_size = library_qc$effective_library_size,
  statistical_unit = "independent_mouse_library", stringsAsFactors = FALSE)
source <- rbind(pca_source, strand_source, library_source)

dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(source, file.path("figures", "source_data", "fig1e.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE, na = "")

stats <- data.frame(
  metric = c("independent_mice", "factorial_cells", "mice_per_cell", "selected_strand",
             "strand1_assignment_fraction_min", "strand1_assignment_fraction_max",
             "strand2_assignment_fraction_min", "strand2_assignment_fraction_max",
             "assigned_fragments_min", "assigned_fragments_max", "TMM_factor_min",
             "TMM_factor_max", "PC1_variance_explained", "PC2_variance_explained",
             "count_integrity_checks_pass", "edgeR_integrity_checks_pass",
             "validation_expression_accessed"),
  value = c(12, 4, 3, 2,
            min(strand$assignment_fraction[strand$strand_setting == 1]),
            max(strand$assignment_fraction[strand$strand_setting == 1]),
            min(strand$assignment_fraction[strand$strand_setting == 2]),
            max(strand$assignment_fraction[strand$strand_setting == 2]),
            min(library_qc$raw_library_size), max(library_qc$raw_library_size),
            min(library_qc$TMM_norm_factor), max(library_qc$TMM_norm_factor),
            pca_var$variance_explained[pca_var$PC == 1L],
            pca_var$variance_explained[pca_var$PC == 2L], 15, 27, 0),
  unit = c("mice", "groups", "mice", "featureCounts_code",
           rep("fraction_of_classified_fragments", 4), rep("fragments", 2),
           rep("factor", 2), rep("fraction", 2), "checks", "checks", "boolean"),
  status = c(rep("PASS", 16), "PASS_LOCKED"),
  interpretation = c(
    "one unpooled library per user-confirmed independent mouse", "balanced 2x2 design",
    "three biological replicates in each cell", "reverse-stranded counting frozen by assignment rule",
    "minimum wrong-direction assignment", "maximum wrong-direction assignment",
    "minimum selected-direction assignment", "maximum selected-direction assignment",
    "minimum raw assigned count", "maximum raw assigned count", "minimum TMM factor",
    "maximum TMM factor", "PC1 sample-level variance", "PC2 sample-level variance",
    "independent count checks", "independent model checks", "validation cohorts remained isolated"),
  stringsAsFactors = FALSE)
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(stats, file.path("results", "figures", "fig1e_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
cat("PASS: exported Figure 1E source data and QC statistics for 12 independent mice\n")
