options(stringsAsFactors = FALSE)

genes <- read.delim(file.path("results", "stage03", "gene_replication.tsv"),
                    check.names = FALSE)
summary <- read.delim(file.path("results", "stage03", "gene_replication_summary.tsv"),
                      check.names = FALSE)
audit <- read.delim(file.path("audits", "stage03_gene_replication_checks.tsv"),
                    check.names = FALSE)
stopifnot(nrow(genes) == 2716L, nrow(summary) == 9L, all(audit$status == "PASS"),
          length(unique(genes$human_gene_symbol)) == 2716L,
          sum(genes$sep_direction == "UP") == 1399L,
          sum(genes$sep_direction == "DOWN") == 1317L)

genes$direction_order <- match(genes$sep_direction, c("UP", "DOWN"))
genes <- genes[order(genes$direction_order, genes$human_gene_symbol), ]
genes$display_index <- seq_len(nrow(genes))
genes$array_display_state <- ifelse(
  genes$array_state == "CONCORDANT_FDR_LT_0.05", "CONCORDANT_STRICT",
  ifelse(genes$array_state == "CONCORDANT_FDR_GE_0.05", "CONCORDANT_NON_FDR",
  ifelse(genes$array_state == "DISCORDANT_FDR_LT_0.05", "DISCORDANT_FDR",
  ifelse(genes$array_state == "DISCORDANT_FDR_GE_0.05", "DISCORDANT_NON_FDR", "UNAVAILABLE"))))
genes$rnaseq_display_state <- ifelse(
  genes$rnaseq_state == "CONCORDANT_FDR_LT_0.05", "CONCORDANT_STRICT",
  ifelse(genes$rnaseq_state == "CONCORDANT_FDR_GE_0.05", "CONCORDANT_NON_FDR",
  ifelse(genes$rnaseq_state == "DISCORDANT_FDR_LT_0.05", "DISCORDANT_FDR",
  ifelse(genes$rnaseq_state == "DISCORDANT_FDR_GE_0.05", "DISCORDANT_NON_FDR", "UNAVAILABLE"))))

dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
write.table(genes, file.path("figures", "source_data", "fig2d.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE, na = "")
dir.create(file.path("results", "figures"), recursive = TRUE, showWarnings = FALSE)
write.table(summary, file.path("results", "figures", "fig2d_statistics.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE, na = "")
cat("PASS: exported all 2716 frozen SEP members and nine Figure 2D summaries\n")
