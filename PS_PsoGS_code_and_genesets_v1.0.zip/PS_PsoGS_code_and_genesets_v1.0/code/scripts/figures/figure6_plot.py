from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'python_libs/stage04'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL import Image

SRC=ROOT/'figures/source_data';PAN=ROOT/'figures/panels';PRE=ROOT/'figures/previews';BASE=ROOT/'data/raw/stage06/sections'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':7,'axes.titlesize':8,'axes.labelsize':7,'svg.fonttype':'none'})
sections=['NS1','NS2','PP1','PP2','PP3','PP4']
def mm(w,h):return(w/25.4,h/25.4)
def save(fig,p):fig.savefig(PAN/f'fig{p}.svg',bbox_inches='tight');fig.savefig(PRE/f'fig{p}.png',dpi=300,bbox_inches='tight');plt.close(fig)
def bg(ax,s,alpha=.60):
    im=np.asarray(Image.open(BASE/s/'spatial/tissue_hires_image.png'));ax.imshow(im,alpha=alpha);ax.set_aspect('equal');ax.axis('off')
def grid_title(ax,s):ax.set_title(s+(' · FFPE' if s=='PP4' else ' · frozen'),fontsize=7,color='#A35D00' if s=='PP4' else '#222')

qc=pd.read_csv(SRC/'fig6a.tsv',sep='\t');fig,axs=plt.subplots(2,3,figsize=mm(180,122));
for ax,s in zip(axs.ravel(),sections):
    bg(ax,s,1);r=qc[qc.section==s].iloc[0];grid_title(ax,s);ax.text(.02,.02,f"QC {int(r.qc_spots)}/{int(r.filtered_spots)} spots\nmedian UMI {r.median_counts:.0f}",transform=ax.transAxes,fontsize=5.6,bbox=dict(fc='white',alpha=.75,ec='none'))
fig.suptitle('6A  All six public tissue images and matrices are present',x=.02,ha='left',weight='bold',fontsize=10);save(fig,'6a')

d=pd.read_csv(SRC/'fig6b.tsv',sep='\t');colors={'keratinocyte-rich':'#E76F51','stromal-rich':'#2A9D8F','immune-rich':'#6A4C93','mixed/uncertain':'#B7B7B7'};fig,axs=plt.subplots(2,3,figsize=mm(180,122));
for ax,s in zip(axs.ravel(),sections):
    bg(ax,s,.36);z=d[(d.section==s)&d.qc_pass];
    for lab,c in colors.items():q=z[z.expression_compartment==lab];ax.scatter(q.x_hires,q.y_hires,s=2.2,c=c,label=lab,linewidths=0,alpha=.85)
    grid_title(ax,s)
handles=[plt.Line2D([],[],marker='o',ls='',color=c,label=k,markersize=4) for k,c in colors.items()];fig.legend(handles=handles,loc='lower center',ncol=4,frameon=False,fontsize=6)
fig.suptitle('6B  Marker-defined spot mixtures are descriptive compartments',x=.02,ha='left',weight='bold',fontsize=10);fig.subplots_adjust(bottom=.10);save(fig,'6b')

d=pd.read_csv(SRC/'fig6c.tsv',sep='\t');cts=[c for c in d.columns if c not in ['section','disease','chemistry']];M=d.set_index('section').loc[sections,cts].T;fig,ax=plt.subplots(figsize=mm(178,105));im=ax.imshow(M,aspect='auto',cmap='viridis');ax.set_xticks(range(6),[s+('*' if s=='PP4' else '') for s in sections]);ax.set_yticks(range(len(cts)),cts);ax.set_title('6C  Median reference-mapped cell-state mixture by section',loc='left',weight='bold');fig.colorbar(im,ax=ax,label='median NNLS proportion',fraction=.025);ax.text(1,-.12,'* FFPE; other sections frozen',transform=ax.transAxes,ha='right',fontsize=6);save(fig,'6c')

def spatial_score(panel,col,title,cmap):
    d=pd.read_csv(SRC/f'fig{panel}.tsv',sep='\t');lo,hi=np.nanquantile(d[col],[.02,.98]);fig,axs=plt.subplots(2,3,figsize=mm(180,122));last=None
    for ax,s in zip(axs.ravel(),sections):
        bg(ax,s,.32);z=d[d.section==s];last=ax.scatter(z.x_hires,z.y_hires,c=z[col],s=2.5,cmap=cmap,vmin=lo,vmax=hi,linewidths=0);grid_title(ax,s)
    fig.colorbar(last,ax=axs.ravel().tolist(),fraction=.02,pad=.02,label=col.replace('_',' '));fig.suptitle(title,x=.02,ha='left',weight='bold',fontsize=10);save(fig,panel)
spatial_score('6d','core_directed','6D  Frozen Core score is mapped without spot-level inference','coolwarm')
spatial_score('6e','sep_directed','6E  Frozen SEP score is mapped without redefining direction','coolwarm')
spatial_score('6g','glutathione_rna','6G  Glutathione transcript score is not a metabolite map','magma')

d=pd.read_csv(SRC/'fig6f.tsv',sep='\t');fig,axs=plt.subplots(4,3,figsize=mm(180,150));
for block,ss in enumerate([sections[:3],sections[3:]]):
    for j,s in enumerate(ss):
        z=d[d.section==s]
        for off,(col,label) in enumerate([('JAG2_log1p_cp10k','JAG2'),('NOTCH2_log1p_cp10k','NOTCH2')]):
            i=block*2+off;ax=axs[i,j];bg(ax,s,.25);q=np.nanquantile(d[col],[.02,.98]);ax.scatter(z.x_hires,z.y_hires,c=z[col],s=2.5,cmap='plasma',vmin=q[0],vmax=q[1],linewidths=0);ax.set_title((s+' · ')+label,fontsize=6.4)
fig.suptitle('6F  Ligand and receptor expression are shown separately; co-localization is blocked',x=.02,ha='left',weight='bold',fontsize=10);save(fig,'6f')

d=pd.read_csv(SRC/'fig6k.tsv',sep='\t');fig,axs=plt.subplots(1,3,figsize=mm(180,88));
for ax,col,label in zip(axs,['median_core','median_sep','median_glutathione'],['Core','SEP','Glutathione RNA']):
    for i,r in d.iterrows():ax.scatter(i,r[col],s=35,c='#E76F51' if r.disease=='psoriasis' else '#457B9D',marker='s' if r.chemistry=='FFPE' else 'o')
    ax.set_xticks(range(len(d)),d.section,rotation=45);ax.set_title(label);ax.spines[['top','right']].set_visible(False)
handles=[plt.Line2D([],[],marker='o',ls='',color='#457B9D',label='healthy frozen'),plt.Line2D([],[],marker='o',ls='',color='#E76F51',label='psoriasis frozen'),plt.Line2D([],[],marker='s',ls='',color='#E76F51',label='psoriasis FFPE')]
fig.legend(handles=handles,loc='lower center',ncol=3,frameon=False,fontsize=6);fig.subplots_adjust(bottom=.20)
fig.suptitle('6K  Section summaries remain visible and FFPE is not pooled with frozen',x=.02,ha='left',weight='bold',fontsize=10);save(fig,'6k')

d=pd.read_csv(SRC/'fig6l.tsv',sep='\t');fig,ax=plt.subplots(figsize=mm(155,95));
for ct,m,c in [('Keratinocyte','o','#E76F51'),('Fibroblast','s','#2A9D8F')]:
    z=d[d.cell_type==ct];ax.scatter(z.section,z.spearman_rho,s=42,marker=m,c=c,label=ct)
ax.axhline(0,color='#777',lw=.7);ax.set_ylim(-1,1);ax.set_ylabel('spot-level Spearman ρ');ax.set_title('6L  Mapping depends on the single-cell reference',loc='left',weight='bold');ax.legend(frameon=False);ax.spines[['top','right']].set_visible(False);save(fig,'6l')
print('PASS: rendered Figure 6 terminal panels')
