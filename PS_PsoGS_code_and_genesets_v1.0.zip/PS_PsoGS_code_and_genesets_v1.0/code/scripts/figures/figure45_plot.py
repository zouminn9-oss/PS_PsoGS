from __future__ import annotations

import sys
import textwrap
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "python_libs/stage04"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

SRC = ROOT / "figures/source_data"; PAN = ROOT / "figures/panels"; PRE = ROOT / "figures/previews"
PAN.mkdir(parents=True, exist_ok=True); PRE.mkdir(parents=True, exist_ok=True)
COL = {"PASS": "#2A9D8F", "LIMIT": "#E9C46A", "NEGATIVE": "#8D99AE", "FAIL": "#E76F51", "BLOCKED": "#6C757D", True: "#2A9D8F", False: "#D95F5F"}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.titlesize": 10, "axes.labelsize": 8, "svg.fonttype": "none"})

def save(fig, panel):
    fig.savefig(PAN / f"fig{panel}.svg", bbox_inches="tight")
    fig.savefig(PRE / f"fig{panel}.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

def mm(w, h): return (w / 25.4, h / 25.4)

d = pd.read_csv(SRC / "fig4a.tsv", sep="\t")
fig, ax = plt.subplots(figsize=mm(180, 102)); y = np.arange(len(d))[::-1]
for yy, ok in zip(y, d["pass"]): ax.scatter(0, yy, s=110, color=COL[bool(ok)], marker="o" if ok else "X")
for yy, row in zip(y, d.itertuples(index=False)):
    ax.text(.13, yy, textwrap.fill(row.criterion.replace("_", " "), 35), va="center", fontsize=7.0)
    ax.text(2.0, yy, textwrap.fill(str(row.evidence), 58), va="center", fontsize=6.1, color="#444444")
ax.set_xlim(-.08, 5.2); ax.set_ylim(-.7, len(d)-.3); ax.axis("off"); ax.set_title("4A  Fibroblast trajectory gate closes before model fitting", loc="left", weight="bold")
ax.text(0, -1.05, "Decision: BLOCKED — no independently defined root and distinct terminal states", fontsize=7.2, weight="bold", color="#8B3A3A")
save(fig, "4a")

d = pd.read_csv(SRC / "fig4h.tsv", sep="\t").sort_values("mean_pp_minus_pn")
fig, ax = plt.subplots(figsize=mm(160, 118)); y=np.arange(len(d));
ax.hlines(y, d.ci95_low, d.ci95_high, color="#65758B", lw=1.3); ax.scatter(d.mean_pp_minus_pn, y, c=[COL[bool(x < .05)] for x in d.fdr_bh], s=28, zorder=3)
ax.axvline(0, color="#333", lw=.8); ax.set_yticks(y, d.tf); ax.set_xlabel("PP − PN inferred regulon activity (paired donor)"); ax.set_title("4H  Nominal TF shifts do not survive BH-FDR correction", loc="left", weight="bold")
ax.text(.99,.01,"76 regulons tested; 0 at BH FDR < 0.05",transform=ax.transAxes,ha="right",fontsize=7,color="#555")
ax.spines[['top','right']].set_visible(False); save(fig,"4h")

d=pd.read_csv(SRC/"fig5a.tsv",sep="\t"); fig,ax=plt.subplots(figsize=mm(170,78)); y=np.arange(len(d))[::-1]
for yy,row in zip(y,d.itertuples(index=False)):
    ax.barh(yy,1,color=COL[row.status],height=.64); ax.text(.02,yy,row.module,va="center",weight="bold",color="white",fontsize=7.2); ax.text(1.04,yy,row.evidence,va="center",fontsize=6.8)
ax.set_xlim(0,2.35);ax.set_ylim(-.6,len(d)-.4);ax.axis('off');ax.set_title("5A  Stage 05 advances only evidence that passes its own gate",loc="left",weight="bold");save(fig,"5a")

d=pd.read_csv(SRC/"fig5b.tsv",sep="\t"); fig,axs=plt.subplots(1,2,figsize=mm(170,95),gridspec_kw={'wspace':.38})
x=d[(d.cohort=="GSE173706") & d.condition.isin(["PN","PP"])].pivot(index="donor_id",columns="condition",values="score").dropna()
for _,r in x.iterrows(): axs[0].plot([0,1],[r.PN,r.PP],color="#9AA5B1",lw=.8);axs[0].scatter([0,1],[r.PN,r.PP],c=["#457B9D","#D1495B"],s=18,zorder=3)
axs[0].set_xticks([0,1],["PN","PP"]);axs[0].set_ylabel("JAG2–NOTCH2 compatibility score");axs[0].set_title("Discovery: 7 paired donors",fontsize=8.5)
r=d[d.cohort=="GSE162183"]
for i,(lab,grp) in enumerate(r.groupby("condition",sort=True)):
    jitter=np.linspace(-.06,.06,len(grp));axs[1].scatter(i+jitter,grp.score,s=26,label=lab,color="#457B9D" if lab=="Control" else "#D1495B")
    axs[1].hlines(grp.score.mean(),i-.16,i+.16,color="#222",lw=1.4)
axs[1].set_xticks([0,1],["Control","Psoriasis"]);axs[1].set_title("Replication: 3 + 3 donors",fontsize=8.5)
for ax in axs: ax.spines[['top','right']].set_visible(False)
fig.suptitle("5B  Endothelial JAG2–fibroblast NOTCH2 expression compatibility",x=.02,ha="left",weight="bold");save(fig,"5b")

d=pd.read_csv(SRC/"fig5d.tsv",sep="\t"); fig,ax=plt.subplots(figsize=mm(170,76));ax.axis('off');ax.set_title("5D  Curated downstream links bound the JAG2–NOTCH2 hypothesis",loc="left",weight="bold")
ax.text(.05,.62,"Endothelial\nJAG2",ha='center',va='center',bbox=dict(boxstyle='round',fc='#CDE5F2',ec='#457B9D'))
ax.text(.35,.62,"Fibroblast\nNOTCH2",ha='center',va='center',bbox=dict(boxstyle='round',fc='#F9D8DC',ec='#D1495B'))
ax.annotate("",xy=(.27,.62),xytext=(.13,.62),arrowprops=dict(arrowstyle='->',lw=1.5));ax.text(.20,.69,"curated LR",ha='center',fontsize=6.5)
for i,row in enumerate(d.itertuples(index=False)):
    yy=.83-i*.21;ax.text(.72,yy,row.TF_symbol,ha='center',va='center',bbox=dict(boxstyle='round',fc='#EEE',ec='#777'));ax.annotate("",xy=(.65,yy),xytext=(.43,.62),arrowprops=dict(arrowstyle='->',lw=.9,color='#777'));ax.text(.98,yy,str(row.Source)[:25],ha='right',va='center',fontsize=5.8)
ax.text(.02,.06,"Receptor→TF edges are curated knowledge, not measured activation; TF family screen had 0 BH-significant regulons.",fontsize=6.8,color='#555');save(fig,"5d")

d=pd.read_csv(SRC/"fig5f.tsv",sep="\t").sort_values("mean_pp_minus_pn");fig,ax=plt.subplots(figsize=mm(165,105));y=np.arange(len(d));
ax.hlines(y,d.ci95_low,d.ci95_high,color='#65758B');ax.scatter(d.mean_pp_minus_pn,y,c=[COL[bool(x<.05)] for x in d.fdr_bh],s=30,zorder=3);ax.axvline(0,color='#333',lw=.8);ax.set_yticks(y,[x.replace(" synthesis and recycling","") for x in d.pathway]);ax.set_xlabel("PP − PN mean gene-percentile score");ax.set_title("5F  One of eight prespecified metabolic RNA programs passes BH",loc='left',weight='bold');ax.spines[['top','right']].set_visible(False);save(fig,"5f")

d=pd.read_csv(SRC/"fig5g.tsv",sep="\t");fig,axs=plt.subplots(1,2,figsize=mm(170,95),gridspec_kw={'wspace':.38})
x=d[(d.cohort=="GSE173706") & d.condition.isin(["PN","PP"])].pivot(index="donor_id",columns="condition",values="score").dropna()
for _,r in x.iterrows():axs[0].plot([0,1],[r.PN,r.PP],color='#9AA5B1',lw=.8);axs[0].scatter([0,1],[r.PN,r.PP],c=['#457B9D','#D1495B'],s=18,zorder=3)
axs[0].set_xticks([0,1],["PN","PP"]);axs[0].set_ylabel("Reactome glutathione transcript score");axs[0].set_title("Discovery: FDR = 0.0055",fontsize=8.5)
r=d[d.cohort=="GSE162183"]
for i,(lab,grp) in enumerate(r.groupby("condition",sort=True)):
    axs[1].scatter(i+np.linspace(-.06,.06,len(grp)),grp.score,s=26,color='#457B9D' if lab=='Control' else '#D1495B');axs[1].hlines(grp.score.mean(),i-.16,i+.16,color='#222',lw=1.4)
axs[1].set_xticks([0,1],["Control","Psoriasis"]);axs[1].set_title("Replication: P = 0.415",fontsize=8.5)
for ax in axs:ax.spines[['top','right']].set_visible(False)
fig.suptitle("5G  Glutathione RNA-program increase does not independently replicate",x=.02,ha='left',weight='bold');save(fig,"5g")

d=pd.read_csv(SRC/"fig5i.tsv",sep="\t");names=list(dict.fromkeys(d.pathway));fig,ax=plt.subplots(figsize=mm(165,105));
for y,name in enumerate(names):
    q=d[d.pathway==name]
    for var,marker,color,off in [("primary","o","#D1495B",-.12),("remove_sep_cell_cycle","s","#457B9D",.12)]:
        z=q[q.variant==var]
        if len(z) and np.isfinite(z.mean_pp_minus_pn.iloc[0]):
            ax.errorbar(z.mean_pp_minus_pn.iloc[0],y+off,xerr=[[z.mean_pp_minus_pn.iloc[0]-z.ci95_low.iloc[0]],[z.ci95_high.iloc[0]-z.mean_pp_minus_pn.iloc[0]]],fmt=marker,color=color,ms=4,lw=1)
        else: ax.text(ax.get_xlim()[0] if ax.get_xlim()[0] else -.01,y+off,"not estimable",fontsize=5.8,color='#777')
ax.axvline(0,color='#333',lw=.8);ax.set_yticks(range(len(names)),[n.replace(' synthesis and recycling','') for n in names]);ax.set_xlabel("PP − PN score");ax.set_title("5I  Removing SEP/cell-cycle overlap changes the evidence",loc='left',weight='bold');ax.scatter([],[],c='#D1495B',label='Primary');ax.scatter([],[],marker='s',c='#457B9D',label='Remove overlap');ax.legend(frameon=False,fontsize=6.5);ax.spines[['top','right']].set_visible(False);save(fig,"5i")

d=pd.read_csv(SRC/"fig5j.tsv",sep="\t");s=pd.read_csv(ROOT/"results/figures/fig5j_statistics.tsv",sep="\t").iloc[0];fig,ax=plt.subplots(figsize=mm(115,105));ax.scatter(d.lr_delta,d.glutathione_delta,s=30,c='#6A4C93');
for r in d.itertuples(index=False):ax.text(r.lr_delta,r.glutathione_delta,r.donor_id,fontsize=5.5,ha='left',va='bottom')
ax.axhline(0,color='#999',lw=.6);ax.axvline(0,color='#999',lw=.6);ax.set_xlabel("Δ JAG2–NOTCH2 compatibility");ax.set_ylabel("Δ glutathione RNA score");ax.set_title("5J  Donor changes are not demonstrably coupled",loc='left',weight='bold');ax.text(.98,.04,f"Spearman ρ={s.spearman_rho:.2f}; P={s.spearman_p:.3f}; n={int(s.n_donors)}",transform=ax.transAxes,ha='right',fontsize=7);ax.spines[['top','right']].set_visible(False);save(fig,"5j")

d=pd.read_csv(SRC/"fig5l.tsv",sep="\t");fig,ax=plt.subplots(figsize=mm(205,115));ax.axis('off');ax.set_title("5L  Stage 05 conclusions retain explicit claim ceilings",loc='left',weight='bold')
y=np.arange(len(d))[::-1]
for yy,row in zip(y,d.itertuples(index=False)):
    ax.scatter(.04,yy,s=90,color=COL[row.status]);ax.text(.13,yy,textwrap.fill(row.claim,32),va='center',weight='bold',fontsize=6.8);ax.text(.95,yy,textwrap.fill(row.evidence,48),va='center',fontsize=6.1);ax.text(1.85,yy,textwrap.fill(row.claim_ceiling,28),va='center',fontsize=6.1,color='#555')
ax.text(.13,len(d)-.35,"Claim",fontsize=6.2,color='#666');ax.text(.95,len(d)-.35,"Observed evidence",fontsize=6.2,color='#666');ax.text(1.85,len(d)-.35,"Claim ceiling",fontsize=6.2,color='#666')
ax.set_xlim(0,2.55);ax.set_ylim(-.8,len(d)-.15);save(fig,"5l")

print("PASS: rendered Figure 4/5 terminal panels")
