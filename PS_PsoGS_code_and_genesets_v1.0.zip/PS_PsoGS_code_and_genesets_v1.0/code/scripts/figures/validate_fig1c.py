#!/usr/bin/env python3
"""Data, provenance, render and print-size QA for Figure 1C."""

from __future__ import annotations

import csv
import struct
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def read_config(path: Path) -> dict[str, str]:
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if line and not line.lstrip().startswith("#") and ":" in line:
            key, value = line.split(":", 1)
            out[key.strip()] = value.strip().strip('"')
    return out


def png_dimensions(path: Path) -> tuple[int, int]:
    with path.open("rb") as handle:
        header = handle.read(24)
    if header[:8] != b"\x89PNG\r\n\x1a\n":
        raise AssertionError(f"Not a PNG: {path}")
    return struct.unpack(">II", header[16:24])


def svg_dimensions(path: Path) -> tuple[float, float]:
    root = ET.parse(path).getroot()
    return (float(root.attrib["width"].replace("pt", "")) / 72,
            float(root.attrib["height"].replace("pt", "")) / 72)


def main() -> None:
    checks = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = str(observed) == str(expected)
        checks.append({"check_id": check_id, "observed": str(observed), "expected": str(expected),
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}, expected {expected!r}")

    source = read_tsv(ROOT / "figures" / "source_data" / "fig1c.tsv")
    stats = read_tsv(ROOT / "results" / "figures" / "fig1c_statistics.tsv")
    registry = read_tsv(ROOT / "metadata" / "gse212126_library_animal_registry.tsv")
    confirmation = read_tsv(ROOT / "audits" / "gse212126_user_confirmation.tsv")
    panels = read_tsv(ROOT / "panel_manifest.tsv")

    groups = [r for r in source if r["record_type"] == "GROUP"]
    estimands = {r["record_id"]: r for r in source if r["record_type"] == "ESTIMAND"}
    gates = {r["record_id"]: r for r in source if r["record_type"] == "GATE"}
    check("fig1c_source_rows", len(source), 9)
    check("fig1c_groups", len(groups), 4)
    check("fig1c_group_labels", ",".join(r["label"] for r in groups), "Control,CRS,IMQ,CRS+IMQ")
    check("fig1c_group_counts", ",".join(r["n"] for r in groups), "3,3,3,3")
    check("fig1c_statistical_unit", sum(r["statistical_unit"] == "independent mouse" for r in groups), 4)
    check("fig1c_registry_rows", len(registry), 12)
    check("fig1c_unique_animals", len({r["canonical_animal_id"] for r in registry}), 12)
    check("fig1c_unique_libraries", len({r["srr"] for r in registry}), 12)
    check("fig1c_one_library_per_animal", sum(r["libraries_per_animal"] == "1" for r in registry), 12)
    check("fig1c_one_animal_per_library", sum(r["animals_per_library"] == "1" for r in registry), 12)
    check("fig1c_no_pooling", sum(r["pooling_status"] == "NO_POOLING_USER_CONFIRMED" for r in registry), 12)
    check("fig1c_user_confirmation", confirmation[0]["animal_gate_status"], "PASS_USER_CONFIRMED")
    check("fig1c_public_source_not_archived", confirmation[0]["public_source_document_archived"], "NO")
    check("fig1c_blocker_at_confirmation", confirmation[0]["remaining_stage02_blocker"], "RAW_INTEGER_COUNTS_NOT_YET_RECONSTRUCTED")
    check("fig1c_estimands", ",".join(estimands), "S0,SD,I")
    check("fig1c_s0_formula", estimands["S0"]["formula"], "mu_CRS - mu_Control")
    check("fig1c_sd_formula", estimands["SD"]["formula"], "mu_CRS+IMQ - mu_IMQ")
    check("fig1c_i_formula", estimands["I"]["formula"], "(mu_CRS+IMQ - mu_IMQ) - (mu_CRS - mu_Control)")
    check("fig1c_estimands_model_available", sum(r["gate_status"] == "PASS_MOUSE_FACTORIAL_MODEL" for r in estimands.values()), 3)
    check("fig1c_animal_gate", gates["ANIMAL"]["gate_status"], "PASS_USER_CONFIRMED")
    check("fig1c_count_gate", gates["COUNTS"]["gate_status"], "PASS_COUNT_AND_MODEL_AUDITS")
    check("fig1c_no_inferential_statistics", all(r["statistical_test"] == "none_design_and_estimand_specification" for r in stats), True)
    check("fig1c_stats_rows", len(stats), len(source))
    check("fig1c_model_outputs_not_displayed",
          sum(r["result_status"] == "MODEL_OUTPUT_AVAILABLE_NOT_DISPLAYED" for r in stats), 3)

    cfg = read_config(ROOT / "config" / "figures" / "fig1c.yaml")
    svg = ROOT / "figures" / "panels" / "fig1c.svg"
    png = ROOT / "figures" / "previews" / "fig1c.png"
    caption = ROOT / "figures" / "captions" / "fig1c.md"
    check("fig1c_minimum_text_pt", float(cfg["minimum_text_pt"]) >= 8, True)
    check("fig1c_print_width_mm", cfg["print_width_mm"], 178)
    check("fig1c_print_height_mm", cfg["print_height_mm"], 110)
    check("fig1c_svg_exists", svg.exists() and svg.stat().st_size > 5000, True)
    check("fig1c_png_exists", png.exists() and png.stat().st_size > 20000, True)
    check("fig1c_caption_exists", caption.exists() and caption.stat().st_size > 1000, True)
    svg_w, svg_h = svg_dimensions(svg)
    check("fig1c_svg_width_inches", abs(svg_w - float(cfg["width_inches"])) < 0.02, True)
    check("fig1c_svg_height_inches", abs(svg_h - float(cfg["height_inches"])) < 0.02, True)
    png_w, png_h = png_dimensions(png)
    check("fig1c_png_width_pixels", abs(png_w - round(float(cfg["width_inches"]) * int(cfg["png_dpi"]))) <= 1, True)
    check("fig1c_png_height_pixels", abs(png_h - round(float(cfg["height_inches"]) * int(cfg["png_dpi"]))) <= 1, True)

    manifest = {r["panel_id"]: r for r in panels}["1C"]
    check("fig1c_manifest_status", manifest["status"], "PASS")
    check("fig1c_manifest_qa", manifest["qa_status"], "PASS_RENDER_DATA_PRINT")
    check("fig1c_manifest_ready", manifest["figure_ready"], "YES")

    out = ROOT / "audits" / "fig1c_qa_checks.tsv"
    with out.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(checks)
    print(f"PASS: {len(checks)} Figure 1C design, provenance and render QA checks")


if __name__ == "__main__":
    main()
