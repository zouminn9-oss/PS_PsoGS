options(stringsAsFactors = FALSE)

scores <- read.delim(file.path("figures", "source_data", "fig2e.tsv"), check.names = FALSE)
stats <- read.delim(file.path("results", "figures", "fig2e_statistics.tsv"), check.names = FALSE)
ink <- "#343B42"; blue <- "#0072B2"; orange <- "#D55E00"
neutral <- "#7A7F85"; grid <- "#DDE2E5"
groups <- c("PSO_PRIMARY", "AD_ORDINARY", "AD_CHRONIC")
group_colors <- c(blue, orange, neutral)
group_y <- c(3, 2, 1)

p_label <- function(p) ifelse(p < 1e-4, formatC(p, format = "e", digits = 2),
                              formatC(p, format = "f", digits = 4))

draw_panel <- function() {
  layout(matrix(c(1, 2), nrow = 1), widths = c(1.18, 0.82))
  par(mar = c(4.2, 1.0, 3.2, 1.0), family = "sans", xpd = NA)
  plot.new(); plot.window(xlim = c(-0.012, 0.145), ylim = c(0.45, 3.72))
  abline(v = seq(0, 0.14, 0.02), col = grid, lwd = 0.65)
  abline(v = 0, col = neutral, lty = 2, lwd = 1)
  group_stats <- stats[stats$record_type == "GROUP", ]
  for (i in seq_along(groups)) {
    values <- scores$delta_LS_minus_NL[scores$group_id == groups[i]]
    set.seed(c(121212, 121213, 121214)[i])
    points(values, group_y[i] + runif(length(values), -0.105, 0.105),
           pch = 21, cex = 0.78, bg = adjustcolor(group_colors[i], alpha.f = 0.72),
           col = "white", lwd = 0.45)
    row <- group_stats[group_stats$record_id == groups[i], ]
    segments(row$ci_low, group_y[i] - 0.25, row$ci_high, group_y[i] - 0.25,
             col = ink, lwd = 2.0)
    segments(row$ci_low, group_y[i] - 0.30, row$ci_low, group_y[i] - 0.20, col = ink)
    segments(row$ci_high, group_y[i] - 0.30, row$ci_high, group_y[i] - 0.20, col = ink)
    points(row$estimate, group_y[i] - 0.25, pch = 23, cex = 1.0,
           bg = group_colors[i], col = ink, lwd = 0.7)
    text(-0.009, group_y[i] + 0.28, row$label, adj = c(0, 0.5),
         cex = 0.73, font = 2, col = group_colors[i])
    text(0.142, group_y[i] + 0.28,
         sprintf("n=%d | mean %.3f [%.3f, %.3f]", row$n_left, row$estimate, row$ci_low, row$ci_high),
         adj = c(1, 0.5), cex = 0.60, col = ink)
  }
  axis(1, at = seq(0, 0.14, 0.02), labels = sprintf("%.2f", seq(0, 0.14, 0.02)),
       cex.axis = 0.70, col.axis = ink, col = ink, tck = -0.018)
  mtext("Patient lesion - non-lesional SEP score", side = 1, line = 2.45, cex = 0.72, col = ink)
  text(-0.009, 3.70, "Patient-level shifts", adj = c(0, 1), cex = 0.92, font = 2, col = ink)
  text(0.142, 0.51, "dots: patients | diamond and bar: mean and 95% CI",
       adj = c(1, 0.5), cex = 0.57, col = neutral)

  par(mar = c(4.2, 1.4, 3.2, 0.8), family = "sans", xpd = NA)
  plot.new(); plot.window(xlim = c(-0.045, 0.066), ylim = c(0.45, 3.72))
  abline(v = seq(-0.04, 0.06, 0.02), col = grid, lwd = 0.65)
  abline(v = 0, col = neutral, lty = 2, lwd = 1)
  contrast <- stats[stats$record_type == "CONTRAST", ]
  contrast_y <- c(3, 2, 1)
  for (i in seq_len(nrow(contrast))) {
    row <- contrast[i, ]; color <- ifelse(row$analysis_role == "PRIMARY", blue, neutral)
    segments(row$ci_low, contrast_y[i], row$ci_high, contrast_y[i], col = color, lwd = 2.1)
    segments(row$ci_low, contrast_y[i] - 0.07, row$ci_low, contrast_y[i] + 0.07, col = color)
    segments(row$ci_high, contrast_y[i] - 0.07, row$ci_high, contrast_y[i] + 0.07, col = color)
    points(row$estimate, contrast_y[i], pch = ifelse(row$analysis_role == "PRIMARY", 23, 21),
           cex = 1.05, bg = color, col = ink, lwd = 0.7)
    text(-0.042, contrast_y[i] + 0.29, row$label, adj = c(0, 0.5),
         cex = 0.66, font = ifelse(row$analysis_role == "PRIMARY", 2, 1), col = color)
    text(0.063, contrast_y[i] + 0.13,
         sprintf("%.3f [%.3f, %.3f]", row$estimate, row$ci_low, row$ci_high),
         adj = c(1, 0.5), cex = 0.59, col = ink)
    text(0.063, contrast_y[i] - 0.25,
         sprintf("Welch P=%s | BH FDR=%s", p_label(row$primary_p_value), p_label(row$BH_FDR)),
         adj = c(1, 0.5), cex = 0.56, col = neutral)
  }
  axis(1, at = seq(-0.04, 0.06, 0.02), labels = sprintf("%.2f", seq(-0.04, 0.06, 0.02)),
       cex.axis = 0.70, col.axis = ink, col = ink, tck = -0.018)
  mtext("Difference between patient-level shifts", side = 1, line = 2.45, cex = 0.72, col = ink)
  text(-0.042, 3.70, "Direct disease contrasts", adj = c(0, 1), cex = 0.92, font = 2, col = ink)
  text(0.063, 0.51, "positive = larger shift in left-named group", adj = c(1, 0.5),
       cex = 0.57, col = neutral)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig2e.svg"), width = 7.0079, height = 4.7244,
    pointsize = 12, family = "sans", bg = "white")
draw_panel(); dev.off()
png(file.path("figures", "previews", "fig2e.png"), width = 7.0079, height = 4.7244,
    units = "in", res = 300, pointsize = 12, type = "cairo", bg = "white")
draw_panel(); dev.off()
cat("PASS: rendered Figure 2E SVG and 300-dpi PNG\n")
