options(stringsAsFactors = FALSE)
source(file.path("scripts", "figures", "fig2i_analysis.R"))
dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)

draw_panel <- function(device_fun) {
  device_fun(); on.exit(dev.off(), add = TRUE)
  layout(matrix(c(1, 2), 1, 2), widths = c(2.25, 4.75))
  par(oma = c(2.5, 0.5, 2.7, 0.5), family = "sans")
  colors <- c(GSE30999 = "#0072B2", GSE121212 = "#D55E00")

  par(mar = c(4.0, 6.3, 2.1, 0.8), mgp = c(2.1, 0.6, 0), tcl = -0.25)
  coverage$label <- paste(coverage$dataset_id, coverage$sep_direction, sep = "  |  ")
  coverage <- coverage[order(coverage$dataset_id, coverage$sep_direction, decreasing = TRUE), ]
  y <- rev(seq_len(nrow(coverage)))
  plot(NA, xlim = c(0.68, 1.005), ylim = c(0.5, 4.5), xlab = "Measurable frozen members",
       ylab = "", yaxt = "n", bty = "n", main = "Platform coverage", cex.main = 0.9, font.main = 2,
       cex.lab = 0.78, cex.axis = 0.70)
  abline(v = 0.70, lty = 3, col = "#7A7F85")
  segments(0.70, y, coverage$coverage_fraction, y, col = "#D9E0E4", lwd = 5)
  points(coverage$coverage_fraction, y, pch = 21, bg = colors[coverage$dataset_id], col = "white", cex = 1.35)
  axis(2, at = y, labels = coverage$label, las = 1, tick = FALSE, cex.axis = 0.66, line = -0.2)
  text(coverage$coverage_fraction - 0.008, y, sprintf("%.1f%%", 100 * coverage$coverage_fraction),
       adj = 1, cex = 0.66, col = "#343B42")
  text(0.705, 0.68, "70% gate", adj = 0, cex = 0.62, col = "#667077")

  par(mar = c(4.0, 3.9, 2.1, 1.0), mgp = c(2.1, 0.6, 0), tcl = -0.25)
  measurable <- influence[influence$measurement_status == "MEASURABLE", ]
  measurable$relative_percent <- 100 * measurable$relative_absolute_change
  plot(NA, xlim = c(0, 1), ylim = range(measurable$relative_percent[measurable$relative_percent > 0]),
       log = "y", xlab = "Within-cohort influence rank (normalized)",
       ylab = "Absolute cohort-mean change (% primary)", bty = "n",
       main = "Complete leave-one-gene-out influence", cex.main = 0.9, font.main = 2,
       cex.lab = 0.78, cex.axis = 0.70)
  abline(h = 0.5, lty = 3, col = "#7A7F85")
  for (dataset in c("GSE30999", "GSE121212")) {
    d <- measurable[measurable$dataset_id == dataset, ]
    d <- d[order(d$absolute_change, decreasing = TRUE), ]
    x <- (seq_len(nrow(d)) - 1) / (nrow(d) - 1)
    lines(x, d$relative_percent, col = colors[dataset], lwd = 1.5)
    points(x, d$relative_percent, col = grDevices::adjustcolor(colors[dataset], alpha.f = 0.28), pch = 16, cex = 0.34)
    top <- d[1, ]
    points(0, top$relative_percent, pch = 21, bg = colors[dataset], col = "white", cex = 1.25)
    text(0.025, top$relative_percent * ifelse(dataset == "GSE30999", 1.12, 0.86),
         sprintf("%s: %s %.3f%%", dataset, top$human_gene_symbol, top$relative_percent),
         adj = 0, cex = 0.66, col = colors[dataset], font = 2)
  }
  legend("topright", legend = c("GSE30999", "GSE121212", "0.5% reference"),
         col = c(colors, "#7A7F85"), lty = c(1, 1, 3), lwd = c(1.6, 1.6, 1), bty = "n", cex = 0.67)
  mtext("Score coverage and single-gene influence", side = 3, outer = TRUE, line = 1.35, cex = 1.05, font = 2)
  mtext("All 2,716 frozen members remain in the source table; non-mappable entries are explicit", side = 3, outer = TRUE, line = 0.15, cex = 0.70, col = "#4C555C")
  mtext("Influence ranks are descriptive; no gene was removed and no threshold was used to revise SEP.", side = 1, outer = TRUE, line = 1.1, cex = 0.66, col = "#4C555C")
}

draw_panel(function() svg(file.path("figures", "panels", "fig2i.svg"), width = 7.0079, height = 4.7244, pointsize = 10))
draw_panel(function() png(file.path("figures", "previews", "fig2i.png"), width = 7.0079, height = 4.7244, units = "in", res = 300, pointsize = 10))
cat("PASS: rendered Figure 2I SVG and 300-dpi PNG\n")
