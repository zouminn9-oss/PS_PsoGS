options(stringsAsFactors = FALSE)

cfg_lines <- readLines(file.path("config", "figures", "fig7a.yaml"), warn = FALSE)
cfg <- function(key, default = NA_character_) {
  hit <- grep(paste0("^", key, ":"), cfg_lines, value = TRUE)
  if (!length(hit)) return(default)
  value <- trimws(sub("^[^:]+:", "", hit[1]))
  gsub('^"|"$', "", value)
}

dat <- read.delim(file.path("figures", "source_data", "fig7a.tsv"),
                  check.names = FALSE, stringsAsFactors = FALSE)
stopifnot(all(dat$expression_values_accessed == "NO"))

width <- as.numeric(cfg("width_inches"))
height <- as.numeric(cfg("height_inches"))
dpi <- as.numeric(cfg("png_dpi"))
blue <- cfg("blue")
blue_light <- cfg("blue_light")
orange <- cfg("orange")
orange_light <- cfg("orange_light")
ink <- cfg("ink")
mid_grey <- cfg("mid_grey")
light_grey <- cfg("light_grey")

arm_short <- c("Brodalumab 140", "Brodalumab 210", "Placebo", "Ustekinumab")
arm <- dat[dat$record_type == "TREATMENT_ARM", ]
pairing <- dat[dat$record_type == "PAIRING", ]
gates <- dat[dat$record_type == "PREDICTION_GATE", ]

draw_panel <- function() {
  par(family = "sans", fg = ink, bty = "n", mar = c(4.3, 1.0, 3.8, 1.0), xpd = NA)
  plot(NA, xlim = c(0, 10), ylim = c(0.15, 8.65), axes = FALSE,
       xlab = "", ylab = "", xaxs = "i", yaxs = "i")
  title(main = "A  Treatment-cohort designs and analysis roles", adj = 0,
        cex.main = 1.02, font.main = 2, line = 2.05)
  mtext("Patient is the statistical unit | metadata-only audit | no expression values or outcome models used",
        side = 3, adj = 0, line = 0.48, cex = 0.74, col = mid_grey)

  rect(0.15, 1.15, 3.15, 7.55, col = "white", border = mid_grey, lwd = 1.1)
  rect(3.38, 1.15, 9.85, 7.55, col = "white", border = mid_grey, lwd = 1.1)

  text(0.35, 7.20, "GSE228421", adj = 0, cex = 0.82, font = 2, col = ink)
  text(0.35, 6.86, "PAIRED MECHANISM ONLY", adj = 0, cex = 0.67, font = 2, col = blue)
  text(0.35, 6.50, "5 patients | 20 scRNA libraries", adj = 0, cex = 0.67, col = mid_grey)

  xpt <- c(0.65, 1.65, 2.65)
  segments(xpt[1], 5.55, xpt[3], 5.55, col = mid_grey, lwd = 1.1)
  arrows(xpt[2] + 0.05, 5.55, xpt[3] - 0.08, 5.55, length = 0.06,
         angle = 24, col = mid_grey, lwd = 1.1)
  text(xpt, 5.95, c("Day 0", "Day 3", "Day 14"), cex = 0.67, font = 2, col = ink)
  points(xpt, rep(5.55, 3), pch = 21, bg = blue, col = blue, cex = 1.25)
  text(xpt, rep(5.18, 3), c("LS n=5", "LS n=5", "LS n=5"), cex = 0.67, col = ink)
  points(xpt[1], 4.65, pch = 21, bg = "white", col = blue, cex = 1.25, lwd = 1.2)
  text(xpt[1], 4.28, "NL n=5", cex = 0.67, col = ink)
  text(1.78, 4.65, "No NL biopsy at Day 3/14", adj = 0.5, cex = 0.67, col = mid_grey)

  rect(0.35, 3.15, 2.95, 3.78, col = blue_light, border = blue, lwd = 1.0)
  text(1.65, 3.53, "USE: paired treatment mechanism", cex = 0.67, font = 2, col = blue)
  rect(0.35, 2.22, 2.95, 2.85, col = orange_light, border = orange, lwd = 1.0)
  text(1.65, 2.60, "NOT USE: response prediction", cex = 0.67, font = 2, col = orange)
  text(1.65, 1.75, "Selected later-clearers; n=5", cex = 0.67, col = ink)
  text(1.65, 1.43, "No outcome-class variation", cex = 0.67, col = mid_grey)

  text(3.60, 7.20, "GSE117468", adj = 0, cex = 0.82, font = 2, col = ink)
  text(3.60, 6.86, "PAIRED CHANGE + CONDITIONAL INTERNAL PREDICTION", adj = 0,
       cex = 0.67, font = 2, col = blue)
  text(3.60, 6.50, "133 public patient IDs | 565 arrays | four treatment arms", adj = 0,
       cex = 0.67, col = mid_grey)

  text(3.62, 6.05, "PUBLIC ARMS (patients)", adj = 0, cex = 0.67, font = 2, col = mid_grey)
  yarm <- c(5.67, 5.28, 4.89, 4.50)
  maxw <- 1.48
  for (i in seq_len(nrow(arm))) {
    text(3.62, yarm[i], arm_short[i], adj = 0, cex = 0.67, col = ink)
    rect(4.83, yarm[i] - 0.12, 4.83 + maxw * arm$count[i] / max(arm$count), yarm[i] + 0.12,
         col = blue_light, border = blue, lwd = 0.8)
    text(6.40, yarm[i], arm$count[i], adj = 1, cex = 0.67, font = 2, col = ink)
  }

  text(6.80, 6.05, "AVAILABLE PATIENT PAIRS", adj = 0, cex = 0.67, font = 2, col = mid_grey)
  ypair <- yarm
  pair_label <- c("BL LS/NL", "LS BL-W4", "LS BL-W12", "Complete BL/W12 LS/NL")
  for (i in seq_len(nrow(pairing))) {
    text(6.80, ypair[i], pair_label[i], adj = 0, cex = 0.67, col = ink)
    text(9.53, ypair[i], pairing$count[i], adj = 1, cex = 0.67, font = 2, col = blue)
  }

  text(3.62, 3.93, "BASELINE-RESPONSE METADATA GATE", adj = 0,
       cex = 0.67, font = 2, col = mid_grey)
  xg <- c(4.00, 5.64, 7.28, 8.92)
  gate_labels <- c("Brodalumab IDs", "BL + W12 PASI", "+ public BL-LS", "PASI75")
  gate_counts <- c(88, 75, 74, NA)
  for (i in 1:3) {
    rect(xg[i] - 0.62, 2.88, xg[i] + 0.62, 3.62,
         col = if (i < 3) light_grey else blue_light,
         border = if (i < 3) mid_grey else blue, lwd = 1.0)
    text(xg[i], 3.39, gate_counts[i], cex = 0.78, font = 2, col = ink)
    text(xg[i], 3.10, gate_labels[i], cex = 0.67, col = ink)
    if (i < 3) arrows(xg[i] + 0.66, 3.25, xg[i + 1] - 0.66, 3.25,
                      length = 0.055, angle = 24, col = mid_grey, lwd = 1.0)
  }
  arrows(xg[3] + 0.66, 3.25, xg[4] - 0.66, 3.25,
         length = 0.055, angle = 24, col = mid_grey, lwd = 1.0)
  rect(xg[4] - 0.62, 2.88, xg[4] + 0.62, 3.62, col = orange_light,
       border = orange, lwd = 1.0)
  text(xg[4], 3.39, "62 | 12", cex = 0.78, font = 2, col = ink)
  text(xg[4], 3.10, "yes | no", cex = 0.67, col = ink)

  text(6.62, 2.48, "Internal nested CV only | class imbalance | wait for F1",
       cex = 0.67, font = 2, col = orange)
  text(6.62, 2.08, "No external response cohort; sex unavailable in public metadata",
       cex = 0.67, col = ink)
  text(6.62, 1.61, "Public deposit: 133 IDs / 565 arrays",
       cex = 0.67, font = 2, col = ink)
  text(6.62, 1.31, "Series narrative: 116 people / 844 biopsies (kept separate)",
       cex = 0.67, col = mid_grey)

  points(0.36, 0.66, pch = 21, bg = blue, col = blue, cex = 1.0)
  text(0.56, 0.66, "LS", adj = 0, cex = 0.67, col = ink)
  points(1.04, 0.66, pch = 21, bg = "white", col = blue, cex = 1.0)
  text(1.24, 0.66, "NL", adj = 0, cex = 0.67, col = ink)
  text(2.02, 0.66,
       "Counts describe public availability; they are not treatment effects or prediction performance.",
       adj = 0, cex = 0.67, col = mid_grey)
}

dir.create(file.path("figures", "panels"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "previews"), recursive = TRUE, showWarnings = FALSE)
svg(file.path("figures", "panels", "fig7a.svg"), width = width, height = height,
    pointsize = 12, bg = "white", family = "sans")
draw_panel()
dev.off()
png(file.path("figures", "previews", "fig7a.png"), width = width, height = height,
    units = "in", res = dpi, pointsize = 12, bg = "white")
draw_panel()
dev.off()
cat("PASS: rendered fig7a SVG and 300-dpi PNG\n")
