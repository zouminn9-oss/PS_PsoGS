from __future__ import annotations

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REQUIRED = {
    "ordinary_psoriasis_inflammation",
    "IL17_TNF_IFN",
    "proliferation",
    "tissue_damage",
    "technical_or_dissociation_stress",
}


def read_tsv(path: Path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main() -> None:
    checks: list[tuple[str, str, str]] = []

    def check(name: str, condition: bool, detail: str) -> None:
        checks.append((name, "PASS" if condition else "FAIL", detail))

    gate_path = ROOT / "metadata/stage03_comparator_program_gate.tsv"
    config_path = ROOT / "config/stage03_comparator_program_gate.yaml"
    registry_path = ROOT / "metadata/signature_registry.tsv"
    rows = read_tsv(gate_path)
    registry = read_tsv(registry_path)
    config = config_path.read_text(encoding="utf-8")

    check("required_program_rows", {r["program_class"] for r in rows} == REQUIRED, str(len(rows)))
    check("all_master_required", all(r["required_by_master"] == "YES" for r in rows), "all five")
    check("all_gate_blocked", all(r["gate_status"] == "BLOCKED" for r in rows), "all five")
    check("no_claimed_prevalidation_freeze", all(r["pre_validation_frozen_resource"] == "NO" for r in rows), "all five")
    check("no_claimed_source_version", all(r["source_version_frozen"] == "NO" for r in rows), "all five")
    check("no_claimed_direction_rule", all(r["direction_rule_frozen"] == "NO" for r in rows), "all five")
    check("registry_contains_only_documented_signatures", len(registry) == 6, str(len(registry)))
    registered_ids = {r["signature_id"] for r in registry}
    comparator_tokens = {"HALLMARK_INFLAMMATORY_RESPONSE", "HALLMARK_INTERFERON_GAMMA_RESPONSE", "HALLMARK_E2F_TARGETS"}
    check("no_named_comparator_in_registry", registered_ids.isdisjoint(comparator_tokens), ",".join(sorted(registered_ids)))
    geneset_names = {p.name for p in (ROOT / "genesets").iterdir() if p.is_file()}
    check("no_hidden_comparator_package", not any("hallmark" in n.lower() or "comparator" in n.lower() for n in geneset_names), str(len(geneset_names)))
    check("config_decision", 'decision: "BLOCKED_MISSING_FROZEN_COMPARATOR_SIGNATURES"' in config, "blocked")
    check("config_zero_eligible", "observed_eligible_comparator_count: 0" in config, "zero")
    check("prohibits_posthoc_selection", "Do not select or tune comparator gene sets after observing" in config, "present")
    check("no_figure2f_outputs", not (ROOT / "figures/panels/fig2f.svg").exists() and not (ROOT / "figures/previews/fig2f.png").exists(), "not rendered")

    audit_path = ROOT / "audits/stage03_comparator_program_gate_checks.tsv"
    with audit_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(["check_id", "status", "detail"])
        for row in checks:
            writer.writerow(row)

    failed = [row for row in checks if row[1] != "PASS"]
    if failed:
        raise SystemExit("FAIL: " + "; ".join(f"{name}={detail}" for name, _, detail in failed))
    print(f"PASS: {len(checks)} Figure 2F comparator-resource gate checks; panel remains BLOCKED")


if __name__ == "__main__":
    main()

