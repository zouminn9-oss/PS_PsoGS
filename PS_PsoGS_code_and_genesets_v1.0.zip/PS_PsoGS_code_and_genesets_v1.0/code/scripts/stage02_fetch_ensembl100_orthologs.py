#!/usr/bin/env python3
"""Freeze the Ensembl 100 mouse-human orthology rows needed by GSE212126.

This script deliberately queries only the Ensembl identifiers present in the
frozen mouse differential-expression table.  It never reads a validation
expression matrix.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python_libs" / "stage02_orthology"))

import pymysql  # noqa: E402


HOST = "ensembldb.ensembl.org"
PORTS = (5306, 3306)
DATABASE = "ensembl_compara_100"
MOUSE_NAME = "mus_musculus"
HUMAN_NAME = "homo_sapiens"
BATCH_SIZE = 1000

MOUSE_RESULT = ROOT / "results/stage02/factorial_edger/gse212126_SD_all_genes.tsv"
OUT_DIR = ROOT / "references/ensembl_release100_compara"
OUT_GZ = OUT_DIR / "mouse_human_orthology_query.tsv.gz"
OUT_SQL = OUT_DIR / "mouse_human_orthology_query.sql"
OUT_META = ROOT / "metadata/ensembl_release100_orthology_source.tsv"
OUT_SCHEMA = OUT_DIR / "queried_table_columns.json"

FIELDS = [
    "mouse_ensembl_gene_id",
    "mouse_gene_version",
    "mouse_display_label",
    "human_ensembl_gene_id",
    "human_gene_version",
    "human_display_label",
    "homology_id",
    "homology_description",
    "is_tree_compliant",
    "dn",
    "ds",
    "goc_score",
    "wga_coverage",
    "mouse_perc_cov",
    "mouse_perc_id",
    "human_perc_cov",
    "human_perc_id",
]

SQL_PROVENANCE = """
-- Ensembl release 100. Each IN list is populated in deterministic batches.
SELECT gene_member_id, stable_id, version, display_label, genome_db_id
FROM gene_member
WHERE genome_db_id = ? AND stable_id IN (...);

SELECT hm.homology_id, hm.gene_member_id, hm.perc_cov, hm.perc_id,
       h.description, h.is_tree_compliant, h.dn, h.ds,
       h.goc_score, h.wga_coverage
FROM homology_member AS hm STRAIGHT_JOIN homology AS h
  ON h.homology_id = hm.homology_id
WHERE hm.gene_member_id IN (...)
  AND h.description LIKE 'ortholog%';

SELECT homology_id, gene_member_id, perc_cov, perc_id
FROM homology_member
WHERE homology_id IN (...);

SELECT gene_member_id, stable_id, version, display_label, genome_db_id
FROM gene_member
WHERE gene_member_id IN (...);
""".strip()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_mouse_ids() -> list[str]:
    with MOUSE_RESULT.open(newline="", encoding="utf-8-sig") as handle:
        ids = {row["gene_id"].split(".", 1)[0] for row in csv.DictReader(handle, delimiter="\t")}
    return sorted(ids)


def write_tsv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, delimiter="\t", fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    mouse_ids = read_mouse_ids()
    if len(mouse_ids) != 18484:
        raise RuntimeError(f"Expected 18,484 frozen mouse genes, observed {len(mouse_ids):,}")

    connection = None
    connection_errors: list[str] = []
    selected_port = None
    for port in PORTS:
        try:
            connection = pymysql.connect(
                host=HOST,
                port=port,
                user="anonymous",
                password="",
                database=DATABASE,
                charset="utf8mb4",
                autocommit=True,
                connect_timeout=15,
                read_timeout=180,
                write_timeout=30,
                cursorclass=pymysql.cursors.DictCursor,
            )
            selected_port = port
            break
        except Exception as exc:
            connection_errors.append(f"port {port}: {type(exc).__name__}: {exc}")
    if connection is None or selected_port is None:
        raise RuntimeError("; ".join(connection_errors))

    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT VERSION() AS server_version")
            server_version = cursor.fetchone()["server_version"]
            cursor.execute("SELECT DATABASE() AS database_name")
            database_name = cursor.fetchone()["database_name"]

            cursor.execute(
                "SELECT genome_db_id, taxon_id, name, assembly, genebuild, "
                "first_release, last_release FROM genome_db "
                "WHERE name IN (%s, %s) ORDER BY name, genome_db_id",
                (MOUSE_NAME, HUMAN_NAME),
            )
            genomes = cursor.fetchall()
            active = [row for row in genomes if row["last_release"] is None or row["last_release"] >= 100]
            mouse_rows = [row for row in active if row["name"] == MOUSE_NAME]
            human_rows = [row for row in active if row["name"] == HUMAN_NAME]
            if len(mouse_rows) != 1 or len(human_rows) != 1:
                raise RuntimeError(f"Ambiguous active genome_db rows: {active!r}")
            mouse_genome_id = mouse_rows[0]["genome_db_id"]
            human_genome_id = human_rows[0]["genome_db_id"]

            schema: dict[str, list[dict[str, object]]] = {}
            for table in ("genome_db", "gene_member", "homology", "homology_member"):
                cursor.execute(f"SHOW COLUMNS FROM {table}")
                schema[table] = cursor.fetchall()

            cursor.execute(
                "SELECT gene_member_id, stable_id, version, display_label, genome_db_id "
                "FROM gene_member FORCE INDEX (genome_db_id_biotype) "
                "WHERE genome_db_id = %s",
                (mouse_genome_id,),
            )
            requested_mouse_ids = set(mouse_ids)
            mouse_gene_rows = [
                row for row in cursor.fetchall() if str(row["stable_id"]) in requested_mouse_ids
            ]
            print(
                f"resolved {len(mouse_gene_rows):,}/{len(mouse_ids):,} frozen mouse stable IDs",
                flush=True,
            )

            mouse_by_member = {int(row["gene_member_id"]): row for row in mouse_gene_rows}
            mouse_member_ids = sorted(mouse_by_member)
            source_homology_rows: list[dict[str, object]] = []
            for start in range(0, len(mouse_member_ids), BATCH_SIZE):
                batch = mouse_member_ids[start : start + BATCH_SIZE]
                placeholders = ",".join(["%s"] * len(batch))
                cursor.execute(
                    "SELECT hm.homology_id, hm.gene_member_id, hm.perc_cov, hm.perc_id, "
                    "h.description, h.is_tree_compliant, h.dn, h.ds, "
                    "h.goc_score, h.wga_coverage "
                    "FROM homology_member AS hm FORCE INDEX (gene_member_id) "
                    "STRAIGHT_JOIN homology AS h "
                    "ON h.homology_id = hm.homology_id "
                    f"WHERE hm.gene_member_id IN ({placeholders}) "
                    "AND h.description LIKE 'ortholog%%'",
                    batch,
                )
                source_homology_rows.extend(cursor.fetchall())
                print(
                    f"queried orthologies for {min(start + BATCH_SIZE, len(mouse_member_ids)):,}/"
                    f"{len(mouse_member_ids):,} mapped mouse members; "
                    f"source orthology rows={len(source_homology_rows):,}",
                    flush=True,
                )

            homology_by_id = {int(row["homology_id"]): row for row in source_homology_rows}
            homology_ids = sorted(homology_by_id)
            all_homology_members: list[dict[str, object]] = []
            for start in range(0, len(homology_ids), BATCH_SIZE):
                batch = homology_ids[start : start + BATCH_SIZE]
                placeholders = ",".join(["%s"] * len(batch))
                cursor.execute(
                    "SELECT homology_id, gene_member_id, perc_cov, perc_id "
                    f"FROM homology_member WHERE homology_id IN ({placeholders})",
                    batch,
                )
                all_homology_members.extend(cursor.fetchall())

            target_member_ids = sorted(
                {
                    int(row["gene_member_id"])
                    for row in all_homology_members
                    if int(row["gene_member_id"]) not in mouse_by_member
                }
            )
            target_gene_rows: list[dict[str, object]] = []
            for start in range(0, len(target_member_ids), BATCH_SIZE):
                batch = target_member_ids[start : start + BATCH_SIZE]
                placeholders = ",".join(["%s"] * len(batch))
                cursor.execute(
                    "SELECT gene_member_id, stable_id, version, display_label, genome_db_id "
                    f"FROM gene_member WHERE gene_member_id IN ({placeholders})",
                    batch,
                )
                target_gene_rows.extend(cursor.fetchall())

            human_by_member = {
                int(row["gene_member_id"]): row
                for row in target_gene_rows
                if int(row["genome_db_id"]) == int(human_genome_id)
            }

            members_by_homology: dict[int, list[dict[str, object]]] = {}
            for row in all_homology_members:
                members_by_homology.setdefault(int(row["homology_id"]), []).append(row)

            rows: list[dict[str, object]] = []
            for homology_id, homology in homology_by_id.items():
                members = members_by_homology.get(homology_id, [])
                mouse_members = [row for row in members if int(row["gene_member_id"]) in mouse_by_member]
                human_members = [row for row in members if int(row["gene_member_id"]) in human_by_member]
                for mouse_member in mouse_members:
                    mouse_gene = mouse_by_member[int(mouse_member["gene_member_id"])]
                    for human_member in human_members:
                        human_gene = human_by_member[int(human_member["gene_member_id"])]
                        rows.append(
                            {
                                "mouse_ensembl_gene_id": mouse_gene["stable_id"],
                                "mouse_gene_version": mouse_gene["version"],
                                "mouse_display_label": mouse_gene["display_label"],
                                "human_ensembl_gene_id": human_gene["stable_id"],
                                "human_gene_version": human_gene["version"],
                                "human_display_label": human_gene["display_label"],
                                "homology_id": homology_id,
                                "homology_description": homology["description"],
                                "is_tree_compliant": homology["is_tree_compliant"],
                                "dn": homology["dn"],
                                "ds": homology["ds"],
                                "goc_score": homology["goc_score"],
                                "wga_coverage": homology["wga_coverage"],
                                "mouse_perc_cov": mouse_member["perc_cov"],
                                "mouse_perc_id": mouse_member["perc_id"],
                                "human_perc_cov": human_member["perc_cov"],
                                "human_perc_id": human_member["perc_id"],
                            }
                        )
    finally:
        connection.close()

    rows.sort(
        key=lambda row: (
            str(row["mouse_ensembl_gene_id"]),
            str(row["human_ensembl_gene_id"]),
            int(row["homology_id"]),
        )
    )
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with gzip.open(OUT_GZ, "wt", newline="", encoding="utf-8", compresslevel=9) as handle:
        writer = csv.DictWriter(handle, delimiter="\t", fieldnames=FIELDS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)

    OUT_SQL.write_text(
        "-- genome_db IDs are resolved at run time from active release-100 rows.\n"
        + SQL_PROVENANCE
        + "\n",
        encoding="utf-8",
    )
    OUT_SCHEMA.write_text(json.dumps(schema, indent=2, default=str) + "\n", encoding="utf-8")

    one2one = sum(row["homology_description"] == "ortholog_one2one" for row in rows)
    metadata = [
        {"field": "retrieved_at_utc", "value": datetime.now(timezone.utc).isoformat()},
        {"field": "host", "value": HOST},
        {"field": "port", "value": selected_port},
        {
            "field": "connection_attempts",
            "value": " | ".join(connection_errors) or "first documented port succeeded",
        },
        {"field": "database", "value": database_name},
        {"field": "mysql_server_version", "value": server_version},
        {"field": "pymysql_version", "value": pymysql.__version__},
        {"field": "mouse_genome_db", "value": json.dumps(mouse_rows[0], sort_keys=True, default=str)},
        {"field": "human_genome_db", "value": json.dumps(human_rows[0], sort_keys=True, default=str)},
        {"field": "queried_mouse_gene_count", "value": len(mouse_ids)},
        {"field": "returned_orthology_row_count", "value": len(rows)},
        {"field": "returned_one2one_row_count", "value": one2one},
        {"field": "raw_query_sha256", "value": sha256(OUT_GZ)},
        {"field": "query_sql_sha256", "value": sha256(OUT_SQL)},
        {"field": "schema_json_sha256", "value": sha256(OUT_SCHEMA)},
    ]
    write_tsv(OUT_META, metadata, ["field", "value"])
    print(f"wrote {OUT_GZ} ({len(rows):,} rows; {one2one:,} one-to-one)")


if __name__ == "__main__":
    main()
