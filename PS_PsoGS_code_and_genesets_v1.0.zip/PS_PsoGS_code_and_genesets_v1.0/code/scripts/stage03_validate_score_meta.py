#!/usr/bin/env python3
"""Independent recalculation of the frozen two-cohort score meta-analysis."""

from __future__ import annotations

import csv
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "audits/stage03_score_meta_checks.tsv"


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main() -> None:
    checks: list[dict[str, object]] = []

    def check(check_id: str, observed: object, expected: object, note: str = "") -> None:
        passed = observed == expected
        checks.append({"check_id": check_id, "observed": observed, "expected": expected,
                       "status": "PASS" if passed else "FAIL", "note": note})
        if not passed:
            raise AssertionError(f"{check_id}: observed {observed!r}; expected {expected!r}")

    upstream = read_tsv(ROOT / "results/stage03/scores/paired_score_statistics.tsv")
    meta = read_tsv(ROOT / "results/stage03/scores/score_meta.tsv")
    heterogeneity = read_tsv(ROOT / "results/stage03/scores/score_meta_heterogeneity.tsv")
    check("meta_upstream_rows", len(upstream), 2)
    check("meta_rows", len(meta), 4)
    check("meta_record_types", [r["record_type"] for r in meta],
          ["COHORT", "COHORT", "SUMMARY", "SUMMARY"])
    check("meta_heterogeneity_rows", len(heterogeneity), 1)

    cohort_rows = {r["dataset_id"]: r for r in meta if r["record_type"] == "COHORT"}
    g_values, variances = [], []
    for row in upstream:
        dataset = row["dataset_id"]
        n = int(row["n_pairs"])
        mean = float(row["mean_delta"])
        sd = float(row["sd_delta"])
        d = mean / sd
        correction = 1 - 3 / (4 * (n - 1) - 1)
        g_value = correction * d
        variance = correction**2 * (1 / n + d**2 / (2 * (n - 1)))
        observed = cohort_rows[dataset]
        check(f"meta_n::{dataset}", int(observed["n_pairs"]), n)
        for field, calculated in (("cohens_dz", d), ("hedges_J", correction),
                                  ("effect", g_value), ("variance", variance),
                                  ("standard_error", math.sqrt(variance))):
            check(f"meta_{field}::{dataset}", abs(float(observed[field]) - calculated) < 1e-12, True)
        check(f"meta_ci_positive::{dataset}", float(observed["ci_low"]) > 0, True)
        g_values.append(g_value); variances.append(variance)

    weights = [1 / value for value in variances]
    fixed = sum(w * g for w, g in zip(weights, g_values)) / sum(weights)
    fixed_variance = 1 / sum(weights)
    q_value = sum(w * (g - fixed)**2 for w, g in zip(weights, g_values))
    c_value = sum(weights) - sum(w * w for w in weights) / sum(weights)
    tau2 = max(0.0, (q_value - 1) / c_value)
    i2 = max(0.0, (q_value - 1) / q_value) * 100 if q_value > 0 else 0.0
    summaries = {r["dataset_id"]: r for r in meta if r["record_type"] == "SUMMARY"}
    check("meta_fixed_effect", abs(float(summaries["FIXED"]["effect"]) - fixed) < 1e-12, True)
    check("meta_fixed_variance", abs(float(summaries["FIXED"]["variance"]) - fixed_variance) < 1e-12, True)
    check("meta_tau2", abs(float(heterogeneity[0]["tau2_DL"]) - tau2) < 1e-12, True)
    check("meta_I2", abs(float(heterogeneity[0]["I2_percent"]) - i2) < 1e-12, True)
    check("meta_Q", abs(float(heterogeneity[0]["Q"]) - q_value) < 1e-12, True)
    check("meta_k", int(heterogeneity[0]["k_cohorts"]), 2)
    check("meta_no_stable_heterogeneity_claim",
          heterogeneity[0]["stable_heterogeneity_claim_allowed"], "NO_K_LT_3")
    check("meta_fixed_random_equal_only_tau_zero",
          abs(float(summaries["FIXED"]["effect"]) - float(summaries["RANDOM_DL"]["effect"])) < 1e-14
          and tau2 == 0, True)

    config = (ROOT / "config/stage03_score_meta.yaml").read_text(encoding="utf-8")
    for rule in ("raw_score_pooling: false", "validation_to_signature_feedback: false",
                 "minimum_cohorts_for_stable_heterogeneity_claim: 3",
                 "DerSimonian-Laird random effect"):
        check(f"meta_rule::{rule}", rule in config, True)

    with AUDIT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(checks)
    print(f"PASS: {len(checks)} frozen score meta-analysis checks")


if __name__ == "__main__":
    main()
