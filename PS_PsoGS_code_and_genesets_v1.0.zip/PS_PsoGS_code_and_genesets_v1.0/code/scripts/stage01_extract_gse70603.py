#!/usr/bin/env python3
"""Extract the official processed GSE70603 sample tables and paired design."""

from __future__ import annotations

import csv
import gzip
import hashlib
import math
import re
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "metadata" / "geo_soft" / "GSE70603_family.soft.gz"
MATRIX = ROOT / "data" / "processed" / "GSE70603_processed_log2_matrix.tsv.gz"
SAMPLES = ROOT / "metadata" / "gse70603_analysis_samples.tsv"
AUDIT = ROOT / "audits" / "gse70603_matrix_audit.tsv"
SAMPLE_MANIFEST = ROOT / "metadata" / "sample_manifest.tsv"


def parse():
    records, current, in_table, header = [], None, False, []
    with gzip.open(SOURCE, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            line = raw.rstrip("\r\n")
            if line.startswith("^SAMPLE = "):
                if current is not None:
                    records.append(current)
                current = {"gsm": line.split("=", 1)[1].strip(), "values": {}}
                in_table, header = False, []
            elif current is None:
                continue
            elif line.startswith("!Sample_title = "):
                current["title"] = line.split("=", 1)[1].strip()
            elif line.startswith("!Sample_source_name_ch1 = "):
                current["source_name"] = line.split("=", 1)[1].strip()
            elif line == "!sample_table_begin":
                in_table, header = True, []
            elif line == "!sample_table_end":
                in_table = False
            elif in_table and not header:
                header = line.split("\t")
                current["table_header"] = header
            elif in_table and line and not line.startswith("!"):
                parts = line.split("\t")
                row = dict(zip(header, parts))
                probe = row.get("ID_REF", parts[0]).strip('"')
                value = row.get("VALUE", parts[1] if len(parts) > 1 else "").strip('"')
                current["values"][probe] = value
    if current is not None:
        records.append(current)
    return records


def design_row(record):
    title, source = record["title"], record["source_name"]
    match = re.search(r"_(\d+)$", title)
    subject = f"subject_{match.group(1)}" if match else ""
    if "control group" in source.lower():
        group = "control_history"
    elif "early adversity" in source.lower():
        group = "early_adversity"
    else:
        group = ""
    lowered = source.lower()
    if "45min pre-stress" in lowered:
        timepoint, minutes = "pre_minus45", -45
    elif "45min post-stress" in lowered:
        timepoint, minutes = "post_plus45", 45
    elif "180min post-stress" in lowered:
        timepoint, minutes = "post_plus180", 180
    else:
        timepoint, minutes = "", ""
    return {"gsm": record["gsm"], "sample_title": title, "subject_id": subject,
            "history_group": group, "timepoint": timepoint, "minutes_relative_to_stressor": minutes,
            "source_name_verbatim": source,
            "primary_contrast_role": "BASELINE" if minutes == -45 else "POST_STRESS",
            "inclusion_status": "INCLUDE_METADATA_COMPLETE" if subject and group and timepoint else "HOLD",
            "source_url": f"https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={record['gsm']}"}


def write_tsv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main():
    records = parse()
    design = [design_row(record) for record in records]
    with SAMPLE_MANIFEST.open(encoding="utf-8", newline="") as handle:
        sample_meta = {row["sample_id"]: row for row in csv.DictReader(handle, delimiter="\t")
                       if row["dataset_id"] == "GSE70603"}
    for row in design:
        meta = sample_meta.get(row["gsm"], {})
        age_match = re.search(r"\d+(?:\.\d+)?", meta.get("age", ""))
        row["age_years"] = age_match.group(0) if age_match else ""
        row["sex"] = meta.get("sex", "").lower()
        row["metadata_match"] = "PASS" if meta else "FAIL"
    probes = list(records[0]["values"])
    probe_set = set(probes)
    same_probe_set = all(set(record["values"]) == probe_set for record in records)
    same_probe_order = all(list(record["values"]) == probes for record in records)
    nonnumeric, missing, finite_values = 0, 0, []
    with gzip.open(MATRIX, "wt", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(["probe_id"] + [record["gsm"] for record in records])
        for probe in probes:
            values = []
            for record in records:
                raw = record["values"].get(probe, "")
                if raw == "":
                    missing += 1
                    values.append("")
                    continue
                try:
                    value = float(raw)
                    if not math.isfinite(value):
                        raise ValueError
                    finite_values.append(value)
                    values.append(raw)
                except ValueError:
                    nonnumeric += 1
                    values.append("")
            writer.writerow([probe] + values)
    write_tsv(SAMPLES, design)
    subject_rows = defaultdict(list)
    for row in design:
        subject_rows[row["subject_id"]].append(row)
    complete_subjects = sum(len(rows) == 3 and len({r["timepoint"] for r in rows}) == 3 and
                            len({r["history_group"] for r in rows}) == 1 for rows in subject_rows.values())
    group_counts = Counter(row["history_group"] for row in design if row["minutes_relative_to_stressor"] == -45)
    audit = [
        {"check":"sample_count","observed":len(records),"expected":180,"status":"PASS" if len(records)==180 else "FAIL"},
        {"check":"probe_count","observed":len(probes),"expected":"constant across samples","status":"PASS" if probes else "FAIL"},
        {"check":"same_probe_set","observed":same_probe_set,"expected":True,"status":"PASS" if same_probe_set else "FAIL"},
        {"check":"same_probe_order","observed":same_probe_order,"expected":True,"status":"PASS" if same_probe_order else "PARTIAL"},
        {"check":"complete_three_timepoint_subjects","observed":complete_subjects,"expected":60,"status":"PASS" if complete_subjects==60 else "FAIL"},
        {"check":"baseline_control_history_n","observed":group_counts["control_history"],"expected":30,"status":"PASS" if group_counts["control_history"]==30 else "FAIL"},
        {"check":"baseline_early_adversity_n","observed":group_counts["early_adversity"],"expected":30,"status":"PASS" if group_counts["early_adversity"]==30 else "FAIL"},
        {"check":"missing_matrix_cells","observed":missing,"expected":0,"status":"PASS" if missing==0 else "PARTIAL"},
        {"check":"nonnumeric_matrix_cells","observed":nonnumeric,"expected":0,"status":"PASS" if nonnumeric==0 else "FAIL"},
        {"check":"matrix_min","observed":min(finite_values) if finite_values else "","expected":"finite","status":"PASS" if finite_values else "FAIL"},
        {"check":"matrix_max","observed":max(finite_values) if finite_values else "","expected":"finite","status":"PASS" if finite_values else "FAIL"},
        {"check":"source_sha256","observed":hashlib.sha256(SOURCE.read_bytes()).hexdigest(),"expected":"recorded","status":"PASS"},
    ]
    write_tsv(AUDIT, audit)
    assert len(records) == 180 and complete_subjects == 60 and same_probe_set and missing == 0 and nonnumeric == 0
    print(f"PASS: {len(probes)} probes x {len(records)} samples; 60 complete subjects; range {min(finite_values):.4g}..{max(finite_values):.4g}")


if __name__ == "__main__":
    main()
