options(stringsAsFactors = FALSE)
.libPaths(c(normalizePath(file.path("r_libs", "stage02")),
            normalizePath(file.path("r_libs", "stage01")), .libPaths()))
stopifnot(requireNamespace("edgeR", quietly = TRUE),
          as.character(packageVersion("edgeR")) == "4.4.2")

out_dir <- file.path("results", "stage03", "random_null")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create("logs", showWarnings = FALSE)
log_con <- file(file.path("logs", "stage03_random_signature_null.log"), open = "wt")
sink(log_con, type = "output", split = TRUE); sink(log_con, type = "message")
on.exit({sink(type = "message"); sink(type = "output"); close(log_con)}, add = TRUE)

seed <- 20260911L
B <- 2000L
set.seed(seed)
sep <- read.delim(file.path("genesets", "SEP_v1.0.tsv"), check.names = FALSE)
sample_lock <- read.delim(file.path("metadata", "stage03_validation_sample_lock.tsv"), check.names = FALSE)
pair30999 <- read.delim(file.path("metadata", "gse30999_metadata_pair_registry.tsv"), check.names = FALSE)
pair30999 <- pair30999[pair30999$metadata_pair_status == "COMPLETE_EXACT_ID_PAIR", ]
observed_stats <- read.delim(file.path("results", "stage03", "scores", "paired_score_statistics.tsv"), check.names = FALSE)
stopifnot(nrow(sep) == 2716L, nrow(pair30999) == 81L, B == 2000L)

equal_frequency_bin <- function(x, bins) {
  as.integer(ceiling(rank(x, ties.method = "first") * bins / length(x)))
}

prepare_sampling <- function(feature_ids, sep_up, sep_down, strata, dataset_id) {
  sep_up <- intersect(as.character(sep_up), feature_ids)
  sep_down <- intersect(as.character(sep_down), feature_ids)
  sep_all <- union(sep_up, sep_down)
  candidates <- setdiff(feature_ids, sep_all)
  target <- data.frame(feature_id = c(sep_up, sep_down),
                       direction = c(rep("UP", length(sep_up)), rep("DOWN", length(sep_down))),
                       stringsAsFactors = FALSE)
  target$stratum <- strata[match(target$feature_id, feature_ids)]
  pool <- data.frame(feature_id = candidates,
                     stratum = strata[match(candidates, feature_ids)], stringsAsFactors = FALSE)
  target_counts <- as.data.frame.matrix(table(target$stratum, target$direction))
  if (!"UP" %in% names(target_counts)) target_counts$UP <- 0L
  if (!"DOWN" %in% names(target_counts)) target_counts$DOWN <- 0L
  target_counts$stratum <- rownames(target_counts)
  rownames(target_counts) <- NULL
  pool_counts <- table(pool$stratum)
  target_counts$pool_n <- as.integer(pool_counts[as.character(target_counts$stratum)])
  target_counts$target_total <- target_counts$UP + target_counts$DOWN
  stopifnot(!anyNA(target_counts$pool_n), all(target_counts$pool_n >= target_counts$target_total))
  target_counts$dataset_id <- dataset_id
  target_counts <- target_counts[, c("dataset_id", "stratum", "UP", "DOWN", "target_total", "pool_n")]
  list(up = sep_up, down = sep_down, target = target, pool = pool,
       target_counts = target_counts)
}

sample_one <- function(prep) {
  up <- character(); down <- character()
  for (i in seq_len(nrow(prep$target_counts))) {
    s <- as.character(prep$target_counts$stratum[i])
    n_up <- prep$target_counts$UP[i]
    n_down <- prep$target_counts$DOWN[i]
    available <- prep$pool$feature_id[prep$pool$stratum == s]
    chosen <- sample(available, n_up + n_down, replace = FALSE)
    if (n_up > 0L) up <- c(up, chosen[seq_len(n_up)])
    if (n_down > 0L) down <- c(down, chosen[n_up + seq_len(n_down)])
  }
  list(up = up, down = down)
}

evaluate_null <- function(dataset_id, prep, gene_mean_delta, observed) {
  rows <- vector("list", B)
  membership <- vector("list", B)
  for (b in seq_len(B)) {
    draw <- sample_one(prep)
    effect <- mean(gene_mean_delta[draw$up]) - mean(gene_mean_delta[draw$down])
    rows[[b]] <- data.frame(dataset_id = dataset_id, permutation_id = b,
                            random_effect = effect,
                            n_up = length(draw$up), n_down = length(draw$down),
                            seed = seed, stringsAsFactors = FALSE)
    membership[[b]] <- draw
  }
  null <- do.call(rbind, rows)
  summary <- data.frame(dataset_id = dataset_id, permutations = B,
                        observed_effect = observed,
                        null_mean = mean(null$random_effect), null_sd = sd(null$random_effect),
                        null_q025 = unname(quantile(null$random_effect, 0.025)),
                        null_q500 = unname(quantile(null$random_effect, 0.5)),
                        null_q975 = unname(quantile(null$random_effect, 0.975)),
                        empirical_p_greater = (1 + sum(null$random_effect >= observed)) / (B + 1),
                        observed_percentile = mean(null$random_effect < observed),
                        n_up = length(prep$up), n_down = length(prep$down),
                        stringsAsFactors = FALSE)
  list(null = null, summary = summary, membership = membership)
}

# Array matching uses all submitted arrays without condition labels.
array_df <- read.delim(gzfile(file.path("results", "stage03", "matrices",
                                       "gse30999_gcrma_entrez_gene_matrix.tsv.gz")), check.names = FALSE)
array_ids <- as.character(array_df[[1]])
array_mat <- as.matrix(array_df[-1]); storage.mode(array_mat) <- "double"; rownames(array_mat) <- array_ids
array_strata <- paste0("E", equal_frequency_bin(rowMeans(array_mat), 10L))
array_prep <- prepare_sampling(array_ids,
  as.character(sep$selected_human_entrez_id[sep$sep_direction == "UP"]),
  as.character(sep$selected_human_entrez_id[sep$sep_direction == "DOWN"]),
  array_strata, "GSE30999")
array_primary <- c(pair30999$nl_gsm, pair30999$ls_gsm)
array_ranks <- apply(array_mat[, array_primary, drop = FALSE], 2, rank, ties.method = "average") /
               (nrow(array_mat) + 1)
array_gene_delta <- rowMeans(array_ranks[, pair30999$ls_gsm, drop = FALSE] -
                             array_ranks[, pair30999$nl_gsm, drop = FALSE])
names(array_gene_delta) <- array_ids
array_observed <- observed_stats$mean_delta[observed_stats$dataset_id == "GSE30999"]
array_check <- mean(array_gene_delta[array_prep$up]) - mean(array_gene_delta[array_prep$down])
stopifnot(abs(array_check - array_observed) < 1e-12)
array_result <- evaluate_null("GSE30999", array_prep, array_gene_delta, array_observed)
rm(array_mat, array_ranks); gc()

# RNA matching uses all 147 libraries and no tissue labels to define expression/detection bins.
count_df <- read.delim(gzfile(file.path("data", "raw", "validation", "GSE121212",
                                       "GSE121212_readcount.txt.gz")), check.names = FALSE)
count_ids <- as.character(count_df[[1]])
count_mat <- as.matrix(count_df[-1]); storage.mode(count_mat) <- "integer"
count_mat <- rowsum(count_mat, group = count_ids, reorder = FALSE)
y_all <- edgeR::DGEList(counts = count_mat)
y_all <- edgeR::calcNormFactors(y_all, method = "TMM")
logcpm_all <- edgeR::cpm(y_all, log = TRUE, prior.count = 2)
rna_expr_bin <- equal_frequency_bin(rowMeans(logcpm_all), 10L)
rna_detect_bin <- equal_frequency_bin(rowMeans(count_mat > 0), 5L)
rna_strata <- paste0("E", rna_expr_bin, "_D", rna_detect_bin)
rna_ids <- rownames(count_mat)
rna_prep <- prepare_sampling(rna_ids,
  sep$human_gene_symbol[sep$sep_direction == "UP"],
  sep$human_gene_symbol[sep$sep_direction == "DOWN"], rna_strata, "GSE121212")
rna_lock <- sample_lock[sample_lock$dataset_id == "GSE121212" &
                        sample_lock$lock_status == "PRIMARY_INCLUDE", ]
rna_primary <- rna_lock$sample_title
rna_ranks <- apply(logcpm_all[, rna_primary, drop = FALSE], 2, rank, ties.method = "average") /
             (nrow(logcpm_all) + 1)
rna_pairs <- split(rna_lock, rna_lock$donor_id)
rna_pair_delta <- do.call(cbind, lapply(rna_pairs, function(rows) {
  ls <- rows$sample_title[rows$skin_type == "lesional"]
  nl <- rows$sample_title[rows$skin_type == "non-lesional"]
  rna_ranks[, ls] - rna_ranks[, nl]
}))
rna_gene_delta <- rowMeans(rna_pair_delta); names(rna_gene_delta) <- rownames(rna_ranks)
rna_observed <- observed_stats$mean_delta[observed_stats$dataset_id == "GSE121212"]
rna_check <- mean(rna_gene_delta[rna_prep$up]) - mean(rna_gene_delta[rna_prep$down])
stopifnot(abs(rna_check - rna_observed) < 1e-12)
rna_result <- evaluate_null("GSE121212", rna_prep, rna_gene_delta, rna_observed)

null_all <- rbind(array_result$null, rna_result$null)
summary_all <- rbind(array_result$summary, rna_result$summary)
strata_all <- rbind(array_prep$target_counts, rna_prep$target_counts)
write.table(null_all, file.path(out_dir, "random_signature_null.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
write.table(summary_all, file.path(out_dir, "random_signature_null_summary.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
write.table(strata_all, file.path(out_dir, "random_signature_match_strata.tsv"), sep = "\t",
            quote = FALSE, row.names = FALSE)
saveRDS(list(seed = seed, B = B,
             GSE30999 = array_result$membership,
             GSE121212 = rna_result$membership),
        file.path(out_dir, "random_signature_membership.rds"), compress = "xz")
cat(sprintf("PASS: %d matched random signatures per cohort; empirical P %.6g and %.6g\n",
            B, summary_all$empirical_p_greater[1], summary_all$empirical_p_greater[2]))
