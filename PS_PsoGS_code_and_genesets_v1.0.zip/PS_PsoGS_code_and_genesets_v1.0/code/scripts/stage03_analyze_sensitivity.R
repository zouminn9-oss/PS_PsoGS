options(stringsAsFactors = FALSE)
.libPaths(c(normalizePath(file.path("r_libs", "stage02")),
            normalizePath(file.path("r_libs", "stage01")), .libPaths()))
stopifnot(requireNamespace("edgeR", quietly = TRUE))
out_dir <- file.path("results", "stage03", "sensitivity")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create("logs", showWarnings = FALSE)
log_con <- file(file.path("logs", "stage03_sensitivity.log"), open = "wt")
sink(log_con, type = "output", split = TRUE); sink(log_con, type = "message")
on.exit({sink(type = "message"); sink(type = "output"); close(log_con)}, add = TRUE)

sep <- read.delim(file.path("genesets", "SEP_v1.0.tsv"), check.names = FALSE)
sample_lock <- read.delim(file.path("metadata", "stage03_validation_sample_lock.tsv"), check.names = FALSE)
pairs30999 <- read.delim(file.path("metadata", "gse30999_metadata_pair_registry.tsv"), check.names = FALSE)
pairs30999 <- pairs30999[pairs30999$metadata_pair_status == "COMPLETE_EXACT_ID_PAIR", ]
primary_stats <- read.delim(file.path("results", "stage03", "scores", "paired_score_statistics.tsv"), check.names = FALSE)

median_df <- read.delim(gzfile(file.path("results", "stage03", "matrices", "gse30999_gcrma_entrez_gene_matrix.tsv.gz")), check.names = FALSE)
mean_df <- read.delim(gzfile(file.path(out_dir, "gse30999_gcrma_entrez_gene_mean_matrix.tsv.gz")), check.names = FALSE)
array_ids <- as.character(median_df[[1]])
stopifnot(identical(array_ids, as.character(mean_df[[1]])))
median_mat <- as.matrix(median_df[-1]); mean_mat <- as.matrix(mean_df[-1])
storage.mode(median_mat) <- "double"; storage.mode(mean_mat) <- "double"
rownames(median_mat) <- rownames(mean_mat) <- array_ids

count_df <- read.delim(gzfile(file.path("data", "raw", "validation", "GSE121212", "GSE121212_readcount.txt.gz")), check.names = FALSE)
count_ids <- as.character(count_df[[1]])
count_mat <- as.matrix(count_df[-1]); storage.mode(count_mat) <- "integer"
count_mat <- rowsum(count_mat, group = count_ids, reorder = FALSE)
y <- edgeR::DGEList(counts = count_mat); y <- edgeR::calcNormFactors(y, method = "TMM")
rna_mat <- edgeR::cpm(y, log = TRUE, prior.count = 2)
rna_ids <- rownames(rna_mat)

sep$measurable_array <- as.character(sep$selected_human_entrez_id) %in% array_ids
sep$measurable_rna <- sep$human_gene_symbol %in% rna_ids
sep$shared <- sep$measurable_array & sep$measurable_rna
sep$high <- as.logical(sep$high_confidence_sep_interaction)
stopifnot(sum(sep$shared) == 2550L, sum(sep$high) == 1530L)

rank_matrix <- function(mat, samples) {
  apply(mat[, samples, drop = FALSE], 2, rank, ties.method = "average") / (nrow(mat) + 1)
}
score_subset <- function(ranks, feature_ids, rows, id_field, pairs, dataset_id, variant_id) {
  up <- as.character(rows[[id_field]][rows$sep_direction == "UP"])
  down <- as.character(rows[[id_field]][rows$sep_direction == "DOWN"])
  up <- intersect(up, feature_ids); down <- intersect(down, feature_ids)
  scores <- colMeans(ranks[match(up, feature_ids), , drop = FALSE]) -
            colMeans(ranks[match(down, feature_ids), , drop = FALSE])
  if (dataset_id == "GSE30999") {
    result <- data.frame(dataset_id = dataset_id, variant_id = variant_id,
      donor_id = pairs$public_subject_id, nonlesional_sample = pairs$nl_gsm,
      lesional_sample = pairs$ls_gsm, n_up = length(up), n_down = length(down),
      nonlesional_score = unname(scores[pairs$nl_gsm]),
      lesional_score = unname(scores[pairs$ls_gsm]), stringsAsFactors = FALSE)
  } else {
    split_rows <- split(pairs, pairs$donor_id)
    result <- do.call(rbind, lapply(split_rows, function(z) {
      nl <- z$sample_title[z$skin_type == "non-lesional"]
      ls <- z$sample_title[z$skin_type == "lesional"]
      data.frame(dataset_id = dataset_id, variant_id = variant_id, donor_id = z$donor_id[1],
        nonlesional_sample = nl, lesional_sample = ls, n_up = length(up), n_down = length(down),
        nonlesional_score = unname(scores[nl]), lesional_score = unname(scores[ls]))
    }))
  }
  rownames(result) <- NULL
  result$delta_LS_minus_NL <- result$lesional_score - result$nonlesional_score
  result
}
summarize_variant <- function(scores, timing, role = "ESTIMATED") {
  delta <- scores$delta_LS_minus_NL
  tt <- t.test(delta); wt <- suppressWarnings(wilcox.test(delta, exact = FALSE))
  data.frame(dataset_id = scores$dataset_id[1], variant_id = scores$variant_id[1],
    status = role, design_timing = timing, n_pairs = length(delta),
    n_up = scores$n_up[1], n_down = scores$n_down[1], mean_delta = mean(delta),
    ci_low = tt$conf.int[1], ci_high = tt$conf.int[2],
    t_p_value = tt$p.value, wilcoxon_p_value = wt$p.value,
    positive_pairs = sum(delta > 0), stringsAsFactors = FALSE)
}

array_samples <- c(pairs30999$nl_gsm, pairs30999$ls_gsm)
array_median_ranks <- rank_matrix(median_mat, array_samples)
array_mean_ranks <- rank_matrix(mean_mat, array_samples)
rna_lock <- sample_lock[sample_lock$dataset_id == "GSE121212" & sample_lock$lock_status == "PRIMARY_INCLUDE", ]
rna_ranks <- rank_matrix(rna_mat, rna_lock$sample_title)

subsets <- list(PRIMARY_FULL_SEP = rep(TRUE, nrow(sep)), SHARED_PLATFORM_SEP = sep$shared,
                HIGH_CONFIDENCE_SEP = sep$high, HIGH_CONFIDENCE_SHARED = sep$high & sep$shared)
score_rows <- list(); stat_rows <- list()
for (variant in names(subsets)) {
  rows <- sep[subsets[[variant]], ]
  a <- score_subset(array_median_ranks, array_ids, rows, "selected_human_entrez_id", pairs30999, "GSE30999", variant)
  r <- score_subset(rna_ranks, rna_ids, rows, "human_gene_symbol", rna_lock, "GSE121212", variant)
  timing <- if (variant == "PRIMARY_FULL_SEP") "FROZEN_PRIMARY_BEFORE_VALIDATION" else "F1_OR_PRE_EFFECT_COVERAGE_FROZEN"
  score_rows <- c(score_rows, list(a, r)); stat_rows <- c(stat_rows, list(summarize_variant(a, timing), summarize_variant(r, timing)))
}
array_mean <- score_subset(array_mean_ranks, array_ids, sep, "selected_human_entrez_id", pairs30999, "GSE30999", "ARRAY_ALL_PROBE_MEAN")
score_rows[[length(score_rows) + 1L]] <- array_mean
stat_rows[[length(stat_rows) + 1L]] <- summarize_variant(array_mean, "POST_PRIMARY_DETERMINISTIC_MASTER_REQUESTED_MAPPING_CHECK")

scores <- do.call(rbind, score_rows); stats <- do.call(rbind, stat_rows)
for (dataset in unique(stats$dataset_id)) {
  reference <- primary_stats$mean_delta[primary_stats$dataset_id == dataset]
  stats$delta_from_primary[stats$dataset_id == dataset] <- stats$mean_delta[stats$dataset_id == dataset] - reference
  stats$ratio_to_primary[stats$dataset_id == dataset] <- stats$mean_delta[stats$dataset_id == dataset] / reference
}
stats$BH_FDR_nonprimary_sensitivities <- NA_real_
idx <- stats$variant_id != "PRIMARY_FULL_SEP"
stats$BH_FDR_nonprimary_sensitivities[idx] <- p.adjust(stats$t_p_value[idx], method = "BH")

blocked <- data.frame(
  dataset_id = rep(c("GSE30999", "GSE121212"), each = 2),
  variant_id = rep(c("CLINICAL_COVARIATE_ADJUSTED", "KNOWN_DONOR_OVERLAP_EXCLUSION"), 2),
  status = rep(c("BLOCKED_UNAVAILABLE_GEO_FIELDS", "NOT_ESTIMABLE_NO_IDENTIFIED_OVERLAP"), 2),
  design_timing = "INPUT_AUDIT", n_pairs = NA, n_up = NA, n_down = NA,
  mean_delta = NA, ci_low = NA, ci_high = NA, t_p_value = NA, wilcoxon_p_value = NA,
  positive_pairs = NA, delta_from_primary = NA, ratio_to_primary = NA,
  BH_FDR_nonprimary_sensitivities = NA, stringsAsFactors = FALSE)
stats <- rbind(stats, blocked)
write.table(scores, file.path(out_dir, "stage03_sensitivity_patient_scores.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(stats, file.path(out_dir, "stage03_sensitivity.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(data.frame(metric = c("shared_SEP", "high_confidence_SEP", "high_confidence_shared",
                                  "covariate_rows_available", "exact_cross_accession_donor_overlap"),
                       value = c(sum(sep$shared), sum(sep$high), sum(sep$high & sep$shared), 0, 0),
                       status = c("PASS", "PASS", "PASS", "BLOCKED", "PROVISIONAL_NONE_IDENTIFIED")),
            file.path(out_dir, "stage03_sensitivity_availability.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
stopifnot(abs(stats$mean_delta[stats$dataset_id == "GSE30999" & stats$variant_id == "PRIMARY_FULL_SEP"] -
              primary_stats$mean_delta[primary_stats$dataset_id == "GSE30999"]) < 1e-12,
          abs(stats$mean_delta[stats$dataset_id == "GSE121212" & stats$variant_id == "PRIMARY_FULL_SEP"] -
              primary_stats$mean_delta[primary_stats$dataset_id == "GSE121212"]) < 1e-12)
cat(sprintf("PASS: %d patient score rows, %d sensitivity status rows\n", nrow(scores), nrow(stats)))
