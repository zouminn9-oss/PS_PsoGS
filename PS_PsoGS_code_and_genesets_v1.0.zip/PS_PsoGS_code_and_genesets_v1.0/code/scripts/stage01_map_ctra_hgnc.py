#!/usr/bin/env python3
"""Map all fixed CTRA symbols against a frozen HGNC complete-set snapshot."""

from __future__ import annotations

import csv
import hashlib
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CTRA = ROOT / "genesets" / "ctra_kohrt2016_v1.0.tsv"
HGNC = ROOT / "metadata" / "hgnc_complete_set_2026-09-10.tsv"
OUTPUT = ROOT / "genesets" / "ctra_kohrt2016_v1.1_hgnc_2026-09-10.tsv"
AUDIT = ROOT / "audits" / "ctra_hgnc_mapping_audit.tsv"


def read_tsv(path):
    with path.open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def write_tsv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def tokens(value):
    return {part.strip() for part in (value or "").split("|") if part.strip()}


def main():
    ctra = read_tsv(CTRA)
    hgnc = read_tsv(HGNC)
    by_symbol = {row["symbol"]: row for row in hgnc if row["status"] == "Approved"}
    by_prev, by_alias = defaultdict(list), defaultdict(list)
    for row in hgnc:
        if row["status"] != "Approved":
            continue
        for value in tokens(row["prev_symbol"]):
            by_prev[value].append(row)
        for value in tokens(row["alias_symbol"]):
            by_alias[value].append(row)

    mapped, audit = [], []
    for item in ctra:
        raw = item["raw_symbol"]
        if raw in by_symbol:
            matches, route = [by_symbol[raw]], "APPROVED_SYMBOL_EXACT"
        elif len(by_prev[raw]) == 1:
            matches, route = by_prev[raw], "UNIQUE_PREVIOUS_SYMBOL"
        elif len(by_alias[raw]) == 1:
            matches, route = by_alias[raw], "UNIQUE_ALIAS_SYMBOL"
        else:
            matches, route = by_prev[raw] or by_alias[raw], "UNRESOLVED_OR_AMBIGUOUS"
        current = matches[0] if len(matches) == 1 else {}
        status = "PASS" if len(matches) == 1 else "FAIL"
        mapped.append({
            "raw_symbol": raw,
            "current_hgnc_symbol": current.get("symbol", ""),
            "hgnc_id": current.get("hgnc_id", ""),
            "approved_name": current.get("name", ""),
            "locus_group": current.get("locus_group", ""),
            "locus_type": current.get("locus_type", ""),
            "ensembl_gene_id": current.get("ensembl_gene_id", ""),
            "entrez_id": current.get("entrez_id", ""),
            "mapping_route": route,
            "mapping_status": status,
            "direction": item["direction"],
            "weight": item["weight"],
            "ctra_source_doi": item["doi"],
            "hgnc_snapshot_date": "2026-09-10",
            "hgnc_snapshot_sha256": hashlib.sha256(HGNC.read_bytes()).hexdigest(),
        })
        audit.append({
            "raw_symbol": raw, "match_count": len(matches), "mapping_route": route,
            "matched_symbols": "|".join(row["symbol"] for row in matches), "status": status,
        })

    assert len(mapped) == 53
    assert all(row["mapping_status"] == "PASS" for row in mapped)
    assert len({row["current_hgnc_symbol"] for row in mapped}) == 53
    assert not ({row["current_hgnc_symbol"] for row in mapped if row["direction"] == "UP"} &
                {row["current_hgnc_symbol"] for row in mapped if row["direction"] == "DOWN"})
    write_tsv(OUTPUT, mapped)
    write_tsv(AUDIT, audit)
    routes = defaultdict(int)
    for row in mapped:
        routes[row["mapping_route"]] += 1
    print(f"PASS: 53/53 uniquely mapped; routes={dict(routes)}")


if __name__ == "__main__":
    main()
