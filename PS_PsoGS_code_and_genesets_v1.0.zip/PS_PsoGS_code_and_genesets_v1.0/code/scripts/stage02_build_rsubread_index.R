options(stringsAsFactors = FALSE)

.libPaths(c(normalizePath(file.path("r_libs", "stage02")),
            normalizePath(file.path("r_libs", "stage01")), .libPaths()))
stopifnot(requireNamespace("Rsubread", quietly = TRUE))
stopifnot(as.character(packageVersion("Rsubread")) == "2.20.0")

reference_root <- file.path("references", "genomes", "GRCm38_gencode_M25")
fasta <- file.path(reference_root, "GRCm38.primary_assembly.genome.fa")
index_base <- file.path(reference_root, "rsubread_index", "GRCm38_GENCODE_M25")
stopifnot(file.exists(fasta))
dir.create(dirname(index_base), recursive = TRUE, showWarnings = FALSE)

Rsubread::buildindex(basename = index_base, reference = fasta, indexSplit = TRUE,
                     memory = 12000, TH_subread = 100)

files <- Sys.glob(paste0(index_base, ".*"))
stopifnot(length(files) > 0L)
write.table(data.frame(file = files, bytes = file.info(files)$size),
            file.path("audits", "gse212126_rsubread_index_files.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
cat(sprintf("PASS: built Rsubread index with %d files\n", length(files)))
