project_lib <- normalizePath(file.path(getwd(), "r_libs", "stage01"), mustWork = TRUE)
.libPaths(c(project_lib, .libPaths()))

dir.create(file.path("figures", "source_data"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path("figures", "qc"), recursive = TRUE, showWarnings = FALSE)

summary <- read.delim(file.path("results", "stage01", "GSE70603_contrast_summary.tsv"),
                      check.names = FALSE, stringsAsFactors = FALSE)
candidates <- read.delim(file.path("genesets", "GSE70603_time_locked_stress_v1.0.tsv"),
                         check.names = FALSE, stringsAsFactors = FALSE)
mapped <- read.delim(file.path("genesets", "GSE70603_time_locked_stress_v1.1_hgnc_2026-09-10.tsv"),
                     check.names = FALSE, stringsAsFactors = FALSE)

contrast_order <- c(
  "stress_plus45_vs_pre_all",
  "stress_plus180_vs_pre_all",
  "stress_plus180_vs_plus45_all",
  "adversity_moderation_plus45_unadjusted",
  "adversity_moderation_plus180_unadjusted",
  "adversity_moderation_plus45_age_sex_adjusted",
  "adversity_moderation_plus180_age_sex_adjusted"
)
contrast_labels <- c(
  "+45 vs -45",
  "+180 vs -45",
  "+180 vs +45",
  "Adversity x +45",
  "Adversity x +180",
  "Adj. adversity x +45",
  "Adj. adversity x +180"
)
summary <- summary[match(contrast_order, summary$contrast_id), ]
stopifnot(!anyNA(summary$contrast_id))
panel_a <- data.frame(
  contrast_id = summary$contrast_id,
  display_label = contrast_labels,
  genes_tested = summary$genes_tested,
  significant_up = summary$fdr_lt_0_05_up,
  significant_down = summary$fdr_lt_0_05_down,
  minimum_fdr = summary$minimum_fdr,
  stringsAsFactors = FALSE
)

class_order <- c("plus45_only", "plus180_only", "persistent_same_direction",
                 "biphasic_opposite_direction")
class_labels <- c("+45 only", "+180 only", "Persistent, same direction", "Biphasic, opposite")
class_counts <- table(factor(candidates$response_class, levels = class_order))
panel_b <- data.frame(
  response_class = class_order,
  display_label = class_labels,
  candidate_count = as.integer(class_counts),
  denominator = nrow(candidates),
  percent = 100 * as.integer(class_counts) / nrow(candidates),
  stringsAsFactors = FALSE
)

mapping_order <- c("PASS", "HOLD", "HOLD_COLLISION")
mapping_labels <- c("One-to-one HGNC pass", "Unmapped or ambiguous hold", "Mapping collision hold")
mapping_counts <- table(factor(mapped$mapping_status, levels = mapping_order))
panel_c <- data.frame(
  mapping_status = mapping_order,
  display_label = mapping_labels,
  symbol_count = as.integer(mapping_counts),
  denominator = nrow(mapped),
  percent = 100 * as.integer(mapping_counts) / nrow(mapped),
  stringsAsFactors = FALSE
)

write.table(panel_a, file.path("figures", "source_data", "stage01_gse70603_qc_panel_a.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)
write.table(panel_b, file.path("figures", "source_data", "stage01_gse70603_qc_panel_b.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)
write.table(panel_c, file.path("figures", "source_data", "stage01_gse70603_qc_panel_c.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)

ink <- "#20262E"
blue <- "#356E9A"
orange <- "#E6A65D"
grey <- "#D5DADF"
grid <- "#E8EBEE"

draw_figure <- function() {
  layout(matrix(1:3, nrow = 1), widths = c(1.45, 1, 1))
  par(family = "sans", fg = ink, col.axis = ink, col.lab = ink, bty = "n")

  par(mar = c(3.6, 8.0, 3.2, 0.8))
  limits <- c(-max(panel_a$significant_down) * 1.22, max(panel_a$significant_up) * 1.22)
  p <- panel_a[nrow(panel_a):1, ]
  mids <- seq_len(nrow(p))
  plot(NA, xlim = limits, ylim = c(0.35, nrow(p) + 0.65), axes = FALSE,
       xlab = "", ylab = "", xaxs = "i", yaxs = "i")
  abline(v = pretty(limits), col = grid, lwd = 0.7)
  abline(v = 0, col = ink, lwd = 0.9)
  rect(-p$significant_down, mids - 0.32, 0, mids + 0.32,
       col = orange, border = ink, lwd = 0.5)
  rect(0, mids - 0.32, p$significant_up, mids + 0.32,
       col = blue, border = ink, lwd = 0.5)
  axis(1, at = pretty(limits), labels = abs(pretty(limits)), cex.axis = 0.72)
  axis(2, at = mids, labels = p$display_label, las = 1, tick = FALSE, cex.axis = 0.69)
  title(main = "A  FDR-significant genes by contrast", adj = 0, cex.main = 0.93)
  mtext("Counts among 32,080 tested symbols; left=DOWN, right=UP", side = 3,
        adj = 0, line = 0.35, cex = 0.67, col = "#59636E")
  for (i in seq_len(nrow(p))) {
    down <- p$significant_down[i]
    up <- p$significant_up[i]
    if (down > 0) text(-down, mids[i], labels = down, pos = 2, offset = 0.25, cex = 0.64)
    if (up > 0) text(up, mids[i], labels = up, pos = 4, offset = 0.25, cex = 0.64)
    if (down == 0 && up == 0) text(0, mids[i], labels = "0", pos = 4, offset = 0.3, cex = 0.64)
  }
  legend("topright", legend = c("UP", "DOWN"), fill = c(blue, orange),
         border = ink, bty = "n", horiz = TRUE, cex = 0.7)

  par(mar = c(3.6, 7.0, 3.2, 0.8))
  b_order <- order(panel_b$candidate_count)
  b <- panel_b[b_order, ]
  mids <- barplot(b$candidate_count, horiz = TRUE, col = blue, border = ink, lwd = 0.5,
                  names.arg = b$display_label, las = 1, cex.names = 0.72,
                  xlim = c(0, max(b$candidate_count) * 1.25), axes = FALSE)
  abline(v = pretty(c(0, max(b$candidate_count))), col = grid, lwd = 0.7)
  axis(1, at = pretty(c(0, max(b$candidate_count))), cex.axis = 0.72)
  text(b$candidate_count, mids, labels = sprintf("%s (%.1f%%)", b$candidate_count, b$percent),
       pos = 4, offset = 0.25, cex = 0.66)
  title(main = "B  Candidate response classes", adj = 0, cex.main = 0.93)
  mtext("Predefined FDR union; 4,426 raw symbols", side = 3, adj = 0,
        line = 0.35, cex = 0.67, col = "#59636E")

  par(mar = c(3.6, 7.3, 3.2, 0.8))
  c_order <- order(panel_c$symbol_count)
  cdat <- panel_c[c_order, ]
  colors <- c(PASS = blue, HOLD = grey, HOLD_COLLISION = orange)[cdat$mapping_status]
  mids <- barplot(cdat$symbol_count, horiz = TRUE, col = colors, border = ink, lwd = 0.5,
                  names.arg = cdat$display_label, las = 1, cex.names = 0.72,
                  xlim = c(0, max(cdat$symbol_count) * 1.28), axes = FALSE)
  abline(v = pretty(c(0, max(cdat$symbol_count))), col = grid, lwd = 0.7)
  axis(1, at = pretty(c(0, max(cdat$symbol_count))), cex.axis = 0.72)
  text(cdat$symbol_count, mids,
       labels = sprintf("%s (%.1f%%)", cdat$symbol_count, cdat$percent),
       pos = 4, offset = 0.25, cex = 0.66)
  title(main = "C  HGNC mapping adjudication", adj = 0, cex.main = 0.93)
  mtext("Frozen HGNC snapshot, 2026-09-10", side = 3, adj = 0,
        line = 0.35, cex = 0.67, col = "#59636E")
}

svg(file.path("figures", "qc", "stage01_gse70603_qc.svg"), width = 11, height = 4.8,
    pointsize = 10, bg = "white")
draw_figure()
dev.off()

png(file.path("figures", "qc", "stage01_gse70603_qc.png"), width = 11, height = 4.8,
    units = "in", res = 180, pointsize = 10, bg = "white")
draw_figure()
dev.off()

cat("PASS: rendered Stage 01 GSE70603 QC figure\n")
