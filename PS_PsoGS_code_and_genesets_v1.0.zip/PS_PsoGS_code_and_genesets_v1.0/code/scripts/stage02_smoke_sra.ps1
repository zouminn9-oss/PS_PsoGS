param(
    [string]$Run = "SRR21221234",
    [int]$MaxSpots = 100000,
    [int]$Threads = 8
)

$ErrorActionPreference = "Stop"
$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$ToolkitBin = Join-Path $ProjectRoot "tools\sratoolkit\sratoolkit.3.4.1-win64\bin"
$SraRoot = Join-Path $ProjectRoot "data\raw\gse212126_sra"
$FastqRoot = Join-Path $ProjectRoot "data\interim\gse212126_fastq\smoke_$Run"
$TempRoot = Join-Path $ProjectRoot "data\interim\gse212126_fastq\temp_$Run"
$LogRoot = Join-Path $ProjectRoot "logs\stage02"
$LogFile = Join-Path $LogRoot "${Run}_smoke.log"
$StatePath = Join-Path $ProjectRoot "audits\gse212126_sra_download_state.tsv"
$OfflineConfig = Join-Path $ProjectRoot "config\sra_toolkit_offline\user-settings.mkfg"

foreach ($Path in @($ToolkitBin, $SraRoot, (Split-Path $FastqRoot -Parent), $LogRoot)) {
    if (-not (Test-Path -LiteralPath $Path)) { throw "Required path missing: $Path" }
}
New-Item -ItemType Directory -Force -Path $FastqRoot, $TempRoot | Out-Null
if (-not (Test-Path -LiteralPath $OfflineConfig)) { throw "offline SRA configuration missing: $OfflineConfig" }

$Validate = Join-Path $ToolkitBin "vdb-validate.exe"
$FastqDump = Join-Path $ToolkitBin "fastq-dump.exe"
$SraAudit = Join-Path $ProjectRoot "audits\gse212126_sra_audit.tsv"
$RunMeta = Import-Csv -LiteralPath $SraAudit -Delimiter "`t" | Where-Object { $_.srr -eq $Run }
if ($null -eq $RunMeta -or @($RunMeta).Count -ne 1) { throw "Expected one SRA audit row for $Run" }
$RunDir = Join-Path $SraRoot $Run
New-Item -ItemType Directory -Force -Path $RunDir | Out-Null
$SraFile = Join-Path $RunDir "${Run}.sra"

"START`t$(Get-Date -Format o)`t$Run`tspots=$MaxSpots`tthreads=$Threads" | Out-File -LiteralPath $LogFile -Encoding utf8
$DownloadUrl = $RunMeta.normalized_sra_url -replace '^https:', 'http:'
$DownloadAction = "DOWNLOAD_OR_RESUME"
$ExistingMd5 = if (Test-Path -LiteralPath $SraFile) {
    (Get-FileHash -LiteralPath $SraFile -Algorithm MD5).Hash.ToLower()
} else { "" }
if ($ExistingMd5 -eq $RunMeta.normalized_sra_md5) {
    $DownloadAction = "REUSE_EXISTING_OFFICIAL_MD5_PASS"
    "REUSE`t$Run`tofficial_md5_already_passed" | Tee-Object -FilePath $LogFile -Append
} else {
    "DOWNLOAD_URL`t$DownloadUrl`ttransport_http_with_official_md5_verification" | Tee-Object -FilePath $LogFile -Append
    & curl.exe -L --fail --retry 8 --retry-all-errors --retry-delay 5 -C - --silent --show-error -o $SraFile $DownloadUrl 2>&1 | Tee-Object -FilePath $LogFile -Append
    if ($LASTEXITCODE -ne 0) { throw "normalized-SRA download failed with exit code $LASTEXITCODE" }
}
$ObservedMd5 = (Get-FileHash -LiteralPath $SraFile -Algorithm MD5).Hash.ToLower()
if ($ObservedMd5 -ne $RunMeta.normalized_sra_md5) {
    throw "normalized-SRA MD5 mismatch: observed $ObservedMd5 expected $($RunMeta.normalized_sra_md5)"
}
"SRA_MD5_PASS`t$ObservedMd5" | Tee-Object -FilePath $LogFile -Append

& $Validate $SraFile 2>&1 | Tee-Object -FilePath $LogFile -Append
if ($LASTEXITCODE -ne 0) { throw "vdb-validate failed with exit code $LASTEXITCODE" }
$ObservedBytes = (Get-Item -LiteralPath $SraFile).Length
$StateRow = [pscustomobject]@{
    srr = $Run
    gsm = $RunMeta.gsm
    expected_bytes_from_cached_xml = $RunMeta.compressed_size_bytes
    downloaded_bytes = $ObservedBytes
    expected_md5 = $RunMeta.normalized_sra_md5
    observed_md5 = $ObservedMd5
    transport = "HTTP_AWS_PUBLIC_OBJECT"
    download_action = $DownloadAction
    integrity_status = "PASS"
    vdb_validate_status = "PASS"
    completed_at = (Get-Date -Format o)
    file = $SraFile.Substring($ProjectRoot.Length + 1).Replace('\','/')
}
$StateRow | Export-Csv -LiteralPath $StatePath -Delimiter "`t" -NoTypeInformation -Encoding utf8

$env:NCBI_SETTINGS = $OfflineConfig
"OFFLINE_CONFIG`t$OfflineConfig`tremote_access_disabled" | Tee-Object -FilePath $LogFile -Append
& $FastqDump $SraFile --split-files --minSpotId 1 --maxSpotId $MaxSpots --outdir $FastqRoot 2>&1 | Tee-Object -FilePath $LogFile -Append
if ($LASTEXITCODE -ne 0) { throw "fastq-dump smoke subset failed with exit code $LASTEXITCODE" }

$Read1 = Join-Path $FastqRoot "${Run}_1.fastq"
$Read2 = Join-Path $FastqRoot "${Run}_2.fastq"
if (-not (Test-Path -LiteralPath $Read1) -or -not (Test-Path -LiteralPath $Read2)) {
    throw "Expected paired FASTQ files were not created"
}
"COMPLETE`t$(Get-Date -Format o)`t$Run" | Tee-Object -FilePath $LogFile -Append
