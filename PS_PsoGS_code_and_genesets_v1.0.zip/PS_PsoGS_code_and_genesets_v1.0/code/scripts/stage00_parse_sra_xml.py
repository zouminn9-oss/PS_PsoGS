#!/usr/bin/env python3
"""Parse the cached official NCBI SRA XML for GSE212126."""

import csv
import hashlib
import xml.etree.ElementTree as ET
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "metadata" / "gse212126_sra_metadata.xml"
OUTPUT = ROOT / "audits" / "gse212126_sra_audit.tsv"


def text(node, path):
    value = node.findtext(path)
    return value.strip() if value else ""


def main():
    root = ET.parse(SOURCE).getroot()
    rows = []
    for package in root.findall("EXPERIMENT_PACKAGE"):
        experiment = package.find("EXPERIMENT")
        sample = package.find("SAMPLE")
        run = package.find("RUN_SET/RUN")
        attrs = {}
        for attr in sample.findall(".//SAMPLE_ATTRIBUTE"):
            attrs[text(attr, "TAG")] = text(attr, "VALUE")
        external = {x.attrib.get("namespace", ""): (x.text or "").strip()
                    for x in sample.findall(".//EXTERNAL_ID")}
        layout_parent = experiment.find("DESIGN/LIBRARY_DESCRIPTOR/LIBRARY_LAYOUT")
        layout = next(iter(layout_parent), None).tag if layout_parent is not None and len(layout_parent) else ""
        platform_parent = experiment.find("PLATFORM")
        platform = next(iter(platform_parent), None)
        original_fastqs = [item for item in run.findall("SRAFiles/SRAFile")
                           if item.attrib.get("supertype") == "Original" and item.attrib.get("semantic_name") == "fastq"]
        normalized_sra = next((item for item in run.findall("SRAFiles/SRAFile")
                               if item.attrib.get("semantic_name") == "SRA Normalized"), None)
        read_stats = run.findall("Statistics/Read")
        rows.append({
            "gsm": experiment.attrib.get("alias", "").split("_r")[0],
            "srx": experiment.attrib.get("accession", ""),
            "srs": sample.attrib.get("accession", ""),
            "biosample": external.get("BioSample", ""),
            "srr": run.attrib.get("accession", ""),
            "title": text(sample, "TITLE"),
            "treatment": attrs.get("treatment", ""),
            "tissue": attrs.get("tissue", ""),
            "strain": attrs.get("strain", ""),
            "library_strategy": text(experiment, "DESIGN/LIBRARY_DESCRIPTOR/LIBRARY_STRATEGY"),
            "library_source": text(experiment, "DESIGN/LIBRARY_DESCRIPTOR/LIBRARY_SOURCE"),
            "library_selection": text(experiment, "DESIGN/LIBRARY_DESCRIPTOR/LIBRARY_SELECTION"),
            "library_layout": layout,
            "platform": platform.tag if platform is not None else "",
            "instrument_model": text(platform, "INSTRUMENT_MODEL") if platform is not None else "",
            "read_count_per_spot": run.find("Statistics").attrib.get("nreads", "") if run.find("Statistics") is not None else "",
            "read1_average_length": read_stats[0].attrib.get("average", "") if len(read_stats) > 0 else "",
            "read2_average_length": read_stats[1].attrib.get("average", "") if len(read_stats) > 1 else "",
            "total_spots": run.attrib.get("total_spots", ""),
            "total_bases": run.attrib.get("total_bases", ""),
            "compressed_size_bytes": run.attrib.get("size", ""),
            "original_fastq_names": "|".join(item.attrib.get("filename", "") for item in original_fastqs),
            "original_fastq_sizes_bytes": "|".join(item.attrib.get("size", "") for item in original_fastqs),
            "original_fastq_md5": "|".join(item.attrib.get("md5", "") for item in original_fastqs),
            "normalized_sra_url": normalized_sra.attrib.get("url", "") if normalized_sra is not None else "",
            "normalized_sra_md5": normalized_sra.attrib.get("md5", "") if normalized_sra is not None else "",
            "geo_processing_assembly": "mm10",
            "geo_processing_note": "GEO states StringTie/edgeR FPKM and limma pairwise DE; submitted original files are named Clean_Data",
            "animal_independence_evidence": "DISTINCT_GSM_SRX_SRS_BIOSAMPLE_SRR;ANIMAL_ID_NOT_EXPLICIT",
            "source_xml_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        })
    fields = list(rows[0])
    with OUTPUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(sorted(rows, key=lambda r: r["gsm"]))
    assert len(rows) == 12
    assert len({r["biosample"] for r in rows}) == 12
    assert len({r["srr"] for r in rows}) == 12
    print(f"wrote {len(rows)} SRA records; {sum(int(r['compressed_size_bytes']) for r in rows)} compressed bytes")


if __name__ == "__main__":
    main()
