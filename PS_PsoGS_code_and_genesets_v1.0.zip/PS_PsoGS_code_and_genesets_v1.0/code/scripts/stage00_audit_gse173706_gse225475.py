#!/usr/bin/env python3
"""Audit GSE173706 donor identities and GSE225475 spatial design.

Expression matrices are intentionally out of scope.  The audit uses the cached
official GEO SOFT files and the primary-paper PMC XML only.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import re
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DATE = "2026-09-10"
PAPER = ROOT / "metadata" / "gse173706_gse225475_pmc10261041.xml"
PAPER_URL = "https://pmc.ncbi.nlm.nih.gov/articles/PMC10261041/"

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_tsv(path: Path, rows: list[dict[str, str]]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write empty audit: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def parse_soft(path: Path) -> list[dict[str, object]]:
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
        text = handle.read()
    rows: list[dict[str, object]] = []
    for part in text.split("^SAMPLE = ")[1:]:
        record: dict[str, object] = {
            "gsm": part.splitlines()[0].strip(),
            "characteristics": [],
            "supplementary_files": [],
        }
        for line in part.splitlines()[1:]:
            if " = " not in line:
                continue
            key, value = line.split(" = ", 1)
            if key == "!Sample_title":
                record["title"] = value
            elif key == "!Sample_description":
                record["description"] = value
            elif key == "!Sample_characteristics_ch1":
                record["characteristics"].append(value)
            elif key.startswith("!Sample_supplementary_file_"):
                record["supplementary_files"].append(value)
        rows.append(record)
    return rows


def characteristic(record: dict[str, object], key: str) -> str:
    prefix = f"{key.lower()}:"
    for value in record["characteristics"]:
        if str(value).lower().startswith(prefix):
            return str(value).split(":", 1)[1].strip()
    return ""


def bracket_code(title: str) -> str:
    match = re.search(r"\[((?:NS|PN|PP)-[^\]]+)\]", title)
    return match.group(1) if match else ""


def code_from_description(description: str) -> str:
    match = re.match(r"((?:NS|PN|PP)-.+?)_S\d+_L\d+", description)
    return match.group(1) if match else ""


def code_from_file(files: list[str]) -> str:
    if not files:
        return ""
    name = Path(files[0]).name
    match = re.match(r"GSM\d+_((?:NS|PN|PP)-.+?)\.csv\.gz", name)
    return match.group(1) if match else ""


def paper_text(path: Path) -> str:
    root = ET.parse(path).getroot()
    return " ".join("".join(root.itertext()).split())


def main() -> None:
    soft173 = ROOT / "metadata" / "geo_soft" / "GSE173706_family.soft.gz"
    soft225 = ROOT / "metadata" / "geo_soft" / "GSE225475_family.soft.gz"
    g173 = parse_soft(soft173)
    g225 = parse_soft(soft225)
    if len(g173) != 33 or len(g225) != 6:
        raise AssertionError(f"Unexpected sample counts: GSE173706={len(g173)}, GSE225475={len(g225)}")

    identity_rows: list[dict[str, str]] = []
    for record in g173:
        gsm = str(record["gsm"])
        title = str(record.get("title", ""))
        raw_subject = characteristic(record, "subject id").removeprefix("donor").strip()
        bracket = bracket_code(title)
        description_code = code_from_description(str(record.get("description", "")))
        file_code = code_from_file(list(record["supplementary_files"]))
        codes = [bracket, description_code, file_code]
        if not all(codes) or len(set(codes)) != 1:
            raise AssertionError(f"Bracket/description/file mismatch not covered by rule for {gsm}: {codes}")
        tissue_code, canonical_donor = bracket.split("-", 1)
        raw_matches = raw_subject == canonical_donor
        status = "PASS_ALL_ID_FIELDS" if raw_matches else "CORRECTED_GEO_SUBJECT_TYPO"
        if not raw_matches and gsm != "GSM5277178":
            raise AssertionError(f"Unexpected subject mismatch at {gsm}")
        identity_rows.append(
            {
                "dataset_id": "GSE173706",
                "sample_accession": gsm,
                "tissue_code": tissue_code,
                "geo_title_verbatim": title,
                "geo_subject_id_verbatim": raw_subject,
                "bracket_sample_code": bracket,
                "description_sample_code": description_code,
                "file_sample_code": file_code,
                "canonical_donor_id": canonical_donor,
                "adjudication_status": status,
                "paired_design_evidence": "PRIMARY_PAPER_11_PN_FROM_SAME_PSORIASIS_PATIENTS",
                "expression_matrix_accessed": "NO",
                "source_url": f"https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={gsm}",
                "source_file": soft173.relative_to(ROOT).as_posix(),
                "source_sha256": sha256(soft173),
                "accessed_local_date": DATE,
                "adjudication_note": (
                    "No correction required."
                    if raw_matches
                    else "Canonical donor 30696 is supported by bracket label, sample description, processed-file name, PP-30696 counterpart, and the primary-paper paired design; raw subject 3696 is retained as provenance."
                ),
            }
        )

    by_donor: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in identity_rows:
        by_donor[row["canonical_donor_id"]].append(row)
    registry_rows: list[dict[str, str]] = []
    for donor, rows in sorted(by_donor.items()):
        tissue_codes = sorted({row["tissue_code"] for row in rows})
        registry_rows.append(
            {
                "dataset_id": "GSE173706",
                "canonical_donor_id": donor,
                "donor_group": "healthy" if donor.startswith("AR") else "psoriasis",
                "sample_accessions": "|".join(sorted(row["sample_accession"] for row in rows)),
                "tissue_codes": "|".join(tissue_codes),
                "library_count": str(len(rows)),
                "pn_pp_pair_status": (
                    "COMPLETE_PAIRED" if {"PN", "PP"}.issubset(tissue_codes) else "NOT_PAIRED"
                ),
                "identity_freeze_status": "PASS",
            }
        )

    spatial_rows: list[dict[str, str]] = []
    for record in g225:
        gsm = str(record["gsm"])
        storage = characteristic(record, "tissue storage")
        disease = characteristic(record, "disease state")
        sample_label = str(record.get("description", ""))
        frozen = storage.lower() == "frozen"
        spatial_rows.append(
            {
                "dataset_id": "GSE225475",
                "sample_accession": gsm,
                "sample_label": sample_label,
                "geo_title_verbatim": str(record.get("title", "")),
                "disease_state": disease,
                "tissue_storage": storage,
                "assay_branch": "Visium_fresh_frozen_polyA" if frozen else "Visium_FFPE_probe_based",
                "section_thickness_um": "20" if frozen else "5",
                "capture_spot_diameter_um": "55",
                "public_donor_id": "",
                "donor_independence_status": "UNRESOLVED_PUBLIC_METADATA",
                "cross_modality_donor_overlap": "UNRESOLVED_NO_PUBLIC_DONOR_IDS",
                "statistical_unit": "section_library",
                "confirmatory_eligibility": "DESCRIPTIVE_SPATIAL_ONLY",
                "source_reported_quality_limit": "low detection; low resolution; incomplete coverage; ambient RNA",
                "proximity_analysis_status": "BLOCKED_BY_PRIMARY_PAPER_QUALITY_LIMITATION",
                "expression_matrix_accessed": "NO",
                "source_url": f"https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={gsm}",
                "source_file": soft225.relative_to(ROOT).as_posix(),
                "source_sha256": sha256(soft225),
                "accessed_local_date": DATE,
            }
        )

    text = paper_text(PAPER)
    required = [
        "8 healthy skin libraries (NS), 11 perilesional psoriasis skin libraries (PN), and 14 lesional psoriasis libraries (PP)",
        "from the same psoriasis patients",
        "thick frozen section placed on top of an array",
        "wells containing spatially barcoded capture oligonucleotides",
        "For Visium for FFPE",
        "5-micron thick sections",
        "Further analyses, including spatial proximity of cell types and co-localization of ligands and receptors, were prohibited",
    ]
    missing = [phrase for phrase in required if phrase not in text]
    if missing:
        raise AssertionError(f"Primary-paper evidence missing: {missing}")

    evidence_rows = [
        {
            "evidence_id": "PAPER_SC_LIBRARY_COUNTS",
            "evidence_summary": "The primary paper reports 8 NS, 11 PN and 14 PP libraries; PN samples came from the same psoriasis patients represented by lesions.",
            "supports": "GSE173706 has 11 PN-PP donor pairs after correcting the one-character donor typo.",
            "limits": "Does not add clinical covariates beyond public labels.",
            "source_url": PAPER_URL,
            "source_file": PAPER.relative_to(ROOT).as_posix(),
            "source_sha256": sha256(PAPER),
            "accessed_local_date": DATE,
        },
        {
            "evidence_id": "PAPER_SPATIAL_SCALE",
            "evidence_summary": "Fresh-frozen Visium used 20-micrometre sections and 55-micrometre capture spots; FFPE used 5-micrometre sections.",
            "supports": "Section thickness and capture-spot scale can be frozen in the design audit.",
            "limits": "Pixel-to-micrometre calibration for each histology image still requires file-level inspection.",
            "source_url": PAPER_URL,
            "source_file": PAPER.relative_to(ROOT).as_posix(),
            "source_sha256": sha256(PAPER),
            "accessed_local_date": DATE,
        },
        {
            "evidence_id": "PAPER_SPATIAL_QUALITY_LIMIT",
            "evidence_summary": "The authors report low detection, low resolution, incomplete coverage and ambient RNA, and state that proximity/co-localization analyses were not supported.",
            "supports": "Local proximity, co-localization and derived permutation panels remain blocked.",
            "limits": "Deconvolution, highly expressed genes and module-score displays remain potentially descriptive after file-level QC.",
            "source_url": PAPER_URL,
            "source_file": PAPER.relative_to(ROOT).as_posix(),
            "source_sha256": sha256(PAPER),
            "accessed_local_date": DATE,
        },
    ]

    write_tsv(ROOT / "audits" / "gse173706_identity_audit.tsv", identity_rows)
    write_tsv(ROOT / "metadata" / "gse173706_donor_registry.tsv", registry_rows)
    write_tsv(ROOT / "audits" / "gse225475_design_audit.tsv", spatial_rows)
    write_tsv(ROOT / "audits" / "gse173706_gse225475_paper_evidence.tsv", evidence_rows)
    print("PASS: wrote 33 identity rows, 22 donor rows, 6 spatial rows and 3 paper-evidence rows")


if __name__ == "__main__":
    main()
