# -*- coding: utf-8 -*-
"""Rewrite the CCID cover letter and highlights for revision 1."""
import docx, copy, json
from docx.text.paragraph import Paragraph
U='/mnt/user-data/uploads/PS_PsoGS/paper_rewriting_output/submission_package/'
log=[]

def setp(doc_label, p, t, label):
    log.append({'file':doc_label,'edit':label,'old':p.text,'new':t})
    p.runs[0].text=t
    for r in p.runs[1:]: r.text=''

def clone_after(p, t):
    node=copy.deepcopy(p._p); p._p.addnext(node)
    q=Paragraph(node, p._parent)
    q.runs[0].text=t
    for r in q.runs[1:]: r.text=''
    return q

# ------------------------------------------------------------------ cover letter
d=docx.Document(U+'cover_letter.en.docx'); P=d.paragraphs

setp('cover_letter', P[2],
 'Please consider our manuscript, "Inflammatory context shapes the cutaneous response to '
 'chronic stress in psoriasis," for publication as Original Research in the Medical '
 'Dermatology section of Clinical, Cosmetic and Investigational Dermatology.',
 'submission sentence shortened')

setp('cover_letter', P[3],
 'Stress is widely reported to worsen psoriasis, yet the prior question has not been tested: '
 'does established inflammation change the direction of the skin\'s response to the same stress '
 'exposure, or only its size? Reanalysing a public four-group chronic-restraint-stress and '
 'imiquimod experiment, we find that it changes the direction. Across 18,484 genes, 65.2% '
 'reverse the sign of the stress effect between non-inflamed and inflamed skin, against 50.0% '
 'under an exact permutation null obtained by enumerating all 400 possible label assignments '
 '(exact P=0.015; Spearman P=0.020). Reversal concentrates in the best-measured genes rather '
 'than the noisiest, and the effect geometry is invariant to library-scaling normalisation, so '
 'it is not an artefact of the compositional difference between inflamed and normal skin.',
 'lead paragraph rebuilt around the question and the calibrated number that answers it')

setp('cover_letter', P[4],
 'Three features should matter to your reviewers. The mouse result is calibrated rather than '
 'asserted: twelve animals permit complete enumeration, so we report exact permutation P values '
 'and state the resolution floor the design imposes. The human gene program was frozen in '
 'membership and direction before either validation cohort was opened, and rose in 79 of 81 and '
 '27 of 27 patient pairs across two platforms. Every biological inference uses independent '
 'animals, patients or donors as the unit, never genes, cells or spatial spots. Donor-level '
 'single-cell analysis places the program in both epidermal and dermal compartments and '
 'nominates an endothelial JAG2-fibroblast NOTCH2 link for direct testing; in longitudinal '
 'treatment data the lesional program falls further than placebo in every active arm '
 '(largest BH FDR=1.1x10^-4), with no comparable change in non-lesional skin.',
 'three increments stated, each pre-answering a likely methodological objection')

newp = P[5].insert_paragraph_before('')
newp.style = P[5].style
r = newp.add_run(
 'The boundaries are visible rather than implied. The program is also raised in atopic '
 'dermatitis, so we report a graded inflammatory-skin readout with greater expression in '
 'psoriasis rather than a psoriasis-exclusive signature; the human cohorts carry no stress '
 'measurements, so no claim is made about psychological stress in patients; and the negative '
 'downstream screens around the candidate link are reported alongside it. What the work offers '
 'your readers is a reproducible, treatment-responsive readout of plaque state and a concrete '
 'experiment to test next.')
try:
    src=P[4].runs[0]; r.font.name=src.font.name; r.font.size=src.font.size
except Exception: pass
log.append({'file':'cover_letter','edit':'boundaries and venue-fit paragraph added','old':'','new':r.text})

P=d.paragraphs                      # indices shift by one after the insertion
setp('cover_letter', P[6],
 'The manuscript is original, has not been published previously, and is not under consideration '
 'elsewhere. All authors have approved the submitted version and agree to its submission to this '
 'journal. Funding and competing-interest declarations are provided in the manuscript and the '
 'submission portal.',
 'author-facing instruction removed from the letter body; written as a declaration')

assert P[11].style.name.startswith('Heading'), P[11].text
items=[
 "Insert the corresponding author's name, affiliation, email, and full postal address.",
 "Obtain every author's confirmation of the originality and exclusive-submission statement above before sending this letter.",
 'Confirm the exact author list, affiliations, ORCID identifiers, and author contributions.',
 'Finalize funding, competing-interest, acknowledgment and ethics statements.',
 'Deposit derived gene sets, figure source data and code, then insert the permanent repository URL and archival DOI.',
 'Archive the source documentation for the GSE212126 twelve-independent-animal statement.',
 'Confirm the generative-AI disclosure wording against the publisher policy.',
 'Nominate suggested reviewers from the methodological literature cited, excluding the closest competing groups.',
]
bullets=[p for p in P[12:] if p.style.name=='List Bullet']
assert len(bullets)==4, len(bullets)
for p,t in zip(bullets, items[:4]):
    setp('cover_letter', p, t, 'checklist item rewritten')
anchor=bullets[-1]
for t in items[4:]:
    anchor=clone_after(anchor,t)
    log.append({'file':'cover_letter','edit':'checklist item added','old':'','new':t})

d.save('cover_letter.en_REV1.docx')

# ------------------------------------------------------------------ highlights
h=docx.Document(U+'highlights.en.docx'); H=h.paragraphs
new=[
 'Pre-existing inflammation reverses, rather than amplifies, the skin response to chronic stress.',
 'Reversal exceeds an exact permutation null and is unaffected by normalisation choice.',
 'A frozen 2,716-gene lesion program replicates in two independent paired psoriasis cohorts.',
 'Both epidermal and dermal compartments carry the program, with the larger shift in keratinocytes.',
 'The program falls further than placebo in every active cytokine-targeted treatment arm.',
]
for p,t in zip(H[1:5], new[:4]):
    setp('highlights', p, t, 'highlight rewritten')
q=clone_after(H[4], new[4])
log.append({'file':'highlights','edit':'fifth highlight added','old':'','new':new[4]})
h.save('highlights.en_REV1.docx')

json.dump(log, open('revision_log_cover_highlights.json','w'), indent=1, ensure_ascii=False)
print('edits:',len(log))
