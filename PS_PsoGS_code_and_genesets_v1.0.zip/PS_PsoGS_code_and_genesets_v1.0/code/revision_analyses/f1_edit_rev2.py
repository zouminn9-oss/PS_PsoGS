# -*- coding: utf-8 -*-
"""Revision 2: fold the selection-matched null, the incremental-value control and the
rebuilt figures into the CCID manuscript."""
import docx, json, copy
from docx.text.paragraph import Paragraph
SRC='01_CCID_Manuscript_REV1.docx'; DST='01_CCID_Manuscript_REV2.docx'
d=docx.Document(SRC); P=d.paragraphs; log=[]

def setr(pi,ri,t,label):
    r=P[pi].runs[ri]; log.append({'paragraph':pi,'edit':label,'old':r.text,'new':t}); r.text=t
def sub(pi,old,new,label):
    for r in P[pi].runs:
        if old in r.text:
            log.append({'paragraph':pi,'edit':label,'old':old,'new':new})
            r.text=r.text.replace(old,new,1); return
    raise AssertionError('anchor not found in paragraph %d: %r'%(pi,old[:60]))

# ---------------------------------------------------------------- Results I: proper matched null
sub(62,
 "Because the interaction is defined as I=SD-S0, conditioning on a large or significant "
 "interaction selects for opposite signs even without context dependence; under the exact null "
 "a comparably selected set, the highest |I| quintile, is already 76.1% discordant. The "
 "observed 86.2% is therefore read against that conditional baseline, while the unconditional "
 "genome-wide comparison above carries the primary evidence.",
 "Because the interaction is defined as I=SD-S0, conditioning on a significant interaction "
 "selects for opposite signs even without context dependence, so this percentage was calibrated "
 "against a null built from the same selection rule. Applying the identical selection to all 400 "
 "label assignments left no selected genes at all in 360 of them; among the 40 assignments that "
 "did yield a selection, the reversal share averaged 68.2% with a 2.5th-97.5th percentile range "
 "of 43.3-86.2%. The observed share is therefore at the top of, but not separable from, its "
 "matched null (exact P=0.10). What the null does separate decisively is the size of the "
 "selection: the observed cross-species interaction set exceeded every permutation except the "
 "observed labelling itself (exact P=0.005, null mean 116 genes). The informative statement is "
 "consequently that this many genes show cross-species context dependence at all, together with "
 "the unconditional genome-wide comparison above; the reversal share within the selected set is "
 "reported descriptively.",
 'Results I: 86.2% calibrated against a selection-matched null; selection size identified as the decisive statistic')

# ---------------------------------------------------------------- Results II: incremental value
anchor=P[71]
new_p=anchor.insert_paragraph_before(''); new_p.style=P[70].style
txt=("A matched-control analysis then asked whether the mouse disease-context selection added "
 "information beyond the human lesional evidence that also defines SEP. For every SEP member we "
 "drew a control gene of the same lesional direction, closely matched on lesional effect size and "
 "average expression, from genes that were lesion-significant in discovery but carried no mouse "
 "selection; 200 such sets were built and matched closely (mean absolute lesional effect 0.369 "
 "versus 0.372 for SEP; mean expression 7.394 versus 7.398). SEP exceeded all 200 matched sets on "
 "the paired lesional effect in GSE30999 (0.0741 versus 0.0691, SD 0.0003) and on the separation "
 "between treated and placebo lesions in GSE117468 (-0.0710 versus -0.0681, SD 0.0003; empirical "
 "P=0.005 for each), and also on the paired psoriasis effect in GSE121212. The same comparison "
 "marks the boundary: every matched set separated psoriasis from ordinary atopic dermatitis more "
 "sharply than SEP did. Cross-species disease-context selection therefore adds measurable "
 "information about plaque state and its response to treatment, and none about disease identity.")
r=new_p.add_run(txt)
try:
    s=P[70].runs[0]; r.font.name=s.font.name; r.font.size=s.font.size
except Exception: pass
log.append({'paragraph':'new (after 70)','edit':'Results II: incremental-value control added','old':'','new':txt})
P=d.paragraphs   # indices below shift by one

# ---------------------------------------------------------------- Methods
sub(43+0,
 "Two thousand expression- and detection-matched random signatures per cohort were generated "
 "without phenotype labels.",
 "Two thousand expression- and detection-matched random signatures per cohort were generated "
 "without phenotype labels. To separate the contribution of the mouse selection from the human "
 "lesional evidence, 200 further control sets were matched gene-for-gene to SEP on lesional "
 "direction, absolute lesional effect and average expression by nearest-neighbour assignment "
 "without replacement, drawn only from genes that were lesion-significant in discovery and absent "
 "from Core; these were scored identically and compared with SEP by empirical P values. The "
 "GSE121212 arm of that comparison used a symbol-mapped count matrix and is internally consistent "
 "across sets rather than numerically equal to the frozen cohort statistics.",
 'Methods: matched-control design specified')

sub(57,
 "The mouse factorial geometry was calibrated against an exact null obtained by complete "
 "enumeration: all 400 assignments of chronic-restraint-stress labels within the IMQ-negative and "
 "IMQ-positive strata (C(6,3) x C(6,3)) were refitted, so the reported permutation P values are "
 "exact and no value below 1/400=0.0025 is attainable in this design.",
 "The mouse factorial geometry was calibrated against an exact null obtained by complete "
 "enumeration: all 400 assignments of chronic-restraint-stress labels within the IMQ-negative and "
 "IMQ-positive strata (C(6,3) x C(6,3)) were refitted, so the reported permutation P values are "
 "exact and no value below 1/400=0.0025 is attainable in this design. Selection-dependent "
 "percentages were calibrated by applying the identical Core and interaction selection rule to "
 "every permutation. Because the frozen quasi-likelihood fit cannot be repeated 400 times within "
 "the archived environment, that calibration used a moderated-variance linear model applied "
 "identically to the observed labels and to every permutation; on the observed labels it returned "
 "3,746 selected genes with 85.8% reversal against the frozen values of 4,085 and 86.2%, so "
 "observed and null are compared on the same footing.",
 'Methods: selection-matched null and its pipeline stated')

# ---------------------------------------------------------------- Discussion
sub(90,
 "Matched random sets and leave-one-gene-out analyses support score stability, but this study did "
 "not complete the prespecified comparisons with general inflammation, interferon, proliferation, "
 "tissue-damage and technical-stress programs.",
 "Matched random sets and leave-one-gene-out analyses support score stability, and a control "
 "matched gene-for-gene on human lesional effect shows where the cross-species layer contributes: "
 "SEP exceeded every matched set on lesional magnitude and on treatment separation, and no matched "
 "set on the separation between psoriasis and ordinary atopic dermatitis.",
 'Discussion: incremental-value result replaces the missing-comparator statement')

sub(94,
 "The absence of completed generic-inflammation comparator analyses limits claims of incremental "
 "specificity, and the atopic-dermatitis comparison covers a restricted disease range.",
 "The matched-control comparison places the contribution in plaque state and treatment response "
 "rather than in disease discrimination, and the atopic-dermatitis comparison covers a restricted "
 "disease range; comparisons with dedicated interferon, proliferation and tissue-damage programs "
 "remain to be made.",
 'Limitations: specificity statement replaced by the measured result')

# ---------------------------------------------------------------- Abstract
sub(17,
 "A 2,716-gene direction-concordant lesion program (SEP) increased in two independent paired "
 "psoriasis cohorts of 81 and 27 patients; 1,589 genes met direction-and-FDR replication in both.",
 "A 2,716-gene direction-concordant lesion program (SEP) increased in two independent paired "
 "psoriasis cohorts of 81 and 27 patients; 1,589 genes met direction-and-FDR replication in both. "
 "Against 200 control sets matched gene-for-gene on human lesional effect, SEP was larger in "
 "lesions and separated treated from placebo lesions more strongly (empirical P=0.005 each), but "
 "separated psoriasis from atopic dermatitis less well.",
 'Abstract: incremental-value result added')

sub(17,
 "Reversal increased with expression level, and the relationship between the two stress effects "
 "was invariant to library-scaling normalization.",
 "Reversal increased with expression and was invariant to library-scaling normalization.",
 'Abstract: trimmed to the journal word limit')

# ---------------------------------------------------------------- Figure legends
sub(162,
 "Figure 1. Psoriasiform inflammation redirects the cutaneous transcriptional response to chronic stress.",
 "Figure 1. Inflammation redirects the cutaneous transcriptional response to chronic stress.",
 'Figure 1 legend: title aligned with the rebuilt figure')
sub(162,
 "The panels show that inflamed skin can invert, amplify or buffer gene-level stress responses;",
 "(D) Exact null distributions of the genome-wide sign-discordance fraction and of the S0-SD rank "
 "correlation over all 400 CRS-label assignments, with observed values marked. (E) Sign discordance "
 "by expression decile, and the same statistic under median-centred, upper-quartile and "
 "trimmed-mean library offsets; the S0-SD correlation is unchanged by any of them. (F) "
 "Selection-matched null for the cross-species interaction set: the number of selected genes, and "
 "the reversal share within the selection among permutations that yield one. The panels show that "
 "inflamed skin can invert, amplify or buffer gene-level stress responses;",
 'Figure 1 legend: new panels D-F described')
sub(164,
 "(C) Within-donor fibroblast SEP effects in eight PP-PN pairs.",
 "(C) Within-donor fibroblast and keratinocyte SEP effects, and the direct within-donor contrast "
 "between the two lineages in the eight donors in which both were eligible.",
 'Figure 3 legend: panel C updated for the rebuilt panel')

# word counts
body=[p.text for p in d.paragraphs[22:115]]
words=sum(len(t.split()) for t in body)
abs_w=sum(len(d.paragraphs[i].text.split()) for i in (15,16,17,18))
setr(6,1,f"Abstract {abs_w}; main text {words}",'title-page word counts refreshed')
d.save(DST)
json.dump(log,open('revision_log_rev2.json','w'),indent=1,ensure_ascii=False)
print('edits',len(log),'| abstract',abs_w,'| main text',words)
