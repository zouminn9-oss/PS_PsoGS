import pandas as pd, numpy as np, itertools
from scipy import stats
U='/mnt/user-data/uploads/PS_PsoGS'
lc=pd.read_csv(U+'/results/stage02/factorial_edger/gse212126_TMM_logCPM.tsv',sep='\t')
des=pd.read_csv(U+'/results/stage02/gse212126_design_matrix.tsv',sep='\t')
M=lc.set_index('gene_id')[des.srr.tolist()].values
crs=des.CRS.values.astype(bool); imq=des.IMQ.values.astype(bool)
idx_neg=np.where(~imq)[0]; idx_pos=np.where(imq)[0]
expr=M.mean(1); top_decile=expr>=np.percentile(expr,90)

def stat(lab):
    a=~imq;b=imq
    S0=M[:,a&lab].mean(1)-M[:,a&~lab].mean(1); SD=M[:,b&lab].mean(1)-M[:,b&~lab].mean(1)
    I=SD-S0; disc=np.sign(S0)*np.sign(SD)<0
    q=np.abs(I)>=np.percentile(np.abs(I),80)
    return disc.mean(), disc[q].mean(), disc[top_decile].mean()

o=stat(crs)
combs=list(itertools.combinations(range(6),3)); null=[]
for cn in combs:
    for cp in combs:
        lab=np.zeros(12,bool); lab[idx_neg[list(cn)]]=True; lab[idx_pos[list(cp)]]=True
        null.append(stat(lab))
null=np.array(null)
names=['discordance: all genes','discordance: top |I| quintile (self-defined per permutation)','discordance: top expression decile']
print('Exact null over 400 label assignments:')
for i,nm in enumerate(names):
    v=null[:,i]; p=(v>=o[i]).mean()
    print('  %-58s observed=%.4f  null mean=%.4f  null 97.5%%=%.4f  exact P=%.4f (%d/400)'%(nm,o[i],v.mean(),np.percentile(v,97.5),p,int((v>=o[i]).sum())))
