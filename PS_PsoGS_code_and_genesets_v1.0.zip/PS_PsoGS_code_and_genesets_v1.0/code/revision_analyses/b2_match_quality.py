"""Match-quality diagnostic + nearest-neighbour matched variant (tighter control)."""
import pandas as pd, numpy as np
from scipy import stats
rng=np.random.default_rng(7)
U='/mnt/user-data/uploads/PS_PsoGS'
sep=pd.read_csv(U+'/genesets/SEP_v1.0.tsv',sep='\t')
core=pd.read_csv(U+'/genesets/PS_PsoGS_Core_v1.0.tsv',sep='\t')
H=pd.read_csv(U+'/results/stage02/gse13355/gse13355_H_paired_all_genes.tsv',sep='\t').dropna(subset=['entrez_id','logFC','AveExpr'])
H['entrez_id']=H.entrez_id.astype(int); hm=H.set_index('entrez_id')
core_e=set(core.selected_human_entrez_id.dropna().astype(int))
s=sep[['selected_human_entrez_id','sep_direction']].dropna(); s['e']=s.selected_human_entrez_id.astype(int)
s=s[s.e.isin(hm.index)]
s['absH']=hm.loc[s.e,'logFC'].abs().values; s['ave']=hm.loc[s.e,'AveExpr'].values
s['sign']=np.sign(hm.loc[s.e,'logFC'].values)
pool=H[(H.FDR<0.05)&(~H.entrez_id.isin(core_e))].copy()
pool['absH']=pool.logFC.abs(); pool['ave']=pool.AveExpr; pool['sign']=np.sign(pool.logFC)
print('SEP  |H| mean %.4f  median %.4f | AveExpr mean %.3f'%(s.absH.mean(),s.absH.median(),s.ave.mean()))
print('pool |H| mean %.4f  median %.4f | AveExpr mean %.3f'%(pool.absH.mean(),pool.absH.median(),pool.ave.mean()))

# ---- nearest-neighbour matching on (|H|, AveExpr) within sign, without replacement
def nn_match(seed):
    r=np.random.default_rng(seed); out={1:[],-1:[]}
    for sg in (1,-1):
        P=pool[pool['sign']==sg]
        pv=np.c_[P.absH.values, P.ave.values/3.0]     # scale AveExpr so both matter
        used=np.zeros(len(P),bool); ids=P.entrez_id.values
        S=s[s['sign']==sg].sample(frac=1,random_state=int(r.integers(1e6)))
        for a,e in zip(S.absH.values, S.ave.values):
            d=np.abs(pv[:,0]-a)+np.abs(pv[:,1]-e/3.0); d[used]=np.inf
            j=int(np.argmin(d))
            if np.isfinite(d[j]): used[j]=True; out[sg].append(ids[j])
    return set(out[1]),set(out[-1])

sets=[nn_match(i) for i in range(100)]
def stat(ids):
    sub=hm.loc[list(ids)]
    return sub.logFC.abs().mean(), sub.AveExpr.mean()
a0,e0=stat(set(s.e)); print('\nSEP            |H| %.4f AveExpr %.3f'%(a0,e0))
aa=np.array([stat(a|b) for a,b in sets])
print('NN controls    |H| %.4f (sd %.4f) AveExpr %.3f'%(aa[:,0].mean(),aa[:,0].std(),aa[:,1].mean()))

# ---- re-run the three axes with the NN-matched controls
M=pd.read_csv(U+'/results/stage03/matrices/gse30999_gcrma_entrez_gene_matrix.tsv.gz',sep='\t',index_col=0)
R=M.rank(axis=0,method='average').values/(M.shape[0]+1); idx=M.index.astype(int).values
ps=pd.read_csv(U+'/results/stage03/scores/paired_scores.tsv',sep='\t'); p30=ps[ps.dataset_id=='GSE30999']
def d30(up,dn):
    u=np.isin(idx,list(up)); d=np.isin(idx,list(dn))
    if u.sum()<20 or d.sum()<20: return np.nan
    v=pd.Series(R[u].mean(0)-R[d].mean(0),index=M.columns)
    return (v[p30.lesional_sample.values].values-v[p30.nonlesional_sample.values].values).mean()
sep_up=set(s.loc[s['sign']>0,'e']); sep_dn=set(s.loc[s['sign']<0,'e'])
o=d30(sep_up,sep_dn); c=np.array([d30(a,b) for a,b in sets])
print('\nGSE30999 lesional effect: SEP %.5f | NN controls %.5f (sd %.5f) |控制集中超过SEP的比例 %.3f'
      %(o,np.nanmean(c),np.nanstd(c,ddof=1),(c>=o).mean()))

T=pd.read_csv(U+'/results/stage07/gse117468_gene_median_gcrma.tsv.gz',sep='\t',index_col=0)
meta=pd.read_csv(U+'/results/stage07/gse117468_sample_scores.tsv',sep='\t')
T=T[[c_ for c_ in T.columns if c_ in set(meta.sample_id)]]
RT=T.rank(axis=0,method='average').values/(T.shape[0]+1); tidx=T.index.astype(int).values
def tgap(up,dn):
    u=np.isin(tidx,list(up)); d=np.isin(tidx,list(dn))
    if u.sum()<20 or d.sum()<20: return np.nan
    v=pd.Series(RT[u].mean(0)-RT[d].mean(0),index=T.columns)
    m=meta[meta.sample_id.isin(v.index)].copy(); m['v']=v[m.sample_id].values
    m=m[m.tissue=='lesional skin']
    w=m.pivot_table(index=['patient_id','treatment'],columns='visit',values='v').dropna(subset=['BL','W12'])
    w['d']=w['W12']-w['BL']; w=w.reset_index()
    return w[w.treatment!='Placebo'].d.mean()-w[w.treatment=='Placebo'].d.mean()
ot=tgap(sep_up,sep_dn); ct=np.array([tgap(a,b) for a,b in sets])
print('GSE117468 active-minus-placebo: SEP %.5f | NN controls %.5f (sd %.5f) | 控制集更强的比例 %.3f'
      %(ot,np.nanmean(ct),np.nanstd(ct,ddof=1),(ct<=ot).mean()))
