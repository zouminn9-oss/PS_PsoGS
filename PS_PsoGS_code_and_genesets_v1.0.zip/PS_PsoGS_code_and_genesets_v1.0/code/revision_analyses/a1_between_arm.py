import pandas as pd, numpy as np, itertools, json
from scipy import stats
def bh(p):
    p=np.asarray(p,float); n=len(p); o=np.argsort(p); r=np.empty(n)
    q=p[o]*n/(np.arange(n)+1); q=np.minimum.accumulate(q[::-1])[::-1]
    r[o]=np.minimum(q,1); return r
U='/mnt/user-data/uploads/PS_PsoGS'
s=pd.read_csv(U+'/results/stage07/gse117468_sample_scores.tsv',sep='\t')

def paired_change(tissue,visit='W12'):
    d=s[(s.tissue==tissue)&(s.visit.isin(['BL',visit]))]
    w=d.pivot_table(index=['patient_id','treatment'],columns='visit',values='sep_score',aggfunc='mean')
    w=w.dropna(subset=['BL',visit])
    w['delta']=w[visit]-w['BL']
    return w.reset_index()

res={}
for tissue in ['lesional skin','non-lesional skin']:
    w=paired_change(tissue)
    print('==',tissue,'n per arm:'); print(w.treatment.value_counts().to_string())
    # within-arm (reproduce manuscript)
    rows=[]
    for arm,g in w.groupby('treatment'):
        x=g.delta.values
        t,p=stats.ttest_1samp(x,0)
        try: wp=stats.wilcoxon(x).pvalue
        except Exception: wp=np.nan
        ci=stats.t.interval(0.95,len(x)-1,loc=x.mean(),scale=stats.sem(x))
        rows.append(dict(tissue=tissue,arm=arm,n=len(x),mean=x.mean(),ci_lo=ci[0],ci_hi=ci[1],t_p=p,wilcoxon_p=wp))
    within=pd.DataFrame(rows)
    # between-arm vs placebo
    pl=w[w.treatment=='Placebo'].delta.values
    rows2=[]
    for arm in ['Brodalumab 140 mg Q2W','Brodalumab 210 mg Q2W','Ustekinumab']:
        x=w[w.treatment==arm].delta.values
        t,p=stats.ttest_ind(x,pl,equal_var=False)
        u,pu=stats.mannwhitneyu(x,pl,alternative='two-sided')
        # Hedges g (unpaired)
        n1,n2=len(x),len(pl); sp=np.sqrt(((n1-1)*x.var(ddof=1)+(n2-1)*pl.var(ddof=1))/(n1+n2-2))
        d=(x.mean()-pl.mean())/sp; J=1-3/(4*(n1+n2)-9); g=d*J
        se=np.sqrt(x.var(ddof=1)/n1+pl.var(ddof=1)/n2)
        df=(x.var(ddof=1)/n1+pl.var(ddof=1)/n2)**2/((x.var(ddof=1)/n1)**2/(n1-1)+(pl.var(ddof=1)/n2)**2/(n2-1))
        tc=stats.t.ppf(0.975,df); diff=x.mean()-pl.mean()
        rows2.append(dict(tissue=tissue,arm=arm,n_arm=n1,n_placebo=n2,
                          mean_arm=x.mean(),mean_placebo=pl.mean(),diff=diff,
                          ci_lo=diff-tc*se,ci_hi=diff+tc*se,welch_p=p,mwu_p=pu,hedges_g=g))
    between=pd.DataFrame(rows2)
    
    between['welch_fdr_bh']=bh(between.welch_p.values)
    between['mwu_fdr_bh']=bh(between.mwu_p.values)
    res[tissue]=(within,between)
    print(within.to_string(index=False)); print(between.to_string(index=False)); print()

# pooled active vs placebo, lesional
w=paired_change('lesional skin')
act=w[w.treatment!='Placebo'].delta.values; pl=w[w.treatment=='Placebo'].delta.values
t,p=stats.ttest_ind(act,pl,equal_var=False); u,pu=stats.mannwhitneyu(act,pl,alternative='two-sided')
print('POOLED active(n=%d) vs placebo(n=%d): diff=%.5f Welch P=%.3g MWU P=%.3g'%(len(act),len(pl),act.mean()-pl.mean(),p,pu))

out=pd.concat([res[t][1] for t in res])
out.to_csv('gse117468_between_arm_tests.tsv',sep='\t',index=False)
pd.concat([res[t][0] for t in res]).to_csv('gse117468_within_arm_tests.tsv',sep='\t',index=False)
