"""Final incremental-value control with nearest-neighbour |H|/expression matching."""
import pandas as pd, numpy as np, json
U='/mnt/user-data/uploads/PS_PsoGS'
exec(open('b2_match_quality.py').read().split("# ---- re-run")[0])   # reuse matching code
sets=[nn_match(i) for i in range(200)]
sep_up=set(s.loc[s['sign']>0,'e']); sep_dn=set(s.loc[s['sign']<0,'e'])

def rk(m): return m.rank(axis=0,method='average').values/(m.shape[0]+1)
def dirscore(R,idx,up,dn):
    u=np.isin(idx,list(up)); d=np.isin(idx,list(dn))
    if u.sum()<20 or d.sum()<20: return None
    return R[u].mean(0)-R[d].mean(0)

out={}
# axis 1 ---------------------------------------------------------------------
M=pd.read_csv(U+'/results/stage03/matrices/gse30999_gcrma_entrez_gene_matrix.tsv.gz',sep='\t',index_col=0)
R=rk(M); idx=M.index.astype(int).values
ps=pd.read_csv(U+'/results/stage03/scores/paired_scores.tsv',sep='\t'); p30=ps[ps.dataset_id=='GSE30999']
def f1(up,dn):
    v=dirscore(R,idx,up,dn)
    if v is None: return np.nan
    v=pd.Series(v,index=M.columns)
    return (v[p30.lesional_sample.values].values-v[p30.nonlesional_sample.values].values).mean()
out['GSE30999 lesional effect (81 pairs)']=(f1(sep_up,sep_dn),[f1(a,b) for a,b in sets],'higher')

# axis 2 ---------------------------------------------------------------------
G=pd.read_csv(U+'/data/raw/validation/GSE121212/GSE121212_readcount.txt.gz',sep='\t',index_col=0)
sym=H.dropna(subset=['gene_symbol']).drop_duplicates('gene_symbol').set_index('gene_symbol').entrez_id
G=G[G.index.isin(sym.index)]; gidx=sym.loc[G.index].values; RG=rk(G)
sp=pd.read_csv(U+'/results/stage03/specificity/gse121212_pso_ad_paired_scores.tsv',sep='\t')
def f2(up,dn,grp):
    v=dirscore(RG,gidx,up,dn)
    if v is None: return np.nan
    v=pd.Series(v,index=G.columns); g=sp[sp.group_id==grp]
    return (v[g.lesional_sample.values].values-v[g.nonlesional_sample.values].values).mean()
out['GSE121212 psoriasis effect (27 pairs)']=(f2(sep_up,sep_dn,'PSO_PRIMARY'),
    [f2(a,b,'PSO_PRIMARY') for a,b in sets],'higher')
gap=lambda u,d: f2(u,d,'PSO_PRIMARY')-f2(u,d,'AD_ORDINARY')
out['GSE121212 psoriasis minus ordinary AD']=(gap(sep_up,sep_dn),[gap(a,b) for a,b in sets],'higher')

# axis 3 ---------------------------------------------------------------------
T=pd.read_csv(U+'/results/stage07/gse117468_gene_median_gcrma.tsv.gz',sep='\t',index_col=0)
meta=pd.read_csv(U+'/results/stage07/gse117468_sample_scores.tsv',sep='\t')
T=T[[c for c in T.columns if c in set(meta.sample_id)]]
RT=rk(T); tidx=T.index.astype(int).values
def f3(up,dn):
    v=dirscore(RT,tidx,up,dn)
    if v is None: return np.nan
    v=pd.Series(v,index=T.columns); m=meta[meta.sample_id.isin(v.index)].copy()
    m['v']=v[m.sample_id].values; m=m[m.tissue=='lesional skin']
    w=m.pivot_table(index=['patient_id','treatment'],columns='visit',values='v').dropna(subset=['BL','W12'])
    w['d']=w['W12']-w['BL']; w=w.reset_index()
    return w[w.treatment!='Placebo'].d.mean()-w[w.treatment=='Placebo'].d.mean()
out['GSE117468 active-minus-placebo change']=(f3(sep_up,sep_dn),[f3(a,b) for a,b in sets],'lower')

rows=[]
print('\n%-42s %9s %9s %8s %9s %8s'%('axis','SEP','ctrl mean','ctrl sd','z','emp. P'))
for k,(o,c,better) in out.items():
    c=np.array([x for x in c if np.isfinite(x)])
    n_beat=(c>=o).sum() if better=='higher' else (c<=o).sum()
    z=(o-c.mean())/c.std(ddof=1)
    p=(n_beat+1)/(len(c)+1)
    print('%-42s %9.5f %9.5f %8.5f %9.1f %8.4f'%(k,o,c.mean(),c.std(ddof=1),z,p))
    rows.append(dict(axis=k,direction_favouring_SEP=better,sep=o,control_mean=c.mean(),
                     control_sd=c.std(ddof=1),control_min=c.min(),control_max=c.max(),
                     z_vs_controls=z,n_control_sets=len(c),n_controls_beating_sep=int(n_beat),
                     empirical_p=p))
pd.DataFrame(rows).to_csv('incremental_value_nn_summary.tsv',sep='\t',index=False)
pd.DataFrame({k:pd.Series(v[1]) for k,v in out.items()}).to_csv('incremental_value_nn_draws.tsv',sep='\t',index=False)
print('\nmatch quality: SEP |H| %.4f AveExpr %.3f'%(hm.loc[list(sep_up|sep_dn)].logFC.abs().mean(),
                                                   hm.loc[list(sep_up|sep_dn)].AveExpr.mean()))
q=np.array([[hm.loc[list(a|b)].logFC.abs().mean(),hm.loc[list(a|b)].AveExpr.mean()] for a,b in sets])
print('              ctrl |H| %.4f (sd %.4f) AveExpr %.3f (sd %.4f)'%(q[:,0].mean(),q[:,0].std(ddof=1),q[:,1].mean(),q[:,1].std(ddof=1)))
