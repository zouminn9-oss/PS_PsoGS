"""Compose Figure 1 and Figure 3 revision 1 using the project's own layout rules."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from reportlab.pdfgen import canvas as pdf_canvas

PREV=Path('/mnt/user-data/uploads/PS_PsoGS/figures/previews')
NEW=Path('newpanels'); OUT=Path('main_figures_rev1'); OUT.mkdir(exist_ok=True)
FIGURES={1:['1F','1G','1K','NEW:fig1d_null','NEW:fig1e_strata','NEW:fig1f_selnull'],
         3:['3A','3G','NEW:fig3h_rev1','3I','3K','3L']}
TITLES={1:'Inflammation redirects the cutaneous stress response',
        3:'The lesion program is carried by epidermal and dermal compartments'}
MASK={'1F':120,'1G':165,'1H':165,'1K':165,'2D':165,'3I':150}
def mask_h(pid): return 112 if pid.startswith('NEW:') else MASK.get(pid,112)
def font(size,bold=False):
    for p in ['/usr/share/fonts/truetype/liberation/LiberationSans-%s.ttf'%('Bold' if bold else 'Regular')]:
        if Path(p).exists(): return ImageFont.truetype(p,size)
    return ImageFont.load_default()
def load(pid):
    if pid.startswith('NEW:'): return Image.open(NEW/(pid[4:]+'.png')).convert('RGB')
    im=Image.open(PREV/f'fig{pid.lower()}.png').convert('RGB'); d=ImageDraw.Draw(im)
    if pid=='1F': d.rectangle((130,55,1260,185),fill='white')
    elif pid=='1G':
        d.rectangle((1450,215,1940,305),fill='white')
        d.text((1475,235),'Response class',fill='#17202A',font=font(38,True))
    return im
def build(number,ids):
    gap,top,cw=42,118,2102
    prepared=[(pid,load(pid)) for pid in ids]
    rows=[max(im.height*cw/im.width for _,im in prepared[i:i+2]) for i in range(0,len(prepared),2)]
    W=cw*2+gap*3; H=round(top+sum(rows)+gap*(len(rows)+1))
    cv=Image.new('RGB',(W,H),'white'); dr=ImageDraw.Draw(cv)
    dr.text((gap,28),f'Figure {number} | {TITLES[number]}',fill='#111111',font=font(48,True))
    for i,(pid,im) in enumerate(prepared):
        r,c=divmod(i,2); x=gap+c*(cw+gap); y=round(top+sum(rows[:r])+gap*r)
        nh=round(im.height*cw/im.width)
        if im.width!=cw: im=im.resize((cw,nh),Image.Resampling.LANCZOS)
        cv.paste(im,(x,y))
        dr.rectangle((x,y,x+cw,y+mask_h(pid)),fill='white')
        dr.text((x+22,y+22),chr(65+i),fill='#111111',font=font(46,True))
    png=OUT/f'Figure_{number}_REV1.png'; cv.save(png,dpi=(300,300),optimize=True)
    wpt,hpt=cv.width*72/300,cv.height*72/300
    doc=pdf_canvas.Canvas(str(OUT/f'Figure_{number}_REV1.pdf'),pagesize=(wpt,hpt),pageCompression=1)
    doc.drawImage(str(png),0,0,width=wpt,height=hpt,preserveAspectRatio=True,mask='auto'); doc.showPage(); doc.save()
    print('built Figure',number,cv.size)
for n,ids in FIGURES.items(): build(n,ids)
