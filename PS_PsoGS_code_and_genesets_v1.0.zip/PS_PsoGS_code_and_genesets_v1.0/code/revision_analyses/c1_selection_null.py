"""Selection-matched exact null for the reversal percentage among interaction-significant
Core genes. R/edgeR is unavailable here, so a limma-style moderated-t pipeline is applied
identically to the observed labels and to all 400 permutations; observed and null are
therefore comparable to each other, not to the frozen edgeR numbers."""
import pandas as pd, numpy as np, itertools, json
from scipy import stats, special, optimize
U='/mnt/user-data/uploads/PS_PsoGS'

lc=pd.read_csv(U+'/results/stage02/factorial_edger/gse212126_TMM_logCPM.tsv',sep='\t')
des=pd.read_csv(U+'/results/stage02/gse212126_design_matrix.tsv',sep='\t')
Y=lc.set_index('gene_id')[des.srr.tolist()].values
genes=lc.gene_id.values
imq=des.IMQ.values.astype(bool); crs_obs=des.CRS.values.astype(bool)

# fixed human side: H FDR<0.05 mapped onto mouse genes through the frozen orthology ledger
H=pd.read_csv(U+'/results/stage02/gse13355/gse13355_H_paired_all_genes.tsv',sep='\t')
H=H.dropna(subset=['entrez_id']); H['entrez_id']=H.entrez_id.astype(int)
orth=pd.read_csv(U+'/metadata/mouse_human_orthology_ensembl100_ledger.tsv.gz',sep='\t')
orth=orth[orth.analysis_join_status=='PASS_JOINED_H'].dropna(subset=['selected_human_entrez_id'])
orth['selected_human_entrez_id']=orth.selected_human_entrez_id.astype(int)
hsig=set(H.loc[H.FDR<0.05,'entrez_id'])
m2h=dict(zip(orth.mouse_gene_id_versioned, orth.selected_human_entrez_id))
human_ok=np.array([m2h.get(g) in hsig for g in genes])
print('genes %d | with reliable one2one human ortholog %d | of which H FDR<0.05 %d'
      %(len(genes), sum(g in m2h for g in genes), human_ok.sum()))

# ---- limma-style moderated t ------------------------------------------------
def trigamma_inv(x):
    f=lambda v: special.polygamma(1,v)-x
    return optimize.brentq(f,1e-8,1e8)

def fit(crs):
    g=(crs.astype(int)*2+imq.astype(int))          # 0 ctrl,1 imq,2 crs,3 crs+imq
    means=np.stack([Y[:,g==k].mean(1) for k in range(4)])
    ss=sum(((Y[:,g==k]-means[k][:,None])**2).sum(1) for k in range(4))
    d=Y.shape[1]-4
    s2=ss/d
    z=np.log(s2); e=z-special.digamma(d/2)+np.log(d/2)
    tgt=np.var(e,ddof=1)-special.polygamma(1,d/2)
    if tgt>0:
        d0=2*trigamma_inv(tgt); s02=np.exp(e.mean()+special.digamma(d0/2)-np.log(d0/2))
    else:
        d0=np.inf; s02=np.exp(e.mean())
    s2p=(d0*s02+d*s2)/(d0+d) if np.isfinite(d0) else np.full_like(s2,s02)
    dft=d0+d if np.isfinite(d0) else 1e6
    n=3.0
    S0=means[2]-means[0]; SD=means[3]-means[1]; I=SD-S0
    se_pair=np.sqrt(s2p*(2/n)); se_I=np.sqrt(s2p*(4/n))
    def p(c,se): return 2*stats.t.sf(np.abs(c)/se, dft)
    return S0,SD,I,p(S0,se_pair),p(SD,se_pair),p(I,se_I)

def bh(p):
    p=np.asarray(p,float); n=len(p); o=np.argsort(p); q=p[o]*n/(np.arange(n)+1)
    q=np.minimum.accumulate(q[::-1])[::-1]; r=np.empty(n); r[o]=np.minimum(q,1); return r

def selection_stats(crs):
    S0,SD,I,pS0,pSD,pI=fit(crs)
    fSD=bh(pSD); fI=bh(pI)
    core = human_ok & (fSD<0.05)                    # Core analogue
    sel  = core & (fI<0.05)                         # the manuscript's selection
    disc = np.sign(S0)*np.sign(SD)<0
    return dict(n_core=int(core.sum()), n_sel=int(sel.sum()),
                disc_sel=float(disc[sel].mean()) if sel.sum() else np.nan,
                disc_all=float(disc.mean()),
                n_I_sig=int((fI<0.05).sum()))

obs=selection_stats(crs_obs)
print('\nobserved labels, this pipeline:', json.dumps(obs))
print('frozen edgeR values for reference: Core 4,976 | Core+I 4,085 | reversal 86.2% | I FDR<0.05 10,660')

combs=list(itertools.combinations(range(6),3))
ineg=np.where(~imq)[0]; ipos=np.where(imq)[0]
rows=[]
for cn in combs:
    for cp in combs:
        lab=np.zeros(12,bool); lab[ineg[list(cn)]]=True; lab[ipos[list(cp)]]=True
        rows.append(selection_stats(lab))
null=pd.DataFrame(rows)
null.to_csv('mouse_selection_matched_null.tsv',sep='\t',index=False)

print('\nexact null over all 400 CRS-label assignments (same pipeline):')
for k,lab in [('disc_sel','reversal % among Core+I-significant genes'),
              ('disc_all','reversal % among all genes'),
              ('n_sel','number of Core+I-significant genes')]:
    v=null[k].dropna().values; o=obs[k]
    p=( (v>=o).sum()+0 )/len(v)
    print('  %-42s observed=%.4f  null mean=%.4f  null 2.5-97.5%%=[%.4f, %.4f]  exact P=%.4f'
          %(lab,o,v.mean(),np.percentile(v,2.5),np.percentile(v,97.5),p))
json.dump(obs,open('mouse_selection_matched_observed.json','w'),indent=1)
