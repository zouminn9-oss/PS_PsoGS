## Exact within-stratum permutation null for the CRS x IMQ factorial result (GSE212126)
## Run locally (edgeR 4.4.2 present in this project's environment). Runtime ~20-40 min.
##
## Why this is needed: the manuscript's reversal statistics are computed on the observed
## labels only. Two of them are selection-conditioned -- conditioning on a large |I| or on
## I FDR<0.05 mechanically enriches for opposite S0/SD signs, because I = SD - S0. This
## script recomputes the manuscript's OWN selection under every possible CRS label
## assignment, so the reported percentages can be quoted against a matched null.
##
## Design: 3 CRS vs 3 Control within IMQ-negative, 3 CRS+IMQ vs 3 IMQ within IMQ-positive.
## The exact permutation space is choose(6,3) x choose(6,3) = 400 assignments, so the
## smallest attainable exact P is 1/400 = 0.0025. Report that floor explicitly.

suppressPackageStartupMessages({library(edgeR)})

root    <- "."                                     # run from the project root
counts  <- read.delim(file.path(root,"results/stage02/counts/gse212126_gene_counts_frozen.tsv"),
                      check.names = FALSE)
design  <- read.delim(file.path(root,"results/stage02/gse212126_design_matrix.tsv"),
                      check.names = FALSE)

gene_id <- counts[[1]]
mat     <- as.matrix(counts[, design$srr, drop = FALSE])
rownames(mat) <- gene_id
imq     <- as.logical(design$IMQ)
crs_obs <- as.logical(design$CRS)

fit_once <- function(crs_lab) {
  d   <- DGEList(counts = mat)
  des <- model.matrix(~ crs_lab * imq)
  keep <- filterByExpr(d, design = des)
  d   <- d[keep, , keep.lib.sizes = FALSE]
  d   <- normLibSizes(d)
  des <- model.matrix(~ crs_lab * imq)
  d   <- estimateDisp(d, des, robust = TRUE)
  f   <- glmQLFit(d, des, robust = TRUE)
  S0  <- glmQLFTest(f, coef = 2)                  # CRS effect, IMQ-negative
  I   <- glmQLFTest(f, coef = 4)                  # CRS:IMQ interaction
  s0  <- topTags(S0, n = Inf, sort.by = "none")$table
  ii  <- topTags(I , n = Inf, sort.by = "none")$table
  sd  <- s0$logFC + ii$logFC                      # SD = S0 + I
  list(S0 = s0$logFC, SD = sd, I = ii$logFC, I_FDR = ii$FDR,
       S0_FDR = s0$FDR, n = nrow(s0))
}

summarise <- function(r) {
  disc <- sign(r$S0) * sign(r$SD) < 0
  sel  <- r$I_FDR < 0.05
  topq <- abs(r$I) >= quantile(abs(r$I), 0.80)
  c(n_genes          = r$n,
    disc_all         = mean(disc),
    pearson          = cor(r$S0, r$SD),
    spearman         = cor(r$S0, r$SD, method = "spearman"),
    n_I_sig          = sum(sel),
    disc_I_sig       = mean(disc[sel]),           # <- the manuscript's 86.2% analogue
    disc_top_absI    = mean(disc[topq]))
}

obs <- summarise(fit_once(crs_obs))

combs <- combn(6, 3, simplify = FALSE)
ineg  <- which(!imq); ipos <- which(imq)
null  <- matrix(NA_real_, nrow = 400, ncol = length(obs),
                dimnames = list(NULL, names(obs)))
k <- 0
for (cn in combs) for (cp in combs) {
  k <- k + 1
  lab <- rep(FALSE, 12); lab[ineg[cn]] <- TRUE; lab[ipos[cp]] <- TRUE
  null[k, ] <- summarise(fit_once(lab))
  if (k %% 25 == 0) message(sprintf("  %d / 400", k))
}

exact_p <- sapply(names(obs), function(nm)
  if (nm %in% c("pearson","spearman")) mean(null[, nm] <= obs[nm])
  else                                  mean(null[, nm] >= obs[nm]))

out <- data.frame(statistic = names(obs), observed = as.numeric(obs),
                  null_mean = colMeans(null),
                  null_p2.5 = apply(null, 2, quantile, 0.025),
                  null_p97.5 = apply(null, 2, quantile, 0.975),
                  exact_p = as.numeric(exact_p),
                  exact_p_floor = 1/400)
dir.create(file.path(root,"results/referee_response"), showWarnings = FALSE, recursive = TRUE)
write.table(out,  file.path(root,"results/referee_response/mouse_exact_null_edger_summary.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)
write.table(null, file.path(root,"results/referee_response/mouse_exact_null_edger_draws.tsv"),
            sep = "\t", row.names = FALSE, quote = FALSE)
print(out)
