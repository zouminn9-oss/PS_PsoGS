"""|H|-matched incremental-value control: does mouse disease-context selection add
information beyond human lesional differential expression?"""
import pandas as pd, numpy as np
from scipy import stats
rng=np.random.default_rng(20260913)
U='/mnt/user-data/uploads/PS_PsoGS'
NSETS=200

sep=pd.read_csv(U+'/genesets/SEP_v1.0.tsv',sep='\t')
core=pd.read_csv(U+'/genesets/PS_PsoGS_Core_v1.0.tsv',sep='\t')
H=pd.read_csv(U+'/results/stage02/gse13355/gse13355_H_paired_all_genes.tsv',sep='\t')
H=H.dropna(subset=['entrez_id','logFC','AveExpr'])
H['entrez_id']=H.entrez_id.astype(int)

core_entrez=set(core.selected_human_entrez_id.dropna().astype(int))
sep_e=sep[['selected_human_entrez_id','human_gene_symbol','sep_direction','H_logFC']].dropna()
sep_e['selected_human_entrez_id']=sep_e.selected_human_entrez_id.astype(int)

# ---- matching pool: same human evidence, no mouse selection ------------------
pool=H[(H.FDR<0.05) & (~H.entrez_id.isin(core_entrez))].copy()
print('SEP %d | H-significant genes %d | matching pool (H-sig, not Core) %d'
      %(len(sep_e), (H.FDR<0.05).sum(), len(pool)))

hmap=H.set_index('entrez_id')
sep_e=sep_e[sep_e.selected_human_entrez_id.isin(hmap.index)]
sep_e['absH']=hmap.loc[sep_e.selected_human_entrez_id,'logFC'].abs().values
sep_e['ave'] =hmap.loc[sep_e.selected_human_entrez_id,'AveExpr'].values
sep_e['sign']=np.sign(hmap.loc[sep_e.selected_human_entrez_id,'logFC'].values)
pool['absH']=pool.logFC.abs(); pool['ave']=pool.AveExpr; pool['sign']=np.sign(pool.logFC)

allabs=np.r_[sep_e.absH.values,pool.absH.values]; allave=np.r_[sep_e.ave.values,pool.ave.values]
qa=np.quantile(allabs,np.linspace(0,1,11)); qe=np.quantile(allave,np.linspace(0,1,6))
def strat(df): return (np.digitize(df.absH,qa[1:-1]).astype(str)+'|'+
                       np.digitize(df.ave ,qe[1:-1]).astype(str)+'|'+df['sign'].astype(int).astype(str))
sep_e['stratum']=strat(sep_e); pool['stratum']=strat(pool)
bins={k:v.entrez_id.values for k,v in pool.groupby('stratum')}
need=sep_e.stratum.value_counts()
short={k:int(n) for k,n in need.items() if len(bins.get(k,[]))<n}
print('strata where the pool cannot cover SEP one-for-one:',len(short),
      '| SEP genes affected:',sum(short.values()))

def draw_set():
    out_up=[]; out_dn=[]
    for k,g in sep_e.groupby('stratum'):
        cand=bins.get(k,np.array([],int))
        if len(cand)==0: continue
        take=rng.choice(cand,size=min(len(g),len(cand)),replace=False)
        s=int(k.split('|')[-1])
        (out_up if s>0 else out_dn).extend(take.tolist())
    return set(out_up),set(out_dn)

control_sets=[draw_set() for _ in range(NSETS)]
sep_up=set(sep_e.loc[sep_e['sign']>0,'selected_human_entrez_id'])
sep_dn=set(sep_e.loc[sep_e['sign']<0,'selected_human_entrez_id'])
print('SEP UP/DOWN used %d/%d | mean control set size %.0f'
      %(len(sep_up),len(sep_dn),np.mean([len(a)+len(b) for a,b in control_sets])))

def ranks(mat):
    return mat.rank(axis=0,method='average').values/(mat.shape[0]+1)
def sc(R,index,up,dn):
    u=np.isin(index,list(up)); d=np.isin(index,list(dn))
    if u.sum()<20 or d.sum()<20: return None
    return R[u].mean(0)-R[d].mean(0)

results={}

# ================= axis 1: lesion magnitude, GSE30999 ========================
M=pd.read_csv(U+'/results/stage03/matrices/gse30999_gcrma_entrez_gene_matrix.tsv.gz',sep='\t',index_col=0)
R=ranks(M); idx=M.index.astype(int).values
ps=pd.read_csv(U+'/results/stage03/scores/paired_scores.tsv',sep='\t')
p30=ps[ps.dataset_id=='GSE30999']
def delta30(up,dn):
    s=sc(R,idx,up,dn)
    if s is None: return np.nan
    s=pd.Series(s,index=M.columns)
    return (s[p30.lesional_sample.values].values-s[p30.nonlesional_sample.values].values)
obs=delta30(sep_up,sep_dn); ctrl=np.array([np.nanmean(delta30(a,b)) for a,b in control_sets])
results['GSE30999 lesional effect']=(obs.mean(),ctrl)

# ================= axis 2: psoriasis-versus-AD separation, GSE121212 =========
G=pd.read_csv(U+'/data/raw/validation/GSE121212/GSE121212_readcount.txt.gz',sep='\t',index_col=0)
sym2ent=H.dropna(subset=['gene_symbol']).drop_duplicates('gene_symbol').set_index('gene_symbol').entrez_id
G=G[G.index.isin(sym2ent.index)]
gidx=sym2ent.loc[G.index].values
RG=ranks(G)
sp=pd.read_csv(U+'/results/stage03/specificity/gse121212_pso_ad_paired_scores.tsv',sep='\t')
def delta121(up,dn,group):
    s=sc(RG,gidx,up,dn)
    if s is None: return np.nan
    s=pd.Series(s,index=G.columns); g=sp[sp.group_id==group]
    return (s[g.lesional_sample.values].values-s[g.nonlesional_sample.values].values)
print('\nGSE121212 groups:',sp.group_id.value_counts().to_dict())
pso_obs=delta121(sep_up,sep_dn,'PSO_PRIMARY'); ad_obs=delta121(sep_up,sep_dn,'AD_ORDINARY')
obs_sep_gap=pso_obs.mean()-ad_obs.mean()
gap_ctrl=[]; pso_ctrl=[]
for a,b in control_sets:
    p_=delta121(a,b,'PSO_PRIMARY'); a_=delta121(a,b,'AD_ORDINARY')
    pso_ctrl.append(np.nanmean(p_)); gap_ctrl.append(np.nanmean(p_)-np.nanmean(a_))
results['GSE121212 psoriasis effect']=(pso_obs.mean(),np.array(pso_ctrl))
results['GSE121212 psoriasis minus ordinary AD']=(obs_sep_gap,np.array(gap_ctrl))

# ================= axis 3: treatment separation, GSE117468 ===================
T=pd.read_csv(U+'/results/stage07/gse117468_gene_median_gcrma.tsv.gz',sep='\t',index_col=0)
meta=pd.read_csv(U+'/results/stage07/gse117468_sample_scores.tsv',sep='\t')
T=T[[c for c in T.columns if c in set(meta.sample_id)]]
RT=ranks(T); tidx=T.index.astype(int).values
def treat_gap(up,dn):
    s=sc(RT,tidx,up,dn)
    if s is None: return np.nan
    s=pd.Series(s,index=T.columns)
    m=meta[meta.sample_id.isin(s.index)].copy(); m['v']=s[m.sample_id].values
    m=m[m.tissue=='lesional skin']
    w=m.pivot_table(index=['patient_id','treatment'],columns='visit',values='v').dropna(subset=['BL','W12'])
    w['d']=w['W12']-w['BL']; w=w.reset_index()
    act=w[w.treatment!='Placebo'].d.values; pl=w[w.treatment=='Placebo'].d.values
    return act.mean()-pl.mean()
obs_t=treat_gap(sep_up,sep_dn)
ctrl_t=np.array([treat_gap(a,b) for a,b in control_sets])
results['GSE117468 active-minus-placebo change']=(obs_t,ctrl_t)

# ================= report ====================================================
rows=[]
print('\n%-46s %10s %10s %10s %14s'%('axis','SEP','ctrl mean','ctrl sd','empirical P'))
for k,(o,c) in results.items():
    c=np.asarray(c,float); c=c[~np.isnan(c)]
    better=(c>=o).mean() if 'change' not in k else (c<=o).mean()   # treatment: more negative is better
    print('%-46s %10.5f %10.5f %10.5f %14.4f'%(k,o,c.mean(),c.std(ddof=1),(better*len(c)+1)/(len(c)+1)))
    rows.append(dict(axis=k,sep=o,control_mean=c.mean(),control_sd=c.std(ddof=1),
                     control_p2_5=np.percentile(c,2.5),control_p97_5=np.percentile(c,97.5),
                     n_control_sets=len(c),empirical_p=(better*len(c)+1)/(len(c)+1)))
pd.DataFrame(rows).to_csv('incremental_value_summary.tsv',sep='\t',index=False)
np.save('incremental_value_control_draws.npy',
        np.array([np.asarray(v[1],float) for v in results.values()]))
print('\nSEP psoriasis %.5f vs ordinary AD %.5f (gap %.5f)'%(pso_obs.mean(),ad_obs.mean(),obs_sep_gap))
