# -*- coding: utf-8 -*-
"""Apply the referee-response revisions to the CCID submission manuscript.
Only the paragraphs listed below are touched; formatting, superscript citation
runs, styles, line numbering and all other content are preserved."""
import docx, sys, json

SRC = 'work.docx'
DST = '01_CCID_Manuscript_REV1.docx'

d = docx.Document(SRC)
P = d.paragraphs
log = []

def set_run(pi, ri, new, label):
    r = P[pi].runs[ri]
    log.append({'paragraph': pi, 'run': ri, 'edit': label,
                'old': r.text, 'new': new})
    r.text = new

def sub_run(pi, ri, old, new, label):
    r = P[pi].runs[ri]
    assert old in r.text, f'paragraph {pi} run {ri}: anchor not found -> {old[:60]!r}'
    log.append({'paragraph': pi, 'run': ri, 'edit': label,
                'old': old, 'new': new})
    r.text = r.text.replace(old, new, 1)

# ---------------------------------------------------------------- Abstract
set_run(17, 1,
 "Across 18,484 mouse genes, 12,047 (65.2%) reversed the sign of the stress effect "
 "between non-inflamed and imiquimod-inflamed skin, against an exact permutation null "
 "centred at 50.0% (exact P=0.015 over all 400 possible label assignments; Spearman "
 "rho=-0.352, P=0.020). Reversal increased with expression level, and the relationship "
 "between the two stress effects was invariant to library-scaling normalization. A "
 "2,716-gene direction-concordant lesion program (SEP) increased in two independent "
 "paired psoriasis cohorts of 81 and 27 patients; 1,589 genes met direction-and-FDR "
 "replication in both. Donor-level single-cell analysis placed the program in both "
 "epidermal and dermal compartments, with the larger shift in keratinocytes (0.0556 "
 "across 11 pairs) than in fibroblasts (0.0252 across 8 pairs; within-donor difference "
 "-0.0333, P=0.0019); fibroblasts were carried forward for mechanistic follow-up. "
 "Endothelial JAG2-fibroblast NOTCH2 provided a focused expression-compatible hypothesis, "
 "and lesional SEP fell further during cytokine-targeted treatment than during placebo in "
 "every active arm (largest BH FDR=1.1x10^-4), with no comparable change in non-lesional skin.",
 'abstract Results: exact null replaces Pearson lead; keratinocyte effect added; between-arm result added')

set_run(18, 1,
 "Psoriasiform inflammation redirected rather than simply amplified the cutaneous response "
 "to chronic stress, and the linked human program is a reproducible, treatment-responsive "
 "readout of plaque state. It is not a measure of psychological stress.",
 'abstract Conclusion: boundary clauses consolidated to one')

# ---------------------------------------------------------------- Methods
sub_run(54, 0,
 "Mean differences and t-based 95% CIs accompanied Wilcoxon signed-rank tests with BH correction.",
 "Mean differences and t-based 95% CIs accompanied Wilcoxon signed-rank tests with BH "
 "correction. Treatment-group differences were then tested directly by comparing the same "
 "within-patient paired changes between each active arm and placebo using two-sided Welch t "
 "tests, Mann-Whitney U tests, unpaired Hedges g and BH correction within tissue.",
 'Methods: between-arm comparison specified')

sub_run(57, 0,
 "BH correction was applied within prespecified families.",
 "BH correction was applied within prespecified families. The mouse factorial geometry was "
 "calibrated against an exact null obtained by complete enumeration: all 400 assignments of "
 "chronic-restraint-stress labels within the IMQ-negative and IMQ-positive strata "
 "(C(6,3) x C(6,3)) were refitted, so the reported permutation P values are exact and no "
 "value below 1/400=0.0025 is attainable in this design. Sensitivity to library scaling was "
 "assessed by recomputing the same contrasts after median-centred, upper-quartile and "
 "30%-trimmed-mean library offsets. Lineage effects that were compared with one another were "
 "tested within the donors in which both lineages were eligible and paired.",
 'Methods: exact permutation null, normalization sensitivity, paired lineage contrast')

# ---------------------------------------------------------------- Results I
set_run(61, 0,
 "The two stress responses differed in more than statistical significance. Across all tested "
 "genes, 12,047 of 18,484 (65.2%) had opposite S0 and SD signs, and the two effects were "
 "negatively related (Spearman rho=-0.352; Pearson r=-0.237; Figure 1A). Because this design "
 "permits complete enumeration, those statistics were calibrated against an exact null: all "
 "400 possible assignments of CRS labels within the IMQ-negative and IMQ-positive strata give "
 "a null discordance of 50.0% (2.5th-97.5th percentile 36.4-63.6%) and a null correlation "
 "centred at zero. The observed discordance and rank correlation exceeded that null (exact "
 "P=0.015 and P=0.020). Two further properties separate this geometry from measurement noise. "
 "Discordance rose monotonically with expression, from 57.8% in the lowest to 70.4% in the "
 "highest expression decile, whereas count noise produces the opposite gradient. The "
 "relationship between S0 and SD was also invariant to per-library scaling, identical to four "
 "decimal places under median-centred, upper-quartile and trimmed-mean offsets, so a "
 "compositional difference between inflamed and non-inflamed skin cannot generate it. Only "
 "5,388 genes were significant in both contexts; 3,752 were significant only for S0 and 3,593 "
 "only for SD. A difference between normal and inflamed skin was therefore supported by the "
 "formal interaction and by calibrated effect geometry, not inferred from one contrast being "
 "significant while another was not.",
 'Results I: exact permutation null, expression gradient and normalization invariance replace uncalibrated correlation claim')

sub_run(62, 0,
 "Thus, IMQ-induced inflammation more often reorganized the direction of the stress-responsive "
 "transcriptome than altered the amplitude of an otherwise shared response.",
 "Because the interaction is defined as I=SD-S0, conditioning on a large or significant "
 "interaction selects for opposite signs even without context dependence; under the exact null "
 "a comparably selected set, the highest |I| quintile, is already 76.1% discordant. The "
 "observed 86.2% is therefore read against that conditional baseline, while the unconditional "
 "genome-wide comparison above carries the primary evidence. On both readings, IMQ-induced "
 "inflammation more often reorganized the direction of the stress-responsive transcriptome "
 "than altered the amplitude of an otherwise shared response.",
 'Results I: 86.2% quoted against its conditional null instead of chance')

sub_run(63, 0,
 "They illustrate rather than define the transcriptome-wide result.",
 "Selection by the largest absolute interaction favours the most extreme and least stable "
 "estimates, and KRT73 is a hair keratin whose expression tracks follicle cycle stage, which "
 "both depilation and restraint can alter. These panels therefore illustrate the response "
 "modes rather than define or quantify the transcriptome-wide result.",
 'Results I: selection rule and hair-cycle caveat stated for the representative panel')

# ---------------------------------------------------------------- Results III
set_run(71, 0,
 "Donor-level analysis places the lesion-associated program in both epidermal and dermal compartments",
 'Results III heading: reframed from fibroblast-only')

set_run(73, 0,
 "Paired effects varied across lineages (Figure 3B). Among lineages represented by at least six "
 "complete donor pairs and at least 20 cells per paired tissue, with a positive SEP effect and "
 "BH FDR<0.05, both keratinocytes and fibroblasts carried the program. Keratinocytes showed the "
 "larger absolute shift across 11 pairs (difference 0.05556, 95% CI 0.04101-0.07010; paired "
 "Hedges g=2.368; BH FDR=3.42x10^-5), and fibroblasts a smaller but equally consistent shift "
 "across eight pairs (0.02519, 0.01744-0.03294; paired Hedges g=2.414; P=1.18x10^-4; BH "
 "FDR=2.95x10^-4; Figure 3C). In the eight donors in which both lineages were eligible and "
 "paired, the direct within-donor contrast favoured keratinocytes (fibroblast minus "
 "keratinocyte -0.03326, 95% CI -0.04948 to -0.01704; paired t P=0.00186; Wilcoxon P=0.016; "
 "larger in keratinocytes in seven of eight donors), and the rank-based score gave the same "
 "result (-0.02202, -0.03224 to -0.01181; P=0.0014). The program is therefore carried by "
 "coordinated epidermal and dermal remodeling rather than by a single compartment. Fibroblasts "
 "were carried forward for mechanistic follow-up because the dermal compartment supports a "
 "directly testable vascular-stromal hypothesis and has defined comparator states in the "
 "psoriasis literature.",
 'Results III: formal within-donor fibroblast-vs-keratinocyte contrast added; prioritization restated as a follow-up choice')

# ---------------------------------------------------------------- Results V
sub_run(83, 2,
 " Non-lesional effects were smaller and less consistent. The selective, marked change in "
 "treated lesions links SEP to active plaque biology and its reversal during cytokine-directed "
 "resolution. It does not identify the molecular route through which treatment acts.",
 " Direct comparison of the same paired changes between arms confirmed a treatment-group "
 "difference. Relative to placebo, lesional SEP fell by a further -0.07018 with brodalumab 140 "
 "mg (95% CI -0.09372 to -0.04665; Welch P=2.94x10^-7; BH FDR=4.41x10^-7; Hedges g=-1.54), "
 "-0.07185 with brodalumab 210 mg (-0.09451 to -0.04918; P=1.31x10^-7; FDR=3.93x10^-7; "
 "g=-1.79) and -0.07128 with ustekinumab (-0.10379 to -0.03878; P=1.08x10^-4; FDR=1.08x10^-4; "
 "g=-1.47); Mann-Whitney tests gave the same result. In non-lesional skin only brodalumab 140 "
 "mg separated from placebo (-0.02233, -0.04039 to -0.00427; P=0.017; BH FDR=0.050), so the "
 "decline was restricted to treated plaques rather than reflecting time on study. This links "
 "SEP to active plaque biology and its reversal during cytokine-directed resolution, without "
 "identifying the molecular route through which treatment acts.",
 'Results V: formal between-arm comparison added; lesion-restriction stated')

# ---------------------------------------------------------------- Discussion
sub_run(87, 0,
 "Indeed, 65.2% of tested genes had opposite estimated effect signs, and reversal was the most "
 "common geometry among Core genes with a significant interaction.",
 "Indeed, 65.2% of tested genes had opposite estimated effect signs, exceeding the 50.0% "
 "expected under the exact permutation null for this design, and reversal became more frequent "
 "in the better-measured genes rather than in the noisiest ones.",
 'Discussion: reversal claim tied to the exact null')

sub_run(90, 0,
 "Keratinocytes had a similarly strong standardized effect, however, and no formal test showed "
 "that the fibroblast effect exceeded the keratinocyte effect. The findings therefore support "
 "multicellular plaque remodeling rather than a unique or dominant fibroblast origin.",
 "A formal within-donor comparison showed that keratinocytes carry the larger absolute shift, "
 "so the findings describe coordinated epidermal and dermal remodeling rather than a dominant "
 "fibroblast origin; fibroblasts were followed up because the dermal compartment yields a "
 "directly testable vascular-stromal hypothesis.",
 'Discussion: fibroblast/keratinocyte relation stated as a formal result')

sub_run(92, 0,
 "In the larger bulk longitudinal cohort, lesional SEP decreased by week 12 within the "
 "brodalumab and ustekinumab arms, whereas the placebo arm did not show a significant "
 "within-arm decrease.",
 "In the larger bulk longitudinal cohort, lesional SEP fell by week 12 in every active arm, "
 "and each active arm differed from placebo in direct between-arm comparison with large effect "
 "sizes and no comparable change in non-lesional skin.",
 'Discussion: within-arm-only statement replaced by the between-arm result')

sub_run(92, 2,
 " Because a formal between-arm comparison of change was not reported, the contrast between "
 "significant treated-arm results and a non-significant placebo result cannot by itself "
 "establish a treatment-group difference. The five-patient",
 " The five-patient",
 'Discussion: obsolete hedge removed')

sub_run(93, 0,
 "limiting precision and generalization to other stressors, inflammatory models, doses and time courses.",
 "limiting precision and generalization to other stressors, inflammatory models, doses and "
 "time courses; with twelve animals the complete permutation null contains 400 points, so no "
 "exact P below 0.0025 is attainable.",
 'Limitations: exact-null resolution floor stated')

# ---------------------------------------------------------------- Figure legends
sub_run(163, 0,
 "Figure 3. Donor-level analysis identifies fibroblasts as a cellular context for the "
 "lesion-associated pattern.",
 "Figure 3. Donor-level analysis places the lesion-associated program in both epidermal and "
 "dermal compartments.",
 'Figure 3 legend: title matched to the revised section heading')

sub_run(163, 0,
 "Fibroblasts are prioritized as a prominent context within coordinated stromal-epidermal remodeling.",
 "Both epidermal and dermal compartments carry the program; fibroblasts are carried forward for "
 "mechanistic follow-up.",
 'Figure 3 legend: closing sentence reframed')


sub_run(165, 0,
 "The larger bulk cohorts show marked lesion-specific decreases during brodalumab and "
 "ustekinumab treatment,",
 "The larger bulk cohorts show lesion-specific decreases during brodalumab and ustekinumab "
 "treatment that exceed placebo in the between-arm comparison reported in the text,",
 'Figure 5 legend: between-arm result reflected')

# ---------------------------------------------------------------- word count
body = [p.text for p in P[22:114]]
words = sum(len(t.split()) for t in body)
abs_words = sum(len(P[i].text.split()) for i in (15,16,17,18))
set_run(6, 1, f"Abstract {abs_words}; main text {words}", 'title-page word counts refreshed')

d.save(DST)
json.dump(log, open('revision_log.json','w'), indent=1, ensure_ascii=False)
print('edits applied:', len(log))
print('abstract words:', abs_words, '| main text words (Intro..AI declaration):', words)
