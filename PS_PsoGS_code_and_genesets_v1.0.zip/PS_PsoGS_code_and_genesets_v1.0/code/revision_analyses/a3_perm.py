import pandas as pd, numpy as np, itertools
from scipy import stats
U='/mnt/user-data/uploads/PS_PsoGS'
lc=pd.read_csv(U+'/results/stage02/factorial_edger/gse212126_TMM_logCPM.tsv',sep='\t')
des=pd.read_csv(U+'/results/stage02/gse212126_design_matrix.tsv',sep='\t')
print('genes:',lc.shape, 'design:',des.shape)
M=lc.set_index('gene_id')[des.srr.tolist()].values          # genes x 12, ordered as design
cond=des.condition.values; srr=des.srr.values
print(dict(zip(*np.unique(cond,return_counts=True))))
crs=des.CRS.values.astype(bool); imq=des.IMQ.values.astype(bool)

def stats_for(crs_lab):
    # S0 = CRS - Control within IMQ-negative ; SD = (CRS+IMQ) - IMQ within IMQ-positive
    a=~imq; b=imq
    S0=M[:,a&crs_lab].mean(1)-M[:,a&~crs_lab].mean(1)
    SD=M[:,b&crs_lab].mean(1)-M[:,b&~crs_lab].mean(1)
    disc=float(np.mean(np.sign(S0)*np.sign(SD)<0))
    r=float(np.corrcoef(S0,SD)[0,1]); rho=float(stats.spearmanr(S0,SD).statistic)
    return S0,SD,disc,r,rho

S0o,SDo,disc_o,r_o,rho_o=stats_for(crs)
print('\nOBSERVED (logCPM group-mean contrasts): discordance=%.4f  Pearson r=%.4f  Spearman=%.4f  (manuscript: 0.652 / -0.237 / -0.352)'%(disc_o,r_o,rho_o))

# exact enumeration: choose which 3 of the 6 IMQ- libraries are "CRS", same for IMQ+
idx_neg=np.where(~imq)[0]; idx_pos=np.where(imq)[0]
combs=list(itertools.combinations(range(6),3))
res=[]
for cn in combs:
    for cp in combs:
        lab=np.zeros(12,bool)
        lab[idx_neg[list(cn)]]=True; lab[idx_pos[list(cp)]]=True
        _,_,d,r,rho=stats_for(lab)
        res.append((d,r,rho,tuple(sorted(srr[lab]))==tuple(sorted(srr[crs]))))
res=pd.DataFrame(res,columns=['discordance','pearson','spearman','is_observed'])
print('\nEXACT permutation null over all %d CRS-label assignments (20 x 20):'%len(res))
for c in ['discordance','pearson','spearman']:
    v=res[c].values; o={'discordance':disc_o,'pearson':r_o,'spearman':rho_o}[c]
    if c=='discordance':
        p=(v>=o).mean(); tail='>='
    else:
        p=(v<=o).mean(); tail='<='
    print('  %-12s observed=%+.4f  null mean=%+.4f sd=%.4f  null 2.5-97.5%%=[%+.4f, %+.4f]  exact P(%s obs)=%.4f (%d/%d)'
          %(c,o,v.mean(),v.std(ddof=1),np.percentile(v,2.5),np.percentile(v,97.5),tail,p,int((v>=o).sum() if c=='discordance' else (v<=o).sum()),len(v)))
res.to_csv('mouse_exact_permutation_null.tsv',sep='\t',index=False)

# ---- normalization sensitivity on the observed labels --------------------------
# re-centre each library (median-of-genes) = median-ratio-like; and upper-quartile
def renorm(M,how):
    if how=='median': off=np.median(M,axis=0)
    elif how=='uq':   off=np.percentile(M,75,axis=0)
    elif how=='trim': off=stats.trim_mean(M,0.3,axis=0)
    return M-off
print('\nNormalization sensitivity (observed labels):')
for how in ['none','median','uq','trim']:
    Mx=M if how=='none' else renorm(M,how)
    a=~imq; b=imq
    S0=Mx[:,a&crs].mean(1)-Mx[:,a&~crs].mean(1); SD=Mx[:,b&crs].mean(1)-Mx[:,b&~crs].mean(1)
    print('  %-7s discordance=%.4f  Pearson r=%+.4f  Spearman=%+.4f'%(how,np.mean(np.sign(S0)*np.sign(SD)<0),np.corrcoef(S0,SD)[0,1],stats.spearmanr(S0,SD).statistic))

# ---- discordance by expression decile and by |I| -------------------------------
I=pd.read_csv(U+'/results/stage02/factorial_edger/gse212126_I_all_genes.tsv',sep='\t')
S0t=pd.read_csv(U+'/results/stage02/factorial_edger/gse212126_S0_all_genes.tsv',sep='\t')
SDt=pd.read_csv(U+'/results/stage02/factorial_edger/gse212126_SD_all_genes.tsv',sep='\t')
m=S0t[['gene_id','gene_name','logFC','logCPM','FDR']].rename(columns={'logFC':'S0','FDR':'S0_FDR'}).merge(
  SDt[['gene_id','logFC','FDR']].rename(columns={'logFC':'SD','FDR':'SD_FDR'}),on='gene_id').merge(
  I[['gene_id','logFC','FDR']].rename(columns={'logFC':'I','FDR':'I_FDR'}),on='gene_id')
m['disc']=np.sign(m.S0)*np.sign(m.SD)<0
print('\nedgeR table: n=%d  overall discordance=%.4f  r=%+.4f  (manuscript 0.652 / -0.237)'%(len(m),m.disc.mean(),np.corrcoef(m.S0,m.SD)[0,1]))
m['expr_decile']=pd.qcut(m.logCPM,10,labels=False)+1
print('\ndiscordance by expression decile:')
print(m.groupby('expr_decile').agg(n=('disc','size'),discordance=('disc','mean'),median_logCPM=('logCPM','median')).round(4).to_string())
m['absI_q']=pd.qcut(m.I.abs(),5,labels=False)+1
print('\ndiscordance by |interaction logFC| quintile:')
print(m.groupby('absI_q').agg(n=('disc','size'),discordance=('disc','mean'),median_absI=('I','median')).round(4).to_string())
sig=m[m.I_FDR<0.05]
print('\namong I FDR<0.05 (n=%d): discordance=%.4f'%(len(sig),sig.disc.mean()))
both=m[(m.S0_FDR<0.05)&(m.SD_FDR<0.05)]
print('among genes significant in BOTH S0 and SD (n=%d): discordance=%.4f'%(len(both),both.disc.mean()))
strong=m[(m.I_FDR<0.05)&(m.logCPM>np.log2(1))&(m.S0.abs()>0.5)&(m.SD.abs()>0.5)]
print('among I FDR<0.05 with |S0|>0.5 and |SD|>0.5 and logCPM>0 (n=%d): discordance=%.4f'%(len(strong),strong.disc.mean()))
m.to_csv('mouse_discordance_strata.tsv',sep='\t',index=False)
