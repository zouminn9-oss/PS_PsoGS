# -*- coding: utf-8 -*-
"""把中文审阅稿里内嵌的图1、图3换成重制版本，并按新长宽比修正显示尺寸。"""
import zipfile, re, shutil, io, json
from PIL import Image

SRC='PS_PsoGS_Manuscript_ZH_REV2.docx'; DST='PS_PsoGS_Manuscript_ZH_REV3.docx'
NEW={'media/image1.png':'main_figures_rev1/Figure_1_REV1.png',
     'media/image3.png':'main_figures_rev1/Figure_3_REV1.png'}
MAX_CX, MAX_CY = 5852160, 7315200          # 该文档使用的版心上限

zin=zipfile.ZipFile(SRC)
doc=zin.read('word/document.xml').decode('utf8')
rels=zin.read('word/_rels/document.xml.rels').decode('utf8')
rid2img=dict(re.findall(r'Id="(rId\d+)"[^>]*Target="(media/image\d+\.png)"',rels))
img2rid={v:k for k,v in rid2img.items()}

log=[]
for target,newpath in NEW.items():
    rid=img2rid[target]
    im=Image.open(newpath); aspect=im.height/im.width
    cx=MAX_CX; cy=round(cx*aspect)
    if cy>MAX_CY: cy=MAX_CY; cx=round(cy/aspect)
    # 定位包含该 r:embed 的 <w:drawing> 块
    i=doc.index('r:embed="%s"'%rid)
    start=doc.rindex('<w:drawing>',0,i); end=doc.index('</w:drawing>',i)+len('</w:drawing>')
    block=doc[start:end]
    old=re.search(r'<wp:extent cx="(\d+)" cy="(\d+)"/>',block)
    ocx,ocy=old.group(1),old.group(2)
    nb=re.sub(r'cx="%s" cy="%s"'%(ocx,ocy),'cx="%d" cy="%d"'%(cx,cy),block)
    doc=doc[:start]+nb+doc[end:]
    log.append({'image':target,'source':newpath,'pixels':list(im.size),
                'extent_old':[int(ocx),int(ocy)],'extent_new':[cx,cy]})
    print('%s <- %s  %dx%d px  extent %s,%s -> %d,%d'%(target,newpath,im.width,im.height,ocx,ocy,cx,cy))

with zipfile.ZipFile(DST,'w',zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        name=item.filename
        if name=='word/document.xml':
            zout.writestr(item, doc.encode('utf8'))
        elif name.startswith('word/') and name[5:] in NEW:
            zout.writestr(item, open(NEW[name[5:]],'rb').read())
        else:
            zout.writestr(item, zin.read(name))
zin.close()
json.dump(log,open('figure_swap_log.json','w'),indent=1,ensure_ascii=False)

# 校验
z=zipfile.ZipFile(DST)
for n in ['word/media/image%d.png'%i for i in range(1,6)]:
    im=Image.open(io.BytesIO(z.read(n))); print('verify',n,im.size)
d=z.read('word/document.xml').decode('utf8')
for m in re.finditer(r'<wp:extent cx="(\d+)" cy="(\d+)"/>.*?r:embed="(rId\d+)"',d,re.S):
    cx,cy,rid=m.groups(); print('verify extent',rid2img.get(rid),cx,cy,'aspect %.4f'%(int(cy)/int(cx)))
