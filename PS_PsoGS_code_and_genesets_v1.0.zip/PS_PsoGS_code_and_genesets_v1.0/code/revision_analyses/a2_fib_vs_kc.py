import pandas as pd, numpy as np
from scipy import stats
U='/mnt/user-data/uploads/PS_PsoGS'
d=pd.read_csv(U+'/results/stage04/donor_celltype_scores.tsv',sep='\t')
print(sorted(d.cell_type.unique())); print(d.tissue.unique())
e=d[d.eligible_min_cells==True]
w=e.pivot_table(index=['donor_id','cell_type'],columns='tissue',values='ucell_sep_directed')
w=w.dropna(subset=['PP','PN']); w['delta']=w['PP']-w['PN']
w=w.reset_index()
print(w.groupby('cell_type').agg(n=('delta','size'),mean=('delta','mean')).to_string())

def paired_stats(x):
    x=np.asarray(x,float); n=len(x); t,p=stats.ttest_1samp(x,0)
    ci=stats.t.interval(0.95,n-1,loc=x.mean(),scale=stats.sem(x))
    g=(x.mean()/x.std(ddof=1))*(1-3/(4*n-5))
    try: wp=stats.wilcoxon(x).pvalue
    except Exception: wp=np.nan
    return dict(n=n,mean=x.mean(),ci_lo=ci[0],ci_hi=ci[1],t_p=p,wilcoxon_p=wp,hedges_gz=g)

fib=w[w.cell_type=='Fibroblast'].set_index('donor_id')['delta']
kc =w[w.cell_type=='Keratinocyte'].set_index('donor_id')['delta']
print('\nFibroblast:',paired_stats(fib.values))
print('Keratinocyte:',paired_stats(kc.values))
common=fib.index.intersection(kc.index)
print('\ndonors with both lineages paired: %d  %s'%(len(common),list(common)))
diff=(fib[common]-kc[common]).values
r=paired_stats(diff)
print('FORMAL fibroblast-minus-keratinocyte paired contrast:',r)
print('sign of difference (fib>kc) in %d/%d donors'%((diff>0).sum(),len(diff)))
# also on rank-based score for robustness
w2=e.pivot_table(index=['donor_id','cell_type'],columns='tissue',values='rankmean_sep_directed').dropna(subset=['PP','PN'])
w2['delta']=w2['PP']-w2['PN']; w2=w2.reset_index()
f2=w2[w2.cell_type=='Fibroblast'].set_index('donor_id')['delta']; k2=w2[w2.cell_type=='Keratinocyte'].set_index('donor_id')['delta']
c2=f2.index.intersection(k2.index)
print('\nrankmean sensitivity:',paired_stats((f2[c2]-k2[c2]).values))
pd.DataFrame({'donor_id':common,'fibroblast_delta':fib[common].values,'keratinocyte_delta':kc[common].values,'fib_minus_kc':diff}).to_csv('fibroblast_vs_keratinocyte_paired.tsv',sep='\t',index=False)
