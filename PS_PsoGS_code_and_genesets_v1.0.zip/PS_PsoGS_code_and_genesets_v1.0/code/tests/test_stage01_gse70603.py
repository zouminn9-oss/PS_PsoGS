import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage01_validate_gse70603
import stage01_validate_gse70603_qc_figure


class Stage01GSE70603Test(unittest.TestCase):
    def test_analysis_outputs_and_candidate_rule(self):
        stage01_validate_gse70603.main()
        self.assertTrue((ROOT / "audits" / "gse70603_result_integrity_checks.tsv").exists())

    def test_qc_figure_exports_and_source_data(self):
        stage01_validate_gse70603_qc_figure.main()
        self.assertTrue((ROOT / "figures" / "qc" / "stage01_gse70603_qc.svg").exists())


if __name__ == "__main__":
    unittest.main()
