import contextlib
import io
import unittest
from scripts.stage03_validate_claim_matrix import main

class Stage03ClaimMatrixTest(unittest.TestCase):
    def test_claims(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            main()
        self.assertIn("claim-ceiling", output.getvalue())

