import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage03_validate_pso_ad_specificity


class Stage03PsoAdSpecificityTest(unittest.TestCase):
    def test_locked_direct_disease_difference(self):
        stage03_validate_pso_ad_specificity.main()


if __name__ == "__main__":
    unittest.main()
