import csv
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class Stage02FreezeTest(unittest.TestCase):
    def test_compute_freeze_and_software_manifest_are_synchronized(self):
        freeze = (ROOT / "config" / "stage02_compute_freeze.yaml").read_text(encoding="utf-8")
        raw_plan = (ROOT / "config" / "gse212126_raw_count_plan.yaml").read_text(encoding="utf-8")
        for token in (
            "Rsubread_subjunc",
            "Rsubread_featureCounts",
            "edgeR_quasi_likelihood",
            "GENCODE",
            "M25",
            "GRCm38.p6",
            "12",
            "pooling: false",
        ):
            self.assertIn(token, freeze)
        self.assertIn("Rsubread_subjunc_2.20.0", raw_plan)
        self.assertIn("edgeR_4.4.2_robust_quasi_likelihood", raw_plan)
        self.assertNotIn("edgeR_or_DESeq2_TO_BE_FROZEN", raw_plan)
        self.assertNotIn("primary_alignment: STAR", raw_plan)

        with (ROOT / "metadata" / "stage02_software_manifest.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            rows = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(rows), 8)
        observed = {(row["component"], row["version"]) for row in rows}
        self.assertIn(("prefetch", "3.4.1"), observed)
        self.assertIn(("vdb-validate", "3.4.1"), observed)
        self.assertIn(("fasterq-dump", "3.4.1"), observed)
        self.assertIn(("fastq-dump", "3.4.1"), observed)
        self.assertIn(("Rsubread", "2.20.0"), observed)
        self.assertIn(("edgeR", "4.4.2"), observed)
        self.assertIn(("locfit", "1.5.9.12"), observed)

    def test_future_count_and_model_scripts_preserve_frozen_boundaries(self):
        count_script = (ROOT / "scripts" / "stage02_count_and_resolve_strand.R").read_text(
            encoding="utf-8"
        )
        model_script = (ROOT / "scripts" / "stage02_factorial_edger.R").read_text(
            encoding="utf-8"
        )
        for token in (
            "countMultiMappingReads = FALSE",
            "primaryOnly = TRUE",
            "requireBothEndsMapped = TRUE",
            "all(ratio1 >= 0.80 & ratio2 <= 0.20)",
            "all(ratio2 >= 0.80 & ratio1 <= 0.20)",
        ):
            self.assertIn(token, count_script)
        for token in (
            "filterByExpr",
            "calcNormFactors(y, method = \"TMM\")",
            "glmQLFit",
            "robust = TRUE",
            "FDR < 0.05",
            "validation_expression_accessed = FALSE",
        ):
            self.assertIn(token, model_script)
        self.assertNotIn("GSE30999", model_script)
        self.assertNotIn("GSE121212", model_script)

    def test_frozen_gtf_registry_is_unique_and_audited(self):
        with (ROOT / "metadata" / "gencode_m25_mouse_gene_registry.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            rows = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(rows), 55487)
        self.assertEqual(len({row["gene_id"] for row in rows}), 55487)
        self.assertEqual(len({row["base_gene_id"] for row in rows}), 55487)
        self.assertTrue(all(row["gene_name"] for row in rows))
        self.assertTrue(all(row["gene_type"] for row in rows))

        with (ROOT / "audits" / "gencode_m25_gtf_summary.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            metrics = {row["metric"]: row for row in csv.DictReader(handle, delimiter="\t")}
        self.assertEqual(metrics["gtf_malformed_rows"]["value"], "0")
        self.assertEqual(metrics["exon_features"]["value"], "843712")
        self.assertTrue(all(row["status"] == "PASS" for row in metrics.values()))

    def test_first_full_library_fastq_audits_pass(self):
        run = "SRR21221234"
        with (ROOT / "audits" / "stage02_fastq" / f"{run}_full_fastq.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            rows = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(rows), 2)
        self.assertTrue(all(int(row["reads"]) == 20857369 for row in rows))
        self.assertEqual(sum(int(row["bases"]) for row in rows), 5850640334)
        for field in (
            "structure_status", "paired_id_status", "read_count_status", "base_total_status",
            "read_length_status", "quality_encoding_status", "n_fraction_status",
        ):
            self.assertTrue(all(row[field] == "PASS" for row in rows))
        with (ROOT / "audits" / "stage02_fastq" / f"{run}_compressed_fastq.tsv").open(
            encoding="utf-8-sig", newline=""
        ) as handle:
            compressed = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(compressed), 2)
        self.assertTrue(all(row["gzip_test_status"] == "PASS" for row in compressed))
        self.assertTrue(all(len(row["sha256"]) == 64 for row in compressed))
        self.assertTrue(all((ROOT / row["file"]).is_file() for row in compressed))

    def test_environment_and_reference_file_audits_pass(self):
        with (ROOT / "audits" / "stage02_environment_checks.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            checks = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(checks), 21)
        self.assertTrue(all(row["status"] == "PASS" for row in checks))

        with (ROOT / "audits" / "gencode_m25_reference_files.tsv").open(
            encoding="utf-8-sig", newline=""
        ) as handle:
            files = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(files), 4)
        self.assertTrue(all(row["status"] == "PASS" for row in files))
        sizes = {row["file"]: int(row["bytes"]) for row in files}
        self.assertEqual(
            sizes["references/genomes/GRCm38_gencode_M25/GRCm38.primary_assembly.genome.fa.gz"],
            773507376,
        )
        self.assertEqual(
            sizes["references/genomes/GRCm38_gencode_M25/gencode.vM25.primary_assembly.annotation.gtf.gz"],
            28556861,
        )

        with (ROOT / "audits" / "gse212126_rsubread_index_files.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            index_files = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(index_files), 7)
        self.assertEqual(sum(int(row["bytes"]) for row in index_files), 14994601711)
        self.assertTrue(all(row["status"] == "PASS" for row in index_files))
        self.assertTrue(all(len(row["sha256"]) == 64 for row in index_files))

        self.assertEqual(len({row["sha256"] for row in index_files}), 7)

    def test_first_full_library_alignment_and_count_pilot_are_audited(self):
        run = "SRR21221234"
        with (ROOT / "audits" / "stage02_alignment" / f"{run}_subjunc_metrics.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            rows = list(csv.DictReader(handle, delimiter="\t"))
        metrics = {row["metric"]: row for row in rows}
        self.assertEqual(metrics["total_fragments"]["value"], "20857369")
        self.assertEqual(metrics["mapped_fragments"]["value"], "20720824")
        self.assertEqual(metrics["mapped_plus_unmapped_equals_total"]["status"], "PASS")
        self.assertEqual(metrics["unique_plus_multimapping_equals_mapped"]["status"], "PASS")

        with (ROOT / "audits" / "stage02_alignment" / f"{run}_bam.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            bam_rows = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(bam_rows), 1)
        self.assertEqual(bam_rows[0]["bytes"], "1785546459")
        self.assertEqual(len(bam_rows[0]["sha256"]), 64)
        self.assertEqual(bam_rows[0]["status"], "PASS")

        with (ROOT / "audits" / "stage02_counts" / f"{run}_pilot_strand_assignment.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            pilot = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual([row["strand_specific"] for row in pilot], ["0", "1", "2"])
        self.assertTrue(all(row["status"] == "PASS_PILOT_ONLY" for row in pilot))
        self.assertTrue(all("NOT_STRAND_FREEZE" in row["inference_scope"] for row in pilot))
        self.assertGreater(float(pilot[2]["retention_vs_unstranded"]), 0.80)
        self.assertLess(float(pilot[1]["retention_vs_unstranded"]), 0.20)

        with (ROOT / "audits" / "gse212126_run_processing_state.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            ledger = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(ledger), 12)
        self.assertEqual(len({row["canonical_animal_id"] for row in ledger}), 12)
        completed = [row for row in ledger if row["alignment_bam"] == "PASS"]
        completed_runs = {row["srr"] for row in completed}
        self.assertTrue({run, "SRR21221228"}.issubset(completed_runs))
        self.assertGreaterEqual(len(completed), 2)
        self.assertTrue(all(row["sra_md5_vdb"] == "PASS" for row in completed))
        self.assertTrue(all(row["full_fastq"] == "PASS" for row in completed))
        self.assertTrue(all(
            row["biological_inference_allowed_at_processing"] == "NO_UNTIL_ALL_12_QC_PASS"
            for row in ledger
        ))

    def test_final_12_mouse_counts_and_factorial_model_pass_independent_audits(self):
        audit_dir = ROOT / "audits" / "stage02_counts"
        for filename, expected_count in (
            ("gse212126_count_integrity_checks.tsv", 15),
            ("gse212126_edger_integrity_checks.tsv", 27),
        ):
            with (audit_dir / filename).open(encoding="utf-8", newline="") as handle:
                rows = list(csv.DictReader(handle, delimiter="\t"))
            self.assertEqual(len(rows), expected_count)
            self.assertTrue(all(row["status"] == "PASS" for row in rows))

        with (ROOT / "results" / "stage02" / "counts" / "gse212126_strand_decision.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            strand = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(strand), 12)
        self.assertTrue(all(row["selected_strand"] == "2" for row in strand))
        self.assertTrue(all(row["selection_used_differential_expression"] == "FALSE" for row in strand))

        with (ROOT / "results" / "stage02" / "factorial_edger" /
              "gse212126_estimand_result_registry.tsv").open(encoding="utf-8", newline="") as handle:
            estimands = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual([row["estimand"] for row in estimands], ["S0", "SD", "I"])
        self.assertTrue(all(row["tested_genes"] == "18484" for row in estimands))
        self.assertTrue(all(row["threshold_changed_after_results"] == "FALSE" for row in estimands))
        self.assertTrue(all(row["validation_expression_accessed"] == "FALSE" for row in estimands))

    def test_second_full_library_fastq_and_alignment_audits_pass(self):
        run = "SRR21221228"
        with (ROOT / "audits" / "stage02_fastq" / f"{run}_full_fastq.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            fastq = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(fastq), 2)
        self.assertTrue(all(int(row["reads"]) == 22600497 for row in fastq))
        self.assertEqual(sum(int(row["bases"]) for row in fastq), 6339471862)
        self.assertTrue(all(row["structure_status"] == "PASS" for row in fastq))
        self.assertTrue(all(row["paired_id_status"] == "PASS" for row in fastq))

        with (ROOT / "audits" / "stage02_fastq" / f"{run}_compressed_fastq.tsv").open(
            encoding="utf-8-sig", newline=""
        ) as handle:
            compressed = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(compressed), 2)
        self.assertTrue(all(row["gzip_test_status"] == "PASS" for row in compressed))
        self.assertTrue(all(len(row["sha256"]) == 64 for row in compressed))

        with (ROOT / "audits" / "stage02_alignment" / f"{run}_subjunc_metrics.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            metrics = {row["metric"]: row for row in csv.DictReader(handle, delimiter="\t")}
        self.assertEqual(metrics["total_fragments"]["value"], "22600497")
        self.assertEqual(metrics["mapped_fragments"]["value"], "22459798")
        self.assertEqual(metrics["mapped_plus_unmapped_equals_total"]["status"], "PASS")
        self.assertEqual(metrics["unique_plus_multimapping_equals_mapped"]["status"], "PASS")

        with (ROOT / "audits" / "stage02_alignment" / f"{run}_bam.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            bam = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(bam), 1)
        self.assertEqual(bam[0]["bytes"], "1929285524")
        self.assertEqual(len(bam[0]["sha256"]), 64)
        self.assertEqual(bam[0]["status"], "PASS")


if __name__ == "__main__":
    unittest.main()
