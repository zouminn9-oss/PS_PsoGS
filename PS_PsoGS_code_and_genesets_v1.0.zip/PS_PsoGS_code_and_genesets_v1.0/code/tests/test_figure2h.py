import contextlib
import io
import unittest
from scripts.figures.validate_fig2h import main


class Figure2HTest(unittest.TestCase):
    def test_figure2h(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output): main()
        self.assertIn("Figure 2H", output.getvalue())


if __name__ == "__main__": unittest.main()
