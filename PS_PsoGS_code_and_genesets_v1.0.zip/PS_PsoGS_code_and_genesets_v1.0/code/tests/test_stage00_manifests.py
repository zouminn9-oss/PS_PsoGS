import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage00_validate_manifests


class Stage00ManifestTest(unittest.TestCase):
    def test_manifests_and_design_counts(self):
        stage00_validate_manifests.main()
        self.assertTrue((ROOT / "audits" / "stage00_integrity_checks.tsv").exists())


if __name__ == "__main__":
    unittest.main()
