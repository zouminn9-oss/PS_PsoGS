import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts" / "figures"))
import validate_fig2c


class Figure2CTest(unittest.TestCase):
    def test_meta_analysis_render_and_print_qa(self):
        validate_fig2c.main()


if __name__ == "__main__":
    unittest.main()
