import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts" / "figures"))
import validate_fig1f


class Figure1FTest(unittest.TestCase):
    def test_full_gene_effect_data_isolation_render_and_print(self):
        validate_fig1f.main()


if __name__ == "__main__":
    unittest.main()
