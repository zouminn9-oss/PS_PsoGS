import contextlib
import io
import unittest
from scripts.stage03_validate_comparator_gate import main


class Stage03ComparatorGateTest(unittest.TestCase):
    def test_locked_gate(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            main()
        self.assertIn("panel remains BLOCKED", output.getvalue())


if __name__ == "__main__":
    unittest.main()
