import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage00_audit_gse270712_labels
import stage00_validate_gse270712


class GSE270712AuditTest(unittest.TestCase):
    def test_label_audit_and_design_gate(self):
        stage00_audit_gse270712_labels.main()
        stage00_validate_gse270712.main()
        self.assertTrue((ROOT / "audits" / "gse270712_integrity_checks.tsv").exists())


if __name__ == "__main__":
    unittest.main()
