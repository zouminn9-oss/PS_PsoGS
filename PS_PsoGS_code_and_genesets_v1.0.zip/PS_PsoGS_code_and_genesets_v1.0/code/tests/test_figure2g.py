import contextlib
import io
import unittest
from scripts.figures.validate_fig2g import main


class Figure2GTest(unittest.TestCase):
    def test_figure2g(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            main()
        self.assertIn("Figure 2G", output.getvalue())


if __name__ == "__main__":
    unittest.main()
