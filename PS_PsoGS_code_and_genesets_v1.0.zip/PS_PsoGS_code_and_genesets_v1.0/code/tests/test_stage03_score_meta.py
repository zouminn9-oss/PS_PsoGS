import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage03_validate_score_meta


class Stage03ScoreMetaTest(unittest.TestCase):
    def test_frozen_two_cohort_meta_analysis(self):
        stage03_validate_score_meta.main()


if __name__ == "__main__":
    unittest.main()
