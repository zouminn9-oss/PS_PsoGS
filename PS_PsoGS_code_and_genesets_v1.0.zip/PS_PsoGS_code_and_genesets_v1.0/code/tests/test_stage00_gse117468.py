import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage00_audit_gse117468
import stage00_validate_gse117468


class GSE117468MetadataAuditTest(unittest.TestCase):
    def test_public_metadata_design_and_prediction_gate(self):
        stage00_audit_gse117468.main()
        stage00_validate_gse117468.main()
        self.assertTrue((ROOT / "metadata" / "gse117468_patient_registry.tsv").exists())


if __name__ == "__main__":
    unittest.main()
