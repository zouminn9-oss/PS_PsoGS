import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts" / "figures"))
import validate_fig2e


class Figure2ETest(unittest.TestCase):
    def test_patient_contrast_render_and_print_qa(self):
        validate_fig2e.main()


if __name__ == "__main__":
    unittest.main()
