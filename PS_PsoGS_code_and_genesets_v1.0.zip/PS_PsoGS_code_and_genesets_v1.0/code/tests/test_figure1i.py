import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts" / "figures"))
import validate_fig1i


class Figure1ITest(unittest.TestCase):
    def test_complete_evidence_ledger_render_and_print_qa(self):
        validate_fig1i.main()


if __name__ == "__main__":
    unittest.main()
