import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts" / "figures"))
import validate_fig1h


class Figure1HTest(unittest.TestCase):
    def test_core_direction_render_and_print_qa(self):
        validate_fig1h.main()


if __name__ == "__main__":
    unittest.main()
