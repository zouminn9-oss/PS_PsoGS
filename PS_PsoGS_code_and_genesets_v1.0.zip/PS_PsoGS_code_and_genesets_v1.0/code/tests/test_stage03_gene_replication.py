import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage03_validate_gene_replication


class Stage03GeneReplicationTest(unittest.TestCase):
    def test_complete_frozen_sep_gene_states(self):
        stage03_validate_gene_replication.main()


if __name__ == "__main__":
    unittest.main()
