import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage00_audit_gse173706_gse225475
import stage00_validate_gse173706_gse225475


class GSE173706GSE225475AuditTest(unittest.TestCase):
    def test_identity_and_spatial_design_gates(self):
        stage00_audit_gse173706_gse225475.main()
        stage00_validate_gse173706_gse225475.main()
        self.assertTrue((ROOT / "audits" / "gse173706_gse225475_integrity_checks.tsv").exists())


if __name__ == "__main__":
    unittest.main()
