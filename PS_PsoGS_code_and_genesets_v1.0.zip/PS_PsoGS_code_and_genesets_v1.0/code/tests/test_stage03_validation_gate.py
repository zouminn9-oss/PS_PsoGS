import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage03_audit_validation_gate


class Stage03ValidationGateTest(unittest.TestCase):
    def test_locked_cohorts_and_platform_coverage(self):
        stage03_audit_validation_gate.main()


if __name__ == "__main__":
    unittest.main()
