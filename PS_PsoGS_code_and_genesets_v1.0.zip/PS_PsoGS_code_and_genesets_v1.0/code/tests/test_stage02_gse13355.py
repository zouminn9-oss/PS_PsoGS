import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage02_validate_gse13355


class Stage02GSE13355Test(unittest.TestCase):
    def test_raw_pairing_rma_and_paired_model(self):
        stage02_validate_gse13355.main()


if __name__ == "__main__":
    unittest.main()
