import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts" / "figures"))
import validate_fig1e


class Figure1ETest(unittest.TestCase):
    def test_mouse_count_qc_data_isolation_render_and_print(self):
        validate_fig1e.main()


if __name__ == "__main__":
    unittest.main()
