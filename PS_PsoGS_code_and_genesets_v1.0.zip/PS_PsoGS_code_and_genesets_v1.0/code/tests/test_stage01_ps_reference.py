import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage01_freeze_ps_reference
import stage01_validate_ps_reference


class PSReferenceFreezeTest(unittest.TestCase):
    def test_layered_reference_and_ontology_freeze(self):
        stage01_freeze_ps_reference.main()
        stage01_validate_ps_reference.main()
        self.assertTrue((ROOT / "audits" / "ps_reference_integrity_checks.tsv").exists())


if __name__ == "__main__":
    unittest.main()
