import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage02_validate_cross_species_signatures


class Stage02CrossSpeciesSignaturesTest(unittest.TestCase):
    def test_orthology_and_f1_signatures(self):
        stage02_validate_cross_species_signatures.main()


if __name__ == "__main__":
    unittest.main()
