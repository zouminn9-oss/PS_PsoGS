import contextlib, io, unittest
from scripts.figures.validate_fig2i import main

class Figure2ITest(unittest.TestCase):
    def test_figure(self):
        x = io.StringIO()
        with contextlib.redirect_stdout(x): main()
        self.assertIn("Figure 2I", x.getvalue())
