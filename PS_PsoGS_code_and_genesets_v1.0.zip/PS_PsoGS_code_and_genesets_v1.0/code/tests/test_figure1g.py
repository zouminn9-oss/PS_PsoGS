import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts" / "figures"))
import validate_fig1g


class Figure1GTest(unittest.TestCase):
    def test_interaction_membership_render_and_print_qa(self):
        validate_fig1g.main()


if __name__ == "__main__":
    unittest.main()
