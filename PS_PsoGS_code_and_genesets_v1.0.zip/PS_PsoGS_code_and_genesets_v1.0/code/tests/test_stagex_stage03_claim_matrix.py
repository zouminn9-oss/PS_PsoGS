import contextlib, io, unittest
from scripts.stage03_validate_claim_matrix import main

class ClaimMatrixTest(unittest.TestCase):
    def test_claims(self):
        x = io.StringIO()
        with contextlib.redirect_stdout(x): main()
        self.assertIn("claim-ceiling", x.getvalue())

