import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage03_validate_bulk_validation


class Stage03BulkValidationTest(unittest.TestCase):
    def test_locked_matrix_models_and_scores(self):
        stage03_validate_bulk_validation.main()


if __name__ == "__main__":
    unittest.main()
