import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts" / "figures"))
import validate_fig1b_fig1d


class Figure1B1DTest(unittest.TestCase):
    def test_data_render_and_print_qa(self):
        validate_fig1b_fig1d.main()
        self.assertTrue((ROOT / "figures" / "panels" / "fig1b.svg").exists())
        self.assertTrue((ROOT / "figures" / "panels" / "fig1d.svg").exists())


if __name__ == "__main__":
    unittest.main()
