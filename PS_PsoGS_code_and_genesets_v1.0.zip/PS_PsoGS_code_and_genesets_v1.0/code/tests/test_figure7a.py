import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts" / "figures"))
import validate_fig7a


class Figure7ATest(unittest.TestCase):
    def test_cohort_roles_isolation_render_and_print_qa(self):
        validate_fig7a.main()
        self.assertTrue((ROOT / "figures" / "panels" / "fig7a.svg").exists())
        self.assertTrue((ROOT / "figures" / "previews" / "fig7a.png").exists())


if __name__ == "__main__":
    unittest.main()
