import contextlib
import io
import unittest
from scripts.figures.validate_fig2j import main

class Figure2JTest(unittest.TestCase):
    def test_figure(self):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            main()
        self.assertIn("Figure 2J", output.getvalue())
