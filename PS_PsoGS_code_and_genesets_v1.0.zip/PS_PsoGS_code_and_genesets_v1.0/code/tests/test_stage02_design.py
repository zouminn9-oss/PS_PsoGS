import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage02_validate_design


class Stage02DesignTest(unittest.TestCase):
    def test_independent_mouse_design_and_contrasts(self):
        stage02_validate_design.main()


if __name__ == "__main__":
    unittest.main()
