import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts" / "figures"))
import validate_fig2a


class Figure2ATest(unittest.TestCase):
    def test_cohort_coverage_isolation_and_render_qa(self):
        validate_fig2a.main()


if __name__ == "__main__":
    unittest.main()
