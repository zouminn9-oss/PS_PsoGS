import csv
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import stage02_validate_environment


class Stage02EnvironmentTest(unittest.TestCase):
    def test_frozen_tools_reference_and_disk_gate(self):
        stage02_validate_environment.main()
        with (ROOT / "audits" / "stage02_environment_checks.tsv").open(
            encoding="utf-8", newline=""
        ) as handle:
            rows = list(csv.DictReader(handle, delimiter="\t"))
        self.assertEqual(len(rows), 21)
        self.assertTrue(all(row["status"] == "PASS" for row in rows))


if __name__ == "__main__":
    unittest.main()
