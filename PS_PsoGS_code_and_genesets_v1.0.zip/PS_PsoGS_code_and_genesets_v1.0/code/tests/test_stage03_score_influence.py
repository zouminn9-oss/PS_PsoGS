import contextlib, io, unittest
from scripts.stage03_validate_score_influence import main

class ScoreInfluenceTest(unittest.TestCase):
    def test_influence(self):
        x = io.StringIO()
        with contextlib.redirect_stdout(x): main()
        self.assertIn("score-influence", x.getvalue())

