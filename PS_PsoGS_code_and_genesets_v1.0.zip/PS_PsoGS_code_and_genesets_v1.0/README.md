# PS_PsoGS — Analysis Code and Derived Gene Sets (v1.0)

Reproducibility package for the PS_PsoGS study (psoriasis × chronic stress, cross-species
reanalysis). It contains the complete analysis and figure code, the frozen parameter
configurations, and the derived gene sets with their provenance ledger.

Packaged: 2026-09-13. Signature freeze: `PASS_F1_2026-09-11`.
Raw and intermediate data matrices are not included (size); every script reads from the
public accessions listed below.

## Contents

```
genesets/
  derived/        PS_PsoGS_Core, PS_PsoGS_Interaction, SEP — TSV (full statistics) + GMT
  reference/      Fixed reference evidence layers (CTRA, GSE70603, endocrine GO snapshot)
  build_ledger/   Cross-species gene ledger and signature build statistics
code/
  scripts/        Stage 00–08 pipeline (188 files: analysis, validation, figure scripts)
  tests/          Per-stage and per-figure regression tests (39 files)
  revision_analyses/  Referee-response analyses and manuscript edit scripts (17 files)
config/           Frozen YAML parameters for every stage and figure panel (97 files)
docs/             SIGNATURE_SPEC.md, ANALYSIS_PLAN.md, METHOD_FEASIBILITY.md, project README
MANIFEST.sha256   SHA-256 of every file in this archive
```

## Derived gene sets

| Set | Members | Definition |
|---|---|---|
| `PS_PsoGS_Core_v1.0` | 4,976 | Reliable 1:1 mouse–human orthologs with BH-FDR < 0.05 for both `SD = (CRS+IMQ) − IMQ` and `H = PP − PN` (GSE13355 within-patient). Direction concordance is not required; 2,260 discordant members are retained and labelled. |
| `PS_PsoGS_Interaction_v1.0` | 4,085 | Core subset with BH-FDR < 0.05 for the formal interaction `I = SD − S0`, classified as augmentation (423), attenuation (141) or reversal (3,521). |
| `SEP_v1.0` | 2,716 | Core subset with `sign(SD) = sign(H)`; SEP-UP 1,399 / SEP-DOWN 1,317. The high-confidence SEP-Interaction subset (1,530) additionally requires FDR < 0.05 for `I`, `sign(I) = sign(SD) = sign(H)` and `|SD| > |S0|`. |

Each TSV carries per-gene `S0/SD/I/H` log fold-changes and FDRs, mouse and human identifiers,
the Ensembl Compara release-100 orthology assignment, and the direction/interaction class.
The GMT files expose the same sets plus their direction-stratified subsets
(13 gene-set records in total) for GSEA/ssGSEA-style tools.

Reference layers in `genesets/reference/` are evidence resources, not members of the derived
sets: the Kohrt 2016 CTRA indicator set (53 genes, HGNC 2026-09-10 snapshot, 53/53 unique
mapping), the GSE70603 time-locked laboratory-stress response (4,426 candidates; 3,871 with
1:1 HGNC mapping), and the frozen QuickGO exact direct annotations for GO:0071385,
GO:0071872 and GO:0071874.

## Scoring

Directed score = UP component − DOWN component, computed separately within each cohort
(bulk: pre-fixed normalisation; scRNA: UCell UP and DOWN computed separately, inference on
donor–cell-type pseudobulk). Directions are never flipped and members are never re-weighted
on validation performance. The primary directed score is reported only when member coverage
is ≥ 70%; below that only the UP/DOWN components, coverage and missing members are reported.

## Running the code

Scripts are stage-ordered and each stage pairs an analysis script with a validation script
(`stageNN_*` / `stageNN_validate_*`), with figure code under `code/scripts/figures/`
(`figX_analysis` → `figX_plot` → `validate_figX`). Parameters are read from `config/`, never
hard-coded in the scripts. `code/scripts/validate_all_stages_terminal.py` re-runs the full
validation chain.

Environments are pinned in `config/stage02_compute_freeze.yaml`,
`config/stage04_python_requirements.txt` and `config/stage02_orthology_requirements.txt`;
R analyses use limma / edgeR / Rsubread as recorded by the `*_record_software` scripts.
Paths in the scripts are relative to the project root, so place this package at the root of a
working copy that also holds `data/`, `metadata/` and `results/`.

## Primary data sources

GSE212126 (mouse CRS × IMQ factorial, 12 libraries, integer raw counts),
GSE13355 (180 raw CEL files, 58 within-patient PP/PN pairs), GSE70603 (human laboratory
stress time course), GSE30999 / GSE121212 / GSE117468 (validation), GSE228421 and related
single-cell and spatial accessions, plus Ensembl Compara release 100 orthology and the
HGNC 2026-09-10 snapshot.

See `docs/SIGNATURE_SPEC.md` for the full membership rules, freeze conditions and the
pre-specified negative results.
