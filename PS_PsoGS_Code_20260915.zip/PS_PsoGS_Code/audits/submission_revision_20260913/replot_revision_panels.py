import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, numpy as np, pandas as pd, json
from scipy import stats
plt.rcParams.update({'font.family':'Arial','pdf.fonttype':42,'svg.fonttype':'none','font.size':10,'axes.linewidth':1.4,
                     'xtick.major.width':1.4,'ytick.major.width':1.4,'savefig.facecolor':'white'})
BLUE='#4C9FD4'; ORANGE='#D9600B'; GREY='#9A9A9A'; DARK='#17202A'
U='/Volumes/brilliant/PS_PsoGS'; OUT='/Volumes/brilliant/PS_PsoGS/audits/submission_revision_20260913/panels/'
def finish(fig,name,top=0.845):
    fig.subplots_adjust(top=top)
    fig._suptitle.remove() if fig._suptitle else None
    fig.savefig(OUT+name.replace('.png','.pdf'),bbox_inches='tight',pad_inches=.12)
    fig.savefig(OUT+name.replace('.png','.svg'),bbox_inches='tight',pad_inches=.12)
    plt.close(fig)

# ---------------- Figure 3 panel C replacement --------------------------------
d=pd.read_csv(U+'/results/stage04/donor_celltype_scores.tsv',sep='\t')
e=d[d.eligible_min_cells==True]
w=e.pivot_table(index=['donor_id','cell_type'],columns='tissue',values='ucell_sep_directed').dropna(subset=['PP','PN']).reset_index()
fib=w[w.cell_type=='Fibroblast'].set_index('donor_id'); kc=w[w.cell_type=='Keratinocyte'].set_index('donor_id')
common=sorted(fib.index.intersection(kc.index))
diff=(fib.loc[common,'PP']-fib.loc[common,'PN'])-(kc.loc[common,'PP']-kc.loc[common,'PN'])
p=0.00186; ci=(-0.04948,-0.01704)

fig,ax=plt.subplots(1,2,figsize=(7.007,4.723),dpi=300,gridspec_kw={'width_ratios':[1.5,1],'wspace':0.42})
a=ax[0]
for name,sub,off,col in [('Fibroblast',fib,0,BLUE),('Keratinocyte',kc,3.1,ORANGE)]:
    for donor in sub.index:
        a.plot([off,off+1],[sub.loc[donor,'PN'],sub.loc[donor,'PP']],color=GREY,lw=1.1,zorder=1)
    a.scatter([off]*len(sub),sub['PN'],s=40,color=col,zorder=2,edgecolor='white',linewidth=.6)
    a.scatter([off+1]*len(sub),sub['PP'],s=40,color=col,zorder=2,edgecolor='white',linewidth=.6)
a.set_xticks([0,1,3.1,4.1]); a.set_xticklabels(['PN','PP','PN','PP'],fontsize=9.75)
a.set_ylabel('SEP UCell UP − DOWN',fontsize=10.12)
a.text(0.5,-0.135,'Fibroblast (n=%d)'%len(fib),ha='center',transform=a.get_xaxis_transform(),
       fontsize=9.0,color=BLUE,weight='bold')
a.text(3.6,-0.135,'Keratinocyte (n=%d)'%len(kc),ha='center',transform=a.get_xaxis_transform(),
       fontsize=9.0,color=ORANGE,weight='bold')
a.set_xlim(-0.6,4.7); a.spines[['top','right']].set_visible(False)

b=ax[1]
b.axhline(0,color=GREY,lw=1.2,ls='--')
jit=np.linspace(-0.14,0.14,len(diff))
b.scatter(jit,diff.values,s=46,color=DARK,zorder=3,edgecolor='white',linewidth=.6)
b.errorbar(0,diff.mean(),yerr=[[diff.mean()-ci[0]],[ci[1]-diff.mean()]],fmt='_',color=ORANGE,
           ms=30,mew=3.0,elinewidth=3.0,capsize=8,capthick=3.0,zorder=4)
b.set_xticks([]); b.set_xlim(-0.5,0.5)
b.set_ylabel('Fibroblast − keratinocyte\nwithin-donor SEP change',fontsize=9.38)
b.text(0.97,0.88,'larger in\nkeratinocytes in\n7 of 8 donors\nP = %.4f'%p,transform=b.transAxes,ha='right',va='top',fontsize=8.62,color=DARK,bbox=dict(facecolor='white',edgecolor='none',pad=2))
b.spines[['top','right']].set_visible(False)
fig.suptitle('Both compartments carry the program',fontsize=10.88,weight='bold',y=0.905,x=0.075,ha='left')
fig.tight_layout(rect=[0,0.02,1,0.855]); finish(fig,'fig3h_rev1.png',top=0.855)

# ---------------- Figure 1 new panels -----------------------------------------
null=pd.read_csv('/Volumes/brilliant/PS_PsoGS/results/referee_response/mouse_exact_permutation_null.tsv',sep='\t')
strat=pd.read_csv('/Volumes/brilliant/PS_PsoGS/results/referee_response/mouse_discordance_strata.tsv',sep='\t')
sel=pd.read_csv('/Volumes/brilliant/PS_PsoGS/results/referee_response/mouse_selection_matched_null.tsv',sep='\t')
obs=json.load(open('/Volumes/brilliant/PS_PsoGS/results/referee_response/mouse_selection_matched_observed.json'))
OD, OR = 0.6482, -0.3531

fig,ax=plt.subplots(1,2,figsize=(7.007,4.723),dpi=300)
for a,(vals,o,lab,xl) in zip(ax,[(null.discordance.values,OD,'sign discordance','Genes with opposite S0 and SD sign'),
                                 (null.spearman.values,OR,'Spearman rho','Spearman rho (S0 vs SD)')]):
    a.hist(vals,bins=26,color='#D6DBDF',edgecolor='#9AA0A6',linewidth=.8)
    a.axvline(o,color=ORANGE,lw=3)
    a.annotate('observed\n%.3f'%o,xy=(o,a.get_ylim()[1]*0.70),xytext=(0.5 if o<np.median(vals) else -0.5,0),
               textcoords='offset fontsize',ha='left' if o<np.median(vals) else 'right',
               color=ORANGE,fontsize=9.75,weight='bold')
    lo,hi=min(vals.min(),o),max(vals.max(),o); pad=(hi-lo)*0.08
    a.set_xlim(lo-pad,hi+pad)
    a.set_xlabel(xl,fontsize=9.38); a.set_ylabel('Label assignments',fontsize=9.75)
    a.spines[['top','right']].set_visible(False)
ax[0].text(0.03,0.97,'exact P = 0.015',transform=ax[0].transAxes,va='top',fontsize=9.38,color=DARK)
ax[1].text(0.55,0.97,'exact P = 0.020',transform=ax[1].transAxes,va='top',fontsize=9.38,color=DARK)
fig.suptitle('Exact null over all 400 CRS-label assignments',fontsize=10.88,weight='bold',y=0.905,x=0.075,ha='left')
fig.tight_layout(rect=[0,0,1,0.855]); finish(fig,'fig1d_null.png',top=0.855)

fig,ax=plt.subplots(1,2,figsize=(7.007,4.723),dpi=300)
g=strat.groupby('expr_decile').agg(disc=('disc','mean'),lo=('logCPM','median')).reset_index()
ax[0].plot(g.expr_decile,g.disc*100,'-o',color=ORANGE,lw=2.6,ms=8)
ax[0].axhline(50,color=GREY,ls='--',lw=1.6)
ax[0].text(1.1,50.9,'permutation null (50.0%)',fontsize=9.0,color='#5D6D7E')
ax[0].set_xlabel('Expression decile (low → high)',fontsize=9.75)
ax[0].set_ylabel('Genes with opposite sign (%)',fontsize=9.75)
ax[0].set_xticks(range(1,11)); ax[0].set_ylim(45,75); ax[0].spines[['top','right']].set_visible(False)
ax[0].text(0.03,0.97,'reversal rises with expression',transform=ax[0].transAxes,va='top',fontsize=9.38,color=DARK)
labs=['TMM\nlogCPM','median-\ncentered','upper\nquartile','trimmed\nmean']
vals=[-0.2724,-0.2724,-0.2724,-0.2724]; disc=[64.82,65.24,65.65,65.34]
ax[1].bar(range(4),disc,color=BLUE,edgecolor='#2E6F9E',linewidth=1.0,width=.62)
for i,dd in enumerate(disc):
    ax[1].text(i,dd+0.6,'%.1f%%'%dd,ha='center',fontsize=8.62,color=DARK)
ax[1].text(0.5,0.955,'Pearson r = −0.2724\nunder every offset',transform=ax[1].transAxes,ha='center',va='top',fontsize=8.62,color=DARK)
ax[1].axhline(50,color=GREY,ls='--',lw=1.6)
ax[1].set_xticks(range(4)); ax[1].set_xticklabels(labs,fontsize=8.25)
ax[1].set_ylabel('Genes with opposite sign (%)',fontsize=9.75); ax[1].set_ylim(45,76)
ax[1].text(0.03,0.055,'correlation unchanged by offsets',transform=ax[1].transAxes,fontsize=9.38,color=DARK)
ax[1].spines[['top','right']].set_visible(False)
fig.suptitle('Reversal concentrates in well-measured genes, not in noise',fontsize=10.88,weight='bold',y=0.905,x=0.075,ha='left')
fig.tight_layout(rect=[0,0,1,0.855]); finish(fig,'fig1e_strata.png',top=0.855)

fig,ax=plt.subplots(1,2,figsize=(7.007,4.723),dpi=300)
ax[0].hist(sel.n_sel.values,bins=30,color='#D6DBDF',edgecolor='#9AA0A6',linewidth=.8)
ax[0].axvline(obs['n_sel'],color=ORANGE,lw=3)
ax[0].annotate('observed\n%d genes'%obs['n_sel'],xy=(obs['n_sel'],ax[0].get_ylim()[1]*0.6),
               xytext=(-0.5,0),textcoords='offset fontsize',ha='right',color=ORANGE,fontsize=9.75,weight='bold')
ax[0].set_xlabel('Interaction-significant cross-species genes',fontsize=9.0)
ax[0].set_ylabel('Label assignments',fontsize=9.75)
ax[0].text(0.30,0.97,'exact P = 0.005',transform=ax[0].transAxes,va='top',fontsize=9.38,color=DARK)
ax[0].spines[['top','right']].set_visible(False)
v=sel.disc_sel.dropna().values*100
ax[1].hist(v,bins=26,color='#D6DBDF',edgecolor='#9AA0A6',linewidth=.8)
ax[1].axvline(obs['disc_sel']*100,color=ORANGE,lw=3)
ax[1].annotate('observed\n%.1f%%'%(obs['disc_sel']*100),xy=(obs['disc_sel']*100,ax[1].get_ylim()[1]*0.7),
               xytext=(-0.5,0),textcoords='offset fontsize',ha='right',color=ORANGE,fontsize=9.75,weight='bold')
ax[1].set_xlabel('Reversal among selected genes (%)',fontsize=9.0)
ax[1].set_ylabel('Label assignments',fontsize=9.75)
ax[1].text(0.03,0.97,'selection-matched null\nexact P = 0.10',transform=ax[1].transAxes,va='top',fontsize=9.38,color=DARK)
ax[1].spines[['top','right']].set_visible(False)
fig.suptitle('Selection-matched null for the interaction-gene set',fontsize=10.88,weight='bold',y=0.905,x=0.075,ha='left')
fig.tight_layout(rect=[0,0,1,0.855]); finish(fig,'fig1f_selnull.png',top=0.855)
