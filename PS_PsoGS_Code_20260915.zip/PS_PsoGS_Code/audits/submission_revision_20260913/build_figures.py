"""Recompose the current five submission figures from archived vector panels.
No statistical model or experimental-image generator is run.
Run with the bundled Python plus the isolated plotting dependencies.
"""
from pathlib import Path
import csv, json, re, io, hashlib, textwrap
from lxml import etree as E
from svglib.svglib import svg2rlg
from reportlab.graphics import renderPDF
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader, PdfWriter, Transformation

BASE=Path(__file__).resolve().parent; ROOT=BASE.parents[1]
PAN=BASE/'panels';OUT=BASE/'staging'/'figures';OUT.mkdir(exist_ok=True)
S='http://www.w3.org/2000/svg'; NS={'s':S}
FONT=Path('/System/Library/Fonts/Supplemental')
pdfmetrics.registerFont(TTFont('Arial',str(FONT/'Arial.ttf')))
pdfmetrics.registerFont(TTFont('Arial-Bold',str(FONT/'Arial Bold.ttf')))

# Replay only the archived plotting instructions; replace the repeated t-test
# with the already archived estimate and interval. All numerical data are retained.
src=(ROOT/'results/referee_response/d1_panels.py').read_text()
src=src.replace("U='/mnt/user-data/uploads/PS_PsoGS'; OUT='newpanels/'",f"U={str(ROOT)!r}; OUT={str(PAN)+'/'!r}")
src=src.replace("'font.family':'Liberation Sans'","'font.family':'Arial','pdf.fonttype':42,'svg.fonttype':'none'")
src=src.replace("t,p=stats.ttest_1samp(diff,0); ci=stats.t.interval(0.95,len(diff)-1,loc=diff.mean(),scale=stats.sem(diff))", "p=0.00186; ci=(-0.04948,-0.01704)")
for f in ['mouse_exact_permutation_null.tsv','mouse_discordance_strata.tsv','mouse_selection_matched_null.tsv','mouse_selection_matched_observed.json']:
    src=src.replace(repr(f),repr(str(ROOT/'results/referee_response'/f)))
src=src.replace("fig.savefig(OUT+name,dpi=300); plt.close(fig); print('wrote',name)","fig._suptitle.remove() if fig._suptitle else None\n    fig.savefig(OUT+name.replace('.png','.pdf'),bbox_inches='tight',pad_inches=.12)\n    fig.savefig(OUT+name.replace('.png','.svg'),bbox_inches='tight',pad_inches=.12)\n    plt.close(fig)")
src=src.replace("'TMM\\n(frozen)'","'TMM\\nlogCPM'").replace("median-\\ncentred","median-\\ncentered")
# Avoid an interpretation unsupported by the library-offset sensitivity test.
src=src.replace("'invariant to library scaling'","'correlation unchanged by offsets'")
src=src.replace("'Pearson r = −0.2724 under every offset'","'Pearson r = −0.2724\\nunder every offset'")
src=src.replace("b.text(0.04,0.88,","b.text(0.97,0.88,").replace("ha='left',va='top',fontsize=11.5,color=DARK)","ha='right',va='top',fontsize=11.5,color=DARK,bbox=dict(facecolor='white',edgecolor='none',pad=2))")
src=re.sub(r'fontsize=([0-9.]+)',lambda m:'fontsize='+str(round(float(m.group(1))*.75,2)),src)
src=src.replace("'font.size':15","'font.size':10")
(BASE/'replot_revision_panels.py').write_text(src)
exec(compile(src,str(BASE/'replot_revision_panels.py'),'exec'),{})

FIGS={1:['1F','1G','1K','fig1d_null','fig1e_strata','fig1f_selnull'],2:['1H','2B','2C','2D','2E'],3:['3A','3G','fig3h_rev1','3I','3K','3L'],4:['5B','5D','6A','6E','6F','6K','6L'],5:['7B','7D','7E','7G','7H']}
TITLES={
 1:['Stress effects in two inflammatory contexts','Interaction response classes','Representative gene effects','Exact permutation distributions','Expression and normalization sensitivity','Selection-matched permutation distributions'],
 2:['Cross-species Core and SEP gene sets','Patient-level paired SEP shifts','Standardized paired effects','Gene-level SEP replication','Psoriasis and atopic dermatitis'],
 3:['Skin single-cell atlas','Paired effects across major lineages','Fibroblast and keratinocyte comparison','Marker-supported fibroblast states','Independent single-cell follow-up','Composition and within-cell contributions'],
 4:['JAG2–NOTCH2 expression compatibility','Curated receptor-to-transcription-factor links','Histology and section quality control','Spatial SEP scores','Separate JAG2 and NOTCH2 expression maps','Section-level program summaries','Sensitivity to the single-cell reference'],
 5:['Patient trajectories during risankizumab','Remodeling within cell types','JAG2–NOTCH2 during treatment','Day 14 versus baseline non-lesional skin','Paired bulk treatment effects']}

manifest=list(csv.DictReader((ROOT/'panel_manifest.tsv').open(encoding='utf-8-sig'),delimiter='\t'))
byid={r['panel_id']:r for r in manifest}; provenance=[];inputs={}
def record(path):
    path=Path(path);inputs[str(path.relative_to(ROOT))]=hashlib.sha256(path.read_bytes()).hexdigest()
def convert(pid):
    if pid.startswith('fig'):return PAN/(pid+'.pdf')
    row=byid[pid];assert row['figure_ready']=='YES',pid
    for field in ['source_data','statistics_file','config_file','analysis_script','plot_script','vector_output','preview_output']:
        for name in row[field].split(';'):
            if name.strip():record(ROOT/name.strip())
    record(ROOT/'figures/captions'/('fig'+pid.lower()+'.md'))
    source=ROOT/row['vector_output']; tree=E.parse(str(source));r=tree.getroot()
    # Remove metadata and old panel-title text nodes rather than masking pixels.
    for e in r.xpath('.//s:metadata',namespaces=NS):e.getparent().remove(e)
    # Older Matplotlib panels store title lettering as outlined glyphs, with
    # the original text retained only as an XML comment.
    if pid in ['3A','3G','3I','3K','3L']:
        for comment in r.xpath('.//comment()'):
            if re.match(r'^'+pid[-1]+r'\s{2,}',(comment.text or '').strip()):
                group=comment.getparent();group.getparent().remove(group)
    for t in r.xpath('.//s:text',namespaces=NS):
        val=''.join(t.itertext())
        if re.match(r'^'+pid+r'\s',val) or (pid in ['3A','3G','3I','3K','3L'] and re.match(r'^'+pid+r'\s',val)):
            t.getparent().remove(t)
        else:
            for k,v in list(t.attrib.items()):t.set(k,v.replace('DejaVu Sans','Arial'))
    # R/Cairo outlines have no text nodes: remove the identified title glyph run.
    title_y={'1F':29.390625,'1G':22.32,'1K':37.44,'1H':22.32,'2D':40.914062}
    for g in r.xpath('.//s:g[s:use]',namespaces=NS):
        use=g.findall('s:use',NS)
        if not use:continue
        y=float(use[0].get('y','9999'))
        if pid in title_y and abs(y-title_y[pid])<.03:
            g.getparent().remove(g)
        # Raise the source cross-cohort heading clear of its bar.
        elif pid=='2D' and len(use)>10 and 220<y<250:
            # The exact heading has 19 glyphs; other numerical notes are retained.
            if len(use)==19:g.set('transform','translate(0,-5)')
    target=PAN/(pid+'.svg');tree.write(str(target),encoding='utf-8',xml_declaration=True)
    drawing=svg2rlg(str(target));pdf=PAN/(pid+'.pdf');renderPDF.drawToFile(drawing,str(pdf))
    return pdf

# Redraw the curated diagram from its exact source records to expose full citations.
def curated_diagram():
    import matplotlib.pyplot as plt
    from matplotlib.font_manager import fontManager
    fontManager.addfont(str(FONT/'Arial.ttf'));fontManager.addfont(str(FONT/'Arial Bold.ttf'))
    rows=list(csv.DictReader((ROOT/'figures/source_data/fig5d.tsv').open(),delimiter='\t'))
    fig,ax=plt.subplots(figsize=(8.0,4.0));ax.set_xlim(0,1);ax.set_ylim(0,1);ax.axis('off')
    for x,label,col in [(.10,'Endothelial\nJAG2','#CDE5F2'),(.34,'Fibroblast\nNOTCH2','#F9D8DC')]:
        ax.text(x,.52,label,ha='center',va='center',fontsize=11,bbox=dict(boxstyle='round,pad=.45',fc=col,ec='#555'))
    ax.annotate('',xy=(.25,.52),xytext=(.18,.52),arrowprops=dict(arrowstyle='->',lw=1.5))
    ax.text(.215,.67,'Curated\nligand–receptor',ha='center',fontsize=9)
    for i,row in enumerate(rows):
        y=.82-i*.25
        ax.annotate('',xy=(.56,y),xytext=(.43,.52),arrowprops=dict(arrowstyle='->',lw=1,color='#666'))
        ax.text(.60,y,row['TF_symbol'],ha='center',va='center',fontsize=11,bbox=dict(boxstyle='round,pad=.3',fc='#eee',ec='#777'))
        st=row['Source'].replace(';',';\n')
        ax.text(.70,y,st,va='center',fontsize=9)
    ax.text(0,.035,'Receptor-to-TF links are curated prior knowledge.\nActivation was not measured; no screened regulon passed BH correction.',fontsize=9)
    for ext in ['pdf','svg']:fig.savefig(PAN/('5D.'+ext),bbox_inches='tight',pad_inches=.14)
    plt.close(fig)

def factorial_panel():
    import pandas as pd,numpy as np
    import matplotlib.pyplot as plt
    d=pd.read_csv(ROOT/'figures/source_data/fig1f.tsv',sep='\t')
    fig=plt.figure(figsize=(8.0,5.4));gs=fig.add_gridspec(2,2,width_ratios=[1.7,1],wspace=.38,hspace=.55)
    ax=fig.add_subplot(gs[:,0]);cats=[('Neither','#BDC5CB','o'),('S0 only','#347FA0','o'),('SD only','#E39D58','^'),('Both FDR<0.05','#80639D','s')]
    for cat,color,marker in cats:
        sub=d[d.significance_category==cat]
        ax.scatter(sub.S0_logFC,sub.SD_logFC,s=3,color=color,marker=marker,alpha=.45,label=f'{cat}; n={len(sub):,}')
    ax.plot([-14,14],[-14,14],ls='--',lw=.8,c='#777');ax.axhline(0,c='#ddd',lw=.6);ax.axvline(0,c='#ddd',lw=.6)
    ax.set(xlim=(-14,14),ylim=(-13,13),xlabel=r'$S_0$ log$_2$ fold change',ylabel=r'$S_D$ log$_2$ fold change')
    ax.text(.98,.97,'Pearson r = −0.237',ha='right',va='top',transform=ax.transAxes,fontsize=9)
    ax.legend(loc='lower left',frameon=False,fontsize=7,markerscale=2)
    for i,(p,title,c) in enumerate([('S0','Stress without IMQ','#347FA0'),('SD','Stress with IMQ','#E39D58')]):
        a=fig.add_subplot(gs[i,1]);ok=d[p+'_FDR']<.05
        a.scatter(d[p+'_logFC'],d[p+'_neg_log10_FDR'],s=3,c=np.where(ok,c,'#DDE2E5'),alpha=.65)
        a.axhline(-np.log10(.05),ls='--',lw=.8,c='#777');a.set_title(title,fontsize=10,pad=9)
        a.set_xlabel(r'log$_2$ fold change',fontsize=9);a.set_ylabel(r'−log$_{10}$ FDR',fontsize=9,labelpad=7)
        a.text(.97,.93,f'FDR < 0.05: {sum(ok):,}',transform=a.transAxes,ha='right',fontsize=8)
    fig.subplots_adjust(left=.10,right=.97,bottom=.12,top=.94)
    for ext in ['pdf','svg']:fig.savefig(PAN/('1F.'+ext),bbox_inches='tight',pad_inches=.15)
    plt.close(fig)

for n,ids in FIGS.items():
    for pid in ids:convert(pid)
curated_diagram()
factorial_panel()

# Use separately placed complete panels. Large spatial matrices get full width.
# Dimensions are explicit points, not a raster-DPI-derived canvas.
layout={1:[['1F','1G'],['1K','fig1d_null'],['fig1e_strata','fig1f_selnull']],2:[['1H','2B'],['2C','2D'],['2E']],3:[['3A','3G'],['fig3h_rev1','3I'],['3K','3L']],4:[['5B','5D'],['6A'],['6E'],['6F'],['6K','6L']],5:[['7B','7D'],['7E','7G'],['7H']]}
config={'width_points':1080,'outer_margin_points':20,'column_gap_points':26,'row_gap_points':22,'panel_header_points':28,'layouts':layout}
(BASE/'figure_layout.json').write_text(json.dumps(config,indent=2))
for n,rows in layout.items():
    cells=[];y=20
    for row in rows:
        cw=(1080-40-26)/2 if len(row)==2 else 1040
        heights=[]
        for j,pid in enumerate(row):
            reader=PdfReader(PAN/(pid+'.pdf'));page=reader.pages[0];w=float(page.mediabox.width);h=float(page.mediabox.height)
            # A lone final panel is full width, with a sane upper scaling bound.
            scale=min(cw/w,1.8);height=h*scale;heights.append(height)
            cells.append((pid,page,20+j*(cw+26),y,scale,height,cw))
        y+=28+max(heights)+22
    height=y;bio=io.BytesIO();c=canvas.Canvas(bio,pagesize=(1080,height))
    c.setTitle('');c.setAuthor('');c.setCreator('');c.setSubject('')
    for pid,page,x,yy,scale,h,cw in cells:
        idx=FIGS[n].index(pid);title=TITLES[n][idx]
        c.setFont('Arial-Bold',17);c.drawString(x,height-yy-16,chr(65+idx))
        c.setFont('Arial-Bold',12);c.drawString(x+25,height-yy-15,title)
        provenance.append({'figure':n,'panel':chr(65+idx),'source_panel':pid,'source_data':byid[pid]['source_data'] if pid in byid else 'results/referee_response/','statistics_file':byid[pid]['statistics_file'] if pid in byid else 'results/referee_response/','config':'audits/submission_revision_20260913/figure_layout.json','plot_code':'audits/submission_revision_20260913/build_figures.py','vector_output':f'submission/figures/Figure {n}.pdf','preview':f'audits/submission_revision_20260913/figure_previews/figure_{n}.png','status':'RUNNING'})
    c.showPage();c.save();background=PdfReader(bio).pages[0]
    for pid,page,x,yy,scale,h,cw in cells:
        background.merge_transformed_page(page,Transformation().scale(scale).translate(x,height-yy-28-h))
    writer=PdfWriter();writer.add_page(background);writer.add_metadata({})
    writer.metadata=None
    with (OUT/f'Figure {n}.pdf').open('wb') as f:writer.write(f)
    print('Built',n,round(height),flush=True)
for p in (ROOT/'results/referee_response').glob('*'):
    if p.is_file() and not p.name.startswith('.') and p.suffix in ['.tsv','.json','.py','.md']:record(p)
(BASE/'figure_input_checksums.json').write_text(json.dumps(inputs,indent=2))
with (BASE/'figure_manifest.tsv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(provenance[0]),delimiter='\t');w.writeheader();w.writerows(provenance)
